package org.community.jwriter.basic;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public abstract class MainSpan extends SpanBranch{
    MainSpan(List<Span> children){
        super(children);
    }
}
