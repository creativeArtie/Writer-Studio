package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanSection extends LinedSpanLevel implements CatalogueHolder{

    LinedSpanSection(List<Span> children, LinedType spanType){
        super(children, spanType);
    }
    
    public Optional<EditionSpan> getEdition(){
        return firstClass(EditionSpan.class);
    }
    
    public EditionType getState(){
        Optional<EditionSpan> status = getEdition();
        return status.isPresent()? status.get().getType(): EditionType.NONE;
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
