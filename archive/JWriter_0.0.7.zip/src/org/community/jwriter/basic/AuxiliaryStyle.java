package org.community.jwriter.basic;

import com.google.common.base.CaseFormat;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public enum AuxiliaryStyle implements DetailStyle{
    ESCAPE(STYLE_OTHER), NO_ID(STYLE_OTHER),
    
    AGENDA(STYLE_INLINE), DIRECT_LINK(STYLE_INLINE),
    REF_LINK(STYLE_INLINE), 
    
    ID_ERROR(STYLE_SPECIFY), DATA_ERROR(STYLE_SPECIFY),
    
    MAIN_SECTION(STYLE_MAIN), MAIN_NOTE(STYLE_MAIN);
    
    private String prefix;
    
    private AuxiliaryStyle(String stylePrefix){
        prefix = stylePrefix;
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(prefix, name());
    }
        
}
