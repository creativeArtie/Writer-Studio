package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * A {@link span} for formatted text.
 */
public final class FormatSpanMain extends SpanBranch {
    
    FormatSpanMain(List<Span> children){
        super(children);
    }
    
    FormatSpanMain(SpanBranch parent){
        super(new ArrayList<>());
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){ }
    
    //TODO
    //protected DetailUpdater getUpdater(Span edit, String newText){ }

}
