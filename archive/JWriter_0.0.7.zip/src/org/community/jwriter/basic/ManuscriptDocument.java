package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import java.util.Iterator;

public class ManuscriptDocument extends Document{
    
    public ManuscriptDocument(String doc){
        super(doc, new MainParser());
    }
    
    public LinedSpan getLine(int line){
        Iterator<SpanBranch> it = iterator();
        SpanBranch section = it.next();
        int found = 0;
        while (section.size() + found <= line){
            found += section.size();
            if (it.hasNext()){
                section = it.next();
            }
        }
        return (LinedSpan) section.get(line - found);
    }
}
