package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanPointNote extends LinedSpanPoint {

    LinedSpanPointNote(List<Span> children, LinedType spanType){
        super(children, spanType);
    }
    
    @Override
    public DirectoryType getDirectoryType(){
        return getType() == LinedType.FOOTNOTE? DirectoryType.FOOTNOTE: 
            DirectoryType.ENDNOTE;
    }
    
    public Optional<FormatSpanMain> getFormatted(){
        return lastClass(FormatSpanMain.class);
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
