package org.community.jwriter.basic;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * A {@link ContentSpan} with format for {@link FormatSpanMain}. 
 */
public class FormatSpanContent extends FormatSpan implements BasicText{
    
    private List<String> enders;
    private SetupLeafStyle style;
    private boolean parse;
    
    FormatSpanContent(List<Span> children, boolean[] spanFormats, 
        List<String> spanEnders, SetupLeafStyle baseStyle, boolean canParse
    ){
        super(children, spanFormats);
        enders = spanEnders;
        style = baseStyle;
        parse = canParse;
    }
    
    @Override
    protected DetailUpdater getUpdater(Span edit, String newText){
        if(parse && search(newText, CHAR_ESCAPE, enders) == -1){
            return DetailUpdater.replace(new FormatParseContent(style, 
                getFormats(), parse, enders));
        }
        return DetailUpdater.unable();
    }
}
