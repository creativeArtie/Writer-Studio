package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;

public class LinedDataSpanFormatted extends LinedDataSpan<FormatSpanMain>{
    
    public LinedDataSpanFormatted cast(){
        return this;
    }
    
    @Override
    public FormatSpanMain getData(){
        return firstClass(FormatSpanMain.class).get();
    }
    
    protected LinedDataSpanFormatted(List<Span> children){
        super(children, LinedDataType.FORMATTED);
    }
}
