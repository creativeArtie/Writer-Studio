package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * SetupParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * SetupParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
abstract class FormatParseLink implements SetupParser {
    
    public static FormatParseLink[] getParsers(boolean[] spanFormats){
        boolean[] formats = Arrays.copyOf(spanFormats, spanFormats.length);
        return new FormatParseLink[]{
            new FormatParseLinkRef(formats),
            new FormatParseLinkDirect(formats)
        };
    }
    
    private String start;
    private boolean[] formats;
    
    FormatParseLink(String s, boolean[] spanFormats){
        start = s;
        formats = spanFormats;
    }
    
    protected boolean[] getFormats(){
        return formats;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, start)){
            return parseFinish(children, pointer);
        }
        return Optional.empty();
    }
    
    protected abstract Optional<SpanBranch> parseFinish(ArrayList<Span> children, 
        SetupPointer pointer);
    
    protected void parseRest(ArrayList<Span> children, 
            SetupPointer pointer){
        
        /// Create display text if any
        if (pointer.startsWith(children, LINK_TEXT)){
            /// Add the text itself
            new ContentParser(LINK_END).parse(children, pointer);
        }
        
        /// Add the ">"
        pointer.startsWith(children, LINK_END);
    }
}
