package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * Used by {@link DirectorySpan} to show main categories.
 */
public enum DirectoryType implements DetailStyle{
    FOOTNOTE(TYPE_FOOTNOTE), ENDNOTE(TYPE_ENDNOTE), 
    LINK(TYPE_LINK), NOTE(TYPE_NOTE);
    
    private String category;
    
    private DirectoryType(String categoryName){
        category = categoryName;
    }
    
    public String getCategory(){
        return category;
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_CATEGORY, name());
    }
}
