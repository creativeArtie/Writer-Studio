package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

enum LinedParseCite implements SetupParser {
    INSTANCE;
    
    public Optional<SpanBranch> parse(SetupPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        
        if (pointer.startsWith(children, LINED_CITE)){
            LinedDataField type = LinedDataField.getField(pointer, children);
            pointer.trimStartsWith(children, LINED_DATA);
            if (! type.parse(children, pointer).isPresent()){
                new ContentParser(SetupLeafStyle.DATA).parse(children, pointer);
            }
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanCite(children));
        }
        return Optional.empty();
    }
}
