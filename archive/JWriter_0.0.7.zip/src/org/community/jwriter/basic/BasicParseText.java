package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import static com.google.common.base.Preconditions.checkNotNull;
import com.google.common.collect.ImmutableList; /// List of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.main.ArgumentChecker;

/**
 * Creates a text span upto a certain character.
 */
abstract class BasicParseText implements SetupParser{
    
    /// Describes how the Span will end
    private final ImmutableList<String> setup;
    private final ImmutableList<String> reparse;
    private final SetupLeafStyle style;
    
    public BasicParseText(List<String> spanEnders){
        this(SetupLeafStyle.TEXT, spanEnders);
    }
    
    public BasicParseText(SetupLeafStyle spanStyle, List<String> spanEnders){
        /// null spanEnders amiguous with main constructor
        this(spanStyle, spanEnders.toArray(new String[0]));
    }
    
    public BasicParseText(String ... spanEnders){
        this(SetupLeafStyle.TEXT, spanEnders);
    }
    
    public BasicParseText(SetupLeafStyle spanStyle, String ... spanEnders){
        /// combining text span enders with escape ender and new line.
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        builder.add(LINED_END);
        for (String ender: spanEnders){
            if (! ender.equals(LINED_END) && ! ender.equals(CHAR_ESCAPE)){
                builder.add(ender);
            }
        }
        reparse = builder.build();
        builder.add(CHAR_ESCAPE);
        setup = builder.build();
        style = spanStyle;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer docPointer){
        ArgumentChecker.checkNotNull(docPointer, "docPointer");
        /// Setup
        ArrayList<Span> children = new ArrayList<>();
        boolean more = true;
        
        /// Extract the text
        do{
            docPointer.getTo(children, style, setup);
            /// no more escape span = no more text to deal with
            more = parseEscape(children, docPointer);
        } while (more);
        
        /// Create span if there are Span extracted
        if (! children.isEmpty()) {
            return Optional.of(buildSpan(children, reparse, style));
        }
        return Optional.empty();
    }
    
    protected abstract SpanBranch buildSpan(List<Span> spanChildren, 
        List<String> spanEnders, SetupLeafStyle leavesStyle);
    
    /// helper method for parse(SetupPointer)
    private boolean parseEscape(List<Span> spanChildren, 
        SetupPointer docPointer
    ){
        /// Setup 
        ArrayList<Span> children = new ArrayList<>();
        
        /// build Span if found
        if (docPointer.startsWith(children, CHAR_ESCAPE)){
            docPointer.nextChars(children, style, 1);
            spanChildren.add(new BasicTextEscape(children));
            return true;
        }
        return false;
    }
}
