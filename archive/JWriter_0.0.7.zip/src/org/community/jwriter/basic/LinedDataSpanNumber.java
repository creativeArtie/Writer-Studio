package org.community.jwriter.basic;

import java.util.ArrayList; /// Use to create DirectoryID
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method

import com.google.common.base.CharMatcher;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedDataSpanNumber extends LinedDataSpan<Integer>{
    
    public LinedDataSpanNumber cast(){
        return this;
    }
    
    @Override
    public Integer getData(){
        String raw = CharMatcher.whitespace().removeFrom(get(0).getRaw());
        try{
            return Integer.parseInt(raw);
        } catch (NumberFormatException ex){
            throw new IllegalStateException("No integer found.", ex);
        }
    }
    
    LinedDataSpanNumber(List<Span> children){
        super(children, LinedDataType.NUMBER);
    }
}
