package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

enum LinedParseLevel implements SetupParser {
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET;
    
    static SetupParser[] getSubList(){
        return new SetupParser[]{QUOTE, NUMBERED, BULLET};
    }
    
    private interface StartBuilder{
        public String getLevel(int level);
    }
    
    private static String repeat(String ch, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(ch);
        }
        return builder.toString();
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        for(int i = LEVEL_MAX; i >= 1; i--){
            if (pointer.startsWith(children, getLevelToken(this, i))){
                
                LinedType type = LinedType.values()[ordinal()];
                
                return ordinal() <= OUTLINE.ordinal()?
                    parseSec(children, pointer, type):
                    parseBasic(children, pointer, type);
            }
        }
        return Optional.empty();
    }
    
    private Optional<SpanBranch> parseSec(
            ArrayList<Span> children, SetupPointer pointer, 
            LinedType type){
        
        DirectoryParser id = new DirectoryParser(DirectoryType.LINK, 
            DIRECTORY_END, EDITION_BEGIN);
        if (pointer.trimStartsWith(children, DIRECTORY_BEGIN)){
            id.parse(children, pointer);
            pointer.startsWith(children, DIRECTORY_END);
        }
        
        new FormatParser(EDITION_BEGIN).parse(children, pointer);
        
        EditionParser.parseAll(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        LinedSpanSection ans = new LinedSpanSection(children, type);
        return Optional.of(ans);
    }
    
    private Optional<SpanBranch> parseBasic(
            ArrayList<Span> children, SetupPointer pointer, 
            LinedType type){
        new FormatParser().parse(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        return Optional.of(new LinedSpanLevel(children, type));
        
    }
}
