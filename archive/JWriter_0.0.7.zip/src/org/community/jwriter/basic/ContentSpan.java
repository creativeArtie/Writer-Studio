package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List; /// For initialization (children)
import java.util.Optional;

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()
import com.google.common.base.Joiner;      /// To remove spaces
import com.google.common.base.Splitter;    /// To remove spaces

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.main.ArgumentChecker;

/**
 * Created from {@link ContentParser}, super class of 
 * {@link ContentSpanContent}. Used for whenever text is needed.
 */
public class ContentSpan extends SpanBranch implements BasicText{
    private List<String> enders;
    private SetupLeafStyle style;
    
    ContentSpan (List<Span> spanChildren, List<String> spanEnders, 
        SetupLeafStyle baseStyle
    ){
        super(spanChildren);
        enders = ArgumentChecker.checkNotNull(spanEnders, "spanEnders");
        style = ArgumentChecker.checkNotNull(baseStyle, "baseStyle");
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){}
    
    @Override
    protected DetailUpdater getUpdater(Span editedSpan, String newText){
        ArgumentChecker.checkNotNull(newText, "newText");
        if(search(newText, CHAR_ESCAPE, enders) == -1){
            return DetailUpdater.replace(new ContentParser(style, enders));
        }
        return DetailUpdater.unable();
    }
    
    public String toString(){
        String ans ="";
        for (Span span: this){
            ans += span.toString() + "-";
        }
        return ans;
    }
}
