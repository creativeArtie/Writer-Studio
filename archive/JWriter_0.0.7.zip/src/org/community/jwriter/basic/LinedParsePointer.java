package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

enum LinedParsePointer implements SetupParser {
    FOOTNOTE(LINED_FOOTNOTE), ENDNOTE(LINED_ENDNOTE), HYPERLINK(LINED_LINK){
    
        @Override
        public Optional<SpanBranch> parse(SetupPointer pointer){
            ArrayList<Span> children = new ArrayList<>();
            if (pointer.startsWith(children, LINED_LINK)){
                DirectoryParser id = parseCommon(pointer, children, this);
                if (pointer.startsWith(children, LINED_DATA)){
                    new ContentParser(SetupLeafStyle.PATH).parse(children, pointer);
                }
                pointer.startsWith(children, LINED_END);
                LinedSpanPointLink ans = new LinedSpanPointLink(children);
                return Optional.of(ans);
            }
            return Optional.empty();
        }
        
    };
    
    private String starter;
    
    private LinedParsePointer(String start){
        starter = start;
    }
    
    private static DirectoryParser parseCommon(SetupPointer pointer,
        ArrayList<Span> children, LinedParsePointer parser
    ){
        DirectoryType idType = DirectoryType.values()[parser.ordinal()];
        DirectoryParser output = new DirectoryParser(idType, LINED_DATA);
        output.parse(children, pointer);
        return output;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.startsWith(children, starter)){
            
            DirectoryParser id = parseCommon(pointer, children, this);
            
            Optional<FormatSpanMain> text = Optional.empty();
            
            if (pointer.startsWith(children, LINED_DATA)){
                new FormatParser(LINED_DATA).parse(children, pointer);
            }
            pointer.startsWith(children, LINED_END);
            
            LinedType type = LinedType.values()
                [LinedType.FOOTNOTE.ordinal() + ordinal()];
            
            LinedSpanPointNote ans = new LinedSpanPointNote(children, type);
            return Optional.of(ans);
        }
        return Optional.empty();
    }
}
