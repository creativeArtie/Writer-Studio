package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;

public class LinedDataSpanText extends LinedDataSpan<ContentSpan>{
    
    public LinedDataSpanText cast(){
        return this;
    }
    
    @Override
    public ContentSpan getData(){
        return (ContentSpan)get(0);
    }
    
    LinedDataSpanText(List<Span> children){
        super(children, LinedDataType.TEXT);
    }
}
