package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * A {@link FormatSpanLink} with path located somewhere in the document.
 */
public final class FormatSpanLinkRef extends FormatSpanLink 
        implements CatalogueHolder{
    
    FormatSpanLinkRef(List<Span> children, boolean[] formats){
        super(children, formats);
    }
    
    public String getPath(){
        Optional<Span> span = getTarget();
        if (span.isPresent()){
            return ((LinedSpanPointLink)span.get()).getPath();
        }
        return "";
    }
    
    public String getText(){
        Optional<ContentSpan> text = firstClass(ContentSpan.class);
        if (text.isPresent()){
            return text.get().getText();
        }
        return getPath();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.REF_LINK);
        if (! hasID()) list.add(AuxiliaryStyle.NO_ID);
        super.addInfo(list);
    }
    
    @Override
    public boolean isId(){
        return false;
    }
}
