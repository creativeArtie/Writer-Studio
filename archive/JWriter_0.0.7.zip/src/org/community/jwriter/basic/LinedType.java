package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.base.CaseFormat;
import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.main.ArgumentChecker;
import org.community.jwriter.markup.DetailStyle;
import org.community.jwriter.markup.SetupParser;

public enum LinedType implements DetailStyle{
    
    HEADING(LinedParseLevel.HEADING), OUTLINE(LinedParseLevel.OUTLINE), 
    QUOTE(LinedParseLevel.QUOTE), NUMBERED(LinedParseLevel.NUMBERED), 
    BULLET(LinedParseLevel.BULLET), 
    
    FOOTNOTE(LinedParsePointer.FOOTNOTE, LINED_FOOTNOTE), 
    ENDNOTE(LinedParsePointer.ENDNOTE, LINED_ENDNOTE), 
    HYPERLINK(LinedParsePointer.HYPERLINK, LINED_LINK), 
    NOTE(LinedParseRest.NOTE, LINED_NOTE), 
    
    AGENDA(LinedParseRest.AGENDA, LINED_AGENDA), 
    BREAK(LinedParseRest.BREAK, LINED_BREAK), 
    SOURCE(LinedParseCite.INSTANCE, LINED_CITE), 
    PARAGRAPH(LinedParseRest.PARAGRAPH);
    
    private SetupParser parser;
    private Optional<String> starter;
    
    private LinedType(SetupParser baseParser){
        parser = baseParser;
        starter = Optional.empty();
    }
    
    private LinedType(SetupParser baseParser, String starterToken){
        parser = baseParser;
        starter = Optional.of(starterToken);
    }
    
    SetupParser getParser(){
        return parser;
    }
    
    static LinedType findType(String rawLine){
        ArgumentChecker.checkNotNull(rawLine, "rawLine");
        for (LinedType type: values()){
            if (type == PARAGRAPH){
                return type;
            }
            if (type.starter.isPresent() && 
                rawLine.startsWith(type.starter.get())
            ){
                return type;
            } 
            if (type.parser instanceof LinedParseLevel){
                LinedParseLevel level = (LinedParseLevel)type.parser;
                for (int i = LEVEL_MAX; i > 0; i--){
                    if(rawLine.startsWith(getLevelToken(level, i))){
                        return type;
                    }
                }
            }
        }
        assert false;
        return null;
    }
    
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_LINED, name());
    }
}
