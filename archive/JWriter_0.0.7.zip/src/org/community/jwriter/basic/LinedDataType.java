package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.base.CaseFormat;

import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.markup.*;

public enum LinedDataType implements DetailStyle{
    FORMATTED, NUMBER, TEXT;
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_DATA, name());
    }
}
