package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanParagraph extends LinedSpan {

    LinedSpanParagraph(List<Span> children){
        super(children, LinedType.PARAGRAPH);
    }
    
    public Optional<FormatSpanMain> getFormatted(){
        return firstClass(FormatSpanMain.class);
    }
    
    @Override
    protected DetailUpdater getUpdater(Span edit, String newText){
        return DetailUpdater.unable();
    } 
}
