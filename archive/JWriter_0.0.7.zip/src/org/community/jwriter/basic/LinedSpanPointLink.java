package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanPointLink extends LinedSpanPoint {

    LinedSpanPointLink(List<Span> children){
        super(children, LinedType.HYPERLINK);
    }
    
    @Override
    public DirectoryType getDirectoryType(){
        return DirectoryType.LINK;
    }
    
    public String getPath(){
        Optional<ContentSpan> span = lastClass(ContentSpan.class);
        return span.isPresent()? span.get().getText() : "";
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
