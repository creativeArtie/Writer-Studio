package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List; /// For initialization (children)
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import org.community.jwriter.main.ArgumentChecker;
import static org.community.jwriter.basic.AuxiliaryString.*;
import com.google.common.base.Preconditions;

/**
 * Created from {@link ContentParser}. Used only in {@link ContentSpan}
 */
public class BasicTextEscape extends SpanBranch{
    
    BasicTextEscape(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public String getEscape(){
        return size() == 2? get(1).getRaw(): "";
    }
    
    @Override
    protected void addInfo(List<DetailStyle> detailStyles){
        ArgumentChecker.checkNotNull(detailStyles, "detailStyles");
        detailStyles.add(AuxiliaryStyle.ESCAPE);
    }
}
