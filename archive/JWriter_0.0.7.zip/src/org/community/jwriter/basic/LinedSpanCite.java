package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanCite extends LinedSpan {
    
    public LinedSpanCite(List<Span> children){
        super(children, LinedType.SOURCE);
    }
    
    public LinedDataField getField(){
        Optional<SpanLeaf> span = firstLeaf(SetupLeafStyle.FIELD);
        if (span.isPresent()) {
            return LinedDataField.getField(span.get().getRaw());
        }
        return LinedDataField.ERROR;
    }
    
    public Optional<LinedDataSpan> getData(){
        return lastClass(LinedDataSpan.class);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        super.addInfo(list);
        list.add(getField());
        if (! getData().isPresent()) list.add(AuxiliaryStyle.DATA_ERROR);
    }
}
