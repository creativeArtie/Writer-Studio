package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * A {@linkplain FormatSpanCurly} for to do text. It will warn user when 
 * exporting while there are these {@link Span spans} still exists.
 */
public final class FormatSpanAgenda extends SpanBranch {
        
    FormatSpanAgenda(List<Span> children){
        super(children);
    }
    
    public Optional<ContentSpan> getAgenda(){
        return lastClass(ContentSpan.class);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.AGENDA);
    }
}
