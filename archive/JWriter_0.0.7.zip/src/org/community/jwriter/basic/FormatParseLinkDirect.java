package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * SetupParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * SetupParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
class FormatParseLinkDirect extends FormatParseLink {
    
    FormatParseLinkDirect(boolean[] formats){
        super(LINK_BEGIN, formats);
    }
    
    @Override
    public Optional<SpanBranch> parseFinish(ArrayList<Span> children, 
        SetupPointer pointer
    ){
        new ContentParser(SetupLeafStyle.PATH, LINK_TEXT, LINK_END)
            .parse(children, pointer);
        
        /// Complete the last steps 
        parseRest(children, pointer);
        return Optional.of(new FormatSpanLinkDirect(children, getFormats()));
    }
}
