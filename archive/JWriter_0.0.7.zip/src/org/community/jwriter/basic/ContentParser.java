package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders
import org.community.jwriter.main.ArgumentChecker;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * Creates a text span upto a certain character.
 */
class ContentParser extends BasicParseText{
    
    public ContentParser(List<String> spanEnders){
        super(SetupLeafStyle.TEXT, spanEnders);
    }
    
    public ContentParser(SetupLeafStyle spanStyle, List<String> spanEnders){
        super(spanStyle, spanEnders);
    }
    
    public ContentParser(SetupLeafStyle spanStyle, String ... spanEnders){
        super(spanStyle, spanEnders);
    }
    
    public ContentParser(String ... spanEnders){
        super(SetupLeafStyle.TEXT, spanEnders);
    }
    
    @Override
    protected ContentSpan buildSpan(List<Span> spanChildren, 
        List<String> spanEnders, SetupLeafStyle baseStyle
    ){
        ArgumentChecker.checkNotNull(spanChildren, "spanChildren");
        ArgumentChecker.checkNotNull(spanEnders, "spanEnders");
        ArgumentChecker.checkNotNull(baseStyle, "baseStyle");
        return new ContentSpan(spanChildren, spanEnders, baseStyle);
    }
    
}
