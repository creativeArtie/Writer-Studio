package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import java.util.ArrayList;

import com.google.common.base.CharMatcher;

import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.markup.*;

public enum LinedDataParser implements SetupParser{
    FORMATTED(pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        if (new FormatParser(SetupLeafStyle.DATA).parse(children, pointer)
            .isPresent()){
            return Optional.of(new LinedDataSpanFormatted(children));
        }
        return Optional.empty();
    }), NUMBER(pointer -> {
        pointer.mark();
        ArrayList<Span> children = new ArrayList<>();
        CharMatcher data = CharMatcher.whitespace()
            .and(CharMatcher.isNot(LINED_END.charAt(0)))
            .or(CharMatcher.javaDigit());
        if (pointer.matches(children, data)){
            if (CharMatcher.javaDigit().countIn(children.get(0).getRaw()) > 0){
                if (! (new ContentParser().parse(children, pointer)
                    .isPresent())
                ){
                    pointer.getTo(children, LINED_END);
                    return Optional.of(new LinedDataSpanNumber(children));
                }
            }
        }
        pointer.rollBack(children);
        return Optional.empty();
    }), TEXT(pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        if (new ContentParser(SetupLeafStyle.DATA).parse(children, pointer)
            .isPresent()){
            return Optional.of(new LinedDataSpanText(children));
        }
        return Optional.empty();
    }), ERROR (pointer -> {return Optional.empty();});
    
    private SetupParser parser;
    
    private LinedDataParser(SetupParser p){
        parser = p;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        return parser.parse(pointer);
    }
}
