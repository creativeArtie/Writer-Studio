package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public abstract class LinedSpanPoint extends LinedSpan implements CatalogueHolder{

    LinedSpanPoint(List<Span> children, LinedType spanType){
        super(children, spanType);
    }
    
    public abstract DirectoryType getDirectoryType();
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        super.addInfo(list);
        if (! hasID()) list.add(AuxiliaryStyle.NO_ID);
    }
}
