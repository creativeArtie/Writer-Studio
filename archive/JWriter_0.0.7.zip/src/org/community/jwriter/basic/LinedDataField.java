package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.base.CaseFormat;

import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.markup.*;

public enum LinedDataField implements DetailStyle{
    /* //TODO add in future version (for automatic LinedDataField Style)
    AUTHOR, EDITOR, TRANSLATOR, ARTICLE, TITLE, EDITION, PUBLISH_HOUSE, 
    PUBLISH_YEAR, MEDIA, ACCESS_LOCATION, ACCESS_DATE, */
    PAGES(LinedDataParser.NUMBER),
    
    SOURCE(LinedDataParser.FORMATTED), IN_TEXT(LinedDataParser.TEXT), 
    FOOTNOTE(LinedDataParser.TEXT), 
    
    ERROR(LinedDataParser.ERROR);
    
    private SetupParser parser;
    
    private LinedDataField(SetupParser p){
        parser = p;
    }
    
    String getCode(){
        return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, name());
    }
    
    static LinedDataField getField(SetupPointer pointer, 
        ArrayList<Span> children
    ){
        for (LinedDataField type: values()){
            if (pointer.trimStartsWith(children, SetupLeafStyle.FIELD, 
                type.getCode())
            ){
                return type;
            }
        }
        new ContentParser(SetupLeafStyle.FIELD, LINED_DATA)
            .parse(children, pointer);
        return LinedDataField.ERROR;
    }
    
    static LinedDataField getField(String raw){
        String trimed = raw.trim();
        String name = CaseFormat.LOWER_HYPHEN
            .to(CaseFormat.UPPER_UNDERSCORE, trimed);
        try {
            return valueOf(name);
        } catch (IllegalArgumentException ex){
            return LinedDataField.ERROR;
        }
    }
    
    Optional<SpanBranch> parse(List<Span> children, 
            SetupPointer pointer){
        return parser.parse(children, pointer);
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_FIELD, name());
    }
}
