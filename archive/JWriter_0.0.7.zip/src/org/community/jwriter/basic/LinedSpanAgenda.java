package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanAgenda extends LinedSpan {

    LinedSpanAgenda(List<Span> children){
        super(children, LinedType.AGENDA);
    }
    
    public Optional<ContentSpan> getReason(){
        return lastClass(ContentSpan.class);
    }
}
