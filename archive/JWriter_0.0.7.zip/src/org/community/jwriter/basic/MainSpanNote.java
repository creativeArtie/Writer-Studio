package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ArrayListMultimap;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class MainSpanNote extends MainSpan implements CatalogueHolder{
    
    MainSpanNote(List<Span> children){
        super(children);
    }
    
    @Override
    public Optional<CatalogueIdentity> getId(){
        Optional<LinedSpanNote> child = firstClass(LinedSpanNote.class);
        if (child.isPresent()){
            return child.get().getId();
        }
        return Optional.empty();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.MAIN_NOTE);
        if (! hasID()) list.add(AuxiliaryStyle.NO_ID);
    }
    
    public ImmutableListMultimap<LinedDataField, LinedDataSpan<?>> getSources(){
        ImmutableListMultimap.Builder<LinedDataField, LinedDataSpan<?>> data = 
            ImmutableListMultimap.builder();
        for (Span child: this){
            if (child instanceof LinedSpanCite){
                LinedSpanCite cite = (LinedSpanCite) child;
                if (cite.getData().isPresent()){
                    data.put(cite.getField(), cite.getData().get());
                }
            }
        }
        return data.build();
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
