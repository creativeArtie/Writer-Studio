package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

class MainParser implements SetupParser {
    private static final SetupParser[] parsers = SetupParser.combine(
        SetupParser.combine(LinedParseLevel.values(), LinedParsePointer.values()),
        SetupParser.combine(LinedParseCite.values(), LinedParseRest.values())
    );
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        LinedSpan line = null;
        for (SetupParser parser: parsers){
            Optional<?> found = parser.parse(children, pointer);
            if(found.isPresent()){
                line = (LinedSpan) found.get();
                break;
            }
        }
        switch (line.getType()){
            case NOTE:
            case SOURCE:
                return parseNote(children, pointer);
            default:
                return parseSection(children, pointer);
        }
    }
    
    private Optional<SpanBranch> parseSection(ArrayList<Span> children, 
            SetupPointer pointer){
        while (true){
            pointer.mark();
            Optional<? extends Span> span = Optional.empty();
            for (SetupParser parser : parsers){
                span = parser.parse(pointer);
                if (span.isPresent()){
                    break;
                }
            }
            if (span.isPresent()){
                LinedSpan line = (LinedSpan) span.get();
                switch(line.getType()){
                    case HEADING:
                    case OUTLINE:
                        pointer.rollBack(line);
                        return buildSection(children);
                    case NOTE:
                    case SOURCE:
                        pointer.rollBack(line);
                        return buildSection(children);
                    default:
                        children.add(line);
                }
            } else {
                return buildSection(children);
            }
        }
    }
    
    private Optional<SpanBranch> buildSection(List<Span> children){
        return Optional.of(new MainSpanSection(children));
    }
    
    private Optional<SpanBranch> parseNote(ArrayList<Span> children, 
            SetupPointer pointer){
        ArrayList<LinedSpanCite> sources = new ArrayList<>();
        while (true){
            pointer.mark();
            if (! LinedParseCite.INSTANCE.parse(children, pointer).isPresent()){
                Optional<SpanBranch> span = LinedParseRest.NOTE.parse(pointer);
                if (! span.isPresent()){
                    return buildNote(pointer, children); 
                } else {
                    LinedSpanNote found = (LinedSpanNote)span.get();
                    if (found.getId().isPresent()){
                        pointer.rollBack(found);
                        return buildNote(pointer, children);
                    }
                }
                children.add(span.get());
            }
            
        }
    }
    
    private Optional<SpanBranch> buildNote(SetupPointer pointer, 
            List<Span> children){
        MainSpanNote ans = new MainSpanNote(children);
        Optional<CatalogueIdentity> idFound = ans.getId();
        return Optional.of(ans);
    }
}
