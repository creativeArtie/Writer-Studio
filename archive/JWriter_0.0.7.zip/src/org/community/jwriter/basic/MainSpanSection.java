package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class MainSpanSection extends MainSpan {
    
    MainSpanSection (List<Span> children){
        super(children);
    }
    
    public Optional<MainSpanSection> getLast(){
        int idx = getDocument().indexOf(this);
        int cur = idx;
        if (idx == 0) {
            return Optional.empty();
        }
        SpanBranch siblings = getDocument().get(idx - 1);
        while (! (siblings instanceof MainSpanSection)){
            idx--;
            if (idx < 0) {
                return Optional.empty();
            }
            siblings = getDocument().get(idx);
        }
        if (cur == idx){
            return Optional.empty();
        }
        return Optional.of((MainSpanSection)siblings);
    }
    
    public Optional<LinedSpanLevel> getHeading(){
        Span first = get(0);
        if (first instanceof LinedSpanSection){
            LinedSpanSection level = (LinedSpanSection) first;
            if (level.getType() == LinedType.HEADING){
                return Optional.of(level);
            }
        }
        int idx = getDocument().indexOf(this);
        while (idx != 0){
            idx--;
            SpanBranch siblings = getDocument().get(idx);
            if (siblings instanceof MainSpanSection){
                return ((MainSpanSection)siblings).getHeading();
            }
        }
        return Optional.empty();
    }
    
    public Optional<LinedSpanLevel> getOutline(){
        Span first = get(0);
        if (first instanceof LinedSpanSection){
            LinedSpanSection level = (LinedSpanSection) first;
            if (level.getType() == LinedType.OUTLINE){
                return Optional.of(level);
            } else if (level.getType() == LinedType.HEADING){
                return Optional.empty();
            }
        }
        int idx = getDocument().indexOf(this);
        while (idx != 0){
            idx--;
            SpanBranch siblings = getDocument().get(idx);
            if (siblings instanceof MainSpanSection){
                return ((MainSpanSection)siblings).getOutline();
            }
        }
        return Optional.empty();
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("SECTION:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.MAIN_SECTION);
    }
}
