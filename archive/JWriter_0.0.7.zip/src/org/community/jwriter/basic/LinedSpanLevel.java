package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanLevel extends LinedSpan {

    LinedSpanLevel(List<Span> children, LinedType spanType){
        super(children, spanType);
    }
    
    public Optional<FormatSpanMain> getFormatted(){
        return lastClass(FormatSpanMain.class);
    }
    
    public int getLevel(){
        int extras = getType() == LinedType.OUTLINE? 1: 0;
        return get(0).getRaw().length() - extras;
    }
}
