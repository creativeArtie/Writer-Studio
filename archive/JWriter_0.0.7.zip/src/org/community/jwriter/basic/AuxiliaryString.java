package org.community.jwriter.basic;

import com.google.common.base.Preconditions;
import com.google.common.base.CaseFormat;

import org.community.jwriter.main.ArgumentChecker;

/**
 * All strings used in this package. Each field (private and public) has its own 
 * prefix. See source code for how the strings are grouped.
 */
final class AuxiliaryString{
    /// ========================================================================
    /// @Part-1: Token Constants------------------------------------------------
    
    /// @Part-1.1: Lines with Levels -------------------------------------------
    /// For LinedParseLevel
    
    /** 
     * Maximum number of levels. Use for 
     * {@link getLevelToken(LinedParseLevel, int)}
     */
    public static final int LEVEL_MAX = 6;
    
    /// Leveled Line begin part token for numbered and bullet
    private static final String LEVEL_BEGIN    = "\t";
    /// Leveled line begin part tokens
    private static final String LEVEL_HEADING  = "=";
    private static final String LEVEL_NUMBERED = "#";
    private static final String LEVEL_OUTLINE  = "#";
    private static final String LEVEL_BULLET   = "-";
    private static final String LEVEL_QUOTE    = ">";
    /** Creates a Leveled Line begin token.
     * @param useParser
     *      use to specific which token. This should be all of them.
     * @param forLevel
     *      a number between 1 and {@link LEVEL_MAX}
     * @return
     *      the starter token created
     */
    public static String getLevelToken(LinedParseLevel useParser, int forLevel){
        ArgumentChecker.checkNotNull(useParser, "useParser");
        Preconditions.checkArgument(0 < forLevel && forLevel <= LEVEL_MAX,
            "forLevel must be between 1 and %s.", LEVEL_MAX , forLevel);
        switch (useParser){
            case HEADING:
                return repeat(LEVEL_HEADING, forLevel);
            case OUTLINE:
                return LINED_BEGIN + repeat(LEVEL_OUTLINE, forLevel);
            case QUOTE:
                return repeat(LEVEL_QUOTE, forLevel);
            case NUMBERED:
                return repeat(LEVEL_BEGIN, forLevel - 1) + LEVEL_NUMBERED;
            case BULLET:
                return repeat(LEVEL_BEGIN, forLevel - 1) + LEVEL_BULLET;
            default:
                assert false : useParser;
                return "";
        }
    }
    /// getLevelToken helper
    private static String repeat(String repeatString, int forLevel){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < forLevel; i++){
            builder.append(repeatString);
        }
        return builder.toString();
    }
    
    /// @Part-1-2: Other Lined Details -----------------------------------------
    /// For BasicTextParse, LinedParseCite, LinedParseLevel, LinedParsePointer,
    ///     LinedParseRest, getLevelToken(LinedParseLevel, int)
    
    /** Line ending token */
    public static final String LINED_END = "\n";
    
    /** Data separator token*/
    public static final String LINED_DATA = ":";
    
    /// "Special" Line begin token  part 1
    private static final String LINED_BEGIN = "!";
    /// "Special" Line begin tokens part 2
    /** Agenda line start token. */
    public static final String LINED_AGENDA   = LINED_BEGIN + "!"; 
    /** User note line start token. */
    public static final String LINED_NOTE     = LINED_BEGIN + "%";   
    /** Citation  line start token. */
    public static final String LINED_CITE     = LINED_BEGIN + ">";
    /** Hyperlink line start token. */
    public static final String LINED_LINK     = LINED_BEGIN + "@";
    /** Footnote  line start token. */
    public static final String LINED_FOOTNOTE = LINED_BEGIN + "^";
    /** Endnote   line start token. */
    public static final String LINED_ENDNOTE  = LINED_BEGIN + "*";
    
    /** Line break token. */
    public static final String LINED_BREAK = "***\n";
    
    /// @Part-1-3: Directory ---------------------------------------------------
    /// For DirectoryParser, LinedParseLevel, LinedParseRest, CURLY_CITE
    
    /** Usual  directory start token. */
    public static final String DIRECTORY_BEGIN    = "@";
    /** Main   directory separate token. */
    public static final String DIRECTORY_CATEGORY = "-";
    /** Common directory end tokne*/
    public static final String DIRECTORY_END      = ":";
    
    /// @Part-1-4: Status ------------------------------------------------------
    /// For EditionParser, LinedParseLevel
    
    /** Edition start token */
    public static final String EDITION_BEGIN = "#";
    /// (more constants are devise with {@link Edition#name()}
    
    /// @Part-1-5: Hyperlinks --------------------------------------------------
    /// For FormatParseLinkDirect, FormatParseLinkRef, listFormatEnderTokens()
    
    /** Inline direct    link token. */
    public static final String LINK_BEGIN =              "<";
    /** Inline reference link token. */
    public static final String LINK_REF   = LINK_BEGIN + "@";
    
    /** Path - text separator token*/
    public static final String LINK_TEXT  = "|";
    /** link end token*/
    public static final String LINK_END   = ">"; /// End
    
    /// @Part-1-6: Curly Formats ------------------------------------------------
    /// For FormatParseAgenda, FormatParseDirectory, listFormatEnderTokens()
    
    /// Curly format begins token  part 1
    private static final String CURLY_BEGIN   = "{";
    /// Curly format begins tokens part 2
    /** Inline agenda      starter token.*/
    public static final String CURLY_AGENDA   = CURLY_BEGIN + "!";
    /** Footnote reference stater token.*/
    public static final String CURLY_FOOTNOTE = CURLY_BEGIN + "^";
    /** Endnote reference  stater token.*/
    public static final String CURLY_ENDNOTE  = CURLY_BEGIN + "*";
    /** Citation reference starter token.*/
    public static final String CURLY_CITE     = CURLY_BEGIN + DIRECTORY_BEGIN;
    
    /** Curly format end token. **/
    public static final String CURLY_END      = "}";
    
    /// @Part-1-7: Format Modifiers ---------------------------------------------
    /// For FormatParser, listFormatEnderTokens()
    
    /// list of possible formats
    private static final String FORMAT_ITALICS  = "*";
    private static final String FORMAT_BOLD     = "**";
    private static final String FORMAT_UNDERLINE = "_";
    private static final String FORMAT_CODED     = "`";
    /** Create the list of possible format of text.
     * @return list of format with the correct parse order
     */
    public static final String[] listFormatTextTokens(){
        // FORMAT_BOLD must before FORMAT_ITALICS
        return new String[]{
            FORMAT_BOLD, FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED
        };
    }
    
    /// @Part-1-8: Escape Begin Token ------------------------------------------
    /// For BasicParseText
    
    /** Char escape token. */
    public static final String CHAR_ESCAPE = "\\";
    
    /// @Part-1-9: Format Part Separators --------------------------------------
    /// For FormatParsers
    
    /** Create the list of how children spans of format can end.
     * @return the list of term, without {@linkplain FORMAT_BOLD}
     */
    public static String[] listFormatEnderTokens(){
        return new String[]{
            CURLY_AGENDA, CURLY_FOOTNOTE, CURLY_ENDNOTE, CURLY_CITE, CURLY_END, 
            LINK_BEGIN, LINK_REF,
            /* FORMAT_BOLD, */ FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED};
    }
    
    /// ========================================================================
    /// @Part-2: Other Types ---------------------------------------------------
    
    /// @Part-2-1: Possible type of Directories
    /// For DirectoryType
    
    /** {@link DirectoryType#FOOTNOTE} id name. */
    public static final String TYPE_FOOTNOTE = "foot";
    /** {@link DirectoryType#ENDNOTE} id name. */
    public static final String TYPE_ENDNOTE  = "end";
    /** {@link DirectoryType#LINK} id name. */
    public static final String TYPE_LINK     = "link";
    /** {@link DirectoryType#NOTE} id name. */
    public static final String TYPE_NOTE     = "note";
    
    /// @Part-2-2: Possible style catagory name.
    /// For AuxilliaryType, DirectoryType, EditionType, FormatType, 
    ///     LinedDataField, LinedDataType, LinedType
    
    /** {@link AuxilliaryType} catagory name. */
    public static final String STYLE_OTHER    = "OTHER"  ;
    /** {@link EditionType} catagory name. */
    public static final String STYLE_EDITION  = "EDITION";
    /** {@link FormatType} catagory name. */
    public static final String STYLE_FORMAT   = "FORMAT" ;
    /** {@link LinedDataField} catagory name. */
    public static final String STYLE_FIELD    = "FIELD"  ;
    /** {@link AuxilliaryType} catagory name. */
    public static final String STYLE_INLINE   = "INLINE" ;
    /** {@link DirectoryType} catagory name. */
    public static final String STYLE_CATEGORY = "INLINE" ;
    /** {@link LinedType} catagory name. */
    public static final String STYLE_LINED    = "LINED"  ;
    /** {@link AuxilliaryType} catagory name. */
    public static final String STYLE_SPECIFY  = "SPECS"  ;
    /** {@link AuxilliaryType} catagory name. */
    public static final String STYLE_MAIN     = "MAIN"   ;
    /** {@link LinedDataType} catagory name. */
    public static final String STYLE_DATA     = "DATA"   ;
    
    /// ========================================================================
    /// @Part-3: Private Constructor -------------------------------------------
    private AuxiliaryString(){}
}
