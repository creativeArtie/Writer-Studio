package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpan extends SpanBranch {
    private final LinedType type;
    
    LinedSpan(List<Span> children, LinedType t){
        super(children);
        type = t;
    }
    
    public LinedType getType(){
        return LinedType.findType(get(0).getRaw());
    }
    
    public String toString(){
        return type + super.toString();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(type);
    }
    
    @Override
    protected DetailUpdater getUpdater(Span edit, String newText){
        if (edit != get(0)){
            SetupParser parser = type.getParser();
            int found = search(newText, CHAR_ESCAPE, LINED_END);
            if (found == -1){
                return DetailUpdater.mergeNext(parser);
            } else if (found == newText.length()){
                return DetailUpdater.replace(parser);
            }
        }
        return DetailUpdater.unable();
    }
}
