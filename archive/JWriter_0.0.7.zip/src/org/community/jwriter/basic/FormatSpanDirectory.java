package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * A {@linkplain FormatSpanCurly} for id referance. This has a span where it is
 * reference to
 */
public final class FormatSpanDirectory extends FormatSpan 
        implements CatalogueHolder {
    private final DirectoryType type;
    
    FormatSpanDirectory(List<Span> children, boolean[] formats, 
        DirectoryType curlyType
    ){
        super(children, formats);
        type = curlyType;
    }
    
    public DirectoryType getType(){
        return type;
    }
    
    public Optional<Span> getSpan(){
        return getTarget();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(type);
        if (! hasID()) list.add(AuxiliaryStyle.NO_ID);
        super.addInfo(list);
    }
    
    @Override
    public boolean isId(){
        return false;
    }
}
