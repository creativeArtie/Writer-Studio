package org.community.jwriter.basic;

import java.util.ArrayList; 
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;
import org.community.jwriter.main.ArgumentChecker;

/**
 * Created from {@link DirectorySpan}. Used to store {@link CatalogueIdentity}
 */
public class DirectorySpan extends SpanBranch implements CatalogueSpan{
    /// helps with categorizing and describes purpose
    private Optional<DirectoryType> purpose;
    
    /// Helper method to get Optional<DirectorySpan> -> Optional<CatalogueIdentity>
    static Optional<CatalogueIdentity> getDirectoryHelper(Optional<DirectorySpan> id){
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
    
    DirectorySpan(List<Span> spanChildren, Optional<DirectoryType> idPurpose){
        super(spanChildren);
        ArgumentChecker.checkNotNull(idPurpose, "idPurpose");
        purpose = idPurpose;
    }
    
    @Override
    public CatalogueIdentity getId(){
        ArrayList<String> builder = new ArrayList<>();
        purpose.ifPresent(found -> builder.add(found.getCategory()));
        Optional<String> idTmp = Optional.empty();
        for(Span child: this){
            if (child instanceof SpanLeaf){
                builder.add(idTmp.orElse(""));
                idTmp = Optional.empty();
            } else {
                idTmp = Optional.of(((ContentSpan)child).getText());
            }
        }
        return new CatalogueIdentity(builder, idTmp.orElse(""));
    }
    
    public DirectoryType getPurpose(){
        //TODO
        return purpose.isPresent()? purpose.get(): null;
    }

    @Override
    protected void addInfo(List<DetailStyle> styleList){
        ArgumentChecker.checkNotNull(styleList, "styleList");
        CatalogueData data = getDocument().getMap().get(getId());
        if (data == null) {
            styleList.add(CatalogueStatus.NO_ID);
        } else {
            styleList.add(data.getState());
        }
    }
        
    
    public String toString(){
        return "ID" + getId().toString();
    }
}
