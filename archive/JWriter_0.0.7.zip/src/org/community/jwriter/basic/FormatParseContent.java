package org.community.jwriter.basic;

import java.util.Arrays; 
import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * Creates a text span upto a certain character.
 */
class FormatParseContent extends BasicParseText{
    
    private boolean[] formats;
    private boolean canParse;
    
    public FormatParseContent(SetupLeafStyle spanStyles, boolean[] spanFormats, 
        boolean parse, List<String> enders
    ){
        this(spanStyles, spanFormats, parse, enders.toArray(new String[0]));
    }
    
    public FormatParseContent(SetupLeafStyle spanStyles, boolean[] spanFormats, 
        boolean parse, String[] enders
    ){
        super(spanStyles, enders);
        formats = Arrays.copyOf(spanFormats, spanFormats.length);
        canParse = parse;
    }

    @Override
    protected FormatSpanContent buildSpan(List<Span> children, 
        List<String> enders, SetupLeafStyle baseStyle
    ){
        return new FormatSpanContent(children, formats, enders, baseStyle, 
            canParse);
    }
    
}
