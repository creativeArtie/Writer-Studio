package org.community.jwriter.basic;

import static org.community.jwriter.basic.AuxiliaryString.*;

import org.community.jwriter.markup.DetailStyle;
public enum EditionType implements DetailStyle{
    STUB, DRAFT, FINAL, OTHER, NONE;
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_EDITION, name());
    }
}
