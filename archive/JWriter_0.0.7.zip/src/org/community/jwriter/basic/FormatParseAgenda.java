package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

/**
 * SetupParser for {@link FormatSpanCurlyDirectory} and {@link FormatSpanCurlyAgenda} that uses 
 * curly bracket. These are footnote, endnote, cite, and to do.
 */
enum FormatParseAgenda implements SetupParser {
    PARSER;
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        /// FOund therefore setup the SpanBranch
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, CURLY_AGENDA)){
            new ContentParser(CURLY_END).parse(children, pointer);
            
            /// Complete the last steps
            pointer.startsWith(children, CURLY_END);
            return Optional.of(new FormatSpanAgenda(children));
        }
        return Optional.empty();
    }
}
