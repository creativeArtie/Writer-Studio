package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryString.*;

public class LinedSpanNote extends LinedSpan{
    
    public LinedSpanNote(List<Span> children){
        super(children, LinedType.NOTE);
    }
    
    public Optional<FormatSpanMain> getFormatted(){
        return lastClass(FormatSpanMain.class);
    }
    
    public boolean hasDirectorySpan(){
        return getId().isPresent();
    }
    
    public Optional<CatalogueIdentity> getId(){
        Optional<DirectorySpan> id = firstClass(DirectorySpan.class);
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
}
