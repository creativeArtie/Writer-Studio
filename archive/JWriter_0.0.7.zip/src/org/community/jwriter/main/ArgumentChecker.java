package org.community.jwriter.main;

import com.google.common.base.Preconditions;

public class ArgumentChecker{
    
    /** 
     * Create {@linkplain NullPointerException} for a field.
     * @param forField
     *      name of the field
     * @return the error String for null exceptions.
     */
    public static <T> T checkNotNull(T obj, String forField){
        String error = "Arguement \"" + forField + "\" can not be null.";
        return Preconditions.checkNotNull(obj, forField);
    }
}
