package org.community.jwriter.main;

import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;

import org.fxmisc.richtext.InlineCssTextArea;
import org.fxmisc.richtext.model.PlainTextChange;

import org.community.jwriter.markup.*;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.basic.ManuscriptDocument;


public class DocumentTextArea extends InlineCssTextArea{
    private Document doc;
    private PropertyManager styles;
    
    public DocumentTextArea(Document document, PropertyManager manager){
        super(document.getRaw());
        doc = document;
        styles = manager;
        plainTextChanges().subscribe(data -> textChanged(data));
        /*setParagraphGraphicFactory(line -> {
            
        });*/
        update();
    }
    
    private void textChanged(PlainTextChange change){
        int pos = change.getPosition();
        switch (change.getType()){
        case DELETION:
            deleteChar(pos, change.getRemovalEnd());
        break;
        case INSERTION:
            insertChar(pos, change.getInserted());
        break;
        case REPLACEMENT:
            deleteChar(pos, change.getRemovalEnd());
            insertChar(pos, change.getInserted());
        break;
        }
        update();
    }
    
    private void insertChar(int pos, String text){
        for (int i = 0; i < text.length(); i++){
            doc.insertChar(pos, text.charAt(i));
        }
    }
    
    private void deleteChar(int pos, int end){
        for(int i = pos; i < end; i++){
            doc.deleteChar(pos);
        }
        
    }
    
    void update(){
        for (DetailSpanLeaf span: doc.getLeaves()){
            setStyle(span.getStart(), span.getEnd(), span.toCss(styles));
        }
    }
}
