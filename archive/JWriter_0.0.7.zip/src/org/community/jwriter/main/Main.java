package org.community.jwriter.main;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import org.community.jwriter.basic.ManuscriptDocument;
import org.community.jwriter.property.PropertyManager;


public class Main extends Application{

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage window){
        WindowText.TITLE.addAndCall((resource, value) -> window.setTitle(value));
        
        ManuscriptDocument doc = new ManuscriptDocument(
            "==Hello *World!* \\# abc # Hello\n" +
            "!#@outlne:Outline 1 #DRAFT\n" +
            "#number line 1\n" +
            "#number line 2 <google.com|google>\n" +
            "!@apple:apple.com\n" +
            "!!more todo\n" +
            "Some more text{@unknown}\n" +
            "!%Note 1\n" +
            "!%@Note 2: Proper note\n" +
            "!>in-text:abc\n" +
            "!>error\n" +
            ">quote with _underline_, *italics*, `code`, and **bold\n" +
            "Simple paragraph with footnote{^1} and {!in line to do}\n" +
            "!^1: Some text"
        );
        PropertyManager manager = null;
        try {
            manager = new PropertyManager("data/base-styles", 
            "data/user-styles");
        } catch (Exception ex){System.out.println(ex);}
        
        StackPane pane = new StackPane();
        pane.getChildren().add(new DocumentTextArea(doc, manager));
        
        Scene tmp = new Scene(pane, 600, 600);
        window.setScene(tmp);
        window.show();
    }
}
