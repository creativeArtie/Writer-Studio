package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ForwardingMap;

import org.community.jwriter.main.ArgumentChecker;

/**
 * A System of {@link DirectorySpan} references with their status
 */
public final class CatalogueMap extends ForwardingMap<CatalogueIdentity, CatalogueData>{
    private final TreeMap<CatalogueIdentity, CatalogueData> ids;
    
    public CatalogueMap(){
        ids = new TreeMap<>();
    }
    
    public void addId(CatalogueIdentity newId, SpanBranch pointSpan){
        ArgumentChecker.checkNotNull(newId, "newId");
        ArgumentChecker.checkNotNull(pointSpan, "ptrSpan");
        CatalogueData data = ids.get(newId);
        if (data == null){
            data = new CatalogueData(this, newId);
            ids.put(newId, data);
        }
        data.addId(pointSpan);
    }
    
    public void addRef(CatalogueIdentity addRef, SpanBranch pointSpan){
        ArgumentChecker.checkNotNull(addRef, "addRef");
        ArgumentChecker.checkNotNull(pointSpan, "pointSpan");
        CatalogueData data = ids.get(addRef);
        if (data == null){
            data = new CatalogueData(this, addRef);
            ids.put(addRef, data);
        }
        data.addRef(pointSpan);
    }
    
    public ImmutableMap<CatalogueIdentity, CatalogueData> delegate(){
        return ImmutableMap.copyOf(ids);
    }
}
