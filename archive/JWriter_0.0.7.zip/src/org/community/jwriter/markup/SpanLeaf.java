package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor
import java.util.List;
import java.util.ArrayList;

import com.google.common.collect.ImmutableList;
import static org.community.jwriter.markup.SetupStrings.*;

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf implements Span{
    private String text;
    private SpanBranch parent;
    private SetupLeafStyle style;
    
    public static String escapeText(String input){
        return "\"" + input.replace("\n", "\" \\n \"")
            .replace("\t", "\" \\t \"") + "\"";
    }
    
    SpanLeaf(SetupPointer pointer, SetupLeafStyle spanStyle){
        text = pointer.getRaw();
        pointer.roll();
        style = spanStyle;
    }
    
    public DetailStyle getInfo(){
        return style;
    }
    
    public List<DetailStyle> getDetailStyle(){
        ArrayList<DetailStyle> ans = new ArrayList<>();
        getDetailStyle(this, ans);
        ans.add(style);
        return ImmutableList.copyOf(ans);
    }
    
    private void getDetailStyle(Span child, 
        ArrayList<DetailStyle> input
    ){
        SpanNode<?> parent = child.getParent();
        if (parent instanceof SpanBranch){
            getDetailStyle(parent, input);
            ((SpanBranch)parent).addInfo(input);
        }
    }
    
    void setParent(SpanBranch childOf){
        parent = childOf;
        setEdit();
    }
    
    @Override
    public final String getRaw(){
        return text;
    }
    
    @Override
    public String toString(){
        return escapeText(text);
    }
    
    @Override
    public Document getDocument(){
        SpanNode<?> span = getParent();
        while (! (span instanceof Document)){
            span = span.getParent();
        }
        return (Document)span;
    }
    
    @Override
    public SpanBranch getParent(){
        return parent;
    }
    
    @Override
    public int getLength(){
        return text.length();
    }
    
    @Override
    public void setRemove(){}
    
    @Override
    public void setEdit(){
        parent.setEdit();
    }
}
