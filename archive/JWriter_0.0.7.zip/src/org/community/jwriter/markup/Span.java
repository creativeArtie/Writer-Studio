package org.community.jwriter.markup;

import java.util.List;
import java.util.ArrayList;

/**
 * A subdivision of a {@link Document}
 */
public interface Span{
    
    public String getRaw();
    
    public int getLength();
    
    public Document getDocument();
    
    public SpanNode<?> getParent();
    
    public void setRemove();
    
    public void setEdit();
}
