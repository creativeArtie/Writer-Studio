package org.community.jwriter.markup;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

enum DetailUpdateType{
    BASIC, REPLACE, MERGE_LAST, MERGE_NEXT, SPLIT, UNABLE;
}
