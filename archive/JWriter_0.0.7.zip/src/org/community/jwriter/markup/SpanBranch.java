package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.TreeMap;

import com.google.common.collect.ImmutableList;

/**
 * A {@link Span} handling {@link SpanLeaf}
 */
public abstract class SpanBranch extends SpanNode<Span> implements Span {
    
    private ArrayList<Span> children;
    
    private SpanNode<?> parent;
    
    public SpanBranch(List<Span> spans){
        children = new ArrayList<>(spans);
        setParents(children);
    }
    
    private void setParents(List<Span> spans){
        for(Span span : spans){
            if (span instanceof SpanBranch){
                ((SpanBranch)span).setParent(this);
            } else {
                ((SpanLeaf)span).setParent(this);
            }
        }
    }
    
    protected int search(String raw, String escape, List<String> find){
        return search(raw, escape, find.toArray(new String[0]));
    }
    
    protected int search(String raw, String escape, String ... find){
        boolean isEscape = false;
        for(int i = 0; i < raw.length(); i++){
            if (isEscape){
                isEscape = false;
            } else {
                if (raw.startsWith(escape, i)){
                    isEscape = true;
                } else {
                    for(String str: find){
                        if (raw.startsWith(str, i)){
                            return i;
                        }
                    }
                }
            }
        }
        return -1;
    }
    
    @Override
    public final List<Span> delegate(){
        return ImmutableList.copyOf(children);
    }
    
    @Override
    Span removeChild(int idx){
        Span span = children.remove(idx);
        span.setRemove();
        return span;
    }
    
    @Override
    void addChildren(int idx, List<Span> spans){
        children.addAll(idx, spans);
        setParents(spans);
    }
    
    @Override
    public Document getDocument(){
        return get(0).getDocument();
    }
    
    @Override
    public SpanNode<?> getParent(){
        return parent;
    }
    
    void setParent(SpanNode<?> childOf){
        parent = childOf;
    }
    
    protected abstract void addInfo(List<DetailStyle> list);
    
    protected <T extends SpanBranch> Optional<T> firstClass(Class<T> clazz){
        for(Span span: this){
            if (clazz.isInstance(span)){
                return Optional.of(clazz.cast(span));
            }
        }
        return Optional.empty();
    }
    
    protected <T extends SpanBranch> Optional<T> lastClass(Class<T> clazz){
        for(int i = size() - 1; i >= 0; i--){
            Span span = get(i);
            if (clazz.isInstance(span)){
                return Optional.of(clazz.cast(span));
            }
        }
        return Optional.empty();
    }
    
    protected Optional<SpanLeaf> firstLeaf(DetailStyle info){
        for (Span span: this){
            if (span instanceof SpanLeaf){
                SpanLeaf found = (SpanLeaf) span;
                if (found.getInfo().equals(info)){
                    return Optional.of(found);
                }
            }
        }
        return Optional.empty();
    }
    
    protected DetailUpdater getUpdater(Span edit, String newText){
        return DetailUpdater.unable();
    }
}
