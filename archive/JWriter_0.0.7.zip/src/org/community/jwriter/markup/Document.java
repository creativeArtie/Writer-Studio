package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import com.google.common.base.CharMatcher;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;

import org.community.jwriter.main.ArgumentChecker;

/**
 * {@code Document} is what {@link org.community.jwriter.window} and 
 * {@link org.community.output} use to represent the text file. This will
 * immediately parse the rawText upon the constructor.
 */
public abstract class Document extends SpanNode<SpanBranch>{

    private ArrayList<SpanBranch> children;
    private CatalogueMap ids;
    private SetupParser[] parsers;
    
    public Document(){
        children = new ArrayList<>();
        ids = new CatalogueMap();
    }
        
    public Document(String rawText, SetupParser ... docParsers){
        ArgumentChecker.checkNotNull(rawText, "rawText");
        ArgumentChecker.checkNotNull(docParsers, "docParsers");
        
        parsers = docParsers;
        
        /// Setup for building the doc and a pointer to use
        parseDocument(rawText);
    }
        
    protected void parseDocument(String rawText){
        ArgumentChecker.checkNotNull(rawText, "rawText");
        children = new ArrayList<>();
        SetupPointer ptr = SetupPointer.newPointer(rawText, this);
        /// Setup for runtime exceptions
        int counter = 0; 
        
        /// Parse loop
        while (ptr.hasNext()){
            /// CatalogueStatus checking what happen if SetupPointer fails or 
            /// SetupParser[] misses the texts
            if(counter > rawText.length()){
                System.out.println(children);
                System.out.println(ptr);
                throw new RuntimeException("Loop too much");
            }
            counter++;
            
            /// Finding the correct SetupParser to build span from
            for(SetupParser s: parsers){
                Optional<?> span = s.parse(ptr);
                
                /// Span has been created
                if (span.isPresent()){
                    SpanBranch found = (SpanBranch)span.get();
                    found.setParent(this);
                    children.add(found);
                    break;
                }
            }
        }
        
        /// Finalize the parse loop
        ids = new CatalogueMap();
        fillMap(children);
    }
    
    private void fillMap(List<? extends Span> spanList){
        for (Span span: spanList){
            if (span instanceof CatalogueHolder){
                ((CatalogueHolder)span).fillMap(ids);
            }
            if (span instanceof SpanBranch){
                fillMap((SpanBranch)span);
            }
        }
    }
    
    public CatalogueMap getMap(){
        return ids;
    }
    
    @Override
    public String toString(){
        if (ids.size() == 0){
            return super.toString() + ids.toString();
        }
        return super.toString() + "\n" + ids.toString();
    }
    
    @Override
    public Document getDocument(){
        return this;
    }
    
    @Override
    public SpanNode<?> getParent(){
        throw new UnsupportedOperationException("No parents");
    }
    
    @Override
    public List<SpanBranch> delegate(){
        return ImmutableList.copyOf(children);
    }
    
    @Override
    Span removeChild(int idx){
        
        Span ans = children.remove(idx);
        ans.setRemove();
        return ans;
    }
    
    @Override
    void addChildren(int listIndex, List<Span> spanList){
        ArrayList<SpanBranch> insert = new ArrayList<>();
        for(Span child: spanList){
            if ( !(child instanceof SpanBranch)){
                throw new IllegalArgumentException(
                    "Child is not a brench:" + child);
            }
            insert.add((SpanBranch)child);
            ((SpanBranch)child).setParent(this);
        }
        children.addAll(listIndex, insert);
    }
    
    @Override
    public void setRemove(){
        for (SpanBranch child: children){
            child.setRemove();
        }
    }
    
    public List<Span> getSpan(int docIndex){
        Preconditions.checkPositionIndex(docIndex, getLength(), "Doc index");
        ArrayList<Span> ans = new ArrayList<>();
        findSpan(ans, docIndex);
        return ImmutableList.copyOf(ans);
    }
    
    private int findSpan(ArrayList<Span> spanList, int docIndex){
        spanList.add(this);
        int length = getLength();
        if (docIndex == length){
            Span search = this.get(size() - 1);
            while (search instanceof SpanNode){
                spanList.add(search);
                SpanNode<? extends Span> parent = (SpanNode<? extends Span>) 
                    search;
                search = parent.get(parent.size() - 1);
            }
            spanList.add(search);
            return search.getLength();
        }
        
        int start = 0;
        Iterator<? extends Span> it = iterator();
        while (true){
            if (! it.hasNext()){
                throw new IllegalArgumentException("Out of range.");
            }
            Span found = it.next();
            if (start + found.getLength() > docIndex){
                spanList.add(found);
                if (found instanceof SpanBranch){
                    it = ((SpanBranch)found).iterator();
                } else {
                    return docIndex - start;
                }
            } else {
                start += found.getLength();
            }
        }
    }
    
    public void insertChar(int location, char ch){
        ArrayList<Span> spans = new ArrayList<>();
        int loc = findSpan(spans, location);
        StringBuilder raw = new StringBuilder(spans.get(spans.size() - 1)
            .getRaw());
        raw.insert(loc, ch);
        edit(spans, raw.toString());
    }
    
    public void deleteChar(int location){
        ArrayList<Span> spans = new ArrayList<>();
        int loc = findSpan(spans, location);
        StringBuilder raw = new StringBuilder(spans.get(spans.size() - 1)
            .getRaw());
        raw.deleteCharAt(loc);
        edit(spans, raw.toString());
    }
    
    private void edit(List<Span> spans, String raw){
        ImmutableSet.Builder<CatalogueIdentity> builder = ImmutableSet.builder();
        for (Span span: spans){
            if (span instanceof CatalogueSpan){
                builder.add(((CatalogueSpan)span).getId());
            } else if (span instanceof CatalogueHolder){
                ((CatalogueHolder)span).getId().ifPresent(id -> builder.add(id));
            }
        }
        edit(spans, raw, spans.size() - 1);
        ids = new CatalogueMap();
        fillMap(children);
    }
    
    private void edit(List<Span> spans, String base, int idx){
        
        Span replaced = spans.get(idx);
        Span editor = spans.get(idx - 1);
        String raw = "";
        for (Span span: (SpanNode<? extends Span>)editor){
            if (span == replaced){
                raw += base;
            } else {
                raw += span.getRaw();
            }
        }
        
        if (idx - 1 == 0){
            parseDocument(raw);
        } else {
            DetailUpdater updater = ((SpanBranch)editor)
                .getUpdater(replaced, raw);
            if (updater.getType() == DetailUpdateType.UNABLE){
                edit(spans, raw, idx - 1);
            } else {
                parseText(updater, spans, idx, raw);
            }
        }
    }
    
    private void parseText(DetailUpdater updater, List<Span> spans, int idx,
        String base
    ){
        SpanNode<? extends Span> holder = (SpanNode<? extends Span>)spans
            .get(idx - 2);
        SpanNode<? extends Span> editor = (SpanNode<? extends Span>)spans
            .get(idx - 1);
        String input = base;

        int replaceIdx = holder.indexOf(editor);
        if (updater.getType() == DetailUpdateType.MERGE_NEXT){
            if (replaceIdx + 1 < holder.size()){
                input = base + holder.get(replaceIdx + 1).getRaw();
                holder.removeChild(replaceIdx + 1);
            }
        }
        holder.removeChild(replaceIdx);
        if (updater.getType() == DetailUpdateType.MERGE_LAST){
            if (replaceIdx -1 >= 0){
                input = holder.get(replaceIdx - 1).getRaw() + base;
                holder.removeChild(replaceIdx - 1);
            }
        }
        List<Span> children = updater.parse(input, this);
        holder.addChildren(replaceIdx, children);
    }
    
    public List<DetailSpanLeaf> getLeaves(){
        return ImmutableList.copyOf(getLeaves(this, 0));
    }
    
    private List<DetailSpanLeaf> getLeaves(SpanNode<?> spans, int start){
        ImmutableList.Builder<DetailSpanLeaf> builder = ImmutableList.builder();
        int end = start;
        for(Span span: spans){
            start = end;
            end = start + span.getLength();
            if (span instanceof SpanLeaf){
                builder.add(new DetailSpanLeaf(start, end, (SpanLeaf) span));
            } else {
                builder.addAll(getLeaves((SpanBranch)span, start));
            }
        }
        return builder.build();
    }
}
