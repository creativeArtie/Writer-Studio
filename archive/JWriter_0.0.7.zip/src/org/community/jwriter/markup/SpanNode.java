package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ForwardingList;

/**
 * Common methods for {@link Document} and {@link SpanBranch}.
 */
public abstract class SpanNode<T extends Span> extends ForwardingList<T> 
        implements Span {
    
    private ArrayList<DetailListener> removers;
    private ArrayList<DetailListener> editors;
    
    protected SpanNode(){
        removers = new ArrayList<>();
        editors = new ArrayList<>();
    }
                
    @Override
    public final String getRaw(){
        StringBuilder builder = new StringBuilder();
        
        for (Span span: this){
            builder.append(span.getRaw());
        }
        return builder.toString();
    }
    
    @Override
    public int getLength(){
        int ans = 0;
        for(Span child: this){
            ans += child.getLength();
        }
        return ans;
    }
    
    public void addRemover(DetailListener listener){
        removers.add(listener);
    }
    
    @Override
    public void setRemove(){
        for(DetailListener remover: removers){
            remover.changed(this);
        }
        for(Span child: this){
            if (child instanceof SpanBranch){
                ((SpanBranch)child).setRemove();
            }
        }
    }
    
    public void addEditor(DetailListener listener){
        editors.add(listener);
    }
    
    @Override
    public void setEdit(){
        for(DetailListener editor: editors){
            editor.changed(this);
        }
    }
    
    abstract Span removeChild(int idx);
    
    abstract void addChildren(int idx, List<Span> children);
}
