package org.community.jwriter.markup;


import java.util.Arrays;
import java.util.ArrayList;
import java.util.Stack;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.base.CharMatcher;

/**
 * SetupPointer for the rawText. Stores two points: {@linkplain start} for where the
 * pointer is currently checking from and {@linkplain end} for where is the 
 * next matching data. 
 */
public final class SetupPointer{

    private final String text;
    private final Document doc;
    
    /// Points to where the pointer would roll back to
    private int mark;
    /// Points to the matching start
    private int cur;
    /// Points to the last success (but not commit) check
    private int found;
    
    public static SetupPointer newPointer(String docText, Document document){
        return new SetupPointer(docText, document);
    }
    
    static SetupPointer updatePointer(String docText, Document document){
        return new SetupPointer(docText, document);
    }
    
    private SetupPointer(String docText, Document document){
        text = docText;
        doc = document;
        cur = 0;
        found = 0;
        mark = 0;
    }
    
    public void mark(){
        mark = cur;
    }
    
    public void rollBack(SpanBranch remove){
        remove.setRemove();
        rollBack(remove.toArray(new Span[0]));
    }
    
    public void rollBack(List<Span> remove){
        rollBack(remove.toArray(new Span[0]));
    }
    
    public void rollBack(Span ... remove){
        cur = mark;
        found = mark;
        for(Span span: remove){
            span.setRemove();
        }
    }
    
    public boolean trimStartsWith(ArrayList<Span> children, String compare){
        return trimStartsWith(children, SetupLeafStyle.KEYWORD, compare);
    }
    
    public boolean trimStartsWith(ArrayList<Span> children, SetupLeafStyle style,  
        String compare
    ){
        return finishing(children, style, trimStartsWith(compare));
    }
    
    private boolean trimStartsWith(String ... compares){
        if (cur >= text.length()){
            return false;
        }
        int next = ignoreSpaces();
        if (next == -1){
            return false;
        }
        for (String compare: compares){
            if (text.startsWith(compare, next)){
                found = next + compare.length();
    
                return true;
            }
        }
        return false;
    }
    
    public boolean startsWith(ArrayList<Span> children, String compare){
        return startsWith(children, SetupLeafStyle.KEYWORD, compare);
    }  
    
    public boolean startsWith(ArrayList<Span> children, SetupLeafStyle style,  
        String compare
    ){
        return finishing(children, style, startsWith(compare));
    }
    
    /**
     * Check if the pointer at the text location starts with 
     * {@linkplain compare}. If so move {@linkplain end} to the length of 
     * {@linkplain compare}.
     */
    private boolean startsWith(String ... compares){
        int next = cur;
        for(String compare : compares){
            if (text.startsWith(compare, next)){
                found = next + compare.length();
    
                return true;
            }
        }
        return false;
    }
    
    public boolean matches(ArrayList<Span> children, CharMatcher matches){
        return matches(children, SetupLeafStyle.DATA, matches);
    }
    
    public boolean matches(ArrayList<Span> children, SetupLeafStyle style, 
        CharMatcher matches
    ){
        return finishing(children, style, matches(matches));
    }
    
    private boolean matches(CharMatcher matches){
        int next = cur;
        for (; next < text.length() && matches.matches(text.charAt(next)); 
            next++);
        if (next != cur){
            found = next;
            return true;
        }
        return false;
    }
    
    public boolean getTo(ArrayList<Span> children, List<String> compare){
        return getTo(children, SetupLeafStyle.KEYWORD, compare);
    }        
    
    public boolean getTo(ArrayList<Span> children, SetupLeafStyle style,  
        List<String> compare
    ){
        return finishing(children, style, getTo(compare));
    }
    
    public boolean getTo(ArrayList<Span> children, String ... compare){
        return getTo(children, SetupLeafStyle.KEYWORD, compare);
    }
    
    public boolean getTo(ArrayList<Span> children, SetupLeafStyle style,  
        String ... compare
    ){
        return finishing(children, style, getTo(Arrays.asList(compare)));
    }
    
    /**
     * Moves {@linkplain end} pointer to before one of the {@linkplain enders} 
     * or the end of the rawText.
     */
    public boolean getTo(List<String> enders) {
        
        /// Set up next
        int next = cur;
        /// going the the text from pointer, looking out for ender strings
        for(;next < text.length(); next++){
            for (String ender : enders){
                if (text.startsWith(ender, next)){
                    /// Match is found
                    found = next;
                    if (found != cur){
                        return true;
                    }
                    return false;
                }
            }
        }
        if (cur != next) {
            found = next;
            return true;
        }
        
        
        return false;
    }
    
    public boolean nextChars(ArrayList<Span> children, int size){
        return nextChars(children, SetupLeafStyle.KEYWORD, size);
    }
    
    public boolean nextChars(ArrayList<Span> children, SetupLeafStyle style, 
        int size
    ){
        return finishing(children, style, nextChars(size));
    }
    
    /**
     * Moves {@linkpalin end} pointer to {@linkplain size}, if possible. If not
     * possible do not move {@linkplain end}
     */
    private boolean nextChars(int size) {
        if (cur + size <= text.length()){
            found = cur + size;
    
            return true;
        }
        return false;
    }
    
    private boolean finishing(ArrayList<Span> children, SetupLeafStyle style, 
        boolean matches
    ){
        if(matches){
            children.add(new SpanLeaf(this, style));
        }
        return matches;
    }
    
    public boolean hasNext(){
        return cur < text.length();
    }
    
    protected String getRaw(){
        return text.substring(cur, found);
    }
    
    public Document getDocument(){
        return doc;
    }
    
    protected void roll(){
        cur = found;
    }
    
    
    @Override
    public String toString(){
        return "(" + pointerHelper(mark) + "-" + pointerHelper(cur) + "-" + 
            pointerHelper(found) + "): " + text;
    }
    
    private String pointerHelper(int ptr){
        if (ptr < text.length()){
            return ptr + "(" + text.charAt(ptr) + ")";
        }
        return ptr + "(end)";
    }
    
    private int ignoreSpaces(){
        if (cur >= text.length()){
            return -1;
        }
        int next = cur;
        while(CharMatcher.whitespace().matches(text.charAt(next))){
            next++;
            if (next >= text.length()){
                return -1;
            }
        }
        return next;
    }
}
