package org.community.jwriter.markup;

import java.util.List;
import java.util.ArrayList;
import com.google.common.base.Splitter;
import com.google.common.base.CaseFormat;
import com.google.common.base.Preconditions;

import org.community.jwriter.property.StyleProperty;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.main.ArgumentChecker;


public class DetailSpanLeaf {
    private int start;
    private int end;
    private SpanLeaf span;
    
    DetailSpanLeaf(int spanStart, int spanEnd, SpanLeaf targetSpan){
        ArgumentChecker.checkNotNull(targetSpan, "targetSpan");
        Preconditions.checkArgument(spanStart <= spanEnd, 
            "SpanStart (%s) can not be greater then spanEnd (%s)", spanStart, 
            spanEnd);
        start = spanStart;
        end = spanEnd;
        span = targetSpan;
    }
    
    public int getStart(){
        return start;
    }
    
    public int getEnd(){
        return end;
    }
    
    public String toCss(PropertyManager styleFile){
        ArgumentChecker.checkNotNull(styleFile, "styleFile");
        ArrayList<StyleProperty> list = new ArrayList<>();
        for(DetailStyle info: getDetailStyle()){
            String style = info.getStyleClass();
            list.add(styleFile.getStyleProperty(style));
        }
        list.add(styleFile.getStyleProperty(DetailStyle.styleFromEnum(
            SetupStrings.STYLE_BASIC, SetupStrings.STYLE_ALL
        )));
        return StyleProperty.toCss(list);
    }
    
    
    public SpanLeaf getSpan(){
        return span;
    }
    
    public DetailStyle getInfo(){
        return span.getInfo();
    }
    
    public List<DetailStyle> getDetailStyle(){
        return span.getDetailStyle();
    }
    
    public final String getRaw(){
        return span.getRaw();
    }
    
    public Document getDocument(){
        return span.getDocument();
    }
    
    public SpanBranch getParent(){
        return span.getParent();
    }
    
    public int getLength(){
        return span.getLength();
    }
}
