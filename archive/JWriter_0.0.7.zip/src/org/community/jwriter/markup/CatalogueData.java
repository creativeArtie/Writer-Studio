package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.Optional;
import com.google.common.collect.ImmutableList;
import com.google.common.base.Preconditions;

import org.community.jwriter.main.ArgumentChecker;

public class CatalogueData{
    private ArrayList<SpanBranch> ids;
    private ArrayList<SpanBranch> refs;
    private CatalogueMap parent;
    private CatalogueIdentity key;
    
    public CatalogueData(CatalogueMap mapTo, CatalogueIdentity forId){
        ArgumentChecker.checkNotNull(mapTo, "mapTo");
        ArgumentChecker.checkNotNull(forId, "forId");
        ids = new ArrayList<>();
        refs = new ArrayList<>();
        parent = mapTo;
        key = forId;
    }
        
    void addId(SpanBranch newSpan){
        ArgumentChecker.checkNotNull(newSpan, "newSpan");
        ids.add(newSpan);
    }
    
    void addRef(SpanBranch newSpan){
        ArgumentChecker.checkNotNull(newSpan, "newSpan");
        refs.add(newSpan);
    }
    
    public CatalogueStatus getState(){
        if (ids.size() > 1){
            return CatalogueStatus.MULTIPLE;
        } else if (ids.isEmpty()){
            assert !refs.isEmpty();
            return CatalogueStatus.NOT_FOUND;
        } else if (refs.isEmpty()){
            return CatalogueStatus.UNUSED;
        }
        return CatalogueStatus.READY;
    }
    
    public boolean isReady(){
        return getState() == CatalogueStatus.READY;
    }
    
    public Span getTarget(){
        Preconditions.checkState(ids.size() == 1, 
            "There isn't exactly one target (wrong state: %s).", getState());
        return ids.get(0);
    }
    
    public ImmutableList<SpanBranch> getIds(){
        return ImmutableList.copyOf(ids);
    }
    
    public ImmutableList<SpanBranch> getRefs(){
        return ImmutableList.copyOf(refs);
    }
    
    public String toString(){
        return key.toString() + ": " + getState().toString() + "\n\tIds{\n\t" + 
            ids.toString().replace("\n", "\n\t\t") + "\n\t}Refs{" +
            refs.toString() + "}\n";
    }
}
