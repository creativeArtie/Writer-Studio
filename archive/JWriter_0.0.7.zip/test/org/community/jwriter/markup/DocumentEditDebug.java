package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.community.jwriter.basic.*;

@RunWith(JUnit4.class)
public class DocumentEditDebug{
    
    @Test
    public void addBasic(){
        ManuscriptDocument doc = new ManuscriptDocument("abc");
        doc.insertChar(3, 'd');
        assertEquals("abcd", doc.getRaw());
    }
    
    @Test
    public void addEscape(){
        ManuscriptDocument doc = new ManuscriptDocument("abc");
        doc.insertChar(2, '\\');
        assertEquals("ab\\c", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Line
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("ab",              span.get(0)        .getRaw());
        assertEquals("\\", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("c",  ((SpanBranch)span.get(1)).get(1).getRaw());
    }
    
    @Test
    public void insertBeforeEscape(){
        ManuscriptDocument doc = new ManuscriptDocument("ab\\c");
        doc.insertChar(0, 'k');
        assertEquals("kab\\c", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Line
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("kab",             span.get(0)        .getRaw());
        assertEquals("\\", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("c",  ((SpanBranch)span.get(1)).get(1).getRaw());
    }
    
    @Test
    public void changeEscape(){
        ManuscriptDocument doc = new ManuscriptDocument("\\d");
        doc.insertChar(1, 'c');
        assertEquals("\\cd", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Line
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("\\", ((SpanBranch)span.get(0)).get(0).getRaw());
        assertEquals("c",  ((SpanBranch)span.get(0)).get(1).getRaw());
        assertEquals("d",               span.get(1)        .getRaw());
    }
    
    @Test
    public void removeBasic(){
        ManuscriptDocument doc = new ManuscriptDocument("qwderty");
        doc.deleteChar(2);
        assertEquals("qwerty", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Line
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("qwerty", span.get(0).getRaw());
    }
    
    @Test
    public void deleteLastChar(){
        ManuscriptDocument doc = new ManuscriptDocument("abc");
        doc.deleteChar(2);
        assertEquals("ab", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Written Text
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("ab", span.get(0).getRaw());
    }
    
    @Test
    public void removesLastSpan(){
        ManuscriptDocument doc = new ManuscriptDocument("=abc#");
        doc.deleteChar(4);
        assertEquals("=abc", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("=",   span.get(0).getRaw());
        span = (SpanBranch) span.get(1); /// Written Text
        span = (SpanBranch) span.get(0); /// Formatted text
        assertEquals("abc", span.get(0).getRaw());
    }
    
    @Test
    public void removeEscape(){
        ManuscriptDocument doc = new ManuscriptDocument("ab\\c");
        doc.deleteChar(2);
        assertEquals("abc", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Paragraph
        span = (SpanBranch) span.get(0); /// Line
        span = (SpanBranch) span.get(0); /// Formatted text
        
        assertEquals("abc", span.get(0).getRaw());
    }
    
    @Test
    public void mergeLineByDelete(){
        ManuscriptDocument doc = new ManuscriptDocument("=asdf\n jkl; #abc");
        doc.deleteChar(5);
        assertEquals("=asdf jkl; #abc", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Section
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("=",   span.get(0).getRaw());
        
        span = (SpanBranch)        span.get(1); /// Formatted text
        assertEquals("asdf jkl; ", span.get(0).getRaw());
        
        span = (SpanBranch)   span.getParent().get(2); /// Status
        assertEquals("#",                 span.get(0)        .getRaw());
        assertEquals("abc", ((SpanBranch) span.get(1)).get(0).getRaw());
    }
    
    @Test
    public void addStatus(){
        ManuscriptDocument doc = new ManuscriptDocument("=123 DRAFT");
        doc.insertChar(5, '#');
        assertEquals("=123 #DRAFT", doc.getRaw());
        
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("=",   span.get(0).getRaw());
        
        span = (SpanBranch)  span.get(1); /// Formatted text
        assertEquals("123 ", span.get(0).getRaw());
        
        span = (SpanBranch) span.getParent().get(2); /// Status
        assertEquals("#DRAFT",          span.get(0).getRaw());
    }
    
    @Test
    public void mergeLineByEscape(){
        ManuscriptDocument doc = new ManuscriptDocument("#321\nmore text");
        doc.insertChar(4, '\\');
        assertEquals("#321\\\nmore text", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("#",   span.get(0).getRaw());
        
        span = (SpanBranch) span.get(1); /// Written Text
        span = (SpanBranch) span.get(0); /// Formatted Span
        assertEquals("321",              span.get(0).getRaw());
        assertEquals("\\",  ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("\n",  ((SpanBranch)span.get(1)).get(1).getRaw());
        assertEquals("more text",        span.get(2).getRaw());
    }
    
    @Test
    public void changeHeadingID(){
        ManuscriptDocument doc = new ManuscriptDocument("=@abc:{@ad}");
        doc.insertChar(3, 'k');
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 2, map.size());
        
        assertEquals("=@akbc:{@ad}", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        CatalogueData data = getData(map, getId("link", "akbc"));
        assertTrue("Span not found: " + span, data.getIds().contains(span));
        
        assertEquals("=",   span.get(0).getRaw());
        assertEquals("@",   span.get(1).getRaw());
        assertEquals("akbc", ((SpanBranch)span.get(2)).get(0).getRaw());
        assertEquals(":",   span.get(3).getRaw());
        
        
        span = (SpanBranch) span.get(4); /// Written Text
        span = (SpanBranch) span.get(0); /// Cite span
        data = getData(map, getId("note", "ad"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        assertEquals("{@",              span.get(0)        .getRaw());
        assertEquals("ad", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",               span.get(2)        .getRaw());
    }
    
    @Test
    public void changeCiteRef(){
        ManuscriptDocument doc = new ManuscriptDocument("=@abc:{@ad}");
        doc.insertChar(doc.getLength() - 2, 'k');
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 2, map.size());
        
        assertEquals("=@abc:{@akd}", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        CatalogueData data = getData(map, getId("link", "abc"));
        assertTrue("Span not found: " + span, data.getIds().contains(span));
        
        assertEquals("=",   span.get(0).getRaw());
        assertEquals("@",   span.get(1).getRaw());
        assertEquals("abc", ((SpanBranch)span.get(2)).get(0).getRaw());
        assertEquals(":",   span.get(3).getRaw());
        
        
        span = (SpanBranch) span.get(4); /// Written Text
        span = (SpanBranch) span.get(0); /// Cite span
        data = getData(map, getId("note", "akd"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        
        assertEquals("{@",               span.get(0)        .getRaw());
        assertEquals("akd", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",                span.get(2)        .getRaw());
    }
    
    @Test
    public void changeCiteCurly(){
        ManuscriptDocument doc = new ManuscriptDocument("=@abc:{@ad}");
        doc.insertChar(doc.getLength() - 1, 'k');
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 2, map.size());
        
        assertEquals("=@abc:{@adk}", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        CatalogueData data = getData(map, getId("link", "abc"));
        assertTrue("Span not found: " + span, data.getIds().contains(span));
        
        assertEquals("=",   span.get(0).getRaw());
        assertEquals("@",   span.get(1).getRaw());
        assertEquals("abc", ((SpanBranch)span.get(2)).get(0).getRaw());
        assertEquals(":",   span.get(3).getRaw());
        
        
        span = (SpanBranch) span.get(4); /// Written Text
        span = (SpanBranch) span.get(0); /// Cite span
        data = getData(map, getId("note", "adk"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        
        assertEquals("{@",               span.get(0)        .getRaw());
        assertEquals("adk", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",                span.get(2)        .getRaw());
    }
    
    @Test
    public void editNote(){
        ManuscriptDocument doc = new ManuscriptDocument("!%@abc:{@abc}");
        doc.insertChar(doc.getLength(), 'k');
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 1, map.size());
        
        assertEquals("!%@abc:{@abc}k", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Section;
        
        CatalogueData data = getData(map, getId("note", "abc"));
        assertTrue("Span not found: " + span, data.getIds().contains(span));
        
        span = (SpanBranch) span.get(0); /// Note
        assertEquals("!%",  span.get(0).getRaw());
        assertEquals("@",   span.get(1).getRaw());
        assertEquals("abc", ((SpanBranch)span.get(2)).get(0).getRaw());
        assertEquals(":",   span.get(3).getRaw());
        
        
        span = (SpanBranch) span.get(4); /// Written Text
        span = (SpanBranch) span.get(0); /// Cite span
        data = getData(map, getId("note", "abc"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        
        assertEquals("{@",               span.get(0)        .getRaw());
        assertEquals("abc", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",                span.get(2)        .getRaw());
        
        assertEquals("k", ((SpanBranch)span.getParent().get(1)).get(0).getRaw());
    }
    
    @Test
    public void toHeading(){
        ManuscriptDocument doc = new ManuscriptDocument("Canada{@ad}#DRAFT");
        doc.insertChar(0, '=');
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 1, map.size());
        
        assertEquals("=Canada{@ad}#DRAFT", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("=",   span.get(0).getRaw());
        
        span = (SpanBranch) span.get(1); /// Written Text
        assertEquals("Canada", ((SpanBranch)span.get(0)).get(0).getRaw());
        
        span = (SpanBranch) span.get(1); /// Cite
        CatalogueData data = getData(map, getId("note", "ad"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        
        assertEquals("ad", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",               span.get(2)        .getRaw());
        
        span = (SpanBranch) span.getParent().getParent().get(2);
        assertEquals("#DRAFT", span.get(0).getRaw());
    }
    
    @Test
    public void removeHeadingId(){
        ManuscriptDocument doc = new ManuscriptDocument("=@abc:{@ad}");
        doc.deleteChar(1);
        CatalogueMap map = doc.getMap();
        assertEquals("Wrong size.", 1, map.size());
        
        assertEquals("=abc:{@ad}", doc.getRaw());
                
        SpanBranch span =    doc.get(0); /// Scetion;
        span = (SpanBranch) span.get(0); /// Heading
        assertEquals("=",   span.get(0).getRaw());
        
        span = (SpanBranch) span.get(1); /// Written Text
        assertEquals("abc:", ((SpanBranch)span.get(0)).get(0).getRaw());
        
        span = (SpanBranch) span.get(1); /// Cite
        CatalogueData data = getData(map, getId("note", "ad"));
        assertTrue("Span not found: " + span, data.getRefs().contains(span));
        
        assertEquals("ad", ((SpanBranch)span.get(1)).get(0).getRaw());
        assertEquals("}",               span.get(2)        .getRaw());
    }
    
    private CatalogueIdentity getId(String cat, String id){
        return new CatalogueIdentity(Arrays.asList(cat), id);
    }
    
    private CatalogueData getData(CatalogueMap map, CatalogueIdentity id){
        CatalogueData data = map.get(id);
        assertNotNull("Id not found: " + id, map.get(id));
        return data;
        
    }
}
