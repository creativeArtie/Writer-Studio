package org.community.jwriter.markup;

public class DocumentHelper extends Document{
    
    public DocumentHelper(){}
    
    public DocumentHelper(String doc, SetupParser ... parsers){
        super(doc, parsers);
    }
    
    public static SetupPointer createEmptyPointer(){
        return SetupPointer.newPointer("", new DocumentHelper());
    }
}
