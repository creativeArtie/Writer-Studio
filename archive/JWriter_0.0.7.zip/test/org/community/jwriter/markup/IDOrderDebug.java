package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.Arrays;
import java.util.Optional;
import java.util.Set;

@RunWith(JUnit4.class)
public class IDOrderDebug extends IDTest{
    @Test
    public void subCategoryDirectorys(){
        addId(new CatalogueIdentity(Arrays.asList("abc", "dd"), "flies"), 0);
        addId(new CatalogueIdentity(Arrays.asList("abc", "dd"), "fly"  ), 1);
        testAll(true);
    }
    
    @Test
    public void mix(){
        addId(new CatalogueIdentity(Arrays.asList(""),    "id" ),2);
        addId(new CatalogueIdentity(Arrays.asList(),      "abc"),0);
        addId(new CatalogueIdentity(Arrays.asList(),      "kkk"),1);
        addId(new CatalogueIdentity(Arrays.asList("abc"), "ddd"),4);
        addId(new CatalogueIdentity(Arrays.asList("abc"), ""   ),3);
        testAll(true);
    }
    
    @Test
    public void sameCategory(){
        addId(new CatalogueIdentity(Arrays.asList("abc"), "de" ),3);
        addId(new CatalogueIdentity(Arrays.asList(),      "abc"),0);
        addId(new CatalogueIdentity(Arrays.asList("abc"), "aaa"),2);
        addId(new CatalogueIdentity(Arrays.asList("abc"), ""   ),1);
        testAll(true);
    }
    
    @Test
    public void subCategory(){
        addId(new CatalogueIdentity(Arrays.asList("a", "b"),"c"),1);
        addId(new CatalogueIdentity(Arrays.asList("a", ""), "d"),0);
        testAll(true);
    }
    
    @Test
    public void basicSimpleOrder(){
        addId(new CatalogueIdentity(Arrays.asList(), "aaa"),0); 
        addId(new CatalogueIdentity(Arrays.asList(), "ccc"),1); 
        testAll(true);
    }

}
