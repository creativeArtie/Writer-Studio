package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedPointerDebug{
    
    private final SetupParser[] parsers = LinedParsePointer.values();
        
    public static final SpanExpectHelper linkHelp(DirectoryType idType, 
            LinedType type, String id, String path){
        return span ->{
            assertEquals("Wrong class.", LinedSpanPointLink.class, 
                span.getClass());
            LinedSpanPointLink test = (LinedSpanPointLink) span;
            testCommon(test, idType, type, id);
            assertEquals("Wrong path.", path, test.getPath());
        };
    }
    
    public static final SpanExpectHelper noteHelp(DirectoryType idType, 
            LinedType type, String id, String docText){
        return span ->{
            assertEquals("Wrong class.", LinedSpanPointNote.class, 
                span.getClass());
            LinedSpanPointNote test = (LinedSpanPointNote) span;
            testCommon(test, idType, type, id);
            Optional<FormatSpanMain> formatted = test.getFormatted();
            if (docText != null){
                assertTrue("Text not found.", formatted.isPresent());
                assertEquals("Wrong text.", docText, formatted.get().getRaw());
            } else {
                assertFalse("Text is found.", formatted.isPresent());
            }
        };
    }
    
    private static void testCommon(LinedSpanPoint test, DirectoryType idType, 
            LinedType type, String id){
        assertEquals("Wrong CatalogueIdentity type.", idType, test.getDirectoryType());
        assertEquals("Wrong line type.", type, test.getType());
        if (id != null){
            String[] category = new String[]{idType.getCategory()};
            assertArrayEquals("Wrong category.", category, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
        } else {
            assertArrayEquals("Wrong category.", new String[0], 
                test.getCategory());
            assertEquals("Wrong id.", "", test.getIdentity());
        }
    }
    
    @Test
    public void linkFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "Reddit", "www.reddit.com"));
        line.addChild("!@", LinedType.HYPERLINK, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("Reddit", LinedType.HYPERLINK, CatalogueStatus.UNUSED, 
            SetupLeafStyle.ID);
        line.addChild(id);
        
        line.addChild(":", LinedType.HYPERLINK, SetupLeafStyle.KEYWORD);
        line.addGrandchild("www.reddit.com", LinedType.HYPERLINK, SetupLeafStyle.PATH);
        line.addChild("\n", LinedType.HYPERLINK, SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", "test"));
        line.addChildren("!@", "abc", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkPathLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", ""));
        line.addChildren("!@", "abc", ":");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkColonLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", ""));
        line.addChildren("!@", "abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoId(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, null, "test"));
        line.addChildren("!@", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", "test*hello*"));
        line.addChild("!*", LinedType.ENDNOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", LinedType.ENDNOTE, CatalogueStatus.UNUSED,
            SetupLeafStyle.ID);
        line.addChild(id);
        
        line.addChild(":", LinedType.ENDNOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("test", LinedType.ENDNOTE, SetupLeafStyle.TEXT);
        text.addChild("*", LinedType.ENDNOTE, SetupLeafStyle.KEYWORD);
        text.addGrandchild("hello", LinedType.ENDNOTE, FormatType.ITALICS, 
            SetupLeafStyle.TEXT);
        text.addChild("*", LinedType.ENDNOTE, SetupLeafStyle.KEYWORD);
        
        line.addChild(text);
        line.addChild("\n", LinedType.ENDNOTE, SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    
    @Test
    public void endnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", "test"));
        line.addChildren("!*", "abc", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteTextLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", null));
        line.addChildren("!*", "abc", ":");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteColonLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", null));
        line.addChildren("!*", "abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteIDlLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, null, "test"));
        line.addChildren("!*", ":", "test", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.FOOTNOTE, 
            LinedType.FOOTNOTE, "abc", "test"));
        line.addChild("!^", LinedType.FOOTNOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", LinedType.FOOTNOTE, CatalogueStatus.UNUSED,
            SetupLeafStyle.ID);
        line.addChild(id);
        
        line.addChild(":", LinedType.FOOTNOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("test", LinedType.FOOTNOTE, SetupLeafStyle.TEXT);
        line.addChild(text);
        
        line.addChild("\n", LinedType.FOOTNOTE, SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
