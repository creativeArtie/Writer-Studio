package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.Arrays;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedNoteDebug {

    private final SetupParser[] parsers = new SetupParser[]{LinedParseRest.NOTE};
        
    public static final SpanExpectHelper noteHelp(String text, 
        CatalogueIdentity id
    ){
        return span ->{
            assertEquals(LinedSpanNote.class, span.getClass());
            LinedSpanNote test = (LinedSpanNote) span;
            
            Optional<FormatSpanMain> formated = test.getFormatted();
            if (text != null){
                assertTrue("Text not found.", formated.isPresent());
                assertEquals("Wrong text.", text, formated.get().getRaw());
            } else {
                assertFalse("Text is found.", formated.isPresent());
            }
            assertEquals("Wrong type.", LinedType.NOTE, test.getType());
            
            Optional<CatalogueIdentity> found = test.getId();
            if (id == null){
                assertFalse("Id is found.", found.isPresent());
            } else {
                assertTrue("Id is not found.", found.isPresent());
                assertEquals("Wrong id", id, found.get());
            }
        };
    }
    
    private CatalogueIdentity buildId(String id){
        return new CatalogueIdentity(Arrays.asList(new String[]{"note"}), id);
    }
    
    @Test
    public void noteComplete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", buildId("id")));
        line.addChild("!%", LinedType.NOTE, SetupLeafStyle.KEYWORD);
        line.addChild("     @", LinedType.NOTE, SetupLeafStyle.KEYWORD);
        
        /// Note does not create id, see SupplementStatusDebug
        line.addChildren("id"); 
        
        line.addChild(":", LinedType.NOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("Text", LinedType.NOTE, SetupLeafStyle.TEXT);
        line.addChild(format);
        
        line.addChild("\n", LinedType.NOTE, SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noteWithoutNewLine(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", buildId("id")));
        line.addChildren( "!%", "     @", "id", ":", "Text");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void note(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", buildId("id")));
        line.addChildren( "!%", "@", "id", ":", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(null, buildId("id")));
        line.addChildren( "!%", "@", "id", ":", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noColon(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(null, buildId("id")));
        line.addChildren( "!%", "@", "id");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void blackID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", null));
        line.addChildren( "!%", "@", ":", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", null));
        line.addChildren( "!%", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void startOnly(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(null, null));
        line.addChild( "!%");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void startID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(null, null));
        line.addChildren("!%", "@");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
