package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatAgendaDebug{
    
    public static final SpanExpectHelper agendaHelp(String text){
        return span ->{
            assertEquals("Wrong span class", FormatSpanAgenda.class, 
                span.getClass());
            FormatSpanAgenda test = (FormatSpanAgenda) span;
            Optional<ContentSpan> agenda = test.getAgenda();
            if (text != null){
                assertTrue("Text not found.", agenda.isPresent());
                assertEquals("Wrong text.", text, agenda.get().getText());
            } else {
                assertFalse("Text is found.", agenda.isPresent());
            }
        };
    }
    
    private static final SetupParser[] parsers = new SetupParser[]{
        FormatParseAgenda.PARSER};

    @Test
    public void complete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("Agenda}"));
        agenda.addChild("{!", AuxiliaryStyle.AGENDA, SetupLeafStyle.KEYWORD);
        
        SpanExpect text = new SpanExpect();
        text.addChild("Agenda", AuxiliaryStyle.AGENDA, SetupLeafStyle.TEXT);
        
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", AuxiliaryStyle.AGENDA, AuxiliaryStyle.ESCAPE, SetupLeafStyle.KEYWORD);
        escape.addChild("}", AuxiliaryStyle.AGENDA, AuxiliaryStyle.ESCAPE, SetupLeafStyle.TEXT);
        text.addChild(escape);
        
        agenda.addChild(text);
        
        agenda.addChild("}", AuxiliaryStyle.AGENDA, SetupLeafStyle.KEYWORD);
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void noEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("abc"));
        agenda.addChildren("{!", "abc");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void onlyStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp(null));
        agenda.addChild("{!");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test 
    public void noText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp(null));
        agenda.addChild("{!");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
        
}
    
