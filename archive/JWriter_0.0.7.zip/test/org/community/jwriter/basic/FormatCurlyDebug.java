package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatCurlyDebug {
    
    public static final SpanExpectHelper noteHelp(DirectoryType type, 
        String[] expectRef, String expectId, CatalogueStatus status)
    {
        return span ->{
            assertEquals("Wrong span class", FormatSpanDirectory.class,
                span.getClass());
            FormatSpanDirectory test = (FormatSpanDirectory) span;
            assertEquals("Wrong note type", type, test.getType());
            assertArrayEquals("Wrong Category.", expectRef, test.getCategory());
            assertEquals("Wrong id.", expectId, test.getIdentity());
            assertEquals("Wrong status", status, test.getStatus());
        };
    }
    
    public static final SpanExpectHelper noteHelp(DirectoryType type, 
        String[] expectRef, String expectId
    ){
        return noteHelp(type, expectRef, expectId, CatalogueStatus.NOT_FOUND);
    }
    public static final SpanExpectHelper noteHelp(DirectoryType type){
        return noteHelp(type, new String[0], "", CatalogueStatus.NO_ID);
    }
    
    private static final SetupParser[] parsers = 
        FormatParseDirectory.getParsers(new boolean[4]);

    @Test
    public void cite(){
        SpanExpect doc = new SpanExpect();
        SpanExpect note = new SpanExpect(noteHelp(
            DirectoryType.NOTE, new String[]{"note"}, "\\abc"));
        note.addChild("{@", DirectoryType.NOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        SpanExpect text = new SpanExpect();
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", DirectoryType.NOTE, CatalogueStatus.NOT_FOUND, 
            AuxiliaryStyle.ESCAPE, SetupLeafStyle.KEYWORD);
        escape.addChild("\\", DirectoryType.NOTE, CatalogueStatus.NOT_FOUND, 
            AuxiliaryStyle.ESCAPE, SetupLeafStyle.ID);
        text.addChild(escape);
        text.addChild("abc", DirectoryType.NOTE, CatalogueStatus.NOT_FOUND, 
            SetupLeafStyle.ID);
        id.addChild(text);
        note.addChild(id);
        
        note.addChild("}", DirectoryType.NOTE, SetupLeafStyle.KEYWORD);
        doc.addChild(note);
        doc.testAll(parsers);
    }

    @Test
    public void endnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect endnote = new SpanExpect(noteHelp(
            DirectoryType.ENDNOTE, new String[]{"end"}, "abc"));
        endnote.addChild("{*", DirectoryType.ENDNOTE, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", DirectoryType.ENDNOTE, CatalogueStatus.NOT_FOUND, 
            SetupLeafStyle.ID);
        endnote.addChild(id);
        
        endnote.addChild("}", DirectoryType.ENDNOTE, SetupLeafStyle.KEYWORD);
        doc.addChild(endnote);
        doc.testAll(parsers);
    }

    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect footnote = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[]{"foot"}, "abc"));
        footnote.addChild("{^");
        footnote.addChild("abc");
        footnote.addChild("}");
        doc.addChild(footnote);
        doc.testAll(parsers);
    }

    @Test
    public void noEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect footnote = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[]{"foot"}, "abc"));
        footnote.addChild("{^");
        footnote.addChild("abc");
        doc.addChild(footnote);
        doc.testAll(parsers);
    }

    @Test
    public void onlyStart(){
        SpanExpect doc = new SpanExpect();
        doc.addGrandchild("{^", DirectoryType.FOOTNOTE, AuxiliaryStyle.NO_ID, 
            SetupLeafStyle.KEYWORD);
        doc.testAll(parsers);
    }

    @Test
    public void noText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect footnote = new SpanExpect(noteHelp(DirectoryType.FOOTNOTE));
        footnote.addChild("{^");
        footnote.addChild("}");
        doc.addChild(footnote);
        doc.testAll(parsers);
    }
}
