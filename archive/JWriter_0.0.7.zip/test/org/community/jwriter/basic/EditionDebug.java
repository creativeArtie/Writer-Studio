package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class EditionDebug {

    public static final SpanExpectHelper statusHelp(EditionType type, 
            String text){
        return span ->{
            assertEquals("Wrong class gotten: " + span.getClass(), 
                EditionSpan.class, span.getClass());
            EditionSpan test = (EditionSpan) span;
            assertEquals("Wrong type.", type, test.getType());
            if (text == null){
                assertFalse("Fond detail.", test.getDetail().isPresent());
            } else {
                Optional<ContentSpan> detail = test.getDetail();
                assertTrue("Detail not found.", detail.isPresent());
                assertEquals("Wrong detail.", text, detail.get().getText());
            }
        };
    }
    
    private static final SetupParser[] parsers = EditionParser.values();
    
    @Test
    public void statusOtherBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "abc"));
        ref.addChild("#", EditionType.OTHER, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("abc", EditionType.OTHER, SetupLeafStyle.TEXT);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusEscaped(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "FINAL"));
        ref.addChild("#");
        ref.addChild("\\FINAL");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusEmpty(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, null));
        ref.addChild("#");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusStub(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.STUB, "d2"));
        ref.addChild("#STUB", EditionType.STUB, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("d2", EditionType.STUB, SetupLeafStyle.TEXT);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, null));
        ref.addChild("#FINAL", EditionType.FINAL, SetupLeafStyle.KEYWORD);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalTrim(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "2"));
        ref.addChild("#FINAL", EditionType.FINAL, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("  2  ", EditionType.FINAL, SetupLeafStyle.TEXT);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalMidSpanced(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "abc ad"));
        ref.addChildren("#FINAL", "abc  ad");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusDraft(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(EditionType.DRAFT, "ccc"));
        ref.addChild("#DRAFT");
        SpanExpect text = new SpanExpect();
        text.addChild("cc", EditionType.DRAFT, SetupLeafStyle.TEXT);
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", EditionType.DRAFT, AuxiliaryStyle.ESCAPE, SetupLeafStyle.KEYWORD);
        escape.addChild("c", EditionType.DRAFT, AuxiliaryStyle.ESCAPE, SetupLeafStyle.TEXT);
        text.addChild(escape);
        ref.addChild(text);
        doc.addChild(ref);
        doc.testAll(parsers);
    }

}
