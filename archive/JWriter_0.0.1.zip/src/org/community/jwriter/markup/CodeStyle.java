package org.community.jwriter.markup;

public class CodeStyle {
	private final int start;
	private final int end;
	private final String style;
	
	public CodeStyle(int textStart, int textEnd, String styleClass){
		start = textStart;
		end = textEnd;
		style = styleClass;
	}
	
	public int getStart(){
		return start;
	}
	public int getEnd(){
		return end;
	}
	public String getStyleClass(){
		return style;
	}
}
