package org.community.jwriter.markup;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

/**
 * {@code Document} is what {@link org.community.jwriter.window} and 
 * {@link org.community.output} use to represent the text file. This will
 * immediately parse the document upon the constructor.
 */
public final class Document extends SpanNode<SpanBranch>{

	private final ImmutableList<SpanBranch> nodes;
	private final IDMap idMap;
	
	public Document(String doc, Parser<?> ... init){
		/// Setup for runtime exceptions
		int counter = 0; 
		
		/// Setup for building the doc and a pointer to use
		ImmutableList.Builder<SpanBranch> children = ImmutableList.builder();
		Pointer ptr = new Pointer(doc);
		
		/// Parse loop
		while (ptr.hasNext()){
			/// IDStatus checking what happen if Pointer fails or Parser[] misses 
			/// the texts
			if(counter > doc.length()){
				System.out.println(children.build());
				System.out.println(ptr);
				throw new RuntimeException("Loop too much");
			}
			counter++;
			
			/// Finding the correct Parser to build span from
			for(Parser<?> s: init){
				Optional<? extends Span> span = s.parse(ptr);
				
				//Span has been created
				if (span.isPresent()){
					children.add((SpanBranch)span.get());
					break;
				}
			}
		}
		
		/// Finalize the parse loop
		nodes = children.build();
		idMap = ptr.getMap().build();
	}
	
	@Override
	public List<SpanBranch> delegate(){
		return nodes;
	}
	
	public IDMap getMap(){
		return idMap;
	}
	
	public String toString(){
		return super.toString() + idMap.toString();
	}
}
