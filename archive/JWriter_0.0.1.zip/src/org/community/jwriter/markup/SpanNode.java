package org.community.jwriter.markup;

import java.util.List;

import com.google.common.collect.ForwardingList;

/**
 * Common methods for {@link Document} and {@link SpanBranch}.
 */
public abstract class SpanNode<T extends Span> extends ForwardingList<T> implements Span {
	
	public SpanNode(){}
	
	@Override
	public final String getDoc(){
		StringBuilder builder = new StringBuilder();
		
		for (Span span: this){
			builder.append(span.getDoc());
		}
		return builder.toString();
	}
	
	// public abstract List<CodeStyle> getStyles();
}
