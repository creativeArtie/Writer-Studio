package org.community.jwriter.markup;

import java.util.List;

import com.google.common.collect.ImmutableList;

/**
 * A {@link Span} handling {@link SpanLeaf}
 */
public class SpanBranch extends SpanNode<Span> {
	
	private final ImmutableList<Span> spans;
	
	public SpanBranch (List<Span> children){
		spans = ImmutableList.copyOf(children);
	}
	
	@Override
	public final List<Span> delegate(){
		return spans;
	}
}
