package org.community.jwriter.markup;

	
/**
 * Types of error with the ID.
 */
public enum IDStatus{
	/// There is an id but nothing is refer to it
	UNUSED,
	/// A reference that pointing to no known ID. 
	NOT_FOUND, 
	/// More than one ID has the same name
	MUTILPLE, 
	/// No error is found.
	NONE;
}
