package org.community.jwriter.markup;

import java.util.ArrayList;
import com.google.common.collect.ImmutableList;

public class IDData{
	private final ImmutableList<Span> targets;
	private final ImmutableList<Span> pointers;
	private final IDStatus status;
	
	static class Builder{
		private ArrayList<Span> tBuild;
		private ArrayList<Span> pBuild;
		
		private Builder(){
			tBuild = new ArrayList<>();
			pBuild = new ArrayList<>();
		}
		
		void addID(Span span){
			tBuild.add(span);
		}
		
		void addRef(Span span){
			pBuild.add(span);
		}
		
		void removeLastID(){
			tBuild.remove(tBuild.size() - 1);
		}
		
		void removeLastRef(){
			pBuild.remove(pBuild.size() - 1);
		}
		
		IDData build(){
			return new IDData(tBuild, pBuild);
		}
	}
	
	static Builder builder(){
		return new Builder();
	}
	
	private IDData (ArrayList<Span> t, ArrayList<Span> p){
		targets = ImmutableList.copyOf(t);
		pointers = ImmutableList.copyOf(p);
		if (targets.size() > 1){
			status = IDStatus.MUTILPLE;
		} else if (targets.size() == 0){
			status = IDStatus.NOT_FOUND;
		} else {
			status = pointers.size() > 0? IDStatus.NONE: IDStatus.UNUSED;
		}
	}
	
	public IDStatus getStatus(){
		return status;
	}
	public Span getTarget(){
		if (targets.size() == 1){
			targets.get(0);
		}
		throw new IllegalStateException("ID Data is in the wrong state: " 
			+ status);
	}
	
	public ImmutableList<Span> getIDs(){
		return targets;
	}
	
	public ImmutableList<Span> getRefs(){
		return pointers;
	}
	
	public String toString(){
		return status.toString() + "\nIDS{\n\t" + 
			targets.toString().replace("\n", "\n\t") + "\n}\nRefs{" +
			pointers.toString();
	}
}
