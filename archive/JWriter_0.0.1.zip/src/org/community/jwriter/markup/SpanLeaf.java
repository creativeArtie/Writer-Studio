package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf implements Span{
	private final String text;
	private final int start;
	private final int end;
	
	public SpanLeaf(Pointer pointer){
		start = pointer.getStart();
		end = pointer.getEnd();
		text = pointer.getDoc();
		pointer.roll();
	}
	
	@Override
	public final String getDoc(){
		return text;
	}
	
	public final int getStart(){
		return start;
	}
	
	public final int getEnd(){
		return end;
	}
	
	@Override
	public String toString(){
		return "\"" + text.replace("\n", "\" \\n \"").replace("\t", "\" \\t \"") 
			+ "\"";
	}
}
