package org.community.jwriter.markup;

/**
 * A subdivision of a {@link Document}
 */
public interface Span{
	
	/**
	 * Get the raw document for saving and for markup editor.
	 */
	public String getDoc();
}
