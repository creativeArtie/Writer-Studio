package org.community.jwriter.markup;

import java.util.Optional;

public interface IDHolder extends Comparable<IDHolder>{
	public Optional<ID> getID();

	public default String[] getCategory(){
		Optional<ID> id = getID();
		return getID().isPresent()? id.get().getCategory(): new String[0];
	}
	
	public default String getIdentity(){
		Optional<ID> id = getID();
		return id.isPresent()? id.get().getIdentity(): "";
	}
	
	public default int compareTo(IDHolder holder){
		Optional<ID> id = getID();
		if (id.isPresent()){
			Optional<ID> id2 = holder.getID();
			if (id2.isPresent()){
				return id.get().compareTo(id2.get());
			}
			return 1;
		}
		return -1;
	}
}
