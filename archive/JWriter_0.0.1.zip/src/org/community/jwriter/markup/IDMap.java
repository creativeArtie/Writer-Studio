package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ForwardingMap;

/**
 * A System of {@link IDSpan} references with their status
 */
public final class IDMap extends ForwardingMap<ID, IDData>{
	private final ImmutableMap<ID, IDData> ids;
	
	/**
	 * Builds the IDMap.
	 */
	public static class Builder{
		private TreeMap<ID, IDData.Builder> idBuilders;
		private Optional<ID> lastID;
		private Optional<ID> lastRef;
		
		private Builder(){
			idBuilders = new TreeMap<>();
			lastID = Optional.empty();
			lastRef = Optional.empty();
		}
		
		public void addID(ID id, Span value){
			if (idBuilders.containsKey(id)){
				idBuilders.get(id).addID(value);
			} else {
				IDData.Builder data = IDData.builder();
				data.addID(value);
				idBuilders.put(id, data);
			}
			lastID = Optional.of(id);
		}
		
		public void removeLastID(){
			lastID.ifPresent(id -> idBuilders.get(id).removeLastID());
		}
		
		public void addRef(ID id, Span value){
			if (idBuilders.containsKey(id)){
				idBuilders.get(id).addRef(value);
			} else {
				IDData.Builder data = IDData.builder();
				data.addRef(value);
				idBuilders.put(id, data);
			}
			lastRef = Optional.of(id);
		}
		
		public void removeLastRef(){
			lastRef.ifPresent(id -> idBuilders.get(id).removeLastRef());
		}
		
		IDMap build(){
			ImmutableMap.Builder<ID, IDData> data = ImmutableMap.builder();
			for(Entry<ID, IDData.Builder> entry: idBuilders.entrySet()){
				data.put(entry.getKey(), entry.getValue().build());
			}
			return new IDMap(data.build());
		}
	}
	
	public static Builder builder(){
		return new Builder();
	}
	
	public ImmutableMap<ID, IDData> delegate(){
		return ids;
	}
	
	private IDMap(ImmutableMap<ID, IDData> data){
		ids = data;
	}
}
