package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanSection extends LinedSpanLevel implements IDHolder{
	private final Optional<ID> id;
	private final Optional<StatusSpan> status;

	LinedSpanSection(List<Span> children, int levelDepth, 
			LinedType spanType, Optional<IDSpan> spanID, 
			Optional<FormatSpan> text, Optional<StatusSpan> spanStatus){
		super(children, levelDepth, spanType, text);
		id = IDSpan.getIDHelper(spanID);
		
		status = spanStatus;
	}
	
	public StatusType getStatus(){
		return status.isPresent()? status.get().getType(): StatusType.NONE;
	}
	
	@Override
	public Optional<ID> getID(){
		return id;
	}
}
