package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanNote extends LinedSpan implements IDHolder{
	private final Optional<ID> id;
	private final FormatSpan text;
	
	public LinedSpanNote(ImmutableList<Span> children, Optional<IDSpan> idSpan, 
			Optional<FormatSpan> textSpan){
		super(children, LinedType.NOTE);
		id = IDSpan.getIDHelper(idSpan);
		text = textSpan.isPresent()? textSpan.get(): new FormatSpan();
	}
	
	@Override
	public Optional<ID> getID(){
		return id;
	}
	
	public FormatSpan getText(){
		return text;
	}
	
	public boolean hasIDSpan(){
		return id.isPresent();
	}
}
