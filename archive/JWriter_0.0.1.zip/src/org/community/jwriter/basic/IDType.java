package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.Objects;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public enum IDType{
	FOOTNOTE("foot"), ENDNOTE("end"), LINK("link"), NOTE("note"), NONE("");
	
	private String categoryName;
	
	private IDType(String name){
		categoryName = name;
	}
	
	public String getCategory(){
		return categoryName;
	}
}
