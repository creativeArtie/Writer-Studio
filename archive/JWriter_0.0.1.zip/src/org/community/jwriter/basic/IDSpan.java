package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.Objects;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} that is an ID pointing to somewhere in the {@link Document}.
 */
public class IDSpan extends SpanBranch{
	private final IDType type;
	private final ID id;
	
	static Optional<ID> getIDHelper(Optional<IDSpan> id){
		return id.isPresent()? Optional.of(id.get().getID()): Optional.empty();
	}
	
	public static ImmutableList<Span> combine(Optional<FormatSpan> text1, 
			Optional<FormatSpan> text2){
		ImmutableList.Builder<Span> texts = ImmutableList.builder();
		text1.ifPresent(text -> texts.addAll(text));
		if (text1.isPresent() && text2.isPresent()){
			texts.add(() ->{return " ";});
		}
		text2.ifPresent(text -> texts.addAll(text));
		return texts.build();
	}
	
	IDSpan(List<Span> children, List<String> categories, 
			Optional<ContentSpan> idSpan, IDType idType){
		super(children);
		ImmutableList.Builder<String> builder = ImmutableList.builder();
		if (idType != IDType.NONE) builder.add(idType.getCategory());
		builder.addAll(categories);
		id = new ID(builder.build(),
			idSpan.isPresent()? idSpan.get().getOutput(): ""
		);
		type = idType;
	}
	
	public ID getID(){
		return id;
	}
	
	public IDType getType(){
		return type;
	}
	
	public String toString(){
		return "[" + id.getFullID() + "]";
	}
}
