package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link Parser} for create section status. Will warn if #FINAL is not on all
 * headings and outline (unless the user allows headings and outline with out
 * {@code #FINAL} to be call final draft.
 */
enum StatusParser implements Parser<StatusSpan>{
	STUB, DRAFT, FINAL, OTHER(){
		@Override
		public Optional<StatusSpan> parse(Pointer pointer){
			ImmutableList.Builder<Span> children = ImmutableList.builder();
			if (pointer.startsWith(children, STATUS_BEGIN)){
				return setUp(children, pointer);
			}
			return Optional.empty();
		}
	};
	
	static String getSTATUS_BEGIN(){
		return STATUS_BEGIN;
	}
	
	static Optional<StatusSpan> parseAll(ImmutableList.Builder<Span> children, 
			Pointer pointer){
		for(StatusParser parser: values()){
			Optional<StatusSpan> ans = parser.parse(children, pointer);
			if (ans.isPresent()){
				return ans;
			}
		}
		return Optional.empty();
	}
	
	protected Optional<StatusSpan> setUp(ImmutableList.Builder<Span> children, 
			Pointer pointer){
		
		/// Add the meta text, if any found
		Optional<ContentSpan> text = new ContentParser().parse(children, pointer);
		
		return Optional.of(new StatusSpan(children.build(), 
			StatusType.values()[ordinal()], text));
		
	}
	
	@Override
	public Optional<StatusSpan> parse(Pointer pointer){
		ImmutableList.Builder<Span> children = ImmutableList.builder();
		if (pointer.startsWith(children, STATUS_BEGIN + name())){
			return setUp(children, pointer);
		}
		return Optional.empty();
	}
}
