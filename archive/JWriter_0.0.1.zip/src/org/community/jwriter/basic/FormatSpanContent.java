package org.community.jwriter.basic;

import java.util.List;
import org.community.jwriter.markup.*;

/**
 * A {@link ContentSpan} with format for {@link FormatSpan}. 
 */
public class FormatSpanContent extends ContentSpan {
	private final boolean bold;
	private final boolean italics;
	private final boolean underline;
	private final boolean coded; 
	
	FormatSpanContent(boolean[] formats, ContentSpan children){
		super(children);
		bold = formats[0];
		italics = formats[1];
		underline = formats[2];
		coded = formats[3];
	}
	
	public boolean isBold(){
		return bold;
	}
	
	public boolean isItalics(){
		return italics;
	}
	
	public boolean isUnderline(){
		return underline;
	}
	
	public boolean isCoded(){
		return coded;
	}
	
}
