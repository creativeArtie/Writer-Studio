package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.community.jwriter.markup.*;

public class LinedSpan extends SpanBranch {
	private final LinedType type;
	
	LinedSpan(List<Span> children, LinedType t){
		super(children);
		type = t;
	}
	
	public LinedType getType(){
		return type;
	}
	
	public String toString(){
		return type + super.toString();
	}
}
