package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public abstract class LinedSpanPoint extends LinedSpan implements IDHolder{
	private final IDType type;
	private final Optional<ID> idSpan;

	LinedSpanPoint(List<Span> children, LinedType spanType, 
			Optional<IDSpan> foundID){
		super(children, spanType);
		idSpan = IDSpan.getIDHelper(foundID);
		type = idSpan.isPresent()? foundID.get().getType(): IDType.NONE;
	}
	
	public IDType getIDType(){
		return type;
	}
	
	@Override
	public Optional<ID> getID(){
		return idSpan;
	}
}
