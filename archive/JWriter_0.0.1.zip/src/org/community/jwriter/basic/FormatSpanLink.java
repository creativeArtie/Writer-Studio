package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A formatted {@link Span} for common methods in {@link FormatSpanLinkDirect} 
 * and {@link FormatSpanLinkRef}.
 */
public abstract class FormatSpanLink extends SpanBranch {
	
	FormatSpanLink(List<Span> children){
		super(children);
	}
	
	/**
	 * Return the path of the link
	 */
	public abstract String getPath();
	
	/**
	 * Return the display output text.
	 */
	public abstract String getOutput();
}
