package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@link FormatSpanLink} with path located somewhere in the document.
 */
public final class FormatSpanLinkRef extends FormatSpanLink implements 
		IDHolder{
	private final String text;
	private final Optional<ID> idSpan;
	
	FormatSpanLinkRef(List<Span> children, 
			Optional<IDSpan> inputID, Optional<ContentSpan> textSpan){
		super(children);
		idSpan = IDSpan.getIDHelper(inputID);
		text = textSpan.isPresent()? textSpan.get().getOutput(): ""; //TODO
	}
	
	public String getPath(){
		return ""; //TODO 
	}
	
	public String getOutput(){
		return text;
	}

	@Override
	public Optional<ID> getID(){
		return idSpan;
	}
}
