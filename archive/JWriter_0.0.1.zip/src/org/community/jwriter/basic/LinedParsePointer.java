package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParsePointer implements Parser<LinedSpan> {
	FOOTNOTE(LINED_FOOTNOTE), ENDNOTE(LINED_ENDNOTE), HYPERLINK(LINED_LINK);
	
	private String starter;
	
	private LinedParsePointer(String start){
		starter = start;
	}
	
	@Override
	public Optional<LinedSpan> parse(Pointer pointer){
		ImmutableList.Builder<Span> children = ImmutableList.builder();
		if (pointer.startsWith(children, starter)){
			
			IDType idType = IDType.values()[ordinal()];
			Optional<IDSpan> id = new IDParser(idType, LINED_DATA)
				.parse(children, pointer);
				
			if (this == HYPERLINK){
				Optional<ContentSpan> path = Optional.empty();
				if (pointer.startsWith(children, LINED_DATA)){
				path = new ContentParser().parse(children, 
					pointer);
				}
				pointer.startsWith(children, LINED_END);
				LinedSpanPointLink ans = 
					new LinedSpanPointLink(children.build(), id, path);
				id.ifPresent(ptr -> pointer.getMap().addID(ptr.getID(), ans));
				return Optional.of(ans);
			}
			
			Optional<FormatSpan> text = Optional.empty();
			
			if (pointer.startsWith(children, LINED_DATA)){
				text = new FormatParser(LINED_DATA).parse(children, pointer);
			}
			pointer.startsWith(children, LINED_END);
			
			LinedType type = LinedType.values()
				[LinedType.HYPERLINK.ordinal() + ordinal() + 1];
			
			LinedSpanPointNote ans = 
				new LinedSpanPointNote(children.build(), type, id, text);
			id.ifPresent(ptr -> pointer.getMap().addID(ptr.getID(), ans));
			return Optional.of(ans);
		}
		return Optional.empty();
	}
}
