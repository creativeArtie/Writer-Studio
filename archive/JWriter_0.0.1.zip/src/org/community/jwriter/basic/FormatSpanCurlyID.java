package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@linkplain FormatSpanCurly} for id referance. This has a span where it is
 * reference to
 */
public final class FormatSpanCurlyID extends FormatSpanCurly implements IDHolder {
	private final IDType type;
	private final Optional<ID> refSpan;
	
	FormatSpanCurlyID(List<Span> children, Optional<IDSpan> refData, 
			IDType curlyType){
		super(children);
		type = curlyType;
		refSpan = IDSpan.getIDHelper(refData);
	}
	
	public IDType getType(){
		return type;
	}
	
	@Override
	public Optional<ID> getID(){
		return refSpan;
	}

}
