package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@link FormatSpanLink} with path indicated right in the text.
 */
public class FormatSpanLinkDirect extends FormatSpanLink {

	private final String path;
	private final String text;
	
	FormatSpanLinkDirect(List<Span> children, Optional<ContentSpan> linkSpan, 
			Optional<ContentSpan> textSpan){
		super(children);
		path = linkSpan.isPresent()? linkSpan.get().getOutput(): "";
		text = textSpan.isPresent()? textSpan.get().getOutput(): path;
	}
	
	public String getPath(){
		return path;
	}
	
	public String getOutput(){
		return text;
	}

}
