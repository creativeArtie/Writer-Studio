package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Parser that related to {@link FormatSpanContent}. This shows the start of a span.
 */
enum FormatParseContent implements Parser<SpanLeaf>{
	BOLD(FORMAT_BOLD), ITALICS(FORMAT_ITALICS), 
	UNDERLINE(FORMAT_UNDERLINE), CODED(FORMAT_CODED);
	
	private final String marker;
	
	@Override
	public Optional<SpanLeaf> parse(Pointer pointer){
		if(pointer.startsWith(marker)){
			return Optional.of(new SpanLeaf(pointer));
		}
		return Optional.empty();
	}
	
	private FormatParseContent(String symbol){
		marker = symbol;
	}
}
