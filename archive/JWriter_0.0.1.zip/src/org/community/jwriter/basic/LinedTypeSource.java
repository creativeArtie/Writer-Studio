package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.base.CaseFormat;
import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public enum LinedTypeSource{
	AUTHOR, EDITOR, TRANSLATOR, ARTICLE, TITLE, EDITION, PUBLISH_HOUSE, 
	PUBLISH_YEAR, MEDIA, ACCESS_LOCATION, ACCESS_DATE, PAGES, ERROR;
	
	public String getCode(){
		return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, name());
	}
}
