package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanPointLink extends LinedSpanPoint {
	private String path;

	LinedSpanPointLink(List<Span> children, Optional<IDSpan> idSpan, 
			Optional<ContentSpan> pathSpan){
		super(children, LinedType.HYPERLINK, idSpan);
		path = pathSpan.isPresent()? pathSpan.get().getOutput(): "";
	}
	
	public String getPath(){
		return path;
	}
}
