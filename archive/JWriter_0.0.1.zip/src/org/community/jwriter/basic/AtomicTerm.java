package org.community.jwriter.basic;

/**
 * All character strings that is used in some form or another.
 */
public final class AtomicTerm{
	public static final int LEVEL_MAX = 6;
	private static final String LEVEL_BEGIN = "\t";
	private static final String LEVEL_HEADING = "=";
	private static final String LEVEL_NUMBERED = "#";
	private static final String LEVEL_OUTLINE = "#";
	private static final String LEVEL_BULLET = "-";
	private static final String LEVEL_QUOTE = ">";
	private static String repeat(String ch, int level){
		StringBuilder builder = new StringBuilder();
		for(int i = 0; i < level; i++){
			builder.append(ch);
		}
		return builder.toString();
	}
	public static String getLinedLevel(LinedParseLevel from, int level){
		switch (from){
			case HEADING:
				return repeat(LEVEL_HEADING, level);
			case OUTLINE:
				return LINED_BEGIN + repeat(LEVEL_OUTLINE, level);
			case QUOTE:
				return repeat(LEVEL_QUOTE, level);
			case NUMBERED:
				return repeat(LEVEL_BEGIN, level - 1) + LEVEL_NUMBERED;
			case BULLET:
				return repeat(LEVEL_BEGIN, level - 1) + LEVEL_BULLET;
		}
		throw new IllegalArgumentException("LinedLevelParser not used.");
	}
	
	public static final String LINED_BEGIN = "!";
	public static final String LINED_DATA = ":";
	public static final String LINED_NAME = ",";
	public static final String LINED_END = "\n";
	public static final String LINED_AGENDA = LINED_BEGIN + "!";
	public static final String LINED_NOTE = LINED_BEGIN + "%";
	public static final String LINED_SOURCE = LINED_BEGIN + ">";
	public static final String LINED_LINK = LINED_BEGIN + "@";
	public static final String LINED_FOOTNOTE = LINED_BEGIN + "^";
	public static final String LINED_ENDNOTE = LINED_BEGIN + "*";
	public static final String LINED_BREAK = "***\n";
	
	public static final String ID_BEGIN = "@";
	public static final String ID_CATEGORY = "-";
	public static final String ID_END = ":";
	public static final String STATUS_BEGIN = "#";
	
	public static final String LINK_BEGIN = "<";
	public static final String LINK_REF = LINK_BEGIN + "@";
	public static final String LINK_TEXT = "|";
	public static final String LINK_END = ">";
	
	private static final String CURLY_BEGIN = "{";
	public static final String CURLY_AGENDA = CURLY_BEGIN + "!";
	public static final String CURLY_FOOTNOTE = CURLY_BEGIN + "^";
	public static final String CURLY_ENDNOTE = CURLY_BEGIN + "*";
	public static final String CURLY_CITE = CURLY_BEGIN + ID_BEGIN;
	public static final String CURLY_END = "}";
	
	public static final String FORMAT_ITALICS = "*";
	public static final String FORMAT_BOLD = "**";
	public static final String FORMAT_UNDERLINE = "_";
	public static final String FORMAT_CODED = "`";
	public static final String FORMAT_ESCAPE = "\\";
	public static String[] listFormatEnders(){
		return new String[]{CURLY_AGENDA, CURLY_FOOTNOTE, CURLY_ENDNOTE,
			CURLY_CITE, CURLY_END, LINK_BEGIN, LINK_REF, FORMAT_ITALICS,
			FORMAT_BOLD, FORMAT_UNDERLINE, FORMAT_CODED, FORMAT_ESCAPE};
	}
	private AtomicTerm(){}
}
