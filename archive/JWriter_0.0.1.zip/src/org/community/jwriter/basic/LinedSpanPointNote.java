package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanPointNote extends LinedSpanPoint {
	private FormatSpan text;

	LinedSpanPointNote(List<Span> children, LinedType spanType, 
			Optional<IDSpan> idSpan, Optional<FormatSpan> textSpan){
		super(children, spanType, idSpan);
		text = textSpan.isPresent()? textSpan.get(): new FormatSpan();
	}
	
	public FormatSpan getText(){
		return text;
	}
}
