package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.LINED_NAME;

public class LinedSpanCiteName extends LinedSpanCite {
	
	private final String first;
	private final String last;
	
	public LinedSpanCiteName(ImmutableList<Span> children, 
			LinedTypeSource type, Optional<ContentSpan> lastName, 
			Optional<ContentSpan> firstName){
		super(children, type);
		first = firstName.isPresent()? firstName.get().getOutput():"";
		last = lastName.isPresent()? lastName.get().getOutput():"";
	}
	
	public String getFirstName(){
		return first;
	}
	
	public String getLastName(){
		return last;
	}
	
	public String getOutput(){
		return last + LINED_NAME + " " + first;
	}
}
