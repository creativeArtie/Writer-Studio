package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanCiteText extends LinedSpanCite {
	private final String data;
	
	public LinedSpanCiteText(ImmutableList<Span> children, LinedTypeSource type,
			Optional<ContentSpan> textSpan){
		super(children, type);
		data = textSpan.isPresent()? textSpan.get().getOutput(): "";
	}
	
	public String getData(){
		return data;
	}
	
	@Override
	public String getOutput(){
		return data;
	}
}
