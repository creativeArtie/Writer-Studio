package org.community.jwriter.basic;

public enum StatusType {
	STUB, DRAFT, FINAL, OTHER, NONE;
}
