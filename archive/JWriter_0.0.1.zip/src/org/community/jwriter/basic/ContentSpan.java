package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} for text and super class of {@link FormatSpanContent}.
 */
public class ContentSpan extends SpanBranch{
	
	private final String output;
	
	ContentSpan(){
		super(new ArrayList<>());
		output = "";
	}
	
	ContentSpan (List<Span> children){
		super(children);
		
		/// Create a display output text
		StringBuilder builder = new StringBuilder();
		for(Span child: children){
			if (child instanceof SpanLeaf){
				/// Add text from a basic span
				builder.append(child.getDoc());
			} else {
				/// Add escape text but only for the second span.
				SpanBranch escape = (SpanBranch) child;
				if (escape.size() == 2){
					builder.append(escape.get(1).getDoc());
				}
			}
		}
		/// combine mutiple spaces into one.
		output = Joiner.on(" ").join(Splitter.on(CharMatcher.whitespace())
			.omitEmptyStrings().split(builder.toString()));
	}
	
	public String getOutput(){
		return output;
	}
}
