package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link Span} for id with categories.
 */
final class IDParser implements Parser<IDSpan>{
	private final ContentParser idParser;
	private final IDType type;
	
	IDParser(IDType idType, String ... enders){
		String[] init = new String[enders.length + 1];
		System.arraycopy(enders, 0, init, 0, enders.length);
		init[enders.length] = ID_CATEGORY;
		idParser = new ContentParser(init);
		type = idType;
	}
	
	@Override
	public Optional<IDSpan> parse(Pointer pointer){
		
		/// Setup for IDSpan
		ImmutableList.Builder<Span> children = ImmutableList.builder();
		ImmutableList.Builder<String> cat = ImmutableList.builder();
		
		boolean hasMore = true;
		Optional<ContentSpan> current;
		do {
			current = idParser.parse(children, pointer); 
			
			if (pointer.startsWith(children, ID_CATEGORY)){
				cat.add(current.isPresent()? current.get().getOutput(): "");
				current = Optional.empty();
				hasMore = true;
			} else {
				hasMore = false;
			}
		} while (hasMore);
		
		ImmutableList<Span> spans = children.build();
		if (spans.size() > 0) {
			return Optional.of(new IDSpan(spans, cat.build(), current, type));
		}
		return Optional.empty();
	}
}
