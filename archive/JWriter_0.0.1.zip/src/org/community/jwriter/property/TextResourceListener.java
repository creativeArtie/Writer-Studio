package org.community.jwriter.property;

import java.util.ArrayList;

public interface TextResourceListener{
    public void update(TextResource resource, String value);
}
