package org.community.jwriter.property;

public class IntegerProperty extends Property<Integer>{
    
    IntegerProperty(String propertyKey, PropertyManager propertyManager){
        super(propertyKey, propertyManager);
    }
    
    protected Integer fromStorage(String value){
        return Integer.parseInt(value);
    }
    
    protected String toStorage(Integer value){
        return String.valueOf(value);
    }
}
