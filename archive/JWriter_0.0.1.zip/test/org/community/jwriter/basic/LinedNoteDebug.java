package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedNoteDebug extends SpanTest{
	
	@Test
	public void noteComplete(){
		Document doc = build(new Object[]{
			"!%", "     @", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text"}}, "\n"
		});
		testNote(doc.get(0), "Text", new String[]{"note"}, "id");
	}
	
	@Test
	public void noteWithoutNewLine(){
		Document doc = build(new Object[]{
			"!%", "     @", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text"}}
		});
		testNote(doc.get(0), "Text", new String[]{"note"}, "id");
	}
	
	@Test
	public void note(){
		Document doc = build(new Object[]{
			"!%", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text"}}
		});
		testNote(doc.get(0), "Text", new String[]{"note"}, "id");
	}
	
	@Test
	public void note1(){
		Document doc = build(new Object[]{
			"!%", "@", new Object[]{new Object[]{"id"}}, ":",
		});
		testNote(doc.get(0), "", new String[]{"note"}, "id");
	}
	
	@Test
	public void note2(){
		Document doc = build(new Object[]{
			"!%", "@", new Object[]{new Object[]{"id"}},
		});
		testNote(doc.get(0), "", new String[]{"note"}, "id");
	}
	
	@Test
	public void note3(){
		Document doc = build(new Object[]{
			"!%", "@", ":", new Object[]{new Object[]{"Text"}}
		});
		testNote(doc.get(0), "Text", new String[0], "");
	}
	
	@Test
	public void note4(){
		Document doc = build(new Object[]{
			"!%", new Object[]{new Object[]{"Text"}}
		});
		testNote(doc.get(0), "Text", new String[0], "");
	}
	
	@Test
	public void note5(){
		Document doc = build(new Object[]{
			"!%", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text"}}
		});
		testNote(doc.get(0), "Text", new String[]{"note"}, "id");
	}
	
	
	@Test
	public void note9(){
		Document doc = build(new Object[]{"!%"});
		testNote(doc.get(0), "", new String[0], "");
	}
	
	void testNote(Span span, String text, String[] category, String id){
		assertEquals(LinedSpanNote.class, span.getClass());
		LinedSpanNote test = (LinedSpanNote) span;
		assertEquals("Wrong text.", text, test.getText().getDoc());
		assertEquals("Wrong type.", LinedType.NOTE, test.getType());
		assertArrayEquals("Wrong category.", category, test.getCategory());
		assertEquals("Wrong id.", id, test.getIdentity());
	}
	
	@Override
	protected Parser[] getParsers(){
		return new Parser[]{LinedParseRest.NOTE};
	}
}
