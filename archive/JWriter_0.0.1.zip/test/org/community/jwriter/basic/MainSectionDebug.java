package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.MainTest.*;

@RunWith(JUnit4.class)
public class MainSectionDebug extends MainTest{
	@Test
	public void empty(){
		build();
	}
	
	@Test
	public void simple(){
		SectionExpect raw = new SectionExpect();
		raw.addLine(LinedType.PARAGRAPH, "abc\n");
		testSection(build(raw).get(0), raw, null, null, null);
	}
	
	@Test
	public void allSectionLines(){
		SectionExpect raw = new SectionExpect();
		raw.addLine(LinedType.QUOTE, ">qoute\n");
		raw.addLine(LinedType.NUMBERED, "#numbered\n");
		raw.addLine(LinedType.BULLET, "-bullet\n");
		raw.addLine(LinedType.HYPERLINK, "!@hyperlink:http://google.com\n");
		raw.addLine(LinedType.FOOTNOTE, "!^footnote: many text\n");
		raw.addLine(LinedType.ENDNOTE, "!*endnote: text\n");
		raw.addLine(LinedType.AGENDA, "!!agenda\n");
		raw.addLine(LinedType.BREAK, "***\n");
		raw.addLine(LinedType.PARAGRAPH, "abc\n");
		testSection(build(raw).get(0), raw, null, null, null);
	}
	
	@Test
	public void list(){
		SectionExpect raw = new SectionExpect();
		raw.addLine(LinedType.NUMBERED, "# abc\n");
		raw.addLine(LinedType.NUMBERED, "# ccc\n");
		raw.addLine(LinedType.NUMBERED, "#dead\n");
		raw.addLine(LinedType.NUMBERED, "\t#win\n");
		testSection(build(raw).get(0), raw, null, null, null);
	}
	
	@Test
	public void emptyToHeading(){
		SectionExpect raw1 = new SectionExpect();
		raw1.addLine(LinedType.QUOTE, ">quote\n");
		
		SectionExpect raw2 = new SectionExpect();
		LinedExpect heading = raw2.addLine(LinedType.HEADING, "=next!\n");
		raw2.addLine(LinedType.PARAGRAPH, "explain..\n");
		
		Document doc = build(raw1, raw2);
		testSection(doc.get(0), raw1, null, null, null);
		testSection(doc.get(1), raw2, null, heading, null);
	}
	
	@Test
	public void emptyToOutline(){
		SectionExpect raw1 = new SectionExpect();
		raw1.addLine(LinedType.FOOTNOTE, "!^first: before text? Really?\n");
		
		SectionExpect raw2 = new SectionExpect();
		LinedExpect outline = raw2.addLine(LinedType.OUTLINE, "!#before all\n");
		raw2.addLine(LinedType.PARAGRAPH, "show me the footnote{^first}\n");
		
		Document doc = build(raw1, raw2);
		testSection(doc.get(0), raw1, null, null, null);
		testSection(doc.get(1), raw2, null, null, outline);
	}
	
	@Test
	public void header(){
		SectionExpect raw = new SectionExpect();
		LinedExpect heading = raw.addLine(LinedType.HEADING, "===abc\n");
		raw.addLine(LinedType.AGENDA, "!!To do line is part of section:).");
		testSection(build(raw).get(0), raw, null, heading, null);
	}
	
	@Test
	public void outline(){
		SectionExpect raw = new SectionExpect();
		LinedExpect outline = raw.addLine(LinedType.OUTLINE, "!#manuscript\n");
		raw.addLine(LinedType.HYPERLINK, "!@link:/dev/null\n");
		raw.addLine(LinedType.NUMBERED, "#link to the {@ link|best part}\n");
		raw.addLine(LinedType.NUMBERED, "#win me! \n");
		testSection(build(raw).get(0), raw, null, null, outline);
	}
	
	@Test
	public void multiOutline(){
		SectionExpect raw1 = new SectionExpect();
		LinedExpect outline1 = raw1.addLine(LinedType.OUTLINE, "!#abc\n");
		
		SectionExpect raw2 = new SectionExpect();
		LinedExpect outline2 = raw2.addLine(LinedType.OUTLINE, "!#next!\n");
		raw2.addLine(LinedType.PARAGRAPH, "be mine\n");
		
		Document doc = build(raw1, raw2);
		testSection(doc.get(0), raw1, null, null, outline1);
		testSection(doc.get(1), raw2, null, null, outline2);
	}
	
	@Test
	public void headAndPoint(){
		SectionExpect raw1 = new SectionExpect();
		LinedExpect heading = raw1.addLine(LinedType.HEADING, "===abc\n");
		
		SectionExpect raw2 = new SectionExpect();
		LinedExpect outline = raw2.addLine(LinedType.OUTLINE, "!#section\n");
		raw2.addLine(LinedType.NUMBERED, "####See you!\n");
		
		Document doc = build(raw1, raw2);
		testSection(doc.get(0), raw1, null, heading, null);
		testSection(doc.get(1), raw2, null, heading, outline);
	}
	
	@Test
	public void twoSections(){
		SectionExpect raw1 = new SectionExpect();
		LinedExpect heading1 = raw1.addLine(LinedType.HEADING, "=1st topic\n");
		
		SectionExpect raw2 = new SectionExpect();
		LinedExpect outline = raw2.addLine(LinedType.OUTLINE, "!#   #STUB\n");
		
		SectionExpect raw3 = new SectionExpect();
		LinedExpect heading2 = raw3.addLine(LinedType.HEADING, "=2nd topic\n");
		
		Document doc = build(raw1, raw2, raw3);
		testSection(doc.get(0), raw1, null, heading1, null);
		testSection(doc.get(1), raw2, null, heading1, outline);
		testSection(doc.get(2), raw3, null, heading2, null);
	}
}
