package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedRestDebug extends SpanTest{
	
	@Test
	public void testBreak(){
		Document doc = build(new Object[]{"***\n"});
		Span s = doc.get(0);
		assertEquals("Wrong class.", LinedSpan.class, s.getClass());
		assertEquals("Wrong type.", LinedType.BREAK, ((LinedSpan)s).getType());
	}
	
	@Test
	public void fullAgenda(){
		Document doc = build(new Object[]{"!!", new Object[]{"abc"}, "\n"});
		testTodo(doc.get(0), "abc");
	}
	
	@Test
	public void emptyAgenda(){
		Document doc = build(new Object[]{"!!"});
		testTodo(doc.get(0), "");
	}
	
	@Test
	public void spaceAgenda(){
		Document doc = build(new Object[]{"!!", new Object[]{" "}});
		testTodo(doc.get(0), "");
	}
	
	@Test
	public void basicAgenda(){
		Document doc = build(new Object[]{"!!", new Object[]{"Help"}});
		testTodo(doc.get(0), "Help");
	}
	
	@Test
	public void escapeAgenda(){
		Document doc = build(new Object[]{"!!",
			new Object[]{"H", new Object[]{"\\", "!"}}
		});
		testTodo(doc.get(0), "H!");
	}
	
	@Test
	public void emptyParagraph(){
		Document doc = build();
	}
	
	@Test
	public void noNewlineParagraph(){
		Object[] text = new Object[]{new Object[]{"abc"}};
		Document doc = build(new Object[]{text});
		testParagraph(doc.get(0), 0, text);
	}
	
	@Test
	public void simpleParagraph(){
		Object[] text = new Object[]{new Object[]{"abc"}};
		Document doc = build(new Object[]{text, "\n"});
		testParagraph(doc.get(0), 0, text);
	}
	
	@Test
	public void basicParagraph(){
		Object[] text = new Object[]{
			new Object[]{"abc", new Object[]{"\\", "{"}, "@"}
		};
		Document doc = build(new Object[]{text, "\n"});
		testParagraph(doc.get(0), 0, text);
	}
	
	@Test
	public void doubleParagraph(){
		Object[] text1 = new Object[]{
			new Object[]{"abc", new Object[]{"\\", "{"}, "@"}
		};
		Object[] text2 = new Object[]{
			new Object[]{"Charles is boy."}
		};
		Document doc = build(new Object[]{text1, "\n"}, 
			new Object[]{text2}
		);
		testParagraph(doc.get(0), 0, text1);
		testParagraph(doc.get(1), 7, text2);
	}
	
	@Test
	public void doubleParagraph2(){
		Object[] text1 = new Object[]{
			new Object[]{"abc", new Object[]{"\\", "{"}, "@"}
		};
		Object[] text2 = new Object[]{
			new Object[]{"Charles is boy."}
		};
		Document doc = build(new Object[]{text1, "\n"}, 
			new Object[]{text2, "\n"}
		);
		testParagraph(doc.get(0), 0, text1);
		testParagraph(doc.get(1), 7, text2);
	}
	
	private void testTodo(Span span, String text){
		assertEquals("Wrong class.", LinedSpanTodo.class, span.getClass());
		LinedSpanTodo test = (LinedSpanTodo) span;
		assertEquals("Wrong type.", LinedType.AGENDA, test.getType());
		assertEquals("Wrong text.", text, test.getReason());
	}
	
	private void testParagraph(Span span, int start, Object[] formatText){
		assertEquals("Wrong class.", LinedSpanParagraph.class, span.getClass());
		LinedSpanParagraph test = (LinedSpanParagraph) span;
		assertEquals("Wrong type.", LinedType.PARAGRAPH, test.getType());
		testChild(test.getText(), start, formatText, test.getDoc());
	}
	
	@Override
	protected Parser[] getParsers(){
		return LinedParseRest.values();
	}
}
