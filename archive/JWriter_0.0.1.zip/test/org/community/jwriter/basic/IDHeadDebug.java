package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.lang.reflect.Field;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class IDHeadDebug extends IDParamTest{
	
	@Test
	public void link(){
		run("!@abc:text\n");
	}
	
	@Test
	public void outline(){
		run("!#@abc:hello\n");
	}
	
	@Test
	public void heading(){
		run("=@abc:hello\n");
	}
	
	private void run(String line){
		StringBuilder text = new StringBuilder();
		for (States state: input){
			if (state == States.ID){
				text.append(line);
			} else {
				text.append("<@abc>\n");
			}
		}
		Document doc = new Document(text.toString(), getParsers());
		Span span = doc.get(0);
		assertEquals(Arrays.toString(input), expected, doc.getMap().get(
			new ID(Arrays.asList(IDType.LINK.getCategory()), "abc"))
			.getStatus());
	}


	@Override
	protected Parser[] getParsers(){
		return new Parser[]{LinedParseLevel.HEADING, LinedParseLevel.OUTLINE,
			LinedParsePointer.HYPERLINK, LinedParseRest.PARAGRAPH};
	}
}
