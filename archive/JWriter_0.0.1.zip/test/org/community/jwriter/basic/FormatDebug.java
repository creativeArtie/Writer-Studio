package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatDebug extends SpanTest{
    
    @Test
    public void parseBasic(){
		Document test = build(new Object[]{///FormatSpan
			new Object[]{"abc"} ///ContentSpan
		});
		test(test, 0, false, false, false, false, "abc");
	}
	
    @Test
    public void parseBold(){
		Document test = build(new Object[]{
			new Object[]{"or"}, 
			"**", new Object[]{"an"}, "**", ///Bold
			new Object[]{"ge"}
			});
		test(test, 0, false, false, false, false, "or");
		test(test, 2, true, false, false, false, "an");
		test(test, 4, false, false, false, false, "ge");
	}
	
    @Test
    public void parseItalics(){
		Document test = build(new Object[]{
			new Object[]{"g"}, 
			"*", new Object[]{"ee"}, "*", ///Italics
			new Object[]{"n"}
		});
		test(test, 0, false, false, false, false, "g");
		test(test, 2, false, true, false, false, "ee");
		test(test, 4, false, false, false, false, "n");
	}
	
    @Test
    public void parseUnderlineCoded(){
		Document test = build(new Object[]{
			 new Object[]{"g"}, "_", /// start underlining
			 new Object[]{"e", new Object[]{"\\", "_"}, "e"},  ///escape text
			 "`", new Object[]{"dd"}, "_" ///Underlined + code
		 });
		test(test, 0, false, false, false, false, "g");
		test(test, 2, false, false, true, false, "e_e");
		test(test, 4, false, false, true, true, "dd");
	}
	
    @Test
    public void parseStarted(){
		Document test = build(new Object[]{"_", new Object[]{"abc"}});
		test(test, 1, false, false, true, false, "abc");
	}
	
    @Test
    public void parseSeparate(){
		Document test = build(new Object[]{"_", new Object[]{"abc"}, 
			new Object[]{"{^", new Object[]{new Object[]{"see"}}, "}"}, ///Add foot note
			new Object[]{"pee"}, "_"});
		test(test, 1, false, false, true, false, "abc");
		test(test, 3, false, false, true, false, "pee");
	}
	
    @Test
    public void parseEmpty(){
		Document test = new Document("", getParsers());
		assertEquals(0, test.size());
	}

	
	private void test(Document doc, int idx, boolean isBold, boolean isItalics, 
			boolean isUnderline, boolean isCoded, String text){
		Span span = doc.get(0);
		assertEquals("Wrong main class gotten.", FormatSpan.class, 
			span.getClass());
			
		span = ((FormatSpan)span).get(idx);
		assertEquals("Wrong class gotten for "+ idx + ": " + span.getClass(), 
			FormatSpanContent.class, span.getClass());
			
		FormatSpanContent test = (FormatSpanContent) span;
		assertEquals("Wrong text for " + idx, text, test.getOutput());
		
		assertEquals("Wrong bold format for " + idx, isBold, test.isBold());
		assertEquals("Wrong italics format for " + idx, isItalics, 
			test.isItalics());
		assertEquals("Wrong underline format for " + idx, isUnderline, 
			test.isUnderline());
		assertEquals("Wrong coded format for " + idx, isCoded, test.isCoded());
	}
	
	@Override
	protected Parser[] getParsers(){
		return new Parser[]{new FormatParser(), new SpanTestEnder()};
	}

}
