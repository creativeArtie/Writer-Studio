package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinkDebug extends SpanTest{
	
	@Test
	public void parseLinkRefNoCategory(){
		Document test = build(
		new Object[]{"<@", 
			new Object[]{ /// Link Span + ID Span start
				new Object[]{"d"}
			}, 
			"|", new Object[]{"dead"}}
		);
		testRef(test, new String[]{"link"}, "d", "", "dead");
	}
	
	@Test
	public void parseLinkRef(){
		Document test = build( ///Format Span
			new Object[]{"<@", new Object[]{ /// Link Span + ID Span start
				new Object[]{"abc"}, "-", new Object[]{"d"}
			}, ">"}
		);
		testRef(test, new String[]{"link", "abc"}, "d", "", "");
	}
	
	@Test
	public void parseLinkRef1(){
		Document test = build( ///Format Span
			new Object[]{"<@", new Object[]{ /// Link Span + ID Span start
				new Object[]{"abc"}, "-", new Object[]{"d"}
				}, "|", new Object[]{"dead"}, ">"}
		);
		testRef(test, new String[]{"link", "abc"}, "d", "", "dead");
	}
	
	@Test
	public void parseLinkRef2(){
		Document test = build(
			new Object[]{"<@", new Object[]{ /// Link Span + ID Span start
				new Object[]{"abc"}, "-", new Object[]{"d"}
			}}
		);
		testRef(test, new String[]{"link", "abc"}, "d", "", "");
	}
	
	@Test
	public void parseLinkRef3(){
		Document test = build(
		new Object[]{"<@", 
			new Object[]{ /// Link Span + ID Span start
				new Object[]{"abc"}, "-", new Object[]{"d"}
			}, 
			"|", new Object[]{"dead"}}
		);
		testRef(test, new String[]{"link", "abc"}, "d", "", "dead");
	}
	
	@Test
	public void parseLinkPath(){
		Document test = build(new Object[]{"<", new Object[]{"abc/d"}, ">"});
		testDirect(test, "abc/d", "abc/d");
	}
	
	@Test
	public void parseLinkPath1(){
		Document test = build(
			new Object[]{"<", new Object[]{"abc/d"}, "|", new Object[]{"dead"}, ">"}
		);
		testDirect(test, "abc/d", "dead");
	}
	
	@Test
	public void parseLinkPath2(){
		Document test = build(
			new Object[]{"<", new Object[]{"abc/d"}}
		);
		testDirect(test, "abc/d", "abc/d");
	}
	
	@Test
	public void parseLinkPath3(){
		Document test = build(
			new Object[]{"<", new Object[]{"abc/d"}, "|", new Object[]{"dead"}}
		);
		testDirect(test, "abc/d", "dead");
	}

	@Override
	protected Parser[] getParsers(){
		return FormatParseLink.values();
	}
	private void testRef(Document doc, String[] cat, String id, String path, 
			String text){
		Span span = doc.get(0);
		assertEquals("Wrong class gotten.", FormatSpanLinkRef.class, 
			span.getClass());
		FormatSpanLinkRef test = (FormatSpanLinkRef) span;
		assertArrayEquals("Wrong category.", cat, test.getCategory());
		assertEquals("Wrong id.", id, test.getIdentity());
		testCommon(span, path, text);
	}
	
	private void testDirect(Document doc, String path, String text){
		Span span = doc.get(0);
		assertEquals("Wrong class gotten.", FormatSpanLinkDirect.class, 
			span.getClass());
		testCommon(span, path, text);
	}
		
	private void testCommon(Span span, String path, String text){
		FormatSpanLink test = (FormatSpanLink) span;
		assertEquals("Wrong link path", path, test.getPath());
		assertEquals("Wrong link text.", text, test.getOutput());
	}
}
