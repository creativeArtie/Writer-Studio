package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedCiteDebug extends IDTest{
	
	
	@Test
	public void full(){
		Document doc = build(new Object[]{"!>", "author", ":", 
			new Object[]{"Johnson"}, ",", new Object[]{"See"}});
		testName(doc.get(0), LinedTypeSource.AUTHOR, "Johnson", "See");
	}
	
	@Test
	public void full1(){
		Document doc = build(new Object[]{"!>", "editor", ":", 
			new Object[]{"Johnson"}, ",", new Object[]{"See"}});
		testName(doc.get(0), LinedTypeSource.EDITOR, "Johnson", "See");
	}
	
	@Test
	public void full2(){
		Document doc = build(new Object[]{"!>", "translator", ":", 
			new Object[]{"Johnson"}, ",", new Object[]{"See"}});
		testName(doc.get(0), LinedTypeSource.TRANSLATOR, "Johnson", "See");
	}
	
	@Test
	public void full3(){
		Document doc = build(new Object[]{"!>", "article", ":", new Object[]{"hello"}});
		testBasic(doc.get(0), LinedTypeSource.ARTICLE, "hello");
	}
	
	@Test
	public void full4(){
		Document doc = build(new Object[]{"!>", "title", ":", new Object[]{"hello"}});
		testBasic(doc.get(0), LinedTypeSource.TITLE, "hello");
	}
	
	@Test
	public void full5(){
		Document doc = build(new Object[]{"!>", "edition", ":", new Object[]{"hello"}});
		testBasic(doc.get(0), LinedTypeSource.EDITION, "hello");
	}
	
	@Test
	public void full6(){
		Document doc = build(new Object[]{"!>", "publish-house", ":", new Object[]{"hello"}});
		testBasic(doc.get(0),LinedTypeSource.PUBLISH_HOUSE, "hello");
	}
	
	@Test
	public void full7(){
		Document doc = build(new Object[]{"!>", "publish-year", ":", new Object[]{"hello"}});
		testBasic(doc.get(0),LinedTypeSource.PUBLISH_YEAR, "hello");
	}
	
	@Test
	public void full8(){
		Document doc = build(new Object[]{"!>", "media", ":", new Object[]{"hello"}});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "hello");
	}
	
	@Test
	public void full9(){
		Document doc = build(new Object[]{"!>", "access-location", ":", new Object[]{"hello"}});
		testBasic(doc.get(0),LinedTypeSource.ACCESS_LOCATION, "hello");
	}
	
	@Test
	public void full10(){
		Document doc = build(new Object[]{"!>", "access-date", ":", new Object[]{"hello"}});
		testBasic(doc.get(0),LinedTypeSource.ACCESS_DATE, "hello");
	}
	
	@Test
	public void full11(){
		Document doc = build(new Object[]{"!>", "pages", ":", new Object[]{"hello"}});
		testBasic(doc.get(0), LinedTypeSource.PAGES, "hello");
	}

	@Test
	public void partSpaced(){
		Document doc = build(new Object[]{"!>", "  media", "  :", new Object[]{"a"}});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "a");
	}

	@Test
	public void part1(){
		Document doc = build(new Object[]{"!>", "media", ":", new Object[]{"a"}});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "a");
	}

	@Test
	public void part2(){
		Document doc = build(new Object[]{"!>", new Object[]{":a"}, "\n"});
		testBasic(doc.get(0), LinedTypeSource.ERROR, ":a");
	}

	@Test
	public void part3(){
		Document doc = build(new Object[]{"!>", "media", "\n"});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "");
	}

	@Test
	public void part4(){
		Document doc = build(new Object[]{"!>", "media"});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "");
	}

	@Test
	public void part5(){
		Document doc = build(new Object[]{"!>", "media", new Object[]{"see"}});
		testBasic(doc.get(0), LinedTypeSource.MEDIA, "see");
	}

	@Test
	public void part6(){
		Document doc = build(new Object[]{"!>", new Object[]{"sdaf"}});
		testBasic(doc.get(0), LinedTypeSource.ERROR, "sdaf");
	}

	@Test
	public void part7(){
		Document doc = build(new Object[]{"!>", new Object[]{"sdaf:"}, "\n"});
		testBasic(doc.get(0), LinedTypeSource.ERROR, "sdaf:");
	}

	@Test
	public void part8(){
		Document doc = build(new Object[]{"!>", new Object[]{"sdaf:aaa"}, "\n"});
		testBasic(doc.get(0), LinedTypeSource.ERROR, "sdaf:aaa");
	}

	@Test
	public void part9(){
		Document doc = build(new Object[]{"!>", new Object[]{"sdaf:"}});
		testBasic(doc.get(0), LinedTypeSource.ERROR, "sdaf:");
	}
	
	public void testCommon(LinedSpanCite test, LinedTypeSource expectedType, 
			String expectedOutput){
		assertEquals("Wrong line type.", LinedType.SOURCE, test.getType());
		assertEquals("Wrong source field.", expectedType, test.getField());
		assertEquals("Wrong source data.", expectedOutput, test.getOutput());
	}
	
	public void testBasic(Span span, LinedTypeSource expectedType, 
			String expectedOutput){
		assertEquals("Wrong class.", LinedSpanCiteText.class, span.getClass());
		testCommon((LinedSpanCiteText)span, expectedType, expectedOutput);
	}
	
	public void testName(Span span, LinedTypeSource expectedType, 
			String lastName, String firstName){
		assertEquals("Wrong class.", LinedSpanCiteName.class, span.getClass());
		LinedSpanCiteName test = (LinedSpanCiteName) span;
		testCommon(test, expectedType, lastName + ", " + firstName);
		assertEquals("Wrong last name.", lastName, test.getLastName());
		assertEquals("Wrong first name.", firstName, test.getFirstName());
	}
	
	@Override
	protected Parser[] getParsers(){
		return new Parser[]{LinedParseCite.INSTANCE};
	}
}
