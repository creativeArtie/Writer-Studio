package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

import org.community.jwriter.markup.*;

public abstract class MainTest {
	
	protected final Document build(SectionExpect ... expecteds){
		StringBuilder docRaw = new StringBuilder();
		for(SectionExpect content: expecteds){
			for (LinedExpect line: content.lines){
				docRaw.append(line.text);
			}
		}
		Document doc = new Document(docRaw.toString(), new MainParser());
		assertEquals("Wrong doc text.", docRaw.toString(), doc.getDoc());
		assertEquals("Wrong div size.", expecteds.length, doc.size());
		return doc;
	}
	
	public static void testDiv(Span div, SectionExpect expect){
		int i = 0;
		SpanBranch parent = (SpanBranch) div;
		assertEquals("Wrong children size." + parent.getDoc(), 
			expect.lines.size(), parent.size());
		for (LinedExpect expected: expect.lines){
			testLine(parent.get(i), expected);
			i++;
		}
	}
	public static void testLine(Span line, LinedExpect expect){
		assertTrue("Wrong class: " + line.getClass(), line instanceof LinedSpan);
		LinedSpan test = (LinedSpan) line;
		assertEquals("Wrong type: " + line.getDoc(), expect.type, test.getType());
		assertEquals("Wrong text: " + line.getDoc(), expect.text, test.getDoc());
	}
	
	public static class SectionExpect{
		private ArrayList<LinedExpect> lines;
		private ArrayListMultimap<LinedTypeSource, String> sources;
		
		public SectionExpect(){
			lines = new ArrayList<>();
			sources = ArrayListMultimap.create();
		}
		
		public LinedExpect addLine(LinedType expectType, String expectText){
			LinedExpect out = new LinedExpect(expectType, expectText);
			lines.add(out);
			return out;
		}
		
		public LinedExpect addLine(String expectDoc, LinedTypeSource type, 
				String expectText){
			sources.put(type, expectText);
			return addLine(LinedType.SOURCE, expectDoc);
		}
		
		public ID addNoteID(String expectedDoc, String id){
			addLine(LinedType.NOTE, expectedDoc);
			ArrayList<String> cat = new ArrayList<>();
			cat.add(IDType.NOTE.getCategory());
			return new ID(cat, id);
		}
	}
	
	public static class LinedExpect{
		private final LinedType type;
		private final String text;
		public LinedExpect(LinedType expectType, String expectText){
			type = expectType;
			text = expectText;
		}
	}
	
	public static void testSection(Span div, SectionExpect cur, 
			SectionExpect last, LinedExpect heading, LinedExpect outline){
		testDiv(div, cur);
		assertEquals("Wrong class", MainSpanSection.class, div.getClass());
		MainSpanSection test = (MainSpanSection) div;
		if (last == null){
			assertFalse("last is found.", test.getLast().isPresent());
		} else {
			assertTrue("last is not found.", test.getLast().isPresent());
			testDiv(test.getLast().get(), last);
		}
		if (heading == null){
			assertFalse("heading is found.", test.getHeading().isPresent());
		} else {
			assertTrue("heading is not found.", test.getHeading().isPresent());
			testLine(test.getHeading().get(), heading);
		}
		if (outline == null){
			assertFalse("outline is found.", test.getOutline().isPresent());
		} else {
			assertTrue("outline is not found.", test.getOutline().isPresent());
			testLine(test.getOutline().get(), outline);
		}
	}
	
	public static void testNote(Span div, SectionExpect cur, ID expectedID){
		testDiv(div, cur);
		assertEquals("Wrong class", MainSpanNote.class, div.getClass());
		MainSpanNote test = (MainSpanNote) div;
		Optional<ID> id = Optional.ofNullable(expectedID);
		assertEquals("Wrong ID.", id, test.getID());
		for (LinedTypeSource type: LinedTypeSource.values()){
			testSources(type, cur.sources.get(type), 
				test.getSources().get(type));
		}
	}
	
	private static void testSources(LinedTypeSource type, List<String> expect, 
			List<String> test){
		int i = 0;
		assertEquals("Wrong source size for: " + type, expect.size(), 
			test.size());
		for(String e: expect){
			assertEquals("Wrong source  for: " + type, e, test.get(i));
			i++;
		}
	}
}
