package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class IDErrorDebug extends IDParamTest{
    @Test
    @SuppressWarnings("fallthrough")
    public void test() {
		Object[] basic = new Object[]{new Object[]{"abc"}};
		Object[] lined = new Object[]{"\n"};
		Document test;
		switch(input.length){
			case 4:
				test = build(basic, lined, basic, lined, basic, lined, basic);
				break;
			case 3:
				test = build(basic, lined, basic, lined, basic);
				break;
			case 2:
				test = build(basic, lined, basic);
				break;
			default:
				test = build(basic);
				break;
		}
		int i = 0;
		IDTestPrep builder = new IDTestPrep();
		for (States state: input){
			if (i != 0){
				if (state == States.ID){
					builder.addID(test(test, i * 2, new String[0], "abc"));
				} else {
					builder.addRef(test(test, i * 2, new String[0], "abc"));
				}
			} else if (state == States.ID){
				builder.addID(test(test, 0, new String[0], "abc"), expected, 0);
			} else {
				builder.addRef(test(test, 0, new String[0], "abc"), expected, 0);
			}
			i++;
		}
		builder.testAll();
    }

	@Override
	protected Parser[] getParsers(){
		return new Parser[]{new IDParser(IDType.NONE), new SpanTestEnder()};
	}
}
