package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Map.Entry;

import org.community.jwriter.markup.*;

public abstract class SpanTest {
	
	protected abstract Parser[] getParsers();
	
	private int i = 0;
	
	private String buildString(Object[] list){
		StringBuilder builder = new StringBuilder();
		i++;
		for(Object obj: list){
			if (obj instanceof String){
				builder.append((String)obj);
			} else {
				builder.append(buildString((Object[]) obj));
			}
		}
		i--;
		return builder.toString();
	}
	
    protected Document build(Object[] ... expects){
		StringBuilder build = new StringBuilder();
		String doc = buildString(expects);
		Document test = new Document(doc, getParsers());
		assertEquals("Doc get text wrong.", doc, test.getDoc());
		assertEquals("Doc size wrong.", expects.length, test.size());
		testChild(test, 0, expects, "");
		return test;
	}
	
	protected int testChild(Span span, int pos, Object[] expects, String cur){
		assertTrue("Span " + cur + " is not a branch:" + span.getClass(),
				span instanceof SpanNode);
		SpanNode parent = (SpanNode) span;
		int idx = 0;
		assertEquals("Span " + cur + " has wrong size:" + parent.toString(), expects.length, 
			parent.size());
		for(Object expect : expects){
			String id = cur + "." + idx;
			Span child = parent.get(idx);
			if (expect instanceof String){
				assertTrue("Span " + id + " is not a leaf:" + child.getClass(), 
					child instanceof SpanLeaf);
				SpanLeaf test = (SpanLeaf) child;
				assertEquals("Span " + id + " has wrong text.", 
					expect, test.getDoc());
				assertEquals("Span " + id + " has wrong start.", 
					pos, test.getStart());
				pos += ((String)expect).length();
				assertEquals("Span " + id + " has wrong end.", 
					pos, test.getEnd());
			} else {
				pos = testChild(child, pos, (Object[]) expect, id);
			}
			idx++;
		}
		return pos;
	}
}
