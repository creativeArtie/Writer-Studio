package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class SpanTestEnder implements Parser<SpanBranch>{
	
	public Optional<SpanBranch> parse(Pointer pointer){
		if (pointer.startsWith(AtomicTerm.LINED_END)){
			ArrayList<Span> children = new ArrayList<>();
			children.add(new SpanLeaf(pointer));
			return Optional.of(new SpanBranch(children));
		}
		return Optional.empty();
	}
}
