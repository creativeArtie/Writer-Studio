package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedPointerDebug extends SpanTest{
	
	@Test
	public void fulllink(){
		testLink(build(new Object[]{"!@", 
			new Object[]{new Object[]{"abc"}}, ":", 
			new Object[]{"test"}, "\n"}), 
			IDType.LINK, LinedType.HYPERLINK, "abc", "test");
	}
	
	@Test
	public void link(){
		testLink(build(new Object[]{"!@", 
			new Object[]{new Object[]{"abc"}}, ":", 
			new Object[]{"test"}}), 
			IDType.LINK, LinedType.HYPERLINK, "abc", "test");
	}
	
	@Test
	public void link1(){
		testLink(build(new Object[]{"!@", 
			new Object[]{new Object[]{"abc"}}, ":"}), 
			IDType.LINK, LinedType.HYPERLINK, "abc", "");
	}
	
	@Test
	public void link3(){
		testLink(build(new Object[]{"!@", 
			new Object[]{new Object[]{"abc"}}}), 
			IDType.LINK, LinedType.HYPERLINK, "abc", "");
	}
	
	@Test
	public void link4(){
		testLink(build(new Object[]{"!@", ":", 
			new Object[]{"test"}}), 
			IDType.NONE, LinedType.HYPERLINK, "", "test");
	}
	
	@Test
	public void fullendnote(){
		testNote(build(new Object[]{"!*", 
			new Object[]{new Object[]{"abc"}}, ":", 
			new Object[]{new Object[]{"test"}}, "\n" }), 
			IDType.ENDNOTE, LinedType.ENDNOTE, "abc", "test");
	}
	
	
	@Test
	public void endnote(){
		testNote(build(new Object[]{"!*", 
			new Object[]{new Object[]{"abc"}}, ":", 
			new Object[]{new Object[]{"test"}} }), 
			IDType.ENDNOTE, LinedType.ENDNOTE, "abc", "test");
	}
	
	@Test
	public void endnote1(){
		testNote(build(new Object[]{"!*", 
			new Object[]{new Object[]{"abc"}}, ":", }), 
			IDType.ENDNOTE, LinedType.ENDNOTE, "abc", "");
	}
	
	@Test
	public void endnote2(){
		testNote(build(new Object[]{"!*", 
			new Object[]{new Object[]{"abc"}},}), 
			IDType.ENDNOTE, LinedType.ENDNOTE, "abc", "");
	}
	
	@Test
	public void endnote3(){
		testNote(build(new Object[]{"!*", ":", 
			new Object[]{new Object[]{"test"}} }), 
			IDType.NONE, LinedType.ENDNOTE, "", "test");
	}
	
	@Test
	public void footnote(){
		testNote(build(new Object[]{"!^", 
			new Object[]{new Object[]{"abc"}}, ":", 
			new Object[]{new Object[]{"test"}} }), 
			IDType.FOOTNOTE, LinedType.FOOTNOTE, "abc", "test");
	}
	
	private void testLink(Document doc, IDType idType, LinedType type, 
			String id, String path){
		Span span = doc.get(0);
		assertEquals("Wrong class.", LinedSpanPointLink.class, span.getClass());
		LinedSpanPointLink test = (LinedSpanPointLink) span;
		testCommon(test, idType, type, id);
		assertEquals("Wrong path.", path, test.getPath());
	}
	
	private void testNote(Document doc, IDType idType, LinedType type, 
			String id, String docText){
		Span span = doc.get(0);
		assertEquals("Wrong class.", LinedSpanPointNote.class, span.getClass());
		LinedSpanPointNote test = (LinedSpanPointNote) span;
		testCommon(test, idType, type, id);
		assertEquals("Wrong path.", docText, test.getText().getDoc());
	}
	
	private void testCommon(LinedSpanPoint test, IDType idType, 
			LinedType type, String id){
		assertEquals("Wrong ID type.", idType, test.getIDType());
		assertEquals("Wrong line type.", type, test.getType());
		String[] category = idType == IDType.NONE? new String[0] :
			new String[]{idType.getCategory()};
		assertArrayEquals("Wrong category.", category, test.getCategory());
		assertEquals("Wrong id.", id, test.getIdentity());
	}
		
	
	@Override
	protected Parser[] getParsers(){
		return LinedParsePointer.values();
	}
}
