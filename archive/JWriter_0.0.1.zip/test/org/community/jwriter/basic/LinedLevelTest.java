package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelTest extends SpanTest{
	
	void testLeveled(Span span, String text, LinedType type, 
			int level){
		assertEquals(LinedSpanLevel.class, span.getClass());
		testBasic((LinedSpanLevel) span, text, type, level);
	}
	
	void testSectionLeveled(Span span, String text, LinedType type, 
			int level, StatusType status, String[] category, String id){
		assertEquals(LinedSpanSection.class, span.getClass());
		LinedSpanSection test = (LinedSpanSection) span;
		testBasic(test, text, type, level);
		assertEquals("Wrong Status.", status, test.getStatus());
		assertArrayEquals("Wrong category.", category, test.getCategory());
		assertEquals("Wrong id.", id, test.getIdentity());
	}

	void testBasic(LinedSpanLevel test, String text, LinedType type, 
			int level){
		assertEquals("Wrong text.", text, test.getText().getDoc());
		assertEquals("Wrong type.", type, test.getType());
		assertEquals("Wrong level.", level, test.getLevel()); 
	}
	
	@Override
	protected Parser[] getParsers(){
		return LinedParseLevel.values();
	}
}
