package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class CurlyAgendaDebug extends SpanTest{
	
    @Test
    public void parseTodoText(){
		Document doc = build(new Object[]{"{!", 
			new Object[]{"AGENDA", new Object[]{"\\", "a"}}, "}"});
		test(doc, "AGENDAa");
	}
	
    @Test
    public void parseTodoText1(){
		Document doc = build(new Object[]{"{!", new Object[]{"abc"}});
		test(doc, "abc");
	}
	
    @Test
    public void parseTodoText2(){
		Document doc = build(new Object[]{"{!"});
		test(doc, "");
	}
	
	private void test(Document doc, String text){
		Span span = doc.get(0);
			
		assertEquals("Wrong span class", FormatSpanCurlyAgenda.class, span.getClass());
		FormatSpanCurlyAgenda test = (FormatSpanCurlyAgenda) span;
		assertEquals("Wrong id.", text, test.getAgenda());
		
	}
	
	@Override
	protected Parser[] getParsers(){
		return new Parser[]{FormatParseCurly.AGENDA};
	}
}
