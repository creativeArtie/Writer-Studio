package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelRestDebug extends LinedLevelTest{
	
	@Test
	public void heading(){
		Document doc = build(new Object[]{
			"===", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text", new Object[]{"\\", "#"}, "abc"}},
			new Object[]{"#DRAFT", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Text\\#abc", 
			LinedType.HEADING, 3, StatusType.DRAFT, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void outline(){
		Document doc = build(new Object[]{
			"!#", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Text abc"}},
			new Object[]{"#DRAFT", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Text abc", 
			LinedType.OUTLINE, 1, StatusType.DRAFT, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void quote(){
		Document doc = build(new Object[]{
			">>", new Object[]{new Object[]{"@id:Text abc"}}
		});
		testLeveled(doc.get(0), "@id:Text abc", LinedType.QUOTE, 2);
	}
	
	@Test
	public void numbered(){
		Document doc = build(new Object[]{
			"\t\t\t\t#", new Object[]{new Object[]{"@id:Text abc"}}
		});
		testLeveled(doc.get(0), "@id:Text abc", LinedType.NUMBERED, 5);
	}
	
	@Test
	public void emptyBullet(){
		Document doc = build(new Object[]{
			"-", "\n"
		});
		testLeveled(doc.get(0), "", LinedType.BULLET, 1);
	}
	@Test
	public void fullBullet(){
		Document doc = build(new Object[]{
			"-", new Object[]{new Object[]{"@id:Text abc"}}, "\n"
		});
		testLeveled(doc.get(0), "@id:Text abc", LinedType.BULLET, 1);
	}
	
	@Test
	public void bullet(){
		Document doc = build(new Object[]{
			"-", new Object[]{new Object[]{"@id:Text abc"}}
		});
		testLeveled(doc.get(0), "@id:Text abc", LinedType.BULLET, 1);
	}
	
	@Test
	public void bullet1(){
		Document doc = build(new Object[]{
			"\t\t\t\t\t-", new Object[]{new Object[]{"@id:Text abc"}}
		});
		testLeveled(doc.get(0), "@id:Text abc", LinedType.BULLET, 6);
	}
}
