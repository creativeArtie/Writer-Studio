package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class IDOrderDebug extends IDTest{
	@Test
	public void subCategoryIDs(){
		Document test = build(
			new Object[]{new Object[]{"abc"}, "-", new Object[]{"dd"}, "-", 
				new Object[]{"flies"}}, 
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}, "-", new Object[]{"dd"}, "-", 
				new Object[]{"fly"}}
		);
		IDTestPrep builder = new IDTestPrep();
		builder.add(test(test, 0, new String[]{"abc", "dd"}, "flies"), 0);
		builder.add(test(test, 2, new String[]{"abc", "dd"}, "fly"  ), 1);
		builder.testAll(true);
	}
	
	@Test
	public void mix(){
		Document test = build(
			new Object[]{"-", new Object[]{"id"}},
			new String[]{"\n"},
			new Object[]{new Object[]{"abc"}}, 
			new String[]{"\n"}, 
			new Object[]{new Object[]{"kkk"}},
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}, "-", new Object[]{"ddd"}},
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}, "-"}
		);
		IDTestPrep builder = new IDTestPrep();
		builder.add(test(test, 0, new String[]{""},    "id" ),2);
		builder.add(test(test, 2, new String[0],       "abc"),0);
		builder.add(test(test, 4, new String[0],       "kkk"),1);
		builder.add(test(test, 6, new String[]{"abc"}, "ddd"),4);
		builder.add(test(test, 8, new String[]{"abc"}, ""   ),3);
		builder.testAll(true);
	}
	
	@Test
	public void sameCategory(){
		Document test = build(
			new Object[]{new Object[]{"abc"}, "-", new Object[]{"de"}}, 
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}},
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}, "-", new Object[]{"aaa"}},
			new String[]{"\n"}, 
			new Object[]{new Object[]{"abc"}, "-"}
		);
		IDTestPrep builder = new IDTestPrep();
		builder.add(test(test, 0, new String[]{"abc"}, "de" ),3);
		builder.add(test(test, 2, new String[0],       "abc"),0);
		builder.add(test(test, 4, new String[]{"abc"}, "aaa"),2);
		builder.add(test(test, 6, new String[]{"abc"}, ""   ),1);
		builder.testAll(true);
	}
	
	@Test
	public void subCategory(){
		Document test = build(
			new Object[]{new Object[]{"a"}, "-", new Object[]{"b"}, "-", 
				new Object[]{"c"}
			}, 
			new String[]{"\n"},
			new Object[]{
				new Object[]{"a"}, "-", "-", new Object[]{"d"}
			}
		);
		IDTestPrep builder = new IDTestPrep();
		builder.add(test(test, 0, new String[]{"a", "b"},"c"),1);
		builder.add(test(test, 2, new String[]{"a", ""}, "d"),0);
		builder.testAll(true);
	}
	
	@Test
	public void basicSimpleOrder(){
		Document test = build(
			new Object[]{new Object[]{"aaa"}}, 
			new String[]{"\n"}, 
			new Object[]{new Object[]{"ccc"}}
		);
		IDTestPrep builder = new IDTestPrep();
		builder.add(test(test, 0, new String[0], "aaa"),0);
		builder.add(test(test, 2, new String[0], "ccc"),1);
		builder.testAll(true);
		
	}

	@Override
	protected Parser[] getParsers(){
		return new Parser[]{new IDParser(IDType.NONE), new SpanTestEnder()};
	}
}
