package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class ContentDebug extends SpanTest{

	@Test
	public void simple(){
		test(build(new Object[]{"hello"}), "hello");
	}
	
	@Test
	public void escape(){
		test(build(new Object[]{new Object[]{"\\", "a"}}), "a");
	}
	
	@Test
	public void escapeSpecial(){
		test(build(new Object[]{new Object[]{"\\", "\\"}}), "\\");
	}
	
	@Test
	public void escapeEnd(){
		test(build(new Object[]{new Object[]{"\\"}}), 
		"");
	}
	
	@Test
	public void middleEscape(){
		test(build(new Object[]{"see", new Object[]{"\\", "d"}, "ead"}), 
		"seedead");
	}

	private void test(Document doc, String output){
		Span span = doc.get(0);
		assertEquals("Wrong Class.", ContentSpan.class, span.getClass());
		assertEquals("Wrong output.", output, ((ContentSpan)span).getOutput());
	}
	
	@Override
	protected Parser[] getParsers(){
		return new Parser[]{new ContentParser()};
	}
}
