package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelHeadDebug extends LinedLevelTest{
	
	@Test
	public void spacedIDFullHeading(){
		Document doc = build(new Object[]{
			"===", "   @", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}, "\n"
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 3, StatusType.OTHER, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void nonSpacedIDFullHeading(){
		Document doc = build(new Object[]{
			"===", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 3, StatusType.OTHER, new String[]{"link"}, 
			"id");
	}
	@Test
	public void noStatusHeading(){
		Document doc = build(new Object[]{
			"===", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Title"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 3, StatusType.NONE, new String[]{"link"}, 
			"id");
	}
	@Test
	public void nonSpacedIDTitlelessHeading(){
		Document doc = build(new Object[]{
			"===", "@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "", 
			LinedType.HEADING, 3, StatusType.OTHER, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void partlyIDHeading(){
		Document doc = build(new Object[]{
			"===", "@", new Object[]{new Object[]{"id"}}, 
		});
		testSectionLeveled(doc.get(0), "", 
			LinedType.HEADING, 3, StatusType.NONE, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void idLessHeading(){
		Document doc = build(new Object[]{
			"===", new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 3, StatusType.OTHER, new String[0], "");
	}
	
	@Test
	public void idlessHeading(){
		Document doc = build(new Object[]{
			"===", new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 3, StatusType.OTHER, new String[0], "");
	}
	@Test
	public void statusOnlyHeading(){
		Document doc = build(new Object[]{
			"===", new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "", LinedType.HEADING, 3, 
			StatusType.OTHER, new String[0], "");
	}
	@Test
	public void heading6(){
		Document doc = build(new Object[]{"======",
			"@", new Object[]{new Object[]{"id"}}, ":",
			new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 6, StatusType.OTHER, new String[]{"link"}, 
			"id");
	}
	
	@Test
	public void heading1(){
		Document doc = build(new Object[]{
			"=", new Object[]{new Object[]{"Title"}},
			new Object[]{"#", new Object[]{"abc"}}
		});
		testSectionLeveled(doc.get(0), "Title", 
			LinedType.HEADING, 1, StatusType.OTHER, new String[0], "");
	}
}
