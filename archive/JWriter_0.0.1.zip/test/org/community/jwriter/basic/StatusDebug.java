package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class StatusDebug extends SpanTest{
    
    @Test
    public void statusOther1(){
		Document test = build(new Object[]{"#", new Object[]{"abc"}});
		test(test, StatusType.OTHER, "abc");
	}
	
    @Test
    public void statusOther2(){
		Document test = build(new Object[]{"#", 
			new Object[]{new Object[]{"\\", "F"}, "INAL"}
		});
		test(test, StatusType.OTHER, "FINAL");
	}
	
    @Test
    public void statusStub1(){
		Document test = build(
			new Object[]{"#STUB", new Object[]{"d2"}}, ///Status
			new String[]{"\n"} ///New line
		);
		test(test, StatusType.STUB, "d2");
	}
	
    @Test
    public void statusFinal1(){
		Document test = build(new Object[]{"#FINAL"});
		test(test, StatusType.FINAL, "");
	}
	
    @Test
    public void statusFinal2(){
		Document test = build(new Object[]{"#FINAL", new Object[]{" 2 "}});
		test(test, StatusType.FINAL, "2");
	}
	
    @Test
    public void statusDraftRandom(){
		Document test = build(new Object[]{"#DRAFT", new Object[]{"abc  ad"}});
		test(test, StatusType.DRAFT, "abc ad");
	}
	
	private void test(Document doc, StatusType type, String text){
		Span span = doc.get(0);
		assertEquals("Wrong class gotten: " + span.getClass(), StatusSpan.class, 
			span.getClass());
		StatusSpan test = (StatusSpan) span;
		assertEquals("Wrong Parser.", type, test.getType());
		assertEquals("Wrong text.", text, test.getDetail());
	}
	
	@Override
	protected Parser[] getParsers(){
		Parser[] base = StatusParser.values();
		Parser[] ans = new Parser[base.length + 1];
		System.arraycopy(base, 0, ans, 0, base.length);
		ans[ans.length - 1] = new SpanTestEnder();
		return ans;
	}

}
