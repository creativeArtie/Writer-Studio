package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class CurlyDebug extends SpanTest{
	@Test
	public void parseCite(){
		Document test = build(
			new Object[]{"{@", new Object[]{new Object[]{"abc"}}, "}"}
		);
		testNote(test.get(0), IDType.NOTE, new String[]{"note"}, "abc");
	}

	@Test
	public void parseEndnote(){
		Document test = build(
			new Object[]{ "{*", new Object[]{new Object[]{"abc"}}, "}"}
		);
		testNote(test.get(0), IDType.ENDNOTE, new String[]{"end"}, "abc");
	}

	@Test
	public void parseFootnote1(){
		Document test = build(
			new Object[]{"{^", new Object[]{new Object[]{"abc"}}, "}"}
		);
		testNote(test.get(0), IDType.FOOTNOTE, new String[]{"foot"}, "abc");
	}

	@Test
	public void parseFootnote2(){
		Document test = build(
			new Object[]{"{^", new Object[]{new String[]{"abc"}}}
		);
		testNote(test.get(0), IDType.FOOTNOTE, new String[]{"foot"}, "abc");
	}

	@Test
	public void parseFootnote3(){
		Document test = build(
			new Object[]{"{^", new Object[]{new Object[]{"abc"}}}
		);
		testNote(test.get(0), IDType.FOOTNOTE, new String[]{"foot"}, "abc");
	}

	@Test
	public void parseFootnote4(){
		Document test = build(new Object[]{"{^"});
		testNote(test.get(0), IDType.FOOTNOTE, new String[0], "");
	}

	@Test
	public void parseFootnote5(){
		Document test = build(new Object[]{"{^", "}"});
		testNote(test.get(0), IDType.FOOTNOTE, new String[0], "");
	}

	private void testNote(Span span, IDType type, String[] expectRef,
			String expectId){
		assertEquals("Wrong span class", FormatSpanCurlyID.class,
			span.getClass());
		FormatSpanCurlyID test = (FormatSpanCurlyID) span;
		assertEquals("Wrong note type", type, test.getType());
		assertArrayEquals("Wrong Category.", expectRef, test.getCategory());
		assertEquals("Wrong id.", expectId, test.getIdentity());
	}

	@Override
	protected Parser[] getParsers(){
		return FormatParseCurly.values();
	}
}
