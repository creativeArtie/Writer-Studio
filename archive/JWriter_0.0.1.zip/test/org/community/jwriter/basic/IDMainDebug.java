package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.lang.reflect.Field;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class IDMainDebug extends IDParamTest{
	
	private static ID getID(IDType type){
		return new ID(Arrays.asList(type.getCategory()), "abc");
	}
	
	@Test
	public void endnote(){
		run("{*abc}", "!*abc:text", getID(IDType.ENDNOTE));
	}
	
	@Test
	public void footnote(){
		run("{^abc}", "!^abc:text", getID(IDType.FOOTNOTE));
	}
	
	@Test
	public void link(){
		run("<@abc>", "!@abc:text", getID(IDType.LINK));
	}
	
	@Test
	public void outline(){
		run("<@abc>", "!#@abc:hello", getID(IDType.LINK));
	}
	
	@Test
	public void heading(){
		run("<@abc>", "=@abc:hello", getID(IDType.LINK));
	}
	
	private static int i = 0;
	@Test
	public void note(){
		run("{@abc}", "!%@abc:hello", getID(IDType.NOTE), true);
		i++;
	}
	
	private void run(String ref, String line, ID id){
		run(ref,line, id, false);
	}
	
	private void run(String ref, String line, ID id, boolean b){
		StringBuilder text = new StringBuilder();
		int i = 0;
		int idCount = 0;
		int refCount = 0;
		for (States state: input){
			if (state == States.ID){
				text.append(line + i + "\n");
				idCount++;
			} else {
				text.append(ref + i + "\n");
				refCount++;
			}
			i++;
		}
		String which = Arrays.asList(input).toString();
		// if (b) System.out.println(which);
		Document doc = new Document(text.toString(), getParsers());
		// if (b) System.out.println(doc);
		Span span = doc.get(0);
		IDData test = doc.getMap().get(id);
		assertEquals("Wrong ref size: " + which, refCount, test.getRefs().size());
		assertEquals("Wrong id size: " + which, idCount, test.getIDs().size());
		assertEquals("Wrong status: " + which, expected, test.getStatus());
	}


	@Override
	protected Parser[] getParsers(){
		return new Parser[]{new MainParser()};
	}
}
