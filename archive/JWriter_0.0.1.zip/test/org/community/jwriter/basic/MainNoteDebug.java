package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.MainTest.*;

@RunWith(JUnit4.class)
public class MainNoteDebug extends MainTest{
	@Test
	public void basic(){
		SectionExpect raw = new SectionExpect();
		ID id = raw.addNoteID("!%@see:basic note\n", "see");
		raw.addLine("!>media: web\n", LinedTypeSource.MEDIA, "web");
		testNote(build(raw).get(0), raw, id);
	}
	
	@Test
	public void backToBackNotes(){
		SectionExpect raw1 = new SectionExpect();
		raw1.addLine(LinedType.NOTE, "!% basic note\n");
		
		SectionExpect raw2 = new SectionExpect();
		ID id = raw2.addNoteID("!%@ed:data\n", "ed");
		
		Document doc = build(raw1, raw2);
		testNote(doc.get(0), raw1, null);
		testNote(doc.get(1), raw2, id);
	}
	
	@Test
	public void sources(){
		SectionExpect raw = new SectionExpect();
		raw.addLine(LinedType.SOURCE,"!>dsaf\n");
		raw.addLine("!>author:Johny, Dee\n", LinedTypeSource.AUTHOR, "Johny, Dee");
		raw.addLine("!>author:Abc, cd\n", LinedTypeSource.AUTHOR, "Abc, cd");
		
		Document doc = build(raw);
		testNote(doc.get(0), raw, null);
	}
	
	@Test
	public void noteMiddle(){
		SectionExpect raw1 = new SectionExpect();
		raw1.addLine(LinedType.PARAGRAPH, "Random text\n");
		
		SectionExpect raw2 = new SectionExpect();
		ID id = raw2.addNoteID("!%@ed:data\n", "ed");
		
		SectionExpect raw3 = new SectionExpect();
		raw3.addLine(LinedType.PARAGRAPH, "abc");
		
		Document doc = build(raw1, raw2, raw3);
		testSection(doc.get(0), raw1, null, null, null);
		testNote(doc.get(1), raw2, id);
		testSection(doc.get(2), raw3, raw1, null, null);
	}
}
