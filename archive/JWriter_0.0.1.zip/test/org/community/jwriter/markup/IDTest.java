package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.Set;

import org.community.jwriter.basic.*;

public abstract class IDTest extends SpanTest{
	public class IDTestPrep{
		private ArrayList<Integer> order;
		private ArrayList<ID> idList;
		private ArrayList<IDStatus> errors;
		IDMap.Builder builder;
		
		public IDTestPrep(){
			builder = IDMap.builder();
			idList = new ArrayList<>();
			errors = new ArrayList<>();
			order = new ArrayList<>();
		}
		
		public void addID(IDSpan span, IDStatus outcome, int i){
			addID(span);
			idList.add(span.getID());
			errors.add(outcome);
			order.add(i);
		}
		
		public void add(IDSpan span, int i){
			addID(span, IDStatus.UNUSED, i);
		}
		
		public void addID(IDSpan span){
			builder.addID(span.getID(), span);
		}
		
		public void addRef(IDSpan span, IDStatus outcome, int i){
			addRef(span);
			idList.add(i, span.getID());
			errors.add(i, outcome);
			order.add(i);
		}
		
		public void addRef(IDSpan span){
			builder.addRef(span.getID(), span);
		}
		
		public void testAll(){
			testAll(false);
		}
		
		public void testAll(boolean printOrder){
			IDMap system = builder.build();
			
			Set<Entry<ID,IDData>> entries = system.entrySet();
			if (printOrder) {
				System.out.println(system.keySet());
			}
			int i = 0;
			assertEquals("Wrong key size", idList.size(), entries.size());
			for (Entry<ID, IDData> entry: entries){
				int idx = order.indexOf(i);
				assertEquals("Wrong span order at " + idx, idList.get(idx), 
					entry.getKey());
				assertEquals("Wrong id status at " + idx, 
					errors.get(idx), entry.getValue().getStatus());
				i++;
			}
		}
	}
	
	protected IDSpan test(Document doc, int index, String[] ref, String id){
		Span span = doc.get(index);
		assertEquals("Wrong class at " + index, IDSpan.class, span.getClass());
		ID test = ((IDSpan) span).getID();
		assertArrayEquals("Wrong Category at " + index, ref, test.getCategory());
		assertEquals("Wrong ID at " + index, id, test.getIdentity());
		return (IDSpan) span;
	}
}
