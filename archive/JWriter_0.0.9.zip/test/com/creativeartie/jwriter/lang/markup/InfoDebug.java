package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class InfoDebug {
    public static void assertDataFormatted(SpanBranch span, Span data){
        InfoDataSpanFormatted test = assertClass(span, 
            InfoDataSpanFormatted.class);
        
        InfoDataType type = InfoDataType.FORMATTED;
        assertSame(getError("data", test), data, test.getData());
        assertData(test, type);
    }
    
    public static void assertDataNumber(SpanBranch span, int data){
        InfoDataSpanNumber test = assertClass(span, InfoDataSpanNumber.class);
        
        InfoDataType type = InfoDataType.NUMBER;
        
        assertEquals(getError("data", test), new Integer(data), test.getData());
        assertData(test, type);
    }
    
    public static void assertDataText(SpanBranch span, Span data){
        InfoDataSpanText test = assertClass(span, InfoDataSpanText.class);
        
        InfoDataType type = InfoDataType.TEXT;
        
        assertSame(getError("data", test), data, test.getData());
        assertData(test, type);
    }
    
    private static void assertData(InfoDataSpan test, InfoDataType type)
    {
        DetailStyle[] styles = new DetailStyle[]{type};
        
        assertEquals(getError("type", test), type, test.getDataType());
        assertBranch(test, styles);
    }
    
    public static void assertField(SpanBranch span, InfoFieldType type){
        InfoFieldSpan test = assertClass(span, InfoFieldSpan.class);
        
        DetailStyle[] styles = new DetailStyle[]{type};
        
        assertEquals(getError("type", test), type, test.getFieldType());
        assertBranch(test, styles);
    }
    
    @Test
    public void dataFormatted(){
        ///           01234 5678901
        String raw = "abcd*\\*efg*";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoDataParser.FORMATTED);
        SpanBranch data   = doc.assertChild(1, raw,      0);
        SpanBranch format = doc.assertChild(4, raw,      0, 0);
        SpanBranch text1  = doc.assertChild(1, "abcd",   0, 0, 0);
        SpanBranch text2  = doc.assertChild(2, "\\*efg", 0, 0, 2);
        SpanBranch escape = doc.assertChild(2, "\\*",    0, 0, 2, 0);
        
        assertDataFormatted(data, format);
        FormatSpanDebug.assertMain(format, "abcd*efg", "abcd*efg");
        FormatSpanDebug.assertContent(text1, "abcd", false, false);
        FormatSpanDebug.assertContent(text2, "*efg", false, false, 
            FormatType.ITALICS);
        ContentDebug.assertEscape(escape, "*");
        
        doc.assertDataLeaf(0,  4, "abcd", 0, 0, 0, 0);
        doc.assertKeyLeaf( 4,  5, "*",    0, 0, 1);
        doc.assertKeyLeaf( 5,  6, "\\",   0, 0, 2, 0, 0);
        doc.assertDataLeaf(6,  7, "*",    0, 0, 2, 0, 1);
        doc.assertDataLeaf(7, 10, "efg",  0, 0, 2, 1);
        doc.assertKeyLeaf(10, 11, "*",    0, 0, 3);        

        doc.assertIds();
    }

    @Test
    public void dataText(){
        ///           0 1234
        String raw = "*\\*a";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoDataParser.TEXT);
        SpanBranch data   = doc.assertChild(1, raw,      0);
        SpanBranch text   = doc.assertChild(3, "*\\*a",  0, 0);
        SpanBranch escape = doc.assertChild(2, "\\*",    0, 0, 1);
        
        assertDataText(data, text);
        ContentDebug.assertContent(text, "**a", false, false);
        ContentDebug.assertEscape(escape, "*");
        
        doc.assertDataLeaf(0, 1, "*",  0, 0, 0);
        doc.assertKeyLeaf( 1, 2, "\\", 0, 0, 1, 0);
        doc.assertDataLeaf(2, 3, "*",  0, 0, 1, 1);
        doc.assertDataLeaf(3, 4, "a",  0, 0, 2);        

        doc.assertIds();
    }

    @Test
    public void dataNumber(){
        ///           012
        String raw = "48";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoDataParser.NUMBER);
        SpanBranch data   = doc.assertChild(1, raw,  0);
        
        assertDataNumber(data, 48);
        
        doc.assertDataLeaf(0, 2, "48", 0, 0);        

        doc.assertIds();
    }

    @Test
    public void dataNumberRightSpaces(){
        ///           01234
        String raw = "  48";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoDataParser.NUMBER);
        SpanBranch data   = doc.assertChild(1, raw,  0);
        
        assertDataNumber(data, 48);
        
        doc.assertDataLeaf(0, 4, "  48", 0, 0);

        doc.assertIds();
    }

    @Test
    public void dataNumberLeftSpaces(){
        ///           01 234
        String raw = "48\t ";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoDataParser.NUMBER);
        SpanBranch data   = doc.assertChild(1, raw,  0);
        
        assertDataNumber(data, 48);
        
        doc.assertDataLeaf(0, 4, "48\t ", 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void fieldPages(){
        ///           012345
        String raw = "pages";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.PAGES);
        
        doc.assertFieldLeaf(0, 5, raw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void fieldSource(){
        ///           0123456
        String raw = "source";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.SOURCE);
        
        doc.assertFieldLeaf(0, 6, raw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void fieldInText(){
        ///           01234567
        String raw = "in-text";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.IN_TEXT);
        
        doc.assertFieldLeaf(0, 7, raw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void fieldFootnote(){
        ///           012345678
        String raw = "footnote";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.FOOTNOTE);
        
        doc.assertFieldLeaf(0, 8, raw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void fieldError(){
        ///           012345
        String raw = "error";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.ERROR);
        
        doc.assertFieldLeaf(0, 5, raw, 0, 0);
    }
    
    @Test
    public void fieldErrorRandom(){
        ///           012345
        String raw = "p-ges";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, 
            InfoFieldParser.getParsers());
        SpanBranch field = doc.assertChild(1, raw, 0);
        
        assertField(field, InfoFieldType.ERROR);
        
        doc.assertFieldLeaf(0, 5, raw, 0, 0);        

        doc.assertIds();
    }
}
