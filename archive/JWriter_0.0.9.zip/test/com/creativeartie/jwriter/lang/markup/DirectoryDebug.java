package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import java.util.Arrays;
import java.util.ArrayList;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class DirectoryDebug{
    
    static void assertBuildId(LinedSpan read, IDBuilder expected, 
        CatalogueIdentity test)
    {
        if (expected == null){
            assertFalse("Identity should not be build.", test != null);
        } else {
            assertTrue("Identity should not be build", test != null);
            assertEquals(getError("create id", read), expected.build(), test);
        }
    }
    
    static void assertId(SpanBranch span, DirectoryType type,
        IDBuilder produces)
    {
        DirectorySpan test = assertClass(span, DirectorySpan.class);
        
        CatalogueIdentity id = produces.build();
        
        assertEquals(getError("purpose", test), type, test.getPurpose());
        assertEquals(getError("id",      test), id,   test.buildId());
    }
    
    private static final SetupParser[] parsers = new SetupParser[]{
        new DirectoryParser(DirectoryType.ENDNOTE)};
    
    private static IDBuilder buildId(String id){
        return new IDBuilder().addCategory("end").setId(id);
    }
    
    @Test
    public void basic(){
        ///           012345
        String raw = "Hello";
        DocumentAssert doc  = assertDoc(1, raw, parsers);
        SpanBranch test = doc.assertChild(1, raw, 0);
        SpanBranch id   = doc.assertChild(1, raw, 0, 0);
        
        IDBuilder builder = buildId("hello");
        assertId(test, DirectoryType.ENDNOTE, builder);
        ContentDebug.assertContent(id, raw, false, false);
        
        doc.assertIdLeaf(0, raw.length(), raw, 0, 0, 0);

        doc.assertIds();
    }
    
    @Test
    public void singleCategory(){
        ///           0123456
        String raw = "cat-hi";
        DocumentAssert doc  = assertDoc(1, raw, parsers);
        SpanBranch test = doc.assertChild(3, raw, 0);
        SpanBranch cat  = doc.assertChild(1, "cat", 0, 0);
        SpanBranch id   = doc.assertChild(1, "hi",  0, 2);
        
        IDBuilder builder = buildId("hi").addCategory("cat");
        assertId(test, DirectoryType.ENDNOTE, builder);
        ContentDebug.assertContent(cat, "cat", false, false);
        ContentDebug.assertContent(id,  "hi",  false, false);
        
        doc.assertIdLeaf( 0, 3, "cat", 0, 0, 0);
        doc.assertKeyLeaf(3, 4, "-",   0, 1); 
        doc.assertIdLeaf( 4, 6, "hi",  0, 2, 0);

        doc.assertIds();
    }
    
    @Test
    public void twoSubcategories(){
        ///           0123456
        String raw = "a-b-c ";
        DocumentAssert doc  = assertDoc(1, raw, parsers);
        SpanBranch test = doc.assertChild(5, raw,  0);
        SpanBranch cat1 = doc.assertChild(1, "a",  0, 0);
        SpanBranch cat2 = doc.assertChild(1, "b",  0, 2);
        SpanBranch id   = doc.assertChild(1, "c ", 0, 4);
        
        IDBuilder builder = buildId("c").addCategory("a", "b");
        assertId(test, DirectoryType.ENDNOTE, builder);
        
        ContentDebug.assertContent(cat1, "a", false, false);
        ContentDebug.assertContent(cat2, "b", false, false);
        ContentDebug.assertContent(id,   "c", false, true);
        
        doc.assertIdLeaf( 0, 1, "a",  0, 0, 0);
        doc.assertKeyLeaf(1, 2, "-",  0, 1);
        doc.assertIdLeaf( 2, 3, "b",  0, 2, 0);
        doc.assertKeyLeaf(3, 4, "-",  0, 3);
        doc.assertIdLeaf( 4, 6, "c ", 0, 4, 0);

        doc.assertIds();
    }
    
    @Test
    public void emptySubcategory(){
        ///           01234
        String raw = "-see";
        DocumentAssert doc  = assertDoc(1, raw, parsers);
        SpanBranch test = doc.assertChild(2, raw,   0);
        SpanBranch id   = doc.assertChild(1, "see", 0, 1);
        
        IDBuilder builder = buildId("see");
        assertId(test, DirectoryType.ENDNOTE, builder.addCategory(""));
        
        ContentDebug.assertContent(id, "see", false, false);
        
        doc.assertKeyLeaf(0, 1, "-",   0, 0);
        doc.assertIdLeaf( 1, 4, "see", 0, 1, 0);

        doc.assertIds();
    }
    
    @Test
    public void emptySecondSubcategory(){
        ///           012345678901234
        String raw = "yes  sir- -WEE";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch test = doc.assertChild(5, raw,        0);
        SpanBranch cat1 = doc.assertChild(1, "yes  sir", 0, 0);
        SpanBranch cat2 = doc.assertChild(1, " ",        0, 2);
        SpanBranch id = doc.assertChild( 1, "WEE",       0, 4);
        
        IDBuilder builder = buildId("wee").addCategory("yes sir" , "");
        assertId(test, DirectoryType.ENDNOTE, builder);
        
        ContentDebug.assertContent(cat1, "yes sir", false, false);
        ContentDebug.assertContent(cat2, "",        true,  true);
        ContentDebug.assertContent(id,   "WEE",     false, false);
        
        doc.assertIdLeaf (0,   8, "yes  sir", 0, 0, 0);
        doc.assertKeyLeaf(8,   9, "-",        0, 1);
        doc.assertIdLeaf (9,  10, " ",        0, 2, 0);
        doc.assertKeyLeaf(10, 11, "-",        0, 3);
        doc.assertIdLeaf (11, 14, "WEE",      0, 4, 0);

        doc.assertIds();
    }
    
    @Test
    public void categoryEscape(){
        ///            0123
        String raw = "\\-c";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch test    = doc.assertChild(1, raw,    0);
        SpanBranch content = doc.assertChild(2, "\\-c", 0, 0);
        SpanBranch escape  = doc.assertChild(2, "\\-",  0, 0, 0);
        
        IDBuilder builder = buildId("-c");
        assertId(test, DirectoryType.ENDNOTE, builder);
        
        ContentDebug.assertContent(content, "-c", false, false);
        ContentDebug.assertEscape(escape, "-");
        
        doc.assertKeyLeaf(0, 1, "\\", 0, 0, 0, 0);
        doc.assertIdLeaf( 1, 2, "-",  0, 0, 0, 1);
        doc.assertIdLeaf( 2, 3, "c",  0, 0, 1);

        doc.assertIds();
    }
    
    @Test
    public void noId(){
        ///            0123
        String raw = "no-";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch test    = doc.assertChild(2, raw,  0);
        SpanBranch content = doc.assertChild(1, "no", 0, 0);
        
        IDBuilder builder = buildId("").addCategory("no");
        assertId(test, DirectoryType.ENDNOTE, builder);
        
        ContentDebug.assertContent(content, "no", false, false);
        
        doc.assertIdLeaf( 0, 2, "no", 0, 0, 0);
        doc.assertKeyLeaf(2, 3, "-",  0, 1);

        doc.assertIds();
    }
}
