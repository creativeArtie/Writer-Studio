package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class FormatAgendaDebug{
    
    public static void assertAgenda(SpanBranch span, String text, IDBuilder id){
        FormatSpanAgenda test = assertClass(span, FormatSpanAgenda.class);
        
        DetailStyle[] styles = new DetailStyle[]{AuxiliaryStyle.AGENDA};
        
        assertEquals(getError("agenda", test), text, test.getAgenda());
        assertSpanIdentity(test, id);
        assertBranch(span, styles, CatalogueStatus.UNUSED);
    }
    
    static IDBuilder buildId(String id){
        return new IDBuilder().addCategory("agenda", "inline").setId(id);
    }
    
    private static final SetupParser[] parsers = new SetupParser[]{
        FormatParseAgenda.PARSER};

    @Test
    public void complete(){
        ///               0123456789
        String rawText = "{!Agenda}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch agenda = doc.assertChild(3, rawText,  0);
        SpanBranch text   = doc.assertChild(1, "Agenda", 0, 1);
        
        IDBuilder id = buildId("0");
        doc.addId(id,  0);

        
        assertAgenda(agenda, "Agenda", id);
        ContentDebug.assertContent(text, "Agenda", false, false);
        
        doc.assertKeyLeaf( 0, 2, "{!",     0, 0);
        doc.assertTextLeaf(2, 8, "Agenda", 0, 1, 0);
        doc.assertKeyLeaf( 8, 9, "}",     0, 2);

        doc.assertIds();
    }
    
    @Test
    public void noEnd(){
        ///               012345
        String rawText = "{!abc";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch agenda = doc.assertChild(2, rawText,  0);
        SpanBranch text   = doc.assertChild(1, "abc", 0, 1);
        
        IDBuilder id = buildId("0");
        
        assertAgenda(agenda, "abc", id);
        ContentDebug.assertContent(text, "abc", false, false);
        
        doc.assertKeyLeaf( 0, 2, "{!",  0, 0);
        doc.assertTextLeaf(2, 5, "abc", 0, 1, 0);        doc.addId(id, 0);

        doc.assertIds();
    }
    
    @Test
    public void onlyStart(){
        ///               012
        String rawText = "{!";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch agenda = doc.assertChild(1, rawText,  0);
        
        IDBuilder id = buildId("0");
        
        assertAgenda(agenda, "", id);
        
        doc.assertKeyLeaf( 0, 2, "{!",  0, 0);        doc.addId(id, 0);

        doc.assertIds();
    }
    
    @Test 
    public void noText(){
        ///               0123
        String rawText = "{!}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch agenda = doc.assertChild(2, rawText,  0);
        
        IDBuilder id = buildId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, "", id);
        
        doc.assertKeyLeaf(0, 2, "{!", 0, 0);
        doc.assertKeyLeaf(2, 3, "}",  0, 1);

        doc.assertIds();
       
    }
        
}
