package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;


import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Optional;

import com.creativeartie.jwriter.lang.*;


/// @see SupplementSectionDebug
@RunWith(JUnit4.class)
public class MainSectionDebug {

    public void assertSection(SpanBranch span, Span head,
        CatalogueStatus status, IDBuilder id)
    {
        MainSpanSection test = assertClass(span, MainSpanSection.class);

        DetailStyle[] styles = new DetailStyle[]{AuxiliaryStyle.MAIN_SECTION};

        assertSpan("head", head, test.getSelfSection());
        assertSpanIdentity(span, id);
        assertBranch(test, styles, status);
    }

    @Test
    public void simple(){
        String raw = "abc";
        DocumentAssert doc = assertDoc(1, raw, new MainParser());
        SpanBranch section = doc.assertChild(1, raw, 0);
        SpanBranch line    = doc.assertChild(1, raw, 0, 0);
        SpanBranch format  = doc.assertChild(1, raw, 0, 0, 0);

        IDBuilder builder = new IDBuilder().addCategory("head").setId("0");
        doc.addId(builder, 0);
        doc.assertIds();

        assertSection(section, null, CatalogueStatus.UNUSED, builder);
        LinedRestDebug.assertParagraph(line, format);
    }

    @Test
    public void allSectionLines(){
        String[] texts = new String[]{">quote\n", "#numbered\n", "-bullet\n",
            "!@hyperlink:http://google.com\n", "!^footnote: many text\n",
            "!*endnote: text\n", "!!agenda\n", "***\n", "abc\n"};
        String raw = String.join("", texts);
        DocumentAssert doc = assertDoc(1, raw, new MainParser());
        SpanBranch section = doc.assertChild(texts.length, raw, 0);
        SpanBranch[] lines = new SpanBranch[texts.length];
        int i = 0;
        lines[i] = doc.assertChild(3, texts[i], 0, i++); /// quote
        lines[i] = doc.assertChild(3, texts[i], 0, i++); /// numbered
        lines[i] = doc.assertChild(3, texts[i], 0, i++); /// bullet
        lines[i] = doc.assertChild(5, texts[i], 0, i++); /// hyperlink
        lines[i] = doc.assertChild(5, texts[i], 0, i++); /// footnote
        lines[i] = doc.assertChild(5, texts[i], 0, i++); /// endnote
        lines[i] = doc.assertChild(3, texts[i], 0, i++); /// agenda
        lines[i] = doc.assertChild(1, texts[i], 0, i++); /// break
        lines[i] = doc.assertChild(2, texts[i], 0, i++); /// paragraph
        SpanBranch quote     = doc.assertChild(1, "quote",      0, 0, 1);
        SpanBranch number    = doc.assertChild(1, "numbered",   0, 1, 1);
        SpanBranch bullet    = doc.assertChild(1, "bullet",     0, 2, 1);
        SpanBranch footnote  = doc.assertChild(1, " many text", 0, 4, 3);
        SpanBranch endnote   = doc.assertChild(1, " text",      0, 5, 3);
        SpanBranch agenda    = doc.assertChild(1, "agenda",     0, 6, 1);
        SpanBranch paragraph = doc.assertChild(1, "abc",        0, 8, 0);

        IDBuilder builder = new IDBuilder();
        builder.addCategory("head").setId("000");
        doc.addId(builder, 3);

        assertSection(section, null, CatalogueStatus.UNUSED, builder);
        LinedLevelRestDebug.assertLevel(lines[0], LinedType.QUOTE, 1, quote);
        LinedLevelRestDebug.assertLevel(lines[1], LinedType.NUMBERED, 1, number);
        LinedLevelRestDebug.assertLevel(lines[2], LinedType.BULLET, 1, bullet);

        builder.reset().addCategory("link").setId("hyperlink");
        doc.addId(builder, 4);
        LinedPointerDebug.assertLink(lines[3], "http://google.com",
            CatalogueStatus.UNUSED, builder);

        builder.reset().addCategory("foot").setId("footnote");
        doc.addId(builder, 2);
        LinedPointerDebug.assertNote(lines[4],
            LinedType.FOOTNOTE, footnote, CatalogueStatus.UNUSED, builder);

        builder.reset().addCategory("end").setId("endnote");
        doc.addId(builder, 1);
        LinedPointerDebug.assertNote(lines[5],
            LinedType.ENDNOTE, endnote, CatalogueStatus.UNUSED, builder);

        builder.reset().addCategory("agenda", "lined").setId("093");
        doc.addId(builder, 0);
        LinedRestDebug.assertAgenda(lines[6], agenda, builder);

        LinedRestDebug.assertBreak(lines[7]);
        LinedRestDebug.assertParagraph(lines[8], paragraph);

        doc.assertIds();
    }

    @Test
    public void list(){
        String[] texts = new String[]{"# abc\n", "# ccc\n", "#dead\n",
            "#win\n"};
        String raw = String.join("", texts);
        DocumentAssert doc = assertDoc(1, raw, new MainParser());
        SpanBranch section = doc.assertChild(texts.length, raw, 0);
        SpanBranch[] lines = new SpanBranch[texts.length];
        for (int i = 0; i < texts.length; i++){
            lines[i] = doc.assertChild(3, texts[i], 0, i);
        }
        SpanBranch[] content = new SpanBranch[texts.length];
        for(int i = 0; i < texts.length; i++){
            int end = texts[i].length() - 1;
            content[i] = doc.assertChild(1, texts[i].substring(1, end), 0, i, 1);
        }

        IDBuilder builder = new IDBuilder();
        builder.addCategory("head").setId("00");
        doc.addId(builder, 0);

        assertSection(section, null, CatalogueStatus.UNUSED, builder);
        for (int i = 0; i < texts.length; i++){
            LinedLevelRestDebug.assertLevel(lines[i],
                LinedType.NUMBERED, 1, content[i]);
        }

        doc.assertIds();
    }

    @Test
    public void sectionWithId(){
        String[] texts = new String[]{"=@a:next!\n",
            "explain"};
        String raw = String.join("", texts);
        DocumentAssert doc = assertDoc(1, raw, new MainParser());
        SpanBranch section = doc.assertChild(2, raw,  0);
        SpanBranch line1    = doc.assertChild(6, texts[0],  0, 0);
        SpanBranch heading  = doc.assertChild(1, "next!",   0, 0, 4);
        SpanBranch line2    = doc.assertChild(1, texts[1],  0, 1);
        SpanBranch content  = doc.assertChild(1, "explain", 0, 1, 0);

        IDBuilder builder = new IDBuilder();
        doc.addId(builder.addCategory("head").setId("00"), 0);

        assertSection(section, line1, CatalogueStatus.UNUSED, builder);

        doc.addId(builder.reset().addCategory("link").setId("a"),  1);

        LinedLevelHeadDebug.assertHeading(line1, heading, LinedType.HEADING, 1,
            builder, EditionType.NONE, CatalogueStatus.UNUSED);
        LinedRestDebug.assertParagraph(line2, content);

        doc.assertIds();
    }

    @Test
    public void emptyToHeading(){
        String[] texts = new String[]{">quote\n", "=next!\n", "explain\n"};
        String raw = String.join("", texts);
        String sec2 = texts[1] + texts[2];
        DocumentAssert doc = assertDoc(2, raw, new MainParser());
        SpanBranch section1 = doc.assertChild(1, texts[0],  0);
        SpanBranch line1    = doc.assertChild(3, texts[0],  0, 0);
        SpanBranch quote    = doc.assertChild(1, "quote",   0, 0, 1);
        SpanBranch section2 = doc.assertChild(2, sec2,      1);
        SpanBranch line2    = doc.assertChild(3, texts[1],  1, 0);
        SpanBranch heading  = doc.assertChild(1, "next!",   1, 0, 1);
        SpanBranch line3    = doc.assertChild(2, texts[2],  1, 1);
        SpanBranch content  = doc.assertChild(1, "explain", 1, 1, 0);

        IDBuilder builder = new IDBuilder().addCategory("head").setId("00");
        doc.addId(builder, 0);

        assertSection(section1, null, CatalogueStatus.UNUSED, builder);
        LinedLevelRestDebug.assertLevel(line1, LinedType.QUOTE, 1, quote);

        doc.addId(builder.reset().addCategory("head").setId("07"), 1);
        assertSection(section2, line2, CatalogueStatus.UNUSED, builder);
        LinedLevelHeadDebug.assertHeading(line2, heading, LinedType.HEADING, 1,
            null, EditionType.NONE, CatalogueStatus.NO_ID);
        LinedRestDebug.assertParagraph(line3, content);

        doc.assertIds();

    }

    /// More test at SupplementSectionDebug
}
