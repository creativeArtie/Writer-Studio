package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class FormatLinkDebug {
    
    public static void assertRefLink(SpanBranch span, String path, String text, CatalogueStatus status, IDBuilder id, FormatType... formats)
    {
        FormatSpanLink test = assertClass(span, FormatSpanLinkRef.class);
        
        DetailStyle[] styles = FormatSpanDebug.mergeStyle(
            new DetailStyle[]{AuxiliaryStyle.REF_LINK, status}, formats);
        
        assertLink(test, path, text, status, styles, formats);
        assertSpanIdentity(span, id);
    }
    
    public static void assertDirLink(SpanBranch span, String path, String text,
        FormatType ... formats)
    {
        FormatSpanLink test = assertClass(span, FormatSpanLinkDirect.class);
        
        DetailStyle[] styles = FormatSpanDebug.mergeStyle(
            new DetailStyle[]{AuxiliaryStyle.DIRECT_LINK}, formats);
            
        assertLink(test, path, text, CatalogueStatus.NO_ID, styles, formats);
    }
    
    private static void assertLink(FormatSpanLink test, String path, 
        String text, CatalogueStatus status, DetailStyle[] styles, 
        FormatType ... formats)
    {
        assertEquals(getError("link path", test),  path,   test.getPath());
        assertEquals(getError("link text", test), text,   test.getText());
        FormatSpanDebug.assertFormats(test, formats);
        assertBranch(test, styles, status);
    }
    
    private static final SetupParser[] parsers = FormatParseLink.getParsers(
        new boolean[4]);
        
    public static IDBuilder buildId(String name){
        return new IDBuilder().addCategory("link").setId("id");
    }
    
    @Test
    public void refFull(){
        ///           012345678901234
        String raw = "<@cat-id|text>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link   = doc.assertChild(5, raw,      0);
        SpanBranch idSpan = doc.assertChild(3, "cat-id", 0, 1);
        SpanBranch cat    = doc.assertChild(1, "cat",    0, 1, 0);
        SpanBranch id     = doc.assertChild(1, "id",     0, 1, 2);
        SpanBranch text   = doc.assertChild(1, "text",   0, 3);
        
        IDBuilder builder = buildId("id").addCategory("cat");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertRefLink(link, "", "text", CatalogueStatus.NOT_FOUND, builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.LINK, builder);
        ContentDebug.assertContent(cat, "cat", false, false);
        ContentDebug.assertContent(text, "text", false, false);
        
        doc.assertKeyLeaf( 0,  2, "<@",   0, 0);
        doc.assertIdLeaf(  2,  5, "cat",  0, 1, 0, 0);
        doc.assertKeyLeaf( 5,  6, "-",    0, 1, 1);
        doc.assertIdLeaf(  6,  8, "id",   0, 1, 2, 0);
        doc.assertKeyLeaf( 8,  9, "|",    0, 2);
        doc.assertTextLeaf(9, 13, "text", 0, 3, 0);
        doc.assertKeyLeaf(13, 14, ">",    0, 4);
        doc.assertIds();
    }
    
    @Test
    public void refEmptyText(){
        ///           01234567890
        String raw = "<@cat-id|>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link   = doc.assertChild(4, raw,      0);
        SpanBranch idSpan = doc.assertChild(3, "cat-id", 0, 1);
        SpanBranch cat    = doc.assertChild(1, "cat",    0, 1, 0);
        SpanBranch id     = doc.assertChild(1, "id",     0, 1, 2);
        
        IDBuilder builder = buildId("id").addCategory("cat");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertRefLink(link, "", "", CatalogueStatus.NOT_FOUND, builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.LINK, builder);
        ContentDebug.assertContent(cat, "cat", false, false);
        
        doc.assertKeyLeaf(0,  2, "<@",  0, 0);
        doc.assertIdLeaf( 2,  5, "cat", 0, 1, 0, 0);
        doc.assertKeyLeaf(5,  6, "-",   0, 1, 1);
        doc.assertIdLeaf( 6,  8, "id",  0, 1, 2, 0);
        doc.assertKeyLeaf(8,  9, "|",   0, 2);
        doc.assertKeyLeaf(9, 10, ">",   0, 3);
        doc.assertIds();
    }
    
    @Test
    public void refNoText(){
        ///           0123456789
        String raw = "<@cat-id>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link   = doc.assertChild(3, raw,      0);
        SpanBranch idSpan = doc.assertChild(3, "cat-id", 0, 1);
        SpanBranch cat    = doc.assertChild(1, "cat",    0, 1, 0);
        SpanBranch id     = doc.assertChild(1,  "id",    0, 1, 2);
        
        IDBuilder builder = buildId("id").addCategory("cat");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertRefLink(link, "", "", CatalogueStatus.NOT_FOUND, builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.LINK, builder);
        ContentDebug.assertContent(cat, "cat", false, false);
        
        doc.assertKeyLeaf(0,  2, "<@",  0, 0);
        doc.assertIdLeaf( 2,  5, "cat", 0, 1, 0, 0);
        doc.assertKeyLeaf(5,  6, "-",   0, 1, 1);
        doc.assertIdLeaf( 6,  8, "id",  0, 1, 2, 0);
        doc.assertKeyLeaf(8, 9, ">",    0, 2);
        doc.assertIds();
    }
    
    @Test
    public void refBasic(){
        ///           012345
        String raw = "<@id>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link   = doc.assertChild(3, raw,  0);
        SpanBranch idSpan = doc.assertChild(1, "id", 0, 1);
        SpanBranch id     = doc.assertChild(1, "id", 0, 1, 0);
        
        IDBuilder builder = buildId("id");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertRefLink(link, "", "", CatalogueStatus.NOT_FOUND, builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.LINK, builder);
        ContentDebug.assertContent(id, "id", false, false);
        
        doc.assertKeyLeaf(0, 2, "<@", 0, 0);
        doc.assertIdLeaf( 2, 4, "id", 0, 1, 0, 0);
        doc.assertKeyLeaf(4, 5, ">",  0, 2);
        doc.assertIds();
    }
    
    @Test
    public void refEmpty(){
        ///           0123
        String raw = "<@>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(2, raw,  0);
        
        assertRefLink(link, "", "", CatalogueStatus.NO_ID, null);
        
        doc.assertKeyLeaf(0, 2, "<@", 0, 0);
        doc.assertKeyLeaf(2, 3, ">",  0, 1);
        doc.assertIds();
    }
    
    @Test
    public void refStart(){
        ///           012
        String raw = "<@";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(1, raw,  0);
        
        assertRefLink(link, "", "", CatalogueStatus.NO_ID, null);
        
        doc.assertKeyLeaf(0, 2, "<@", 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void linkFull(){
        ///           012345678901
        String raw = "<path|text>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(5, raw,    0);
        SpanBranch path = doc.assertChild(1, "path", 0, 1);
        SpanBranch text = doc.assertChild(1, "text", 0, 3);
        
        assertDirLink(link, "path", "text");
        ContentDebug.assertContent(path, "path", false, false);
        ContentDebug.assertContent(text, "text", false, false);
        
        doc.assertKeyLeaf( 0,  1, "<",    0, 0);
        doc.assertPathLeaf(1,  5, "path", 0, 1, 0);
        doc.assertKeyLeaf( 5,  6, "|",    0, 2);
        doc.assertTextLeaf(6, 10, "text", 0, 3, 0);
        doc.assertKeyLeaf(10, 11, ">",    0, 4);        

        doc.assertIds();
    }
    
    @Test
    public void linkPath(){
        ///           0123456
        String raw = "<path>";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(3, raw,    0);
        SpanBranch path = doc.assertChild(1, "path", 0, 1);
        
        assertDirLink(link, "path", "path");
        ContentDebug.assertContent(path, "path", false, false);
        
        doc.assertKeyLeaf( 0,  1, "<",    0, 0);
        doc.assertPathLeaf(1,  5, "path", 0, 1, 0);
        doc.assertKeyLeaf( 5,  6, ">",    0, 2);        

        doc.assertIds();
    }
    
    @Test
    public void linkStart(){
        ///           01
        String raw = "<";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(1, raw,    0);
        
        assertDirLink(link, "", "");
        
        doc.assertKeyLeaf(0, 1, "<", 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void linkNoEnd(){
        ///           01234567890
        String raw = "<path|text";
        DocumentAssert doc = DocumentAssert.assertDoc(1, raw, parsers);
        SpanBranch link = doc.assertChild(4, raw,    0);
        SpanBranch path = doc.assertChild(1, "path", 0, 1);
        SpanBranch text = doc.assertChild(1, "text", 0, 3);
        
        assertDirLink(link, "path", "text");
        ContentDebug.assertContent(path, "path", false, false);
        ContentDebug.assertContent(text, "text", false, false);
        
        doc.assertKeyLeaf( 0,  1, "<",    0, 0);
        doc.assertPathLeaf(1,  5, "path", 0, 1, 0);
        doc.assertKeyLeaf( 5,  6, "|",    0, 2);
        doc.assertTextLeaf(6, 10, "text", 0, 3, 0);        

        doc.assertIds();
    }
}
