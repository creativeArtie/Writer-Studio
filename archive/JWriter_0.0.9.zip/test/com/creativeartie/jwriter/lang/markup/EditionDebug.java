package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class EditionDebug {
    
    public static void assertEdition(SpanBranch span, EditionType type,
        String text
    ){
        EditionSpan test = assertClass(span, EditionSpan.class);
        
        DetailStyle[] info = new DetailStyle[]{type};
        assertEquals(getError("edition", test), type, test.getEdition());
        assertEquals(getError("detail", test),  text, test.getDetail());
        assertBranch(span, info);
    }
    
    private static final SetupParser[] parsers = EditionParser.values();
    
    @Test
    public void stubBasic(){
        ///              012345
        String docRaw = "#STUB";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(1, docRaw, 0);
        
        assertEdition(edition, EditionType.STUB, "");
        
        doc.assertKeyLeaf(0, 5, docRaw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void draftBasic(){
        ///            0123456
        String docRaw = "#DRAFT";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(1, docRaw, 0);
        
        assertEdition(edition, EditionType.DRAFT, "");
        
        doc.assertKeyLeaf(0, 6, docRaw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void finalBasic(){
        ///              0123456
        String docRaw = "#FINAL";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(1, docRaw, 0);
        
        assertEdition(edition, EditionType.FINAL, "");
        
        doc.assertKeyLeaf(0, 6, docRaw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void otherBasic(){
        ///              01
        String docRaw = "#";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(1, docRaw, 0);
        
        assertEdition(edition, EditionType.OTHER, "");
        
        doc.assertKeyLeaf(0, 1, docRaw, 0, 0);        

        doc.assertIds();
    }
    
    @Test
    public void otherWithDetail(){
        ///              01234
        String docRaw = "#abc";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(2, docRaw, 0);
        SpanBranch detail  = doc.assertChild(1, "abc",  0, 1);
        
        assertEdition(edition, EditionType.OTHER, "abc");
        ContentDebug.assertContent(detail, "abc", false, false);
        
        doc.assertKeyLeaf( 0, 1, "#",   0, 0);
        doc.assertTextLeaf(1, 4, "abc", 0, 1, 0);        

        doc.assertIds();
    }
    
    @Test
    public void finalEscaped(){
        ///              0 1234567
        String docRaw = "#\\FINAL";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(2,  docRaw,   0);
        SpanBranch detail  = doc.assertChild(2, "\\FINAL", 0, 1);
        SpanBranch escape  = doc.assertChild(2, "\\F",     0, 1, 0);
        
        assertEdition(edition, EditionType.OTHER, "FINAL");
        ContentDebug.assertContent(detail, "FINAL", false, false);
        ContentDebug.assertEscape(escape, "F");
        
        doc.assertKeyLeaf( 0, 1, "#",    0, 0);
        doc.assertKeyLeaf( 1, 2, "\\",   0, 1, 0, 0);
        doc.assertTextLeaf(2, 3, "F",    0, 1, 0, 1);
        doc.assertTextLeaf(3, 7, "INAL", 0, 1, 1);        

        doc.assertIds();
    }
    
    @Test
    public void finalDetailed(){
        ///              01234567890123456
        String docRaw = "#FINAL version 8";
        DocumentAssert doc = assertDoc(1, docRaw, parsers);
        
        SpanBranch edition = doc.assertChild(2,  docRaw,      0);
        SpanBranch detail  = doc.assertChild(1, " version 8", 0, 1);
        
        assertEdition(edition, EditionType.FINAL, "version 8");
        ContentDebug.assertContent(detail, "version 8", true, false);
        
        doc.assertKeyLeaf( 0, 6, "#FINAL",      0, 0);
        doc.assertTextLeaf(6, 16, " version 8", 0, 1, 0);        

        doc.assertIds();
    }

}
