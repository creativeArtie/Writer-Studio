package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class LinedRestDebug {
    public static final void assertBreak(SpanBranch span){
        LinedSpanBreak test = assertClass(span, LinedSpanBreak.class);
        
        DetailStyle[] styles = new DetailStyle[]{LinedType.BREAK};
        
        assertEquals(getError("type", span), LinedType.BREAK, test.getLinedType());
        assertBranch(span, styles);
    }
    
    public static final void assertAgenda(SpanBranch span, Span agenda, 
        IDBuilder id)
    {
        LinedSpanAgenda test = assertClass(span, LinedSpanAgenda.class);
        
        DetailStyle[] styles = new DetailStyle[]{LinedType.AGENDA};
        
        assertEquals(getError("type", span), LinedType.AGENDA, test.getLinedType());
        assertSpan("reason", agenda, test.getReasonSpan());
        assertSpanIdentity(span, id);
        assertBranch(span, styles, CatalogueStatus.UNUSED);
    }
    
    public static final void assertParagraph(SpanBranch span, Span format){
        LinedSpanParagraph test = assertClass(span, LinedSpanParagraph.class);
        
        DetailStyle[] styles = new DetailStyle[]{LinedType.PARAGRAPH};
        
        assertEquals(getError("type", span), LinedType.PARAGRAPH, test.getLinedType());
        assertSpan("text", format, test.getFormattedSpan());
        assertBranch(span, styles);
    }
    
    private static final SetupParser[] parsers = LinedParseRest.values();
    
    @Test
    public void testBreak(){
        String raw = "***\n";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch span = doc.assertChild(1, raw, 0);
        
        assertBreak(span);
        
        doc.assertKeyLeaf(0, 4, "***\n",  0, 0);
        
        doc.assertIds();
    }
    
    
    @Test
    public void basicAgenda(){
        String raw = "!!abc**ab";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch agenda  = doc.assertChild(2, raw, 0);
        SpanBranch content = doc.assertChild(1, "abc**ab", 0 , 1);
        
        IDBuilder id = new IDBuilder().addCategory("agenda", "lined")
            .setId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, content, id);
        
        doc.assertKeyLeaf( 0, 2, "!!",      0, 0);
        doc.assertTextLeaf(2, 9, "abc**ab", 0, 1, 0);
        
        doc.assertIds();
    }
    
    @Test
    public void emptyAgenda(){
        String raw = "!!";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch agenda  = doc.assertChild(1, raw, 0);
        
        IDBuilder id = new IDBuilder().addCategory("agenda", "lined")
            .setId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, null, id);
        
        doc.assertKeyLeaf( 0, 2, "!!", 0, 0);
        
        doc.assertIds();
    }
    
    @Test
    public void spaceAgenda(){
        String raw = "!!  \n";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch agenda  = doc.assertChild(3, raw, 0);
        SpanBranch content = doc.assertChild(1, "  ", 0 , 1);
        
        IDBuilder id = new IDBuilder().addCategory("agenda", "lined")
            .setId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, content, id);
        
        doc.assertKeyLeaf( 0, 2, "!!", 0, 0);
        doc.assertTextLeaf(2, 4, "  ", 0, 1, 0);
        doc.assertKeyLeaf( 4, 5, "\n", 0, 2);
        
        doc.assertIds();
    }
    
    @Test
    public void fullAgenda(){
        String raw = "!!ab\n";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch agenda  = doc.assertChild(3, raw, 0);
        SpanBranch content = doc.assertChild(1, "ab", 0 , 1);
        
        IDBuilder id = new IDBuilder().addCategory("agenda", "lined")
            .setId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, content, id);
        
        doc.assertKeyLeaf( 0, 2, "!!", 0, 0);
        doc.assertTextLeaf(2, 4, "ab", 0, 1, 0);
        doc.assertKeyLeaf( 4, 5, "\n", 0, 2);
        
        doc.assertIds();
    }
    
    @Test
    public void escapeAgenda(){
        String raw = "!!Hi\\\\\n";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch agenda  = doc.assertChild(3, raw, 0);
        SpanBranch content = doc.assertChild(2, "Hi\\\\", 0 , 1);
        
        IDBuilder id = new IDBuilder().addCategory("agenda", "lined")
            .setId("0");
        doc.addId(id, 0);
        
        assertAgenda(agenda, content, id);
        
        doc.assertKeyLeaf( 0, 2, "!!", 0, 0);
        doc.assertTextLeaf(2, 4, "Hi", 0, 1, 0);
        doc.assertKeyLeaf( 4, 5, "\\", 0, 1, 1, 0);
        doc.assertTextLeaf(5, 6, "\\", 0, 1, 1, 1);
        doc.assertKeyLeaf( 6, 7, "\n", 0, 2);
        
        doc.assertIds();
    }
    
    @Test
    public void fullParagraph(){
        String raw = "ddHi\\\\\n";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch paragraph = doc.assertChild(2, raw, 0);
        SpanBranch content   = doc.assertChild(1, "ddHi\\\\", 0 , 0);
        
        assertParagraph(paragraph, content);
        
        doc.assertTextLeaf(0, 4, "ddHi", 0, 0, 0, 0);
        doc.assertKeyLeaf( 4, 5, "\\",   0, 0, 0, 1, 0);
        doc.assertTextLeaf(5, 6, "\\",   0, 0, 0, 1, 1);
        doc.assertKeyLeaf( 6, 7, "\n",   0, 1);
        
        doc.assertIds();
    }
    
    @Test
    public void simpleParagraph(){
        String raw = "abc";
        DocumentAssert doc = assertDoc(1, raw, parsers);
        SpanBranch paragraph = doc.assertChild(1, raw, 0);
        SpanBranch content   = doc.assertChild(1, "abc", 0 , 0);
        
        assertParagraph(paragraph, content);
        
        doc.assertTextLeaf(0, 3, "abc", 0, 0, 0, 0);
        
        doc.assertIds();
    }
    
}
