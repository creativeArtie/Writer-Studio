package com.creativeartie.jwriter.lang.markup;

import static org.junit.Assert.*;
import static com.creativeartie.jwriter.lang.DocumentAssert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import com.creativeartie.jwriter.lang.*;

@RunWith(JUnit4.class)
public class FormatCurlyDebug {
    
    public static void assertNote(SpanBranch span, DirectoryType type,
        FormatType ... formats)
    {
        assertNote(span, type, CatalogueStatus.NO_ID, null, formats);
    }
    
    public static void assertNote(SpanBranch span, DirectoryType type, 
        CatalogueStatus status, IDBuilder id, FormatType ... formats)
    {
        FormatSpanDirectory test = assertClass(span, FormatSpanDirectory.class);
        DetailStyle[] baseStyles = new DetailStyle[]{type, status};
        DetailStyle[] styles = FormatSpanDebug.mergeStyle(baseStyles, formats);
        
        assertEquals(getError("name", test), type, test.getIdType());
        FormatSpanDebug.assertFormats(test, formats);
        assertBranch(test, styles, status);
        assertSpanIdentity(span, id);
    }
    
    private static final SetupParser[] parsers = 
        FormatParseDirectory.getParsers(new boolean[4]);

    @Test
    public void cite(){
        ///               0123 456789
        String rawText = "{@a-\\-bc}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite   = doc.assertChild(3, rawText,   0);
        SpanBranch idSpan = doc.assertChild(3, "a-\\-bc", 0, 1);
        SpanBranch cat    = doc.assertChild(1, "a",       0, 1, 0);
        SpanBranch id     = doc.assertChild(2, "\\-bc",   0, 1, 2);
        SpanBranch escape = doc.assertChild(2, "\\-",     0, 1, 2, 0);
        
        IDBuilder builder = new IDBuilder().addCategory("note", "a")
            .setId("-bc");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertNote(cite, DirectoryType.NOTE, CatalogueStatus.NOT_FOUND, 
            builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.NOTE, builder);
        ContentDebug.assertContent(cat, "a", false, false);
        ContentDebug.assertContent(id, "-bc", false, false);
        ContentDebug.assertEscape(escape, "-");
        
        doc.assertKeyLeaf(0, 2, "{@", 0, 0);
        doc.assertIdLeaf( 2, 3, "a",  0, 1, 0, 0);
        doc.assertKeyLeaf(3, 4, "-",  0, 1, 1);
        doc.assertKeyLeaf(4, 5, "\\", 0, 1, 2, 0, 0);
        doc.assertIdLeaf( 5, 6, "-",  0, 1, 2, 0, 1);
        doc.assertIdLeaf( 6, 8, "bc", 0, 1, 2, 1);

        doc.assertIds();
    }

    @Test
    public void endnote(){
        ///               0123456
        String rawText = "{*abc}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite   = doc.assertChild(3, rawText, 0);
        SpanBranch idSpan = doc.assertChild(1, "abc",   0, 1);
        SpanBranch id     = doc.assertChild(1, "abc",   0, 1, 0);
        
        IDBuilder builder = new IDBuilder().addCategory("end").setId("abc");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertNote(cite, DirectoryType.ENDNOTE, CatalogueStatus.NOT_FOUND,
            builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.ENDNOTE, builder);
        ContentDebug.assertContent(id, "abc", false, false);
        
        doc.assertKeyLeaf(0, 2, "{*",  0, 0);
        doc.assertIdLeaf( 2, 5, "abc", 0, 1, 0, 0);
        doc.assertKeyLeaf(5, 6, "}",   0, 2);

        doc.assertIds();
    }

    @Test
    public void footnote(){
        ///               0123456
        String rawText = "{^abc}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite   = doc.assertChild(3, rawText, 0);
        SpanBranch idSpan = doc.assertChild(1, "abc",   0, 1);
        SpanBranch id     = doc.assertChild(1, "abc",   0, 1, 0);
        
        IDBuilder builder = new IDBuilder().addCategory("foot").setId("abc");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertNote(cite, DirectoryType.FOOTNOTE, CatalogueStatus.NOT_FOUND,
            builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.FOOTNOTE, builder);
        ContentDebug.assertContent(id, "abc", false, false);
        
        doc.assertKeyLeaf(0, 2, "{^",  0, 0);
        doc.assertIdLeaf( 2, 5, "abc", 0, 1, 0, 0);
        doc.assertKeyLeaf(5, 6, "}",   0, 2);

        doc.assertIds();
    }

    @Test
    public void noEnd(){
        ///               012345
        String rawText = "{^abc";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite   = doc.assertChild(2, rawText, 0);
        SpanBranch idSpan = doc.assertChild(1, "abc",   0, 1);
        SpanBranch id     = doc.assertChild(1, "abc",   0, 1, 0);
        
        IDBuilder builder = new IDBuilder().addCategory("foot").setId("abc");
        doc.addRef(builder, CatalogueStatus.NOT_FOUND, 0);
        
        assertNote(cite, DirectoryType.FOOTNOTE, CatalogueStatus.NOT_FOUND,
            builder);
        DirectoryDebug.assertId(idSpan, DirectoryType.FOOTNOTE, builder);
        ContentDebug.assertContent(id, "abc", false, false);
        
        doc.assertKeyLeaf(0, 2, "{^",  0, 0);
        doc.assertIdLeaf( 2, 5, "abc", 0, 1, 0, 0);

        doc.assertIds();
    }

    @Test
    public void onlyStart(){
        ///               012
        String rawText = "{^";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite = doc.assertChild(1, rawText, 0);
        
        assertNote(cite, DirectoryType.FOOTNOTE);
        
        doc.assertKeyLeaf(0, 2, "{^", 0, 0);        

        doc.assertIds();
    }

    @Test
    public void noText(){
        ///               0123
        String rawText = "{^}";
        DocumentAssert doc = assertDoc(1, rawText, parsers);
        SpanBranch cite = doc.assertChild(2, rawText, 0);
        
        assertNote(cite, DirectoryType.FOOTNOTE);
        
        doc.assertKeyLeaf(0, 2, "{^", 0, 0);        
        doc.assertKeyLeaf(2, 3, "}",  0, 1);

        doc.assertIds();
    }
}
