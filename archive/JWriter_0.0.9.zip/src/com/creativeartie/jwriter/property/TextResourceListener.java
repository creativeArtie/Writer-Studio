package com.creativeartie.jwriter.property;

public interface TextResourceListener{
    public void update(TextResource resource, String value);
}
