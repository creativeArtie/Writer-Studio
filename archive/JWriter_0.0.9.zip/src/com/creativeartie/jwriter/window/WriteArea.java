package com.creativeartie.jwriter.window;

import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.control.Label;
import javafx.animation.AnimationTimer;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.io.IOException;
import javafx.beans.property.ReadOnlyBooleanProperty;

import org.fxmisc.richtext.InlineCssTextArea;
import org.fxmisc.richtext.model.PlainTextChange;

import com.creativeartie.jwriter.lang.*;
import com.creativeartie.jwriter.property.PropertyManager;
import com.creativeartie.jwriter.lang.markup.ManuscriptDocument;
import com.creativeartie.jwriter.main.*;

public final class WriteArea extends InlineCssTextArea{
    private final MainPane parent;
    private boolean hasEdited;
    private final long UPDATE_TIME = 10000000l;
    private long start;
    
    WriteArea(MainPane parentPane) throws IOException{
        super(parentPane.getDocument().getRaw());
        parent = parentPane;
        setWrapText(true);
        plainTextChanges().subscribe(data -> textChanged(data));
        update();
        requestFollowCaret();
        focusedProperty().addListener(focused -> {
            if (! ((ReadOnlyBooleanProperty)focused).getValue()){
                update();
            }
        });
        new AnimationTimer(){
            @Override
            public void handle(long now) {
                if (hasEdited && now - start > UPDATE_TIME){
                    update();
                } else {
                    start = now;
                }
            }
        }.start();
    }
    
    private void textChanged(PlainTextChange change){
        int pos = change.getPosition();
        switch (change.getType()){
        case DELETION:
            deleteChar(pos, change.getRemovalEnd());
        break;
        case INSERTION:
            insertChar(pos, change.getInserted());
        break;
        case REPLACEMENT:
            deleteChar(pos, change.getRemovalEnd());
            insertChar(pos, change.getInserted());
        break;
        }
        assert parent.getDocument().getRaw().equals(getText()) : parent
            .getDocument().getRaw();
        hasEdited = true;
    }
    
    private void insertChar(int pos, String text){
        for (int i = 0; i < text.length(); i++){
            parent.getDocument().insertChar(pos, text.charAt(i));
        }
    }
    
    private void deleteChar(int pos, int end){
        for(int i = pos; i < end; i++){
            parent.getDocument().deleteChar(pos);
        }
        
    }
    
    void update(){
        hasEdited = false;
        for (SpanLeaf span: parent.getDocument().getLeaves()){
            setStyle(span.getStart(), span.getEnd(), span.toCss(Utilities
                .getStyles()));
        }
        parent.update();
    }
}
