package com.creativeartie.jwriter.window;

import java.util.Map;
import java.util.Optional;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.TreeSet;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Pane;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.control.ListCell;
import javafx.scene.text.TextFlow;
import javafx.scene.text.Text;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import com.google.common.base.Joiner;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableMap;


import com.creativeartie.jwriter.lang.markup.*;
import com.creativeartie.jwriter.lang.SpanBranch;
import com.creativeartie.jwriter.lang.CatalogueIdentity;
import com.creativeartie.jwriter.lang.CatalogueData;
import com.creativeartie.jwriter.lang.Span;
import com.creativeartie.jwriter.lang.Catalogued;
import com.creativeartie.jwriter.property.TextResourceEnumHelper;
import com.creativeartie.jwriter.main.*;

public class UserList extends GridPane{
    @FXML private ListView<DirectoryType> typesNode;
    @FXML private ListView<List<String>> categoryNode;
    private Multimap<List<String>, DirectoryUnit> subIdList;
    @FXML private ListView<DirectoryUnit> idNode;
    @FXML private UserDetailPane details;
    private TitledPane detailsPane;
    private MainPane parent;

    private static class TypeCell extends ListCell<DirectoryType>{
        @Override
        protected void updateItem(DirectoryType item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null){
                setText(null);
                setGraphic(null);
            } else {
                setText(ListText.valueOf(item).get());
            }
        }
    }

    private static class CatergoryCell extends ListCell<List<String>>{
        @Override
        protected void updateItem(List<String> item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null){
                setText(null);
                setGraphic(null);
            } else {
                Label text = new Label();
                String found = Joiner.on("-").join(item.subList(1, item.size()));
                if (found.isEmpty()){
                    setText(WindowText.USER_NO_CATEOGRY.get());
                    setStyle(Utilities.getCss("UserList.Empty"));
                } else {
                    setText(found);
                }
            }
        }
    }

    private static class IdCell extends ListCell<DirectoryUnit>{
        @Override
        protected void updateItem(DirectoryUnit item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null){
                setText(null);
                setGraphic(null);
            } else {
                CatalogueIdentity id = item.getIdentity();
                TextFlow graphic = null;
                Text base = new Text(item.getIdentity().getIdentity());
                if (item.getIndex() != -1){
                    Text idx = new Text("\t(" + item.getIndex() + ")");
                    idx.setStyle(Utilities.getCss("UserList.MultiTarget"));
                    graphic = new TextFlow(base, idx);
                } else {
                    graphic = new TextFlow(base);
                }

                setGraphic(graphic);
            }
        }
    }

    public UserList(MainPane parentPane){
        for(int i = 0; i < 4; i++){
             ColumnConstraints column = new ColumnConstraints();
             column.setPercentWidth(25);
             getColumnConstraints().add(column);
        }
        parent = parentPane;
        typesNode = createTypeList();
        categoryNode = createCategoryList();
        idNode = createIdsList();
        details = createUserDetails();
        detailsPane = createWrapPane(ListText.NOTE, details);
        add(detailsPane, 3, 0);
        initLists();
    }

    private ListView<DirectoryType> createTypeList(){
        ListView<DirectoryType> ans = new ListView<>(FXCollections
            .observableArrayList(DirectoryType.values()));
        add(createWrapPane(WindowText.LIST_TYPES, ans), 0, 0);
        ans.setCellFactory(list -> new TypeCell());
        ans.getSelectionModel().select(0);
        ans.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue)-> {
                selectType(newValue);
                selectCategory();
                selectId();
            });
        return ans;
    }

    private ListView<List<String>> createCategoryList(){
        ListView<List<String>> ans = new ListView<>();
        ans.setCellFactory(list -> new CatergoryCell());
        add(createWrapPane(WindowText.LIST_CATEGORY, ans), 1, 0);
        ans.setPlaceholder(new Label(WindowText.USER_NO_ITEMS.get()));
        ans.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue)-> {
                selectCategory(newValue);
                selectId();
            });
        return ans;
    }

    private ListView<DirectoryUnit> createIdsList(){
        ListView<DirectoryUnit> ans = new ListView<>();
        ans.setCellFactory(list -> new IdCell());
        add(createWrapPane(WindowText.LIST_IDS, ans), 2, 0);
        ans.setPlaceholder(new Label(WindowText.USER_NO_ITEMS.get()));
        ans.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue)-> {
                selectId(newValue);
            });
        return ans;
    }

    private UserDetailPane createUserDetails(){
        UserDetailPane pane = new UserDetailPane();
        pane.setParent(parent);
        return pane;
    }

    private TitledPane createWrapPane(TextResourceEnumHelper label, Node node){
        TitledPane title = new TitledPane(label.get(), node);
        title.setPrefHeight(150.0);
        title.setCollapsible(false);
        return title;
    }

    private void initLists(){
        selectType(DirectoryType.NOTE);
        selectCategory();
        selectId();
    }

    private void update(){
        // TODO
        throw new UnsupportedOperationException("Not implemented");
    }

    private void selectType(DirectoryType type){
        subIdList = DirectoryUnit.getDirectory(type, parent.getDocument());
        categoryNode.setItems(FXCollections.observableArrayList(subIdList
            .keySet()));

    }

    private void selectCategory(){
        if (! categoryNode.getItems().isEmpty()){
            selectCategory(categoryNode.getItems().get(0));
        }
    }

    private void selectCategory(List<String> category){
        categoryNode.getSelectionModel().select(category);
        categoryNode.scrollTo(category);
        Collection<DirectoryUnit> list = subIdList.get(category);
        idNode.setItems(FXCollections.observableArrayList(list));
    }

    private void selectId(){
        if (! idNode.getItems().isEmpty()){
            selectId(idNode.getItems().get(0));
        }
    }

    private void selectId(DirectoryUnit struct){
        idNode.getSelectionModel().select(struct);
        details.setData(struct);
    }
}
