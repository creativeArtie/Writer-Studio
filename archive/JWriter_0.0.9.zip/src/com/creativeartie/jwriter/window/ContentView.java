package com.creativeartie.jwriter.window;

import java.util.Optional;
import javafx.scene.text.*;


import com.google.common.base.*;

import com.creativeartie.jwriter.lang.markup.*;
import com.creativeartie.jwriter.lang.Span;
import com.creativeartie.jwriter.main.*;
public class ContentView {
    static String toCss(String base){
        return Utilities.getCss("Heading." +
            CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, base));
    }

    static void addFormat(TextFlow node, Optional<FormatSpanMain> formated){
        if (formated.isPresent()){
            formated.get().forEach((span) -> {
                String css = "";
                if (span instanceof FormatSpanDirectory){
                    css += toCss("Directory");
                }
                if (span instanceof FormatSpan) {
                    FormatSpan add = (FormatSpan) span;
                    Text input = new Text(add.getOutput());
                    for (FormatType type: add.listFormats()){
                        css += toCss(type.name());
                    }
                    input.setStyle(css);
                    node.getChildren().add(input);
                }
            });
        }
    }
}