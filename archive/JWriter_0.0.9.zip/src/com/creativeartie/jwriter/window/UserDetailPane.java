package com.creativeartie.jwriter.window;

import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import java.util.Optional;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.beans.property.SimpleIntegerProperty;

import com.creativeartie.jwriter.main.Utilities;
import com.creativeartie.jwriter.main.WindowText;
import com.creativeartie.jwriter.lang.CatalogueIdentity;
import com.creativeartie.jwriter.lang.CatalogueData;
import com.creativeartie.jwriter.lang.SpanBranch;
import com.creativeartie.jwriter.lang.markup.*;

class UserDetailPane extends BorderPane{
    @FXML private TextFlow detail;
    @FXML private Label refCount;
    private DirectoryUnit dataUnit;
    private MainPane parentSpan;

    UserDetailPane(){
        Utilities.loadFxml(this);
    }

    void setParent(MainPane parent){
        parentSpan = parent;
    }

    void setData(DirectoryUnit data){
        dataUnit = data;
        detail.getChildren().clear();
        if (data != null){
            SpanBranch span = data.getIdSpan();
            if (span instanceof LinedSpanPointLink){
                LinedSpanPointLink link = (LinedSpanPointLink) span;
                detail.getChildren().add(new Hyperlink(link.getPath()));
            }
            if (span instanceof LinedSpanPointNote){
                LinedSpanPointNote note = (LinedSpanPointNote) span;
                ContentView.addFormat(detail, note.getFormattedSpan());
            }
            if (span instanceof LinedSpanSection){
                LinedSpanSection section = (LinedSpanSection) span;
                HeadingView.setText(detail, Optional.of(section));
            }
            if (span instanceof MainSpanNote){
                detail.getChildren().add(new Text(span.getRaw()));
            }
            refCount.setText("" + dataUnit.getData().getRefs().size());
        }
    }

    @FXML
    public void toFirst(){
    }

    @FXML
    public void lastRef(){
    }

    @FXML
    public void nextRef(){
    }

    @FXML
    public void toLast(){
    }

    @FXML
    public void toSpan(){
        parentSpan.setPosition(dataUnit.getIdSpan().getEnd() - 1);
        parentSpan.returnFoucs();
    }
}