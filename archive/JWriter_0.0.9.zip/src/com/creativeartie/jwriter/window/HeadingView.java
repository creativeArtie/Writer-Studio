package com.creativeartie.jwriter.window;

import java.util.Optional;
import javafx.scene.text.TextFlow;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;


import com.google.common.base.CaseFormat;

import com.creativeartie.jwriter.lang.markup.*;
import com.creativeartie.jwriter.lang.Span;
import com.creativeartie.jwriter.main.*;

public class HeadingView extends TextFlow {
    private Optional<LinedSpanSection> line;

    public HeadingView(){
        this(Optional.empty());
    }

    public HeadingView(LinedSpanSection showHeading){
        this(Optional.ofNullable(showHeading));
    }

    public HeadingView(Optional<LinedSpanSection> showHeading){
        line = showHeading;
        setText(this, line);
    }

    static void setText(TextFlow node, Optional<LinedSpanSection> line){
        if (line.isPresent()){
            Text status = new Text(WindowText.getStatus(line.get().getEdition())
                .get());
            status.setStyle(ContentView.toCss("Status"));
            node.getChildren().add(status);
            ContentView.addFormat(node, line.get().getFormattedSpan());
        } else {
            Text empty = new Text(WindowText.VIEW_NO_FOUND.get());
            empty.setStyle(ContentView.toCss("Status"));
            node.getChildren().add(empty);
        }
    }
}
