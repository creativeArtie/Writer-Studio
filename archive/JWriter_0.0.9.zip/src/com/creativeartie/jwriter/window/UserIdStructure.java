package com.creativeartie.jwriter.window;

import javafx.scene.text.Text;
import java.util.Optional;

import com.creativeartie.jwriter.main.Utilities;
import com.creativeartie.jwriter.lang.CatalogueIdentity;
import com.creativeartie.jwriter.lang.CatalogueData;
import com.creativeartie.jwriter.lang.SpanBranch;

class UserIdStructure {
    private final int level;
    private final CatalogueData data;

    UserIdStructure(CatalogueData d){
        level = -1;
        data = d;
    }

    UserIdStructure(int l, CatalogueData d){
        level = l;
        data = d;
    }

    int getLevel(){
        return level;
    }

    CatalogueData getData(){
        return data;
    }

    String getIdentity(){
        return data.getKey().getIdentity();
    }

    Optional<Text> getSpanDetail(){
        if (level == -1) {
            return Optional.empty();
        }
        Text ans = new Text("\t(" +  level + ")");
        ans.setStyle(Utilities.getCss("UserList.MultiTarget"));
        return Optional.of(ans);
    }

    Optional<SpanBranch> getIdSpan(){
        if (data.isReady()){
            return Optional.of(data.getIds().get(0));
        }
        if (level == -1){
            return Optional.empty();
        }
        return Optional.of(data.getIds().get(level));
    }

    @Override
    public String toString(){
        return level + "" + data;
    }
}