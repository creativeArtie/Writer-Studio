package com.creativeartie.jwriter.window;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class StartWindow{
}