package com.creativeartie.jwriter.window;

import java.io.File;
import java.io.IOException;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import com.creativeartie.jwriter.lang.markup.ManuscriptDocument;
import com.creativeartie.jwriter.property.PropertyManager;
import com.creativeartie.jwriter.main.*;

public class MainPane extends BorderPane{

    private WriteArea area;
    private HeadingList table;
    private UserList lists;;
    private ManuscriptDocument doc;
    private boolean isReady;

    public MainPane(File file) throws IOException{
        this(new ManuscriptDocument(file));
    }

    public MainPane() throws IOException{
        this(new ManuscriptDocument(""));
    }

    public MainPane(ManuscriptDocument document) throws IOException{
        isReady = false;
        doc = document;
        BorderPane main = new BorderPane();

        area = new WriteArea(this);
        table = new HeadingList(this);
        lists = new UserList(this);

        setMargin(area, new Insets(5.0, 10.0, 10.0, 5.0));
        setAlignment(area, Pos.CENTER);
        setCenter(area);

        setAlignment(table, Pos.CENTER);
        setMargin(table, new Insets(5.0, 5.0, 10.0, 10.0));
        setLeft(table);

        setAlignment(lists, Pos.CENTER);
        setMargin(lists, new Insets(10.0, 10.0, 5.0, 10.0));
        setTop(lists);

        area.caretPositionProperty().addListener((observable, oldValue,
            newValue) -> {
            if (area.isFocused()){
                table.updatePosition();
                // lists.update();
            }
        });
        isReady = true;
        returnFoucs();
    }

    public void setDocument(ManuscriptDocument document){
        doc = document;
    }

    void update(){
        if (isReady){
            table.updateHeadings();
        }
    }

    ManuscriptDocument getDocument(){
        return doc;
    }

    void setPosition(int start){
        area.moveTo(start);
        area.requestFollowCaret();
    }

    void returnFoucs(){
        area.requestFocus();
    }

    public int getPosition(){
        return area.getCaretPosition();
    }

    boolean isReady(){
        return isReady;
    }
}
