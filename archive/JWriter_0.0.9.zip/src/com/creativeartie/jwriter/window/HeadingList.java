package com.creativeartie.jwriter.window;

import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;

import java.util.*;

import com.creativeartie.jwriter.lang.*;
import com.creativeartie.jwriter.lang.markup.*;
import com.creativeartie.jwriter.main.*;

public class HeadingList extends VBox{
    /// When document remember about null (which might not be properly handled)
    private final TreeView<Optional<LinedSpanSection>> headingTree;
    private final TreeView<Optional<LinedSpanSection>> outlineTree;
    private final HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>>
        headingMap;
    private final HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>>
        outlineMap;
    private SectionHeading header;
    private final MainPane parent;
    private boolean isUpdating;

    private class HeadingCell extends TreeCell<Optional<LinedSpanSection>> {
        @Override
        public void updateItem(Optional<LinedSpanSection> item, boolean empty){
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                TextFlow graphic = new TextFlow();
                graphic.getChildren().add(new HeadingView(item));
                setText(null);
                setGraphic(graphic);
            }
        }
    }

    HeadingList(MainPane parentPane){
        super(0);
        parent = parentPane;
        headingMap = new HashMap<>();
        outlineMap = new HashMap<>();
        headingTree = createTreeView(WindowText.TREE_HEADINGS, true);
        outlineTree = createTreeView(WindowText.TREE_OUTLINES, false);
        initHeadings();
    }

    private TreeView<Optional<LinedSpanSection>> createTreeView(WindowText text,
        boolean isHeading)
    {
        TreeView<Optional<LinedSpanSection>> ans = new TreeView<>();
        ans.setShowRoot(false);
        ans.setCellFactory(param -> new HeadingCell());
        ans.getSelectionModel().selectedItemProperty().addListener(
            (event, old, newItem) -> moveCaret(newItem, isHeading));
        ans.setOnMouseReleased(event -> parent.returnFoucs());

        TitledPane store = new TitledPane(text.get(), ans);
        getChildren().add(store);
        return ans;
    }

    private void initHeadings(){
        isUpdating = true;
        refreshHeadings();
        selectHeading();
        isUpdating = false;
    }

    private void moveCaret(TreeItem<Optional<LinedSpanSection>> item,
        boolean isHeading)
    {
        if(! isUpdating && item.getValue() != null){
            item.getValue().ifPresent(value -> parent.setPosition(value
                .getEnd() - 1));
            selectHeading();
            parent.returnFoucs();
        }
    }

    public void updateHeadings(){
        isUpdating = true;
        refreshHeadings();
        selectHeading();
        isUpdating = false;
    }

    public void updatePosition(){
        isUpdating = true;
        selectHeading();
        isUpdating = false;
    }

    private void selectHeading(){
        List<Span> spans = parent.getDocument().spansAt(parent.getPosition());
        MainSpan span = (MainSpan) spans.get(1);
        if (span instanceof MainSpanSection){
            Optional<LinedSpanSection> heading = ((MainSpanSection)span)
                .getHeading();
            if (heading.isPresent()){
                LinedSpanSection target = heading.get();
                TreeItem<Optional<LinedSpanSection>> item = headingMap
                    .get(target);
                selectAndFocus(headingTree, headingMap.get(target));
                header.findChild(heading).ifPresent(section ->
                    updateOutlines(section, ((MainSpanSection)span).getOutline()));
            }
        }
    }

    private void updateOutlines(SectionHeading heading,
        Optional<LinedSpanSection> outline)
    {
        TreeItem<Optional<LinedSpanSection>> root = new TreeItem<>();
        outlineMap.clear();
        List<SectionOutline> children = heading.getOutlines();
        if (children.isEmpty()){
            root.getChildren().add(new TreeItem<>(Optional.empty()));
        } else {
            fill(root, heading.getOutlines(), outlineMap);
        }
        outlineTree.setRoot(root);
        outline.ifPresent(span -> selectAndFocus(outlineTree, outlineMap
            .get(span)));
    }

    private <T extends Optional<LinedSpanSection>> void selectAndFocus(
        TreeView<T> view, TreeItem<T> item)
    {
        view.getSelectionModel().select(item);
        view.scrollTo(view.getRow(item));
    }

    private void refreshHeadings(){
        TreeItem<Optional<LinedSpanSection>> root = new TreeItem<>();
        header = parent.getDocument().getSections();
        headingMap.clear();
        fill(root, header.getChildren(), headingMap);
        headingTree.setRoot(root);
    }

    private void fill(TreeItem<Optional<LinedSpanSection>> parent,
        List<? extends Section> children,
        HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>> items)
    {
        for(Section found: children){
            TreeItem<Optional<LinedSpanSection>> child =
                new TreeItem<>(found.getLine());
            parent.getChildren().add(child);
            if (found.getLine().isPresent()){
                items.put(found.getLine().get(), child);
            }
            fill(child, found.getChildren(), items);
        }
    }

}
