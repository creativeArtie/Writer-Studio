package com.creativeartie.jwriter.main;

import com.creativeartie.jwriter.property.*;
import com.creativeartie.jwriter.lang.markup.*;
import com.google.common.base.*;

public enum ListText implements TextResourceEnumHelper{
    NOTE, FOOTNOTE, ENDNOTE, LINK;
    private static final String TITLE = "ListView.";
    
    private static final TextResourceManager MANAGER = TextResourceManager
        .getResouce("data/windowtext/text");
    
    private TextResource testResource;

    @Override
    public TextResource delegate(){
        if (testResource == null){
            String name = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, 
                name());
            testResource = MANAGER.getText(TITLE + name);
        }
        return testResource;
    }
    
    public static ListText valueOf(DirectoryType type){
        return values()[type.ordinal()];
    }
}
