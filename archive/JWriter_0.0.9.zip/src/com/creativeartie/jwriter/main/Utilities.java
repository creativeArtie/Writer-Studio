package com.creativeartie.jwriter.main;

import javafx.fxml.*;

import com.google.common.base.*;

import com.creativeartie.jwriter.property.*;
import java.io.*;

public class Utilities{

    private static PropertyManager styles;
    public static PropertyManager getStyles(){
        if (styles == null){
            try {
                styles = new PropertyManager("data/base-styles",
                    "data/user-styles");
            } catch (IOException ex){
                throw new RuntimeException(ex);
            }
        }
        return styles;
    }

    public static String getCss(String key){
        return getStyles().getStyleProperty(key).toCss();
    }

    public static void loadFxml(Object obj){
        String name = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE,
            obj.getClass().getSimpleName());

        FXMLLoader fxmlLoader = new FXMLLoader(obj.getClass().getResource(
            "/data/fxml/" + name + ".fxml"));
        fxmlLoader.setRoot(obj);
        fxmlLoader.setController(obj);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private Utilities(){}
}
