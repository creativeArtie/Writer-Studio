package com.creativeartie.jwriter.main;

import com.creativeartie.jwriter.property.*;
import com.creativeartie.jwriter.lang.markup.*;

public enum WindowText implements TextResourceEnumHelper{
    STUB_STATUS("SectionStatus.Stub"), DRAFT_STATUS("SectionStatus.Draft"),
    FINAL_STATUS("SectionStatus.Final"), OTHER_STATUS("SectionStatus.Other"),
    NONE_STATUS("SectionStatus.None"),

    LIST_TYPES("ListView.Types"), LIST_CATEGORY("ListView.Category"),
    LIST_IDS("ListView.Ids"),

    TREE_HEADINGS("TreeView.Headings"), TREE_OUTLINES("TreeView.Outlines"),
    TITLE("MainWindow.Title"),
    VIEW_NO_FOUND("HeadingView.NoFound"),
    VIEW_EMPTY("HeadingView.NoText"),
    USER_NO_CATEOGRY("UserList.NoCategory"), USER_NO_ITEMS("UserList.NoItems"),
    NO_ID_FOUND("UserList.NotFound");

    public static WindowText getStatus(EditionType type){
        return values()[type.ordinal()];
    }

    private static final TextResourceManager MANAGER = TextResourceManager
        .getResouce("data/windowtext/text");

    private TextResource testResource;

    private final String textName;

    private WindowText(String name){
        textName = name;
    }

    @Override
    public TextResource delegate(){
        if (testResource == null){
            testResource = MANAGER.getText(textName);
        }
        return testResource;
    }
}
