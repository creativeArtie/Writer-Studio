package com.creativeartie.jwriter.main;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import java.util.*;
import java.io.*;

import com.creativeartie.jwriter.window.*;

public class Main extends Application{
    public final static ResourceBundle ABBREVIATION = PropertyResourceBundle
        .getBundle("data.abbreviation");


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage window) throws Exception{
        WindowText.TITLE.addAndCall((resource, value) -> window.setTitle(value));
        /*
        Parent root = FXMLLoader.load(getClass().getResource(
            "/data/startWindow.fxml"));
        Scene scene = new Scene(root, 800, 600);
        window.setScene(scene);
        window.show();*/
        try{
            File tmp = new File("data/sectionDebug5.txt");
            MainPane pane = new MainPane(tmp);
            Scene writing = new Scene(pane, 800, 600);
            window.setScene(writing);
        } catch (IOException ex){
            throw new RuntimeException(ex);
        }
        window.show();
    }
}
