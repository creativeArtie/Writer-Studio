package com.creativeartie.jwriter.lang.markup;

import java.util.*;

import com.google.common.base.*;
import com.google.common.collect.*;

import com.creativeartie.jwriter.lang.*;

/**
 * A {@link span} for formatted text.
 */
public final class FormatSpanMain extends SpanBranch {
    
    FormatSpanMain(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    public List<DetailStyle> getBranchStyles(){
        return ImmutableList.of();
    }
    
    public String getWriting(){
        return buildText(false);
    }
    
    public String getScript(){
        return buildText(true);
    }
    
    private String buildText(boolean isAll){
        StringBuilder text = new StringBuilder();
        for (Span span: this){
            if (span instanceof FormatSpanContent){
                FormatSpanContent content = (FormatSpanContent) span;
                if (content.isSpaceBegin()){
                    text.append(" ");
                }
                text.append(content.getParsed());
                if (content.isSpaceEnd()){
                    text.append(" ");
                }
            }
            if (span instanceof FormatSpanLink){
                FormatSpanLink link = (FormatSpanLink) span;
                text.append(link.getText());
            }
            if (isAll && span instanceof FormatSpanAgenda){
                text.append(" {").append(((FormatSpanAgenda)span).getAgenda())
                    .append("} ");
            }
        }
        return CharMatcher.whitespace().trimAndCollapseFrom(text.toString(), ' ');
    }
    
    //TODO
    //protected DetailUpdater getUpdater(Span edit, String newText){ }

}
