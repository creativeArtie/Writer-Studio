package com.creativeartie.jwriter.lang.markup;

import com.creativeartie.jwriter.lang.*;

import java.util.*;

import com.google.common.collect.*;

public class DirectoryUnit{

    public static Multimap<List<String>, DirectoryUnit>
        getDirectory(DirectoryType type, ManuscriptDocument doc)
    {
        ImmutableListMultimap.Builder<List<String>, DirectoryUnit> builder =
            ImmutableListMultimap.builder();
        for(Map.Entry<CatalogueIdentity, CatalogueData> entry:
            doc.getCatalogue().getCategory(type.getCategory()).entrySet())
        {
            List<String> key = entry.getKey().getCategories();
            CatalogueData data = entry.getValue();
            List<SpanBranch> ids = data.getIds();
            if (ids.size() == 1){
                builder.put(key, new DirectoryUnit(-1, ids.get(0), data));
            } else {
                int i = 0;
                for (SpanBranch branch: ids){
                    builder.put(key, new DirectoryUnit(i, ids.get(i), data));
                    i++;
                }
            }
        }
        return builder.build();
    }

    private final int spanIndex;

    private final SpanBranch idSpan;

    private final CatalogueData idData;

    private DirectoryUnit(int index, SpanBranch span, CatalogueData data){
        spanIndex = index;
        idSpan = span;
        idData = data;
    }

    public int getIndex(){
        return spanIndex;
    }

    public CatalogueIdentity getIdentity(){
        return idData.getKey();
    }

    public SpanBranch getIdSpan(){
        return idSpan;
    }

    public CatalogueData getData(){
        return idData;
    }
}