package com.creativeartie.jwriter.lang.markup;

import static com.creativeartie.jwriter.lang.markup.AuxiliaryData.*;

import com.creativeartie.jwriter.lang.DetailStyle;
public enum EditionType implements DetailStyle{
    /// Enum order mandated by WindowText
    STUB, DRAFT, FINAL, OTHER, NONE;
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_EDITION, name());
    }
}
