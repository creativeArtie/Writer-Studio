package com.creativeartie.jwriter.lang.markup;

import java.util.*;

public abstract class Section {
    Section(){}
    
    public abstract List<? extends Section> getChildren();
    
    public abstract Optional<LinedSpanSection> getLine();
}
