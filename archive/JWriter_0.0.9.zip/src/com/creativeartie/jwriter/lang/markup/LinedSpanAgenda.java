package com.creativeartie.jwriter.lang.markup;

import java.util.*;

import com.creativeartie.jwriter.lang.*;
import static com.creativeartie.jwriter.lang.markup.AuxiliaryData.*;

public class LinedSpanAgenda extends LinedSpan implements Catalogued{

    LinedSpanAgenda(List<Span> children){
        super(children);
    }
    
    public Optional<ContentSpan> getReasonSpan(){
        return spanFromLast(ContentSpan.class);
    }
    
    @Override
    public Optional<CatalogueIdentity> getSpanIdentity(){
        return Optional.of(new CatalogueIdentity(TYPE_AGENDA_LINED, this));
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
