package com.creativeartie.jwriter.lang.markup;

import java.util.*;

import com.creativeartie.jwriter.lang.*;

public class LinedSpanParagraph extends LinedSpan {

    LinedSpanParagraph(List<Span> children){
        super(children);
    }
    
    public Optional<FormatSpanMain> getFormattedSpan(){
        return spanAtFirst(FormatSpanMain.class);
    }
}
