package com.creativeartie.jwriter.lang.markup;

import com.creativeartie.jwriter.lang.*;

import static com.creativeartie.jwriter.lang.markup.AuxiliaryData.*;

/**
 * Used by {@link DirectorySpan} to show main categories.
 */
public enum DirectoryType implements DetailStyle{
    /// Enum value order mandated by ListText and LinedParsePointer
    NOTE(TYPE_NOTE), FOOTNOTE(TYPE_FOOTNOTE), ENDNOTE(TYPE_ENDNOTE), 
    LINK(TYPE_LINK);
    
    private final String baseCategory;
    
    private DirectoryType(String category){
        baseCategory = category;
    }
    
    public String getCategory(){
        return baseCategory;
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_CATEGORY, name());
    }
}
