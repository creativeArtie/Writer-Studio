package com.creativeartie.jwriter.lang.markup;

import java.util.*;

import com.creativeartie.jwriter.lang.*;

public abstract class MainSpan extends SpanBranch implements Catalogued{
    MainSpan(List<Span> spanChildren){
        super(spanChildren);
    }
    
    /*@Override
    protected DetailUpdater getUpdater(List<Span> edit, String newText){
        if (size() == 1){
            return DetailUpdater.mergeBoth(new MainParser());
        }
        
        if (edit.get(0) == get(0)){
            return DetailUpdater.mergeLast(new MainParser());
        } 
        
        if (edit.get(0) == get(size() - 1)){
            return DetailUpdater.mergeNext(new MainParser());
        }
        return DetailUpdater.replace(new MainParser());
    }*/
    
    @Override
    public boolean isId(){
        return true;
    }
}
