package com.creativeartie.jwriter.lang.markup;

import java.util.List;

import com.creativeartie.jwriter.lang.*;

public class LinedSpanBreak extends LinedSpan {

    LinedSpanBreak(List<Span> children){
        super(children);
    } 
}
