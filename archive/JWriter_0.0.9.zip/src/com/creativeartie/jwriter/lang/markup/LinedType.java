package com.creativeartie.jwriter.lang.markup;

import java.util.*;

import com.creativeartie.jwriter.main.*;
import com.creativeartie.jwriter.lang.*;
import static com.creativeartie.jwriter.lang.markup.AuxiliaryData.*;

public enum LinedType implements DetailStyle{

    HEADING(LinedParseLevel.HEADING), OUTLINE(LinedParseLevel.OUTLINE),
    QUOTE(LinedParseLevel.QUOTE), NUMBERED(LinedParseLevel.NUMBERED),
    BULLET(LinedParseLevel.BULLET),

    FOOTNOTE(LinedParsePointer.FOOTNOTE, LINED_FOOTNOTE),
    ENDNOTE(LinedParsePointer.ENDNOTE, LINED_ENDNOTE),
    HYPERLINK(LinedParsePointer.HYPERLINK, LINED_LINK),
    NOTE(LinedParseRest.NOTE, LINED_NOTE),

    AGENDA(LinedParseRest.AGENDA, LINED_AGENDA),
    BREAK(LinedParseRest.BREAK, LINED_BREAK),
    SOURCE(LinedParseCite.INSTANCE, LINED_CITE),
    PARAGRAPH(LinedParseRest.PARAGRAPH);

    private final SetupParser setupParser;
    private final Optional<String> spanStarter;

    private LinedType(SetupParser parser){
        setupParser = parser;
        spanStarter = Optional.empty();
    }

    private LinedType(SetupParser parser, String starter){
        setupParser = parser;
        spanStarter = Optional.of(starter);
    }

    SetupParser getParser(){
        return setupParser;
    }

    static LinedType findType(String raw){
        Checker.checkNotNull(raw, "raw");
        for (LinedType type: values()){
            if (type == PARAGRAPH){
                return type;
            }
            if (type.spanStarter.isPresent() &&
                raw.startsWith(type.spanStarter.get())
            ){
                return type;
            }
            if (type.setupParser instanceof LinedParseLevel){
                LinedParseLevel level = (LinedParseLevel)type.setupParser;
                for (int i = LEVEL_MAX + 1; i > 0; i--){
                    if(raw.startsWith(getLevelToken(level, i))){
                        if (i == LEVEL_MAX + 1){
                            return LinedType.PARAGRAPH;
                        } else {
                            return type;
                        }
                    }
                }
            }
        }
        assert false;
        return null;
    }


    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_LINED, name());
    }
}
