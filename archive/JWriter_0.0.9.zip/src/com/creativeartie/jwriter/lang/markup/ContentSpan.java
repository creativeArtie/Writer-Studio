package com.creativeartie.jwriter.lang.markup;

import java.util.List; /// For initialization (children)

import com.creativeartie.jwriter.lang.*;
import static com.creativeartie.jwriter.lang.markup.AuxiliaryData.*;
import com.creativeartie.jwriter.main.Checker;

import com.google.common.collect.ImmutableList;

/**
 * Created from {@link ContentParser}, super class of 
 * {@link ContentSpanContent}. Used for whenever text is needed.
 */
public class ContentSpan extends SpanBranch implements BasicText{
    
    /// Stuff for getUpdater(List<Span>, String)
    private final List<String> reparseEnders;
    private final SetupLeafStyle leafStyle;
    
    ContentSpan (List<Span> spanChildren, List<String> enders, 
        SetupLeafStyle style
    ){
        super(spanChildren);
        reparseEnders = Checker.checkNotNull(enders, "enders");
        leafStyle = Checker.checkNotNull(style, "style");
    }
    
    @Override
    public List<DetailStyle> getBranchStyles(){
        return ImmutableList.of();
    }
    
    @Override
    protected DetailUpdater getUpdater(List<Span> edited, String text){
        Checker.checkNotNull(text, "text");
        if(search(text, CHAR_ESCAPE, reparseEnders) == -1){
            return DetailUpdater.replace(new ContentParser(leafStyle, reparseEnders));
        }
        return DetailUpdater.unable();
    }
    
    @Override
    public String toString(){
        String ans = "";
        for (Span span: this){
            ans += span.toString() + "-";
        }
        return ans;
    }
}
