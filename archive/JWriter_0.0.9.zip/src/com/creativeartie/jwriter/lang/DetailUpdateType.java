package com.creativeartie.jwriter.lang;


enum DetailUpdateType{
    REPLACE(1), MERGE_LAST(2), MERGE_NEXT(2), MERGE_BOTH(3), UNABLE(0);
    private final int removeSpan;
    
    private DetailUpdateType(int remove){
        removeSpan = remove;
    }
    
    public int getRemoveSpans(){
        return removeSpan;
    }
}
