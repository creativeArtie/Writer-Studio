package com.creativeartie.jwriter.lang;

public interface DetailListener {

    void changed(Span span);
    
}
