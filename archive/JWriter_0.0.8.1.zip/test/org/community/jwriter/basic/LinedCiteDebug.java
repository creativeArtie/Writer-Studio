package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedCiteDebug {
    
    public static final SpanExpectHelper textHelp(LinedDataField expectedType, 
        String expectedOutput)
    {
        return span -> {
            LinedDataSpan child = basicHelp(span, expectedType, 
                expectedOutput != null);
            if(expectedOutput != null){
                assertEquals("Wrong citation class." + child, 
                    LinedDataSpanText.class, child.getClass());
                LinedDataSpanText test = (LinedDataSpanText) child;
                assertEquals("Wrong text: " + test, expectedOutput, 
                    test.getDataSpan().getParsed());
            }
        };
    }
    
    public static final SpanExpectHelper formatHelp(LinedDataField expectedType, 
        String expectedOutput)
    {
        return span -> {
            LinedDataSpan child = basicHelp(span, expectedType, 
                expectedOutput != null);
            if(expectedOutput != null){
                assertEquals("Wrong citation class." + child, 
                    LinedDataSpanFormatted.class, child.getClass());
                LinedDataSpanFormatted test = (LinedDataSpanFormatted) child;
                assertEquals("Wrong text: " + span, expectedOutput, 
                    test.getDataSpan().getRaw());
            }
        };
    }
    
    public static final SpanExpectHelper errorHelp(){
        return span -> basicHelp(span, LinedDataField.ERROR, false);
    }
    
    public static final SpanExpectHelper numberHelp(LinedDataField expectedType, 
        int expectedOutput)
    {
        return span -> {
            LinedDataSpan child = basicHelp(span, expectedType, true);
            assertEquals("Wrong citation class." + child, 
                LinedDataSpanNumber.class, child.getClass());
            assertEquals("Wrong number: " + child, expectedOutput, child.getDataSpan());
        };
    }
    
    public static final SpanExpectHelper numberHelp(LinedDataField expectedType)
    {
        return span -> {
            LinedDataSpan child = basicHelp(span, expectedType, false);
        };
    }
    
    public static final LinedDataSpan basicHelp(Span span, 
        LinedDataField expectedType, boolean hasResult
    ){
        assertEquals("Wrong class.", LinedSpanCite.class, span.getClass());
        LinedSpanCite test = (LinedSpanCite) span;
        assertEquals("Wrong line type.", LinedType.SOURCE, test.getType());
        assertEquals("Wrong source field.", expectedType, test.getField());
        if (hasResult){
            Optional<? extends LinedDataSpan> data = test.getData();
            assertTrue("Data is not found: " + test, data.isPresent());
            return data.get();
        }
        assertFalse("Data is found: " + span, test.getData().isPresent());
        return null;
    }
    
    private static final SetupParser[] parsers = new SetupParser[]{
            LinedParseCite.INSTANCE};
            
    
    @Test
    public void inTextComplete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedDataField.IN_TEXT, "a"));
        line.addChild("!>", LinedType.SOURCE, LinedDataField.IN_TEXT, 
            SetupLeafStyle.KEYWORD);
        line.addChild("in-text", LinedType.SOURCE, LinedDataField.IN_TEXT, 
            SetupLeafStyle.FIELD);
        line.addChild(":", LinedType.SOURCE, LinedDataField.IN_TEXT, 
            SetupLeafStyle.KEYWORD);
        
        SpanExpect data = new SpanExpect();
        data.addGrandchild("a", LinedType.SOURCE, LinedDataField.IN_TEXT,
            LinedDataType.TEXT, SetupLeafStyle.DATA);
        line.addChild(data);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void inTextNoColonNewline(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedDataField.IN_TEXT, null));
        line.addChildren("!>", "in-text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void inTextNoColon(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedDataField.IN_TEXT, null));
        line.addChildren("!>", "in-text");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void errorNoField(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", ":", "a", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void inTextNoColonData(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedDataField.IN_TEXT, "see"));
        line.addChildren("!>", "in-text", "see");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void errorEmptyData(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void errorEmptyDataNewLine(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void errorEmptyDataWithColon(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf", ":", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void errorEmptyDataWithExraSpaces(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf", ":", "     ", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void errorFieldOnly(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void errorUsingError(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "error", ":", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void unknownField(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChild("!>", LinedType.SOURCE, LinedDataField.ERROR, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addGrandchild("sdaf", LinedType.SOURCE, LinedDataField.ERROR, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.FIELD);
        line.addChild( ":", LinedType.SOURCE, LinedDataField.ERROR, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addGrandchild("aaa", LinedType.SOURCE, LinedDataField.ERROR, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.DATA);
        line.addChild("\n", LinedType.SOURCE, LinedDataField.ERROR, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void format(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(formatHelp(LinedDataField.SOURCE, "abc\\\\"));
        line.addChildren("!>", "source", ":", "abc\\\\");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedDataField.FOOTNOTE, "abc\\"));
        line.addChildren("!>", "footnote", ":", "abc\\\\");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES, 5));
        line.addChildren("!>", "pages", ":", "5");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesTrimLeft(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES, 5));
        line.addChildren("!>", "pages", ":", "5     ");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesTrimRight(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES, 5));
        line.addChildren("!>", "pages", ":", "     5");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES, 6));
        line.addChild("!>", LinedType.SOURCE, LinedDataField.PAGES, 
            SetupLeafStyle.KEYWORD);
        line.addChild("pages", LinedType.SOURCE, LinedDataField.PAGES, 
            SetupLeafStyle.FIELD);
        line.addChild(":", LinedType.SOURCE, LinedDataField.PAGES, 
            SetupLeafStyle.KEYWORD);
        
        SpanExpect data = new SpanExpect();
        data.addChild("    6     ", LinedType.SOURCE, LinedDataField.PAGES, 
            LinedDataType.NUMBER, SetupLeafStyle.DATA);
        line.addChild(data);
        
        line.addChild("\n", LinedType.SOURCE, LinedDataField.PAGES, 
            SetupLeafStyle.KEYWORD);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesTextInput(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES));
        line.addChild("!>", LinedType.SOURCE, LinedDataField.PAGES, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addChild("pages", LinedType.SOURCE, LinedDataField.PAGES,
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.FIELD);
        line.addChild(":", LinedType.SOURCE, LinedDataField.PAGES,  
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addGrandchild("abc", LinedType.SOURCE, LinedDataField.PAGES, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.DATA);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesTextAfter(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES));
        line.addChild("!>", LinedType.SOURCE, LinedDataField.PAGES, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addChild("pages", LinedType.SOURCE, LinedDataField.PAGES,  
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.FIELD);
        line.addChild(":", LinedType.SOURCE, LinedDataField.PAGES, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.KEYWORD);
        line.addGrandchild("22 read", LinedType.SOURCE, LinedDataField.PAGES, 
            AuxiliaryStyle.DATA_ERROR, SetupLeafStyle.DATA);
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    
    @Test
    public void sources(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(formatHelp(LinedDataField.SOURCE,
            "Henry, **Read"));
        line.addChild("!>", LinedType.SOURCE, LinedDataField.SOURCE, 
            SetupLeafStyle.KEYWORD);
        line.addChild("source", LinedType.SOURCE, LinedDataField.SOURCE,  
            SetupLeafStyle.FIELD);
        line.addChild(":", LinedType.SOURCE, LinedDataField.SOURCE, 
            SetupLeafStyle.KEYWORD);
            
        SpanExpect data = new SpanExpect();
        SpanExpect text = new SpanExpect();
        text.addGrandchild("Henry, ", LinedType.SOURCE, LinedDataField.SOURCE, 
            LinedDataType.FORMATTED, SetupLeafStyle.DATA);
        text.addChild("**", LinedType.SOURCE, LinedDataField.SOURCE, 
            LinedDataType.FORMATTED, SetupLeafStyle.KEYWORD);
        text.addGrandchild("Read", LinedType.SOURCE, LinedDataField.SOURCE, 
            LinedDataType.FORMATTED, FormatType.BOLD, SetupLeafStyle.DATA);
        data.addChild(text);
        line.addChild(data);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesNoData(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES));
        line.addChildren("!>", "pages", ":");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesDatalessNewLine(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES));
        line.addChildren("!>", "pages", ":", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesSpaceDataNewLine(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedDataField.PAGES));
        line.addChildren("!>", "pages", ":", "    ", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
