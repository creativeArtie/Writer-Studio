package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.Scanner;
import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class SupplementSectionDebug {
    
    @Parameter
    public int index;
    
    @Parameter(value = 1)
    public int last;
    
    @Parameter(value = 2)
    public int next;
    
    @Parameter(value = 3)
    public int heading;
    
    @Parameter(value = 4)
    public int outline;
    
    private static void add(ArrayList<Object[]> data, int index, int last,
        int next, int heading, int outline){
        data.add(new Object[]{index, last, next, heading, outline});
    }
    
    @Parameters
    public static Collection<Object[]> data() {
        ArrayList<Object[]> data = new ArrayList<>();
        ///     index, last, next, heading, outline
        add(data,  0,   -1,    2,      -1,      -1); /// 0
        add(data,  2,    0,   -1,      -1,      -1); /// 1
        add(data,  5,   -1,    7,      -1,       5); /// 2
        add(data,  7,    5,    9,      -1,       5); /// 3
        add(data,  9,    7,   -1,      -1,       5); /// 4
        add(data, 10,   -1,   12,      -1,      10); /// 5
        add(data, 12,   10,   -1,      -1,      10); /// 6
        add(data, 13,   -1,   -1,      -1,      13); /// 7
        add(data, 14,   -1,   -1,      -1,      14); /// 8
        add(data, 15,   -1,   -1,      -1,      15); /// 9
        add(data, 16,   -1,   -1,      -1,      16); /// 10
        add(data, 17,   -1,   -1,      17,      -1); /// 11
        add(data, 18,   -1,   -1,      18,      -1); /// 12
        add(data, 19,   -1,   -1,      18,      19); /// 13
        add(data, 20,   -1,   -1,      18,      20); /// 14
        add(data, 21,   -1,   -1,      21,      -1); /// 15
        add(data, 22,   -1,   -1,      21,      22); /// 16
        add(data, 23,   -1,   -1,      21,      23); /// 17
        add(data, 24,   -1,   26,      21,      24); /// 18
        add(data, 26,   24,   -1,      21,      24); /// 19
        return data;
    }
    
    private static ManuscriptDocument doc;
    private static ManuscriptDocument doc2;
    
    @BeforeClass
    public static void beforeClass() throws Exception{
        doc = getFile("data/sectionDebug1.txt");
    }
    
    private static boolean verbose = false;
    
    private static ManuscriptDocument getFile(String file) throws Exception{
        if (verbose) System.out.println();
        StringBuilder rawBuilder = new StringBuilder();
        int i = 0;
        try(Scanner scan = new Scanner(new File(file))){
            while (scan.hasNextLine()){
                String found = scan.nextLine();
                if (verbose){
                    System.out.printf("%2d", i);
                    System.out.println(": \"" + found + "\"");
                }
                rawBuilder.append(found + "\n");
                i++;
            }
        }
        return new ManuscriptDocument(rawBuilder.toString());
    }
    
    private MainSpanSection test;
    
    @Before
    public void before(){
        test = (MainSpanSection) doc.get(index);
    }
    
    @Test
    public void testLastPart(){
        testCommon(getMainSection(last), test.getLastPart());
    }
    
    @Test
    public void testNextPart(){
        testCommon(getMainSection(next), test.getNextPart());
    }
    
    @Test
    public void testHeading(){
        testCommon(getTopLine(heading), test.getHeading());
    }
    
    @Test
    public void testOutline(){
        testCommon(getTopLine(outline), test.getOutline());
    }
    
    
    private MainSpanSection getMainSection(int loc){
        return loc == -1? null: (MainSpanSection)doc.get(loc);
    }
    
    private LinedSpanSection getTopLine(int loc){
        return loc == -1? null: (LinedSpanSection)doc.get(loc).get(0);
    }
    
    
    private <T> void testCommon(T expect, Optional<T> found){
        if (expect == null){
            assertFalse("Unexpected Span for " + test + " found: " + found,
                found.isPresent());
        } else {
            assertTrue("Unexpected empty for " + test + ". Expect: " + expect, 
                found.isPresent());
            assertSame("Different spans: " + test.toString(), expect, 
                found.get());
        }
    }
}
