package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.Scanner;
import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class SectionListingDebug{
    
    private static void doc1(ArrayList<Object[]> data, int index, 
        int ... search)
    {
        data.add(new Object[]{true, index, search});
    }
    
    private static void doc2(ArrayList<Object[]> data, int index, 
        int ... search)
    {
        data.add(new Object[]{false, index, search});
    }
    
    @Parameters
    public static Collection<Object[]> data() {
        ArrayList<Object[]> data = new ArrayList<>();
        doc1(data, -1, -1, 0);
        doc2(data, 0,  0);
        doc2(data, 1,  0, -1, 0);
        doc2(data, 2,  0, -1, 0, 0);
        doc2(data, 3,  0, -1, 1);
        doc2(data, 11, 0,  0);
        doc2(data, 22, 0,  1);
        doc2(data, 26, 1);
        doc2(data, 27, 2);
        doc2(data, 28, 2, 0);
        doc2(data, 29, 2, 1);
        doc2(data, 30, 2, 2);
        /// It is easier to just check by study the printed SectionHeading
        return data;
    }
    
    private static ManuscriptDocument doc1;
    private static ManuscriptDocument doc2;
    
    private static boolean print = false;
    @BeforeClass
    public static void beforeClass() throws Exception{
        doc1 = setup("data/sectionDebug1.txt");
        doc2 = setup("data/sectionDebug2.txt");
    }
    
    private static ManuscriptDocument setup(String file) throws Exception{
        ManuscriptDocument doc = new ManuscriptDocument(new File(file));
        if (print){
            int i = 0;
            for (Span span: doc){
                System.out.printf("%2d", i);
                System.out.println(": " + SpanLeaf.escapeText(span.getRaw()));
                i++;
            }
        }
        if (print) System.out.println(doc.getSections());
        return doc;
    }
    
    @Parameter
    public boolean isFirst;
    
    @Parameter(1)
    public int location;
    
    @Parameter(2)
    public int[] search;
    
    @Test
    public void test(){
        Span expect = location != -1 ?
            ((SpanBranch)(isFirst? doc1 : doc2).get(location)).get(0): 
            null;
        SectionHeading ptr = (isFirst? doc1: doc2).getSections();
        boolean toHeading = true;
        SectionOutline out = null;
        for(int i: search){
            if (toHeading){
                if (i == -1){
                    toHeading = false;
                } else {
                    ptr = ptr.getChildren().get(i);
                }
            } else {
                if (out == null){
                    out = ptr.getOutlines().get(i);
                } else {
                    out = out.getChildren().get(i);
                }
            }
        }
        
        Optional<LinedSpanSection> test = out != null? out.getLine(): 
            ptr.getHeading();
        if (location == -1){
            assertFalse(test.toString(), test.isPresent());
        } else {
            assertTrue(test.toString(), test.isPresent());
            assertEquals(expect, test.get());
        }
    }
}
