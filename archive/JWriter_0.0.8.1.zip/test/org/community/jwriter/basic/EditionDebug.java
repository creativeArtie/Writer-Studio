package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.markup.DocumentHelper.*;

@RunWith(JUnit4.class)
public class EditionDebug {

    public static final SpanExpectHelper statusHelp(EditionType type, 
            String text){
        return span ->{
            assertEquals("Wrong class gotten: " + span.getClass(), 
                EditionSpan.class, span.getClass());
            EditionSpan test = (EditionSpan) span;
            assertEquals("Wrong type.", type, test.getEdition());
            if (text == null){
                assertFalse("Fond detail.", test.getDetailSpan().isPresent());
            } else {
                Optional<ContentSpan> detail = test.getDetailSpan();
                assertTrue("Detail not found.", detail.isPresent());
                assertEquals("Wrong detail.", text, detail.get().getParsed());
            }
        };
    }
    
    public static final void checkStatus(DocumentChecker base, EditionType type, 
        String text
    ){
        Span span = base.getSpan();
        assertEquals("Wrong class gotten: " + span.getClass(), 
            EditionSpan.class, span.getClass());
        EditionSpan test = (EditionSpan) span;
        assertEquals("Wrong type.", type, test.getEdition());
        if (text == null){
            assertFalse("Fond detail.", test.getDetailSpan().isPresent());
        } else {
            Optional<ContentSpan> detail = test.getDetailSpan();
            assertTrue("Detail not found.", detail.isPresent());
            assertEquals("Wrong detail.", text, detail.get().getParsed());
        }
    }
    
    private static final SetupParser[] parsers = EditionParser.values();
    
    @Test
    public void statusOtherBasic(){
        DocumentChecker doc = DocumentChecker.checkDoc(1, "#abc", parsers);
        
        DocumentChecker edition = doc.checkBranch(2, "#abc", 0);
        checkStatus(edition, EditionType.OTHER, "abc");
        
        edition.checkLeaf(     "#",   SetupLeafStyle.KEYWORD, 0);
        edition.checkGrandLeaf("abc", SetupLeafStyle.TEXT, 1, 0);
    }
    
    @Test
    public void statusEscaped(){
        DocumentChecker doc = DocumentChecker.checkDoc(1, "#\\FINAL", parsers);
        
        DocumentChecker edition = doc.checkBranch(2, "#\\FINAL", 0);
        checkStatus(edition, EditionType.OTHER, "FINAL");
        
        edition.checkKeyLeaf("#",         0);
        edition.checkBranch(2, "\\FINAL", 1);
    }
    
    @Test
    public void statusEmpty(){
        DocumentChecker doc = DocumentChecker.checkDoc(1, "#", parsers);
        DocumentChecker edition = doc.checkBranch(1, "#", 0);
        checkStatus(edition, EditionType.OTHER, null);
        edition.checkKeyLeaf("#", 0);
    }
    
    @Test
    public void statusStub(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(EditionType.STUB, "d2"));
        ref.addChild("#STUB", EditionType.STUB, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("d2", EditionType.STUB, SetupLeafStyle.TEXT);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, null));
        ref.addChild("#FINAL", EditionType.FINAL, SetupLeafStyle.KEYWORD);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalTrim(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "2"));
        ref.addChild("#FINAL", EditionType.FINAL, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("  2  ", EditionType.FINAL, SetupLeafStyle.TEXT);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalMidSpanced(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "abc ad"));
        ref.addChildren("#FINAL", "abc  ad");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusDraft(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(EditionType.DRAFT, "ccc"));
        ref.addChild("#DRAFT");
        SpanExpect text = new SpanExpect();
        text.addChild("cc", EditionType.DRAFT, SetupLeafStyle.TEXT);
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", EditionType.DRAFT, AuxiliaryStyle.ESCAPE, SetupLeafStyle.KEYWORD);
        escape.addChild("c", EditionType.DRAFT, AuxiliaryStyle.ESCAPE, SetupLeafStyle.TEXT);
        text.addChild(escape);
        ref.addChild(text);
        doc.addChild(ref);
        doc.testAll(parsers);
    }

}
