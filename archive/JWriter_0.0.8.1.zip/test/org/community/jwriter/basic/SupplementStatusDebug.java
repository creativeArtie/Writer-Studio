package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;
import org.community.jwriter.property.*;

@RunWith(JUnit4.class)
public class SupplementStatusDebug{

    private static Document createDoc(String raw){
        return new DocumentHelper(raw, new MainParser());
    }
    
    private static Span getFootnoteRef(Document doc){
        SpanBranch section   = (SpanBranch) doc.get(0);
        SpanBranch paragraph = (SpanBranch) section.get(0);
        SpanBranch format    = (SpanBranch) paragraph.get(0);
        SpanBranch footnote  = (SpanBranch) format.get(0);
        SpanBranch id        = (SpanBranch) footnote.get(1);
        SpanBranch content   = (SpanBranch) id.get(0);
        return content.get(0);
    }
    
    private static Span getFootnoteID(Document doc, int which){
        SpanBranch section = (SpanBranch) doc.get(0);
        SpanBranch line    = (SpanBranch) section.get(which);
        SpanBranch id      = (SpanBranch) line.get(1);
        SpanBranch content = (SpanBranch) id.get(0);
        return content.get(0);
    }
    
    private static PropertyManager manager;
    
    private static void check(Span test, DetailStyle ... infos){
        if (manager == null){
            try{
                manager = new PropertyManager("data/styles", "data/user-styles");
            } catch(Exception ex){
                throw new RuntimeException(ex);
            }
        }
        assertTrue(test.toString(), test instanceof SpanLeaf);
         
        assertArrayEquals("Wrong style: " + test, infos, 
            ((SpanLeaf)test).getDetailStyle().toArray(new DetailStyle[0]));
    }
    
    @Test
    public void unused(){
        Document doc = createDoc("!^abc:unused");
        check(getFootnoteID(doc, 0), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.FOOTNOTE, CatalogueStatus.UNUSED, SetupLeafStyle.ID);
    }
    
    @Test
    public void notFound(){
        Document doc = createDoc("{^abc}");
        check(getFootnoteRef(doc), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.PARAGRAPH, DirectoryType.FOOTNOTE, 
            CatalogueStatus.NOT_FOUND, SetupLeafStyle.ID);
    }
    
    @Test
    public void multiple(){
        Document doc = createDoc("!^abc:first\n!^abc:second");
        check(getFootnoteID(doc, 0), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.FOOTNOTE, CatalogueStatus.MULTIPLE, SetupLeafStyle.ID);
        check(getFootnoteID(doc, 1), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.FOOTNOTE, CatalogueStatus.MULTIPLE, SetupLeafStyle.ID);
    }
    
    @Test
    public void none(){
        Document doc = createDoc("{^abc}\n!^abc:inUsed\n");
        check(getFootnoteRef(doc), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.PARAGRAPH, DirectoryType.FOOTNOTE, 
            CatalogueStatus.READY, SetupLeafStyle.ID);
        check(getFootnoteID(doc, 1), AuxiliaryStyle.MAIN_SECTION, 
            LinedType.FOOTNOTE, CatalogueStatus.READY, SetupLeafStyle.ID);
    }
    
}
