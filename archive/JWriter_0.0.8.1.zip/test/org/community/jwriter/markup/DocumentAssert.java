package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;

public class DocumentAssert {
    
    private Document doc;
    private Span ptr;
    private DocumentAssert parent;
    
    private DocumentAssert(DocumentAssert parentChecker, Document document, 
        Span pointer)
    {
        parent = parentChecker;
        doc = document;
        ptr = pointer;
    }
    
    public Document getDocument(){
        return doc;
    }
    
    public DocumentAssert getParent(){
        return parent;
    }
    
    public Span getSpan(){
        return ptr;
    }
    
    public static SetupPointer createEmptyPointer(){
        return SetupPointer.newPointer("", new DocumentHelper());
    }
        
    public static DocumentAssert checkDoc(int childrenSize, String rawText, 
        SetupParser ... parsers
    ){
        Document test = new Document(rawText, parsers){};
        assertEquals("Wrong doc text.", rawText,      test.getRaw());  
        assertEquals("Wrong doc size.", childrenSize, test.size());
        return new DocumentAssert(null, test, test);
    }
    
    public DocumentAssert checkBranch(int size, String rawText, int idx){
        Span span = ((SpanNode)ptr).get(idx);
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanBranch, gotten " + span.getClass(), 
            span instanceof SpanBranch);
        SpanBranch test = (SpanBranch) span;
        assertEquals("Wrong branch text: " + test, rawText, test.getRaw()); 
        assertEquals("Wrong branch size: " + test, size,    test.size()); 
        assertSame  ("Wrong document: "    + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "      + test, ptr,     test.getParent());
        return new DocumentAssert(this, doc, test);
    }
    
    public DocumentAssert checkBranchDetails(DetailStyle ... styles){
        SpanBranch test = (SpanBranch) ptr;
        assertArrayEquals("Wrong style: " + test, styles, test.getInfo());
        return this;
    }
    
    private void assertLeaf(int start, int end, String rawText, 
        DetailStyle info, int ... idx
    ){
        Span span = ptr;
        Span parent = null;
        for (int i: idx){
            assertTrue("Not a span branch: " + span, span instanceof SpanBranch);
            parent = span;
            span = ((SpanBranch)span).get(i);
        }
        assert parent != null;
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanLeaf, gotten " + span.getClass(), 
            span instanceof SpanLeaf);
        SpanLeaf test = (SpanLeaf) span;
        assertEquals("Wrong leaf text: "  + test, rawText, test.getRaw()); 
        assertEquals("Wrong leaf style: " + test, info,    test.getInfo()); 
        assertSame  ("Wrong document: "   + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "     + test, parent,  test.getParent());
        assertEquals("Wrong start: "      + test, start,   test.getStart());
        assertEquals("Wrong end: "        + test, end,     test.getEnd());
    }
    
    public void assertTextLeaf(int start, int end, String rawText, int ... idx)
    {
        assertLeaf(start, end, rawText, SetupLeafStyle.TEXT, idx);
    }
    
    public void assertKeyLeaf(int start, int end, String rawText, int ... idx)
    {
        assertLeaf(start, end, rawText, SetupLeafStyle.KEYWORD, idx);
    }
    
    public void assertIdLeaf(int start, int end, String rawText, int ... idx)
    {
        assertLeaf(start, end, rawText, SetupLeafStyle.ID, idx);
    }
    
    public void assertDataLeaf(int start, int end, String rawText, int ... idx)
    {
        assertLeaf(start, end, rawText, SetupLeafStyle.DATA, idx);
    }
    
    public void assertFieldLeaf(int start, int end, String rawText, int ... idx)
    {
        assertLeaf(start, end, rawText, SetupLeafStyle.FIELD, idx);
    }
    
    public void assertPathLeaf(int start, int end, String rawText, int ... idx){
        assertLeaf(start, end, rawText, SetupLeafStyle.PATH, idx);
    }
}
