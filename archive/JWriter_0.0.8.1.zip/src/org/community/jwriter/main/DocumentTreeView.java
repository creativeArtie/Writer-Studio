package org.community.jwriter.main;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.TreeCell;
import javafx.scene.text.TextFlow;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.scene.layout.VBox;
import javafx.scene.control.TitledPane;
import javafx.geometry.Insets;

import java.util.Optional;
import java.util.List;
import java.util.HashMap;

import org.community.jwriter.markup.Span;
import org.community.jwriter.basic.FormatSpan;
import org.community.jwriter.basic.FormatSpanMain;
import org.community.jwriter.basic.Section;
import org.community.jwriter.basic.SectionHeading;
import org.community.jwriter.basic.SectionOutline;
import org.community.jwriter.basic.LinedSpanSection;
import org.community.jwriter.basic.MainSpanSection;

public class DocumentTreeView extends VBox{
    /// When document remember about null (which might not be properly handled)
    private TreeView<Optional<LinedSpanSection>> headingTree;
    private TreeView<Optional<LinedSpanSection>> outlineTree;
    private HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>> 
        headingList;
    private Optional<LinedSpanSection> head;
    private Optional<LinedSpanSection> out;
    private DocumentPane parent;
    private SectionHeading base;
    
    private class HeadingCell extends TreeCell<Optional<LinedSpanSection>> {
        @Override 
        public void updateItem(Optional<LinedSpanSection> item, boolean empty){
            super.updateItem(item, empty);
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                TextFlow graphic = new TextFlow();
                graphic.getChildren().add(new DocumentHeadingView(item));
                setText(null);
                setGraphic(graphic);
            }
        }
    }
    
    DocumentTreeView(DocumentPane parentPane){
        super(-20.0);
        parent = parentPane;
        headingTree = createTreeView(WindowText.TREE_HEADINGS, true);
        outlineTree = createTreeView(WindowText.TREE_OUTLINES, false);
        refreshHeadings();
    }
    
    private TreeView<Optional<LinedSpanSection>> createTreeView(WindowText text, 
        boolean isHeading)
    {
        TreeView<Optional<LinedSpanSection>> ans = new TreeView<>();
        ans.setShowRoot(false);
        // ans.setPrefWidth(100.0);
        ans.setCellFactory(param -> new HeadingCell());
        ans.setOnMouseClicked(event -> setPosition(ans, isHeading));
        
        TitledPane store = new TitledPane(text.get(), ans);
        getChildren().add(store);
        setMargin(store, new Insets(10.0));
        return ans;
    }
    
    private void setPosition(TreeView<Optional<LinedSpanSection>> view,
        boolean isHeading)
    {
        Optional<LinedSpanSection> last = isHeading? head: out;
        List<TreeItem<Optional<LinedSpanSection>>> list = view
            .getSelectionModel().getSelectedItems();
        if (list.isEmpty()){
            return;
        }
        Optional<LinedSpanSection> selected = list.get(0).getValue();
        if (last.isPresent()){
            if (selected.isPresent() && selected.get() != last.get()){
                updateTrees(selected, isHeading);
            }
        } else {
            if (selected.isPresent()){
                updateTrees(selected, isHeading);
            }
        }
    }
    
    private void updateTrees(Optional<LinedSpanSection> updated, 
        boolean isHeading)
    {
        parent.setPosition(updated.get().getEnd() - 1);
        if (isHeading){
            head = updated;
        } else {
            out = updated;
        }
        refreshOutlines(base.findChild(updated));
    }
    
    void refreshHeadings(){
        headingList = new HashMap<>();
        base = parent.getDocument().getSections();
        TreeItem<Optional<LinedSpanSection>> root = new TreeItem<>(Optional
            .empty());
        
        if(! parent.getDocument().allHasHeading()){
             TreeItem<Optional<LinedSpanSection>> child = new TreeItem<>(
                Optional.empty());
             root.getChildren().add(child);
             headingList.put(null, child);
        }
        addChildren(root, base);
        headingTree.setRoot(root);
        setPosition(parent.getPosition());
    }
    
    void setPosition(int i){
        Span section = parent.getDocument().spansAt(i).get(1);
        if (section instanceof MainSpanSection){
            head = ((MainSpanSection)section).getHeading();
            TreeItem<Optional<LinedSpanSection>> ptr;
            SectionHeading child;
            if (head.isPresent()){
                ptr = headingList.get(head.get());
            } else {
                ptr = headingList.get(null);
            }
            headingTree.getSelectionModel().select(ptr);
            out = ((MainSpanSection)section).getOutline();
            refreshOutlines(base.findChild(head));
        }
    }
    
    private void refreshOutlines(Optional<SectionHeading> headingLine){
        if (! headingLine.isPresent()){
            return;
        }
        TreeItem<Optional<LinedSpanSection>> root = new TreeItem<>(Optional
            .empty());
        List<SectionOutline> outlines = headingLine.get().getOutlines();
        if (outlines.isEmpty()){
             TreeItem<Optional<LinedSpanSection>> child = new TreeItem<>(
                Optional.empty());
             root.getChildren().add(child);
            outlineTree.setRoot(root);
            outlineTree.getSelectionModel().select(child);
            return;
        } 
        HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>> list = 
            addChildren(root, outlines);
        outlineTree.setRoot(root);
        if (out.isPresent()){
            outlineTree.getSelectionModel().select(list.get(out.get()));
        }
    }
    
    private HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>> 
        addChildren(TreeItem<Optional<LinedSpanSection>> node, 
        List<SectionOutline> outlineList){
        HashMap<LinedSpanSection, TreeItem<Optional<LinedSpanSection>>> ans = 
            new HashMap<>();
        for (SectionOutline child: outlineList){
            TreeItem<Optional<LinedSpanSection>> add = new TreeItem<>(child
                .getLine());
            node.getChildren().add(add);
            Optional<LinedSpanSection> outlineTree = child.getLine();
            if (outlineTree.isPresent()){
                ans.put(outlineTree.get(), add);
            }
            ans.putAll(addChildren(add, child.getChildren()));
        }
        return ans;
    }
    
    private void addChildren(TreeItem<Optional<LinedSpanSection>> node, 
        SectionHeading input)
    {
        TreeItem<Optional<LinedSpanSection>> child;
        for (SectionHeading subheading: input.getChildren()){
            Optional<LinedSpanSection> found;
            found = subheading.getHeading();
            child = new TreeItem<>(found);
            if (found.isPresent()){
                headingList.put(found.get(), child);
            }
            node.getChildren().add(child);
            
            addChildren(child, subheading);
        }
    }
}
