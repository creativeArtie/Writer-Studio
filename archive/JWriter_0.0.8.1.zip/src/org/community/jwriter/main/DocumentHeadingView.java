package org.community.jwriter.main;

import java.util.Optional;
import javafx.scene.text.TextFlow;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;

import com.google.common.base.CaseFormat;

import org.community.jwriter.basic.*;
import org.community.jwriter.markup.Span;

public class DocumentHeadingView extends TextFlow{
    private Optional<LinedSpanSection> line;
    
    public DocumentHeadingView(){
        this(Optional.empty());
    }
    
    public DocumentHeadingView(LinedSpanSection showHeading){
        this(Optional.ofNullable(showHeading));
    }
    
    public DocumentHeadingView(Optional<LinedSpanSection> showHeading){
        line = showHeading;
        addText();
    }
    
    private String toCss(String base){
        return Utilities.getStyles().getStyleProperty("Heading." + 
            CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, base))
            .toCss();
    }
    
    private void addText(){
        if (line.isPresent()){
            Text status = new Text(WindowText.getStatus(line.get().getEdition())
                .get());
            status.setStyle(toCss("Status"));
            getChildren().add(status);
            Optional<FormatSpanMain> formated = line.get().getFormattedSpan();
            if (formated.isPresent()){
                for (Span span: formated.get()){
                    String css = "";
                    if (span instanceof FormatSpanDirectory){
                        css += toCss("Directory");
                    }
                    if (span instanceof FormatSpan){
                        FormatSpan add = (FormatSpan) span;
                        Text input = new Text(add.getOutput());
                        for (FormatType type: add.listFormats()){
                            css += toCss(type.name());
                        }
                        input.setStyle(css);
                        getChildren().add(input);
                    }
                }
            }
        } else {
            Text empty = new Text(WindowText.VIEW_NO_FOUND.get());
            empty.setStyle(toCss("Status"));
            getChildren().add(empty);
        }
    }
}
