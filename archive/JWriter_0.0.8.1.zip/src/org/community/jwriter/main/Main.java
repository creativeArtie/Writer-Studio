package org.community.jwriter.main;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import java.util.ResourceBundle;
import java.util.PropertyResourceBundle;
import java.io.File;

import org.community.jwriter.basic.ManuscriptDocument;
import org.community.jwriter.property.PropertyManager;
import org.fxmisc.richtext.InlineCssTextArea;


public class Main extends Application{
    public final static ResourceBundle ABBREVIATION = PropertyResourceBundle
        .getBundle("data.abbreviation");
    

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage window){
        WindowText.TITLE.addAndCall((resource, value) -> window.setTitle(value));
        try{
            File tmp = new File("data/sectionDebug5.txt");
            DocumentPane pane = new DocumentPane(tmp);
            Scene writing = new Scene(pane, 800, 600);
            window.setScene(writing);
        } catch (Exception ex){
            ex.printStackTrace();
            System.exit(-1);
        }
        window.show();
    }
}
