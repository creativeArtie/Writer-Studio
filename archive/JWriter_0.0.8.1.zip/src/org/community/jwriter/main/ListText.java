package org.community.jwriter.main;

import org.community.jwriter.property.*;
import org.community.jwriter.basic.DirectoryType;
import com.google.common.base.CaseFormat;

public enum ListText implements TextResourceEnumHelper{
    NOTE, FOOTNOTE, ENDNOTE, LINK;
    private static final String TITLE = "ListView.";
    
    private static TextResourceManager manager = TextResourceManager
        .getResouce("data/windowtext/text");
    
    private TextResource resource;

    @Override
    public TextResource delegate(){
        if (resource == null){
            String name = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, 
                name());
            resource = manager.getText(TITLE + name);
        }
        return resource;
    }
    
    public static ListText valueOf(DirectoryType type){
        return values()[type.ordinal()];
    }
}
