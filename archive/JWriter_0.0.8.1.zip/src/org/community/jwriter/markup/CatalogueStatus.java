package org.community.jwriter.markup;

import static org.community.jwriter.markup.SetupStrings.*;
    
/**
 * Types of error with the CatalogueIdentity.
 */
public enum CatalogueStatus implements DetailStyle {
    /// This is no id assoicate in a CatalogueHolder
    NO_ID(STYLE_ID_ERROR),
    /// There is an id but nothing is refer to it
    UNUSED(STYLE_ID_WARNING),
    /// A reference that pointing to no known CatalogueIdentity. 
    NOT_FOUND(STYLE_ID_ERROR), 
    /// More than one CatalogueIdentity has the same name
    MULTIPLE(STYLE_ID_WARNING),
    /// No error is found.
    READY(STYLE_ID_READY);
    
    private String type;
    
    private CatalogueStatus(String readiness){
        type = readiness;
    }
    
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_ID, type);
    }
}
