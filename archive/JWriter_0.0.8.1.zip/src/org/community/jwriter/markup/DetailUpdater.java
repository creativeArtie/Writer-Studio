package org.community.jwriter.markup;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.community.jwriter.markup.DetailUpdateType.*;
import org.community.jwriter.main.Utilities;

public class DetailUpdater{
    
    public static DetailUpdater replace(SetupParser ... parserList){
        return new DetailUpdater(REPLACE, parserList);
    }
    
    public static DetailUpdater mergeBoth(SetupParser ... parseList){
        return new DetailUpdater(MERGE_BOTH, parseList);
    }
    
    public static DetailUpdater mergeLast(SetupParser ... parserList){
        return new DetailUpdater(MERGE_LAST, parserList);
    }
    
    public static DetailUpdater mergeNext(SetupParser ... parserList){
        return new DetailUpdater(MERGE_NEXT, parserList);
    }
    
    public static DetailUpdater unable(){
        return new DetailUpdater(UNABLE, null);
    }
    
    private Optional<SetupParser[]> parsers;
    private DetailUpdateType plan;
    
    private DetailUpdater(DetailUpdateType updatePlan, 
        SetupParser[] parserList
    ){
        parsers = Optional.ofNullable(parserList);
        plan = updatePlan;
    }
    
    DetailUpdateType getType(){
        return plan;
    }
    
    List<Span> parse(String rawText, Document rootDoc){
        SetupPointer pointer = SetupPointer.updatePointer(rawText, rootDoc);
        ArrayList<Span> ans = new ArrayList<>();
        while(pointer.hasNext()){
            for(SetupParser parser: parsers.get()){
                if(parser.parse(ans, pointer)){
                    break;
                }
            }
        }
        return ans;
    }
}
