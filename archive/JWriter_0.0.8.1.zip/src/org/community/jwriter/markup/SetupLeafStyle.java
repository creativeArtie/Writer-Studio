package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.Map;

import static org.community.jwriter.markup.SetupStrings.*;
import org.community.jwriter.property.PropertyManager;
import com.google.common.base.CaseFormat;

public enum SetupLeafStyle implements DetailStyle {
    KEYWORD, ID, FIELD, DATA, PATH, TEXT;
    
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_BASIC, name());
    }
}
