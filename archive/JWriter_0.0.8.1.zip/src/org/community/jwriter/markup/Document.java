package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import com.google.common.base.CharMatcher;
import com.google.common.collect.Range;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;

import java.util.concurrent.Callable;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

import org.community.jwriter.main.Checker;

/**
 * {@code Document} is what {@link org.community.jwriter.window} and 
 * {@link org.community.output} use to represent the text file. This will
 * immediately parse the rawText upon the constructor.
 */
public abstract class Document extends SpanNode<SpanBranch>{
    
    private Cache<Span, Range<Integer>> starts;

    private ArrayList<SpanBranch> children;
    private CatalogueMap ids;
    private SetupParser[] parsers;
    
    public Document(){
        children = new ArrayList<>();
        ids = new CatalogueMap();
        starts = CacheBuilder.newBuilder().weakKeys().build();
    }
        
    public Document(String rawText, SetupParser ... docParsers){
        Checker.checkNotNull(rawText, "rawText");
        Checker.checkNotNull(docParsers, "docParsers");
        starts = CacheBuilder.newBuilder().weakKeys().build();
        
        parsers = docParsers;
        
        /// Setup for building the doc and a pointer to use
        parseDocument(rawText);
    }
        
    protected void parseDocument(String rawText){
        Checker.checkNotNull(rawText, "rawText");
        children = new ArrayList<>();
        SetupPointer ptr = SetupPointer.newPointer(rawText, this);
        /// Setup for runtime exceptions
        int counter = 0; 
        
        /// Parse loop
        while (ptr.hasNext()){
            /// CatalogueStatus checking what happen if SetupPointer fails or 
            /// SetupParser[] misses the texts
            if(counter > rawText.length()){
                System.out.println(children);
                System.out.println(ptr);
                throw new RuntimeException("Loop too much");
            }
            counter++;
            
            /// Finding the correct SetupParser to build span from
            for(SetupParser s: parsers){
                Optional<?> span = s.parse(ptr);
                
                /// Span has been created
                if (span.isPresent()){
                    SpanBranch found = (SpanBranch)span.get();
                    found.setParent(this);
                    children.add(found);
                    break;
                }
            }
        }
        
        /// Finalize the parse loop
        ids = new CatalogueMap();
        update(children);
    }
    
    private List<SpanBranch> update(List<? extends Span> spanList){
        ArrayList<SpanBranch> holders = new ArrayList<>();
        for (Span span: spanList){
            if (span instanceof SpanBranch){
                SpanBranch branch = (SpanBranch) span;
                branch.getIdHolder().ifPresent(holder -> {
                    holder.fillMap(ids);
                    holders.add(branch);
                });
                holders.addAll(update(branch));
            }
            if (span instanceof CatalogueSpan){
                holders.add((SpanBranch) span);
            }
            span.invalidateCache();
        }
        return holders;
    }
    
    public CatalogueMap getMap(){
        return ids;
    }
    
    @Override
    public String toString(){
        if (ids.size() == 0){
            return super.toString() + ids.toString();
        }
        return super.toString() + "\n" + ids.toString();
    }
    
    @Override
    public Document getDocument(){
        return this;
    }
    
    @Override
    public SpanNode<?> getParent(){
        throw new UnsupportedOperationException("No parents");
    }
    
    @Override
    public List<SpanBranch> delegate(){
        return ImmutableList.copyOf(children);
    }
    
    @Override
    Span removeChild(int idx){
        Span ans = children.remove(idx);
        ans.setRemove();
        return ans;
    }
    
    @Override
    void addChildren(int listIndex, List<Span> spanList){
        ArrayList<SpanBranch> insert = new ArrayList<>();
        for(Span child: spanList){
            if ( !(child instanceof SpanBranch)){
                throw new IllegalArgumentException(
                    "Child is not a brench:" + child);
            }
            insert.add((SpanBranch)child);
            ((SpanBranch)child).setParent(this);
        }
        children.addAll(listIndex, insert);
    }
    
    @Override
    public void setRemove(){
        for (SpanBranch child: children){
            child.setRemove();
        }
    }
    
    @Override
    public int getStart(){
        return 0;
    }
    
    protected Range<Integer> getRange(Span child, Callable<Range<Integer>> caller) 
        throws ExecutionException
    {
        return starts.get(child, caller);
    }
    
    public List<SpanLeaf> getLeaves(){
        return ImmutableList.copyOf(getLeaves(this));
    }
    
    private List<SpanLeaf> getLeaves(SpanNode<?> spans){
        ImmutableList.Builder<SpanLeaf> builder = ImmutableList.builder();
        for(Span span: spans){
            if (span instanceof SpanLeaf){
                builder.add((SpanLeaf) span);
            } else {
                builder.addAll(getLeaves((SpanBranch)span));
            }
        }
        return builder.build();
    }
    
    public List<Span> spansAt(int docIndex){
        Preconditions.checkPositionIndex(docIndex, getLength(), "Doc index");
        ArrayList<Span> ans = new ArrayList<>();
        findSpan(ans, docIndex);
        return ImmutableList.copyOf(ans);
    }
    
    private int findSpan(ArrayList<Span> spanList, int docIndex){
        spanList.add(this);
        int length = getLength();
        if (docIndex == length){
            Span search = this.get(size() - 1);
            while (search instanceof SpanNode){
                spanList.add(search);
                SpanNode<? extends Span> parent = (SpanNode<? extends Span>) 
                    search;
                search = parent.get(parent.size() - 1);
            }
            spanList.add(search);
            return search.getLength();
        }
        
        int start = 0;
        Iterator<? extends Span> it = iterator();
        while (true){
            if (! it.hasNext()){
                throw new IllegalArgumentException("Out of range.");
            }
            Span found = it.next();
            if (start + found.getLength() > docIndex){
                spanList.add(found);
                if (found instanceof SpanBranch){
                    it = ((SpanBranch)found).iterator();
                } else {
                    return docIndex - start;
                }
            } else {
                start += found.getLength();
            }
        }
    }
    
    public List<SpanLeaf> insertChar(int location, char ch){
        ArrayList<Span> spans = new ArrayList<>();
        int loc = findSpan(spans, location);
        StringBuilder raw = new StringBuilder(spans.get(spans.size() - 1)
            .getRaw());
        raw.insert(loc, ch);
        return edit(spans, raw.toString());
    }
    
    public List<SpanLeaf> deleteChar(int location){
        ArrayList<Span> spans = new ArrayList<>();
        int loc = findSpan(spans, location);
        StringBuilder raw = new StringBuilder(spans.get(spans.size() - 1)
            .getRaw());
        raw.deleteCharAt(loc);
        return edit(spans, raw.toString());
    }
    
    private List<SpanLeaf> edit(List<Span> spans, String raw){
        
        SpanNode<?> holder = edit(spans, raw, spans.size() - 1);
        ids = new CatalogueMap();
        List<SpanBranch> ids = update(children);
        starts.invalidateAll();
        if (holder instanceof Document){
            return getLeaves();
        }
        List<SpanLeaf> ans = new ArrayList<>();
        ans.addAll(getLeaves(holder));
        for (SpanBranch id: ids){
            ans.addAll(getLeaves(id));
        }
        return ans;
    }
    
    private SpanNode<?> edit(List<Span> spans, String base, int idx){
        
        Span replaced = spans.get(idx);
        Span editor = spans.get(idx - 1);
        String raw = "";
        for (Span span: (SpanNode<? extends Span>)editor){
            if (span == replaced){
                raw += base;
            } else {
                raw += span.getRaw();
            }
        }
        
        if (idx - 1 == 0){
            parseDocument(raw);
        } else {
            DetailUpdater updater = ((SpanBranch)editor)
                .getUpdater(spans.subList(idx, spans.size()), raw);
            if (updater.getType() == DetailUpdateType.UNABLE){
                edit(spans, raw, idx - 1);
            } else {
                parseText(updater, spans, idx, raw);
            }
        }
        return (SpanNode<?>)spans.get(idx - 1);
    }
    
    private void parseText(DetailUpdater updater, List<Span> spans, int idx,
        String base
    ){
        SpanNode<? extends Span> holder = (SpanNode<? extends Span>)spans
            .get(idx - 2);
        SpanNode<? extends Span> editor = (SpanNode<? extends Span>)spans
            .get(idx - 1);
        String input = base;

        int replaceIdx = holder.indexOf(editor);
        DetailUpdateType updateType = updater.getType();
        switch (updateType){
        case REPLACE:
            break;
        case MERGE_LAST:
            input = getSpanRaw(replaceIdx - 1, holder) + input;
            replaceIdx--;
            break;
        case MERGE_BOTH:
            input = getSpanRaw(replaceIdx - 1, holder) + input
                + getSpanRaw(replaceIdx + 1, holder);
            replaceIdx--;
            break;
        case MERGE_NEXT:
            input = input + getSpanRaw(replaceIdx + 1, holder);
            break;
        default:
            throw Checker.typeNotUse(updateType, "updateType");
        }
        if (replaceIdx < 0){
            replaceIdx = 0;
        }
        assert replaceIdx >= 0;
        for (int i = 0; i < updateType.getRemoveSpans(); i++){
            if (replaceIdx < holder.size()){
                holder.removeChild(replaceIdx);
            } else {
                break;
            }
        }
        holder.addChildren(replaceIdx, updater.parse(input, this));
    }
    
    private String getSpanRaw(int i, SpanNode<? extends Span> holder){
        if (0 <= i && i < holder.size()){
            return holder.get(i).getRaw();
        }
        return "";
    }
}
