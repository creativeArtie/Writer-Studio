package org.community.jwriter.markup;

import java.util.concurrent.Callable;
import java.util.List;
import java.util.HashSet;
import java.util.Optional;
import com.google.common.collect.Range;
import org.community.jwriter.main.Checker;
/**
 * A subdivision of a {@link Document}
 */
public abstract class Span{
    
    private HashSet<DetailListener> removers;
    private HashSet<DetailListener> editors;
    
    Span(){
        removers = new HashSet<>();
        editors = new HashSet<>();
    }
    
    public abstract String getRaw();
    
    public abstract int getLength();
    
    public abstract Document getDocument();
    
    public abstract SpanNode<?> getParent();
    
    public void addRemover(DetailListener listener){
        removers.add(listener);
    }
    
    public void setRemove(){
        for(DetailListener remover: removers){
            remover.changed(this);
        }
    }
    
    public void addEditor(DetailListener listener){
        editors.add(listener);
    }
    
    public void setEdit(){
        for(DetailListener editor: editors){
            editor.changed(this);
        }
        if (! (this instanceof Document)){
            getParent().setEdit();
        }
    }
    
    void invalidateCache(){}
    
    protected void invalidateAll(){}
    
    public Range<Integer> getRange(){
        try {
            return getDocument().getRange(this, () ->{
                int ans = getParent().getStart();
                for(Span span: getParent()){
                    if (span == this){
                        return Range.closedOpen(ans, ans + getLength());
                    }
                    ans += span.getLength();
                }
                assert false;
                return Range.closedOpen(ans, ans + getLength());
                
            });
        } catch (Exception ex){
            throw new RuntimeException(ex);
        }
    }
    
    public int getStart(){
        return getRange().lowerEndpoint();
    }
    
    public int getEnd(){
        return getRange().upperEndpoint();
    }
}
