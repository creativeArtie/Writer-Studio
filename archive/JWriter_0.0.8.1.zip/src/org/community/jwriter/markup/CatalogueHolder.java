package org.community.jwriter.markup;

import java.util.Optional;
import org.community.jwriter.main.Checker;

public class CatalogueHolder implements Comparable<CatalogueHolder>{
    
    public static Optional<CatalogueHolder> asId(Document document, 
        SpanBranch parentSpan, Optional<? extends CatalogueSpan> useSpan)
    {
        return build(document, parentSpan, useSpan, true);
    }
    public static Optional<CatalogueHolder> asRef(Document document, 
        SpanBranch parentSpan, Optional<? extends CatalogueSpan> useSpan)
    {
        return build(document, parentSpan, useSpan, false);
    }
    
    public static Optional<CatalogueHolder> asId(Document document, 
        SpanBranch parentSpan, CatalogueIdentity id)
    {
        return build(document, parentSpan, id, true);
    }
    
    public static Optional<CatalogueHolder> asRef(Document document, 
        SpanBranch parentSpan, CatalogueIdentity id)
    {
        return build(document, parentSpan, id, false);
    }
    
    public static Optional<CatalogueHolder> build(Document document, 
        SpanBranch parentSpan, CatalogueIdentity id, boolean asId)
    {
        Checker.checkNotNull(document, "document");
        Checker.checkNotNull(parentSpan, "parentSpan");
        Checker.checkNotNull(id, "id");
        Optional<CatalogueSpan> inSpan = Optional.empty();
        Optional<CatalogueIdentity> inId = Optional.of(id);
        return Optional.of(new CatalogueHolder(document, parentSpan, inSpan, 
            inId, asId));
    }
    
    private static Optional<CatalogueHolder> build(Document document, 
        SpanBranch parentSpan, Optional<? extends CatalogueSpan> useSpan,
        boolean asId)
    {
        Checker.checkNotNull(useSpan, "useSpan");
        if (! useSpan.isPresent()){
            return Optional.empty();
        }
        Checker.checkNotNull(document, "document");
        Checker.checkNotNull(parentSpan, "parentSpan");
        Optional<CatalogueSpan> inSpan = useSpan.map(map -> (CatalogueSpan) map);
        Optional<CatalogueIdentity> inId = Optional.of(inSpan.get().getId());
        return Optional.of(new CatalogueHolder(document, parentSpan, inSpan, 
            inId, true));
    }
            
    private Document doc;
    private SpanBranch parent;
    private Optional<CatalogueSpan> span;
    private Optional<CatalogueIdentity> id;
    private boolean isId;
    
    private CatalogueHolder(Document document, SpanBranch parentSpan, 
        Optional<CatalogueSpan> catSpan, Optional<CatalogueIdentity> catId, 
        boolean isIdNotRef)
    {
        doc = document;
        parent = parentSpan;
        span = catSpan;
        id = catId;
        isId = isIdNotRef;
    }
    
    public Optional<CatalogueIdentity> getId(){
        return id;
    }
    
    public boolean hasId(){
        return getId().isPresent();
    }
    
    public Optional<CatalogueSpan> getIdSpan(){
        return span;
    }
    
    public CatalogueStatus getStatus(){
        if (id.isPresent()){
            return id.get().getStatus(doc.getMap());
        }
        return CatalogueStatus.NO_ID;
    }
    
    public String[] getCategory(){
        return id.isPresent()? id.get().getCategory(): new String[0];
    }
    
    public String getIdentity(){
        return id.isPresent()? id.get().getIdentity(): "";
    }
    
    public String getFullIdentity(){
        return id.isPresent()? id.get().getFullIdentity(): "";
    }
    
    @Override
    public int compareTo(CatalogueHolder otherHolder){
        if (otherHolder == null){
            return 1;
        }
        Optional<CatalogueIdentity> id = getId();
        if (id.isPresent()){
            Optional<CatalogueIdentity> id2 = otherHolder.getId();
            if (id2.isPresent()){
                return id.get().compareTo(id2.get());
            }
            return 1;
        }
        return -1;
    }
    
    public Optional<Span> getTarget(){
        if (id.isPresent()){
            CatalogueData data = doc.getMap().get(id.get());
            if (data.isReady()){
                return Optional.of(data.getTarget());
            }
        }
        return Optional.empty();
    }
    
    void fillMap(CatalogueMap storedMap){
        Checker.checkNotNull(storedMap, "storedMap");
        Optional<CatalogueIdentity> adding = getId();
        id.ifPresent(found -> {
            if (isId){
                storedMap.addId(found, parent);
            } else {
                storedMap.addRef(found, parent);
            }
        });
    }
}
