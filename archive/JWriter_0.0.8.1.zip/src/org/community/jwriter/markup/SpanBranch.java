package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.TreeMap;

import java.util.concurrent.Callable;
import com.google.common.collect.ImmutableList;

/**
 * A {@link Span} handling {@link SpanLeaf}
 */
public abstract class SpanBranch extends SpanNode<Span> {
    
    private ArrayList<Span> children;
    
    private SpanNode<?> parent;
    
    public SpanBranch(List<Span> spans){
        children = new ArrayList<>(spans);
        setParents(children);
    }
    
    private void setParents(List<Span> spans){
        for(Span span : spans){
            if (span instanceof SpanBranch){
                ((SpanBranch)span).setParent(this);
            } else {
                ((SpanLeaf)span).setParent(this);
            }
        }
    }
    
    protected int search(String raw, String escape, List<String> find){
        return search(raw, escape, find.toArray(new String[0]));
    }
    
    protected int search(String raw, String escape, String ... find){
        boolean isEscape = false;
        for(int i = 0; i < raw.length(); i++){
            if (isEscape){
                isEscape = false;
            } else {
                if (raw.startsWith(escape, i)){
                    isEscape = true;
                } else {
                    for(String str: find){
                        if (raw.startsWith(str, i)){
                            return i;
                        }
                    }
                }
            }
        }
        return -1;
    }
    
    @Override
    public final List<Span> delegate(){
        return ImmutableList.copyOf(children);
    }
    
    @Override
    Span removeChild(int idx){
        Span span = children.remove(idx);
        span.setRemove();
        setEdit();
        return span;
    }
    
    @Override
    void addChildren(int idx, List<Span> spans){
        children.addAll(idx, spans);
        setParents(spans);
        setEdit();
    }
    
    @Override
    public Document getDocument(){
        return get(0).getDocument();
    }
    
    @Override
    public SpanNode<?> getParent(){
        return parent;
    }
    
    void setParent(SpanNode<?> childOf){
        parent = childOf;
    }
    
    protected abstract void addInfo(List<DetailStyle> list);
    
    public Optional<CatalogueHolder> getIdHolder(){
        return Optional.empty();
    }

    
    public DetailStyle[] getInfo(){
        // TODO change to abstract method
        return null;
    }
    
    protected DetailStyle[] combineInfo(DetailStyle[] parent, 
        DetailStyle[] child)
    {
        DetailStyle[] ans = new DetailStyle[parent.length + child.length];
        System.arraycopy(ans, 0, parent, 0, parent.length);
        System.arraycopy(ans, parent.length, child, 0, child.length);
        return ans;
    }
    
    protected DetailUpdater getUpdater(List<Span> edit, String newText){
        return DetailUpdater.unable();
    }
}
