package org.community.jwriter.markup;

import com.google.common.base.CaseFormat;

import org.community.jwriter.main.Checker;

public interface DetailStyle{
    public String getStyleClass();
    
    public static final String SEPARATOR = ".";
    
    public static String styleFromEnum(String prefixText, String postfixText){
        Checker.checkNotNull(prefixText, "prefixText");
        Checker.checkNotNull(postfixText, "postfixText");
        CaseFormat from = CaseFormat.UPPER_UNDERSCORE;
        CaseFormat to = CaseFormat.UPPER_CAMEL; 
        return from.to(to, prefixText) + SEPARATOR + from.to(to, postfixText);
    }
    
}
