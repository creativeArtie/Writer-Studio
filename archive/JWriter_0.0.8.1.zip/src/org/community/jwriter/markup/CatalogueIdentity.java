package org.community.jwriter.markup;

import java.util.List;
import java.util.Objects;
import com.google.common.collect.ImmutableList;

import org.community.jwriter.main.Checker;

public class CatalogueIdentity implements Comparable<CatalogueIdentity>{
    private final ImmutableList<String> category;
    private final String id;
    
    public CatalogueIdentity(List<String> categoryegoryList, String baseId){
        Checker.checkNotNull(categoryegoryList, "categoryegoryList");
        Checker.checkNotNull(baseId, "baseId");
        category = ImmutableList.copyOf(categoryegoryList);
        id = baseId;
    }
    
    public CatalogueStatus getStatus(CatalogueMap parentMap){
         Checker.checkNotNull(parentMap, "parentMap");
        return parentMap.get(this).getState();
    }
    
    public String[] getCategory(){
        return category.toArray(new String[0]);
    }
    
    public String getIdentity(){
        return id;
    }
    
    public String getFullIdentity(){
        StringBuilder builder = new StringBuilder();
        int i = 0;
        for(String category: getCategory()){
            builder.append(category);
            builder.append("-");
        }
        builder.append(getIdentity());
        return builder.toString();
    }
    
    @Override
    public String toString(){
        return "(" + getFullIdentity() + ")";
    }
    
    @Override
    public int compareTo(CatalogueIdentity compareId){
        if (compareId == null){
            return 1;
        }
        int i = 0;
        for (String category: category){
            if (i >= compareId.category.size()){
                return 1;
            }
            int compare = category.compareTo(compareId.category.get(i));
            if (compare != 0){
                return compare;
            }
            i++;
        }
        if (i < compareId.category.size()){
            return -1;
        }
        return id.compareTo(compareId.id);
    }
    
    @Override
    public boolean equals(Object compareObj){
        if (compareObj instanceof CatalogueIdentity){ /// compareObject != null
            CatalogueIdentity span = (CatalogueIdentity) compareObj;
            if (category.equals(span.category)){
                return id.equals(span.id);
            }
        }
        return false;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(category, id);
    }
}
