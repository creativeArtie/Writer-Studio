package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor
import java.util.List;
import java.util.ArrayList;

import com.google.common.collect.ImmutableList;
import com.google.common.base.Splitter;
import com.google.common.base.CaseFormat;
import com.google.common.base.Preconditions;

import java.util.concurrent.Callable;
import org.community.jwriter.property.StyleProperty;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.main.Checker;
import static org.community.jwriter.markup.SetupStrings.*;

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf extends Span{
    private String text;
    private SpanBranch parent;
    private SetupLeafStyle style;
    
    public static String escapeText(String input){
        return "\"" + input.replace("\n", "\" \\n \"")
            .replace("\t", "\" \\t \"") + "\"";
    }
    
    SpanLeaf(SetupPointer pointer, SetupLeafStyle spanStyle){
        text = pointer.getRaw();
        pointer.roll();
        style = spanStyle;
    }
    
    public DetailStyle getInfo(){
        return style;
    }
    
    public List<DetailStyle> getDetailStyle(){
        ArrayList<DetailStyle> ans = new ArrayList<>();
        getDetailStyle(this, ans);
        ans.add(style);
        return ImmutableList.copyOf(ans);
    }
    
    private void getDetailStyle(Span child, 
        ArrayList<DetailStyle> input
    ){
        SpanNode<?> parent = child.getParent();
        if (parent instanceof SpanBranch){
            getDetailStyle(parent, input);
            ((SpanBranch)parent).addInfo(input);
        }
    }
    
    void setParent(SpanBranch childOf){
        parent = childOf;
    }
    
    @Override
    public final String getRaw(){
        return text;
    }
    
    @Override
    public String toString(){
        return escapeText(text);
    }
    
    @Override
    public Document getDocument(){
        SpanNode<?> span = getParent();
        while (! (span instanceof Document)){
            span = span.getParent();
        }
        return (Document)span;
    }
    
    @Override
    public SpanBranch getParent(){
        return parent;
    }
    
    @Override
    public int getLength(){
        return text.length();
    }
    
    public String toCss(PropertyManager styleFile){
        Checker.checkNotNull(styleFile, "styleFile");
        ArrayList<StyleProperty> list = new ArrayList<>();
        for(DetailStyle info: getDetailStyle()){
            String style = info.getStyleClass();
            list.add(styleFile.getStyleProperty(style));
        }
        list.add(styleFile.getStyleProperty(DetailStyle.styleFromEnum(
            SetupStrings.STYLE_BASIC, SetupStrings.STYLE_ALL
        )));
        return StyleProperty.toCss(list);
    }
    
    @Override
    public void setRemove(){}
    
    @Override
    public void setEdit(){
        parent.setEdit();
    }
}
