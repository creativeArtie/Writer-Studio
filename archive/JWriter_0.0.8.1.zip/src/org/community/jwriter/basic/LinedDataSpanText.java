package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;

public class LinedDataSpanText extends LinedDataSpan<ContentSpan>{
    
    @Override
    public LinedDataSpanText cast(){
        return this;
    }
    
    @Override
    public ContentSpan getDataSpan(){
        return (ContentSpan)get(0);
    }
    
    LinedDataSpanText(List<Span> spanChildren){
        super(spanChildren, LinedDataType.TEXT);
    }
}
