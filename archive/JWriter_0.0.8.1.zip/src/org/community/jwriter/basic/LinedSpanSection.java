package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanSection extends LinedSpanLevel {

    LinedSpanSection(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    public Optional<CatalogueHolder> getIdHolder(){
        return CatalogueHolder.asId(getDocument(), this, 
            spanAtFirst(DirectorySpan.class));
    }
    
    public Optional<EditionSpan> getEditionSpan(){
        return spanFromLast(EditionSpan.class);
    }
    
    public EditionType getEdition(){
        Optional<EditionSpan> status = getEditionSpan();
        return status.isPresent()? status.get().getEdition(): EditionType.NONE;
    }
}
