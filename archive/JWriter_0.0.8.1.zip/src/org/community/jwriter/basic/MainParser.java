package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

class MainParser implements SetupParser {
    private static final SetupParser[] PARSERS = SetupParser.combine(
        SetupParser.combine(LinedParseLevel.values(), LinedParsePointer.values()),
        SetupParser.combine(LinedParseCite.values(), LinedParseRest.values())
    );
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        SetupParser found = null;
        for (SetupParser parser: PARSERS){
            if(parser.parse(children, childPointer)){
                found = parser;
                break;
            }
        }
        assert found != null;
        if (found == LinedParseRest.NOTE || found == LinedParseCite.INSTANCE){
            return parseNote(children, childPointer);
        } else {
            return parseSection(children, childPointer);
        }
    }
    
    private Optional<SpanBranch> parseSection(ArrayList<Span> spanChildren, 
            SetupPointer childPointer){
        while (true){
            childPointer.mark();
            Optional<? extends Span> span = Optional.empty();
            for (SetupParser parser : PARSERS){
                span = parser.parse(childPointer);
                if (span.isPresent()){
                    break;
                }
            }
            if (span.isPresent()){
                LinedSpan line = (LinedSpan) span.get();
                switch(line.getType()){
                    case HEADING:
                    case OUTLINE:
                        childPointer.rollBack(line);
                        return buildSection(spanChildren);
                    case NOTE:
                    case SOURCE:
                        childPointer.rollBack(line);
                        return buildSection(spanChildren);
                    default:
                        spanChildren.add(line);
                }
            } else {
                return buildSection(spanChildren);
            }
        }
    }
    
    private Optional<SpanBranch> buildSection(List<Span> spanChildren){
        return Optional.of(new MainSpanSection(spanChildren));
    }
    
    private Optional<SpanBranch> parseNote(ArrayList<Span> spanChildren, 
            SetupPointer childPointer){
        while (true){
            childPointer.mark();
            if (! LinedParseCite.INSTANCE.parse(spanChildren, childPointer)){
                Optional<SpanBranch> span = LinedParseRest.NOTE.parse(childPointer);
                if (! span.isPresent()){
                    return buildNote(spanChildren); 
                } else {
                    LinedSpanNote found = (LinedSpanNote)span.get();
                    if (found.getIdSpan().isPresent()){
                        childPointer.rollBack(found);
                        return buildNote(spanChildren);
                    }
                }
                spanChildren.add(span.get());
            }
            
        }
    }
    
    private Optional<SpanBranch> buildNote(List<Span> spanChildren){
        MainSpanNote ans = new MainSpanNote(spanChildren);
        return Optional.of(ans);
    }
}
