package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * SetupParser for {@link FormatSpanLink} that uses angler bracket. It therefore is a 
 * SetupParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
class FormatParseLinkRef extends FormatParseLink {
    
    FormatParseLinkRef(boolean[] spanFormats){
        super(LINK_REF, spanFormats);
    }

    @Override
    public Optional<SpanBranch> parseFinish(ArrayList<Span> spanChildren, 
        SetupPointer childPointer
    ){
        Checker.checkNotNull(spanChildren, "spanChildren");
        Checker.checkNotNull(childPointer, "childPointer");
        DirectoryParser id = new DirectoryParser(DirectoryType.LINK, 
            LINK_TEXT, LINK_END);
        id.parse(spanChildren, childPointer);
        
        /// Complete the last steps 
        parseRest(spanChildren, childPointer);
        FormatSpanLinkRef span = new FormatSpanLinkRef(spanChildren, getFormats());
        return Optional.of(span);
    }
}
