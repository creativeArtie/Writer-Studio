package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;

public class LinedDataSpanFormatted extends LinedDataSpan<FormatSpanMain>{
    
    @Override
    public LinedDataSpanFormatted cast(){
        return this;
    }
    
    @Override
    public FormatSpanMain getDataSpan(){
        return spanAtFirst(FormatSpanMain.class).get();
    }
    
    protected LinedDataSpanFormatted(List<Span> spanChildren){
        super(spanChildren, LinedDataType.FORMATTED);
    }
}
