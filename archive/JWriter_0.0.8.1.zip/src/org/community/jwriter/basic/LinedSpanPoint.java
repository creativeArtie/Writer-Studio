package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public abstract class LinedSpanPoint extends LinedSpan{

    LinedSpanPoint(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public abstract DirectoryType getDirectoryType();
    
    @Override
    public Optional<CatalogueHolder> getIdHolder(){
        return CatalogueHolder.asId(getDocument(), this, 
            spanAtFirst(DirectorySpan.class));
    }
    
    @Override
    public DetailStyle[] getInfo(){
        if (getIdHolder().isPresent()){
            return super.getInfo();
        }
        return combineInfo(super.getInfo(), new DetailStyle[]{AuxiliaryStyle.NO_ID});
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        super.addInfo(list);
        if (! getIdHolder().isPresent()) list.add(AuxiliaryStyle.NO_ID);
    }
}
