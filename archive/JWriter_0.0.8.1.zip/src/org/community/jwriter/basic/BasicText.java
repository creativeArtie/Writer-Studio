package org.community.jwriter.basic;

import java.util.List;      /// For initialization (enders)

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

interface BasicText{
    
    public List<Span> delegate();
    
    public default String getText(){
        StringBuilder builder = new StringBuilder();
        for(Span child: delegate()){
            if (child instanceof BasicTextEscape){
                builder.append(((BasicTextEscape)child).getEscape());
            } else if (child instanceof SpanLeaf){
                /// Add text from a basic span
                builder.append(child.getRaw());
            } else {
                assert false: child.getClass();
            }
        }
        return CharMatcher.whitespace().collapseFrom(builder, ' ');
    }
    
    public default String getParsed(){
        return CharMatcher.whitespace().trimFrom(getText());
    }
    
    public default boolean isSpaceBegin(){
        String output = getText();
        if (output.isEmpty()){
            return false;
        }
        return CharMatcher.whitespace().matches(output.charAt(0));
    }
    
    public default boolean isSpaceEnd(){
        String output = getText();
        if (output.isEmpty()){
            return false;
        }
        return CharMatcher.whitespace()
            .matches(output.charAt(output.length() - 1));
    }
}
