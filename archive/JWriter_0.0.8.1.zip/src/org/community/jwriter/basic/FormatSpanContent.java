package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * A {@link ContentSpan} with format for {@link FormatSpanMain}. 
 */
public class FormatSpanContent extends FormatSpan implements BasicText{
    
    /// Stuff for reparsing
    private final List<String> enders;
    private final SetupLeafStyle style;
    private final boolean parse;
    
    FormatSpanContent(List<Span> spanChildren, boolean[] spanFormats, 
        List<String> spanEnders, SetupLeafStyle baseStyle, boolean canParse
    ){
        super(spanChildren, spanFormats);
        enders = spanEnders;
        style = baseStyle;
        parse = canParse;
    }
    
    @Override
    protected DetailUpdater getUpdater(List<Span> editSpans, String newText){
        Checker.checkNotNull(newText, "newText");
        if(parse && search(newText, CHAR_ESCAPE, enders) == -1){
            return DetailUpdater.replace(new FormatParseContent(style, 
                getFormats(), parse, enders));
        }
        return DetailUpdater.unable();
    }
    
    @Override
    public String getOutput(){
        return getText();
    }
}
