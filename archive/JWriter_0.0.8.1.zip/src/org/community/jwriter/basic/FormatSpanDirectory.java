package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@linkplain FormatSpanCurly} for id reference. This has a span where it is
 * reference to
 */
public final class FormatSpanDirectory extends FormatSpan {
    private final DirectoryType type;
    
    FormatSpanDirectory(List<Span> spanChildren, boolean[] spanFormats, 
        DirectoryType curlyType
    ){
        super(spanChildren, spanFormats);
        type = curlyType;
    }
    
    public DirectoryType getIdType(){
        return type;
    }
    
    @Override
    public Optional<CatalogueHolder> getIdHolder(){
        return CatalogueHolder.asRef(getDocument(), this, 
            spanAtFirst(DirectorySpan.class));
    }
    
    @Override
    public DetailStyle[] getInfo(){
        DetailStyle[] base;
        if (getIdHolder().isPresent()){
            base = new DetailStyle[]{type};
        } else {
            base = new DetailStyle[]{type, AuxiliaryStyle.NO_ID};
        }
        return combineInfo(super.getInfo(), base);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(type);
        if (! getIdHolder().isPresent()) list.add(AuxiliaryStyle.NO_ID);
        super.addInfo(list);
    }
    
    @Override
    public String getOutput(){
        Optional<CatalogueHolder> id = getIdHolder();
        if (id.isPresent()){
            return ((DirectorySpan)id.get().getIdSpan().get()).getIdRaw();
        }
        return "";
    }
}
