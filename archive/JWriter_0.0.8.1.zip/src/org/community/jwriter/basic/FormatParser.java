package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * A {@link Span} for text that has been formatted. This makes all {@link Span}
 * starting with {@code Format}.
 */
class FormatParser implements SetupParser {
    
    private final String[] ends;
    
    private final SetupLeafStyle style;
    private final boolean parse;
    public FormatParser(boolean allowParse, String ... formatEnders){
        this (SetupLeafStyle.TEXT, allowParse, formatEnders);
    }
    
    public FormatParser(String ... formatEnders){
        this (SetupLeafStyle.TEXT, true, formatEnders);
    }
    
    public FormatParser(SetupLeafStyle baseStyle, String ... formatEnders){
        this (baseStyle, true, formatEnders);
    }
    
    public FormatParser(SetupLeafStyle baseStyle, boolean canParse, 
        String ... formatEnders
    ){
        /// Combine the list of span enders and formatting enders
        Checker.checkNotNull(formatEnders, "formatEnders");
        ends = SetupParser.combine(listFormatEnderTokens(), formatEnders);
        style = Checker.checkNotNull(baseStyle, "baseStyle");
        parse = canParse;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        
        /// Setup format style: bold, italics, underline, coded
        boolean[] formats = new boolean[]{false, false, false, false};
        
        /// Setup for FormatSpanMain
        ArrayList<Span> children = new ArrayList<>();
        
        /// check where the loop ends
        boolean more;
        
        do {
            more = false; /// Assume FormatSpanMain has ended
            
            /// try to find text first
            if (new FormatParseContent(style, formats, parse, ends)
                .parse(children, childPointer)
            ){
                more = true;
            }
            
            if (FormatParseAgenda.PARSER.parse(children, childPointer)){
                more = true;
            }
            
            /// Keeps FomratContentParser parsing alone b/c of needs to edit format
            int i = 0;
            for (String type : listFormatTextTokens()){
                if (childPointer.startsWith(children, type)){
                    /// change format of bold/italics/underline/code
                    formats[i] = ! formats[i];
                    
                    more = true;
                    break;
                }
                i++;
            }
            
            /// Lastly deal with FormatParseCurly and FormatParseLink together
            for (SetupParser parser: SetupParser.combine(
                FormatParseDirectory.getParsers(formats), 
                FormatParseLink.getParsers(formats)
            )){
                if(parser.parse(children, childPointer)){
                    /// Striaght forwarding adding of found spans.
                    more = true;
                }
            }
        } while(more);
        
        /// Add the FormatParser with its children spans if there are children.
        if (children.size() > 0){
            return Optional.of(new FormatSpanMain(children));
        }
        return Optional.empty();
    }
}
