package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import java.util.ArrayList;
import java.util.Optional;
import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;

public class SectionOutline extends Section{
    private SectionHeading heading;
    private Optional<LinedSpanSection> line;
    private Optional<SectionOutline> parent;
    private ArrayList<SectionOutline> outlines;
    private int depth;
    
    SectionOutline(SectionHeading sectionHeading, SectionOutline outlineParent, 
        int nodeDepth, LinedSpanSection outline)
    {
        this(sectionHeading, Optional.ofNullable(outlineParent), nodeDepth, 
            outline);
    }
    
    private SectionOutline(SectionHeading sectionHeading, 
        Optional<SectionOutline> outlineParent, 
        int nodeDepth, LinedSpanSection outline)
    {
        heading = sectionHeading;
        line = Optional.ofNullable(outline);
        parent = outlineParent;
        depth = nodeDepth;
        outlines = new ArrayList<>();
    }
    
    Optional<SectionOutline> append(LinedSpanSection section){
        int level = section.getLevel();
        if (level <= depth){
            if (parent.isPresent()){
                return parent.get().append(section);
            } else {
                return Optional.empty();
            }
        }
        if (level == depth + 1){
            SectionOutline ans = new SectionOutline(heading, this, 
                depth + 1, section);
            outlines.add(ans);
            return Optional.of(ans);
        }
        assert level > depth + 1;
        SectionOutline ans = new SectionOutline(heading, this, depth + 1, 
            null);
        outlines.add(ans);
        return ans.append(section);
    }
    
    public SectionHeading getHeading(){
        return heading;
    }
    
    public Optional<LinedSpanSection> getLine(){
        return line;
    }
    
    public Optional<SectionOutline> getParent() {
        return parent;
    }
    
    
    @Override
    public ImmutableList<SectionOutline> getChildren(){
        return ImmutableList.copyOf(outlines);
    }
    
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append(line.isPresent()? line.get() : "null");
        for (SectionOutline child: outlines){
            builder.append("\n\t");
            builder.append(child.toString().replace("\n", "\n\t"));
        }
        return builder.toString();
    }
    
    public int getLevel() {
        return depth;
    }
}
