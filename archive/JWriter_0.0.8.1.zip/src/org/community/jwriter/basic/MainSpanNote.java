package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableListMultimap;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class MainSpanNote extends MainSpan {
    
    MainSpanNote(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    public Optional<CatalogueHolder> getIdHolder(){
        Optional<LinedSpanNote> child = spanAtFirst(LinedSpanNote.class);
        if (child.isPresent()){
            Optional<DirectorySpan> found = child.get().getIdSpan();
            if (found.isPresent()) {
                return CatalogueHolder.asId(getDocument(), this, found);
            }
        }
        return Optional.empty();
    }
    
    @Override
    public DetailStyle[] getInfo(){
        if (getIdHolder().isPresent()) {
            return new DetailStyle[]{AuxiliaryStyle.MAIN_NOTE};
        }
        return new DetailStyle[]{AuxiliaryStyle.MAIN_NOTE,
            AuxiliaryStyle.NO_ID};
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.MAIN_NOTE);
        if (! getIdHolder().isPresent()) list.add(AuxiliaryStyle.NO_ID);
    }
    
    public ImmutableListMultimap<LinedDataField, LinedDataSpan<?>> getSources(){
        ImmutableListMultimap.Builder<LinedDataField, LinedDataSpan<?>> data = 
            ImmutableListMultimap.builder();
        for (Span child: this){
            if (child instanceof LinedSpanCite){
                LinedSpanCite cite = (LinedSpanCite) child;
                if (cite.getData().isPresent()){
                    data.put(cite.getField(), cite.getData().get());
                }
            }
        }
        return data.build();
    }
    
    @Override
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span span: this){
            output.append("\n\t").append(span.toString());
        }
        output.append("\n}");
        return output.toString();
    }
}
