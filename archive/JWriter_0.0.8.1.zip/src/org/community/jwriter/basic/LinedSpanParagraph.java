package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanParagraph extends LinedSpan {

    LinedSpanParagraph(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public Optional<FormatSpanMain> getFormattedSpan(){
        return spanAtFirst(FormatSpanMain.class);
    }
}
