package org.community.jwriter.basic;

import static org.community.jwriter.basic.AuxiliaryData.*;

import org.community.jwriter.markup.DetailStyle;
public enum FormatType implements DetailStyle{
    BOLD, ITALICS, UNDERLINE, CODED;
    
    @Override 
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_FORMAT, name());
    }
}
