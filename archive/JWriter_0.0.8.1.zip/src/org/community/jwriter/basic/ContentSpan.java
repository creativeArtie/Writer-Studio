package org.community.jwriter.basic;

import java.util.List; /// For initialization (children)

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Created from {@link ContentParser}, super class of 
 * {@link ContentSpanContent}. Used for whenever text is needed.
 */
public class ContentSpan extends SpanBranch implements BasicText{
    
    /// Stuff for getUpdater(List<Span>, String)
    private final List<String> enders;
    private final SetupLeafStyle style;
    
    ContentSpan (List<Span> spanChildren, List<String> spanEnders, 
        SetupLeafStyle baseStyle
    ){
        super(spanChildren);
        enders = Checker.checkNotNull(spanEnders, "spanEnders");
        style = Checker.checkNotNull(baseStyle, "baseStyle");
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return new DetailStyle[0];
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){}
    
    @Override
    protected DetailUpdater getUpdater(List<Span> editedSpan, String newText){
        Checker.checkNotNull(newText, "newText");
        if(search(newText, CHAR_ESCAPE, enders) == -1){
            return DetailUpdater.replace(new ContentParser(style, enders));
        }
        return DetailUpdater.unable();
    }
    
    @Override
    public String toString(){
        String ans ="";
        for (Span span: this){
            ans += span.toString() + "-";
        }
        return ans;
    }
}
