package org.community.jwriter.basic;

import java.util.List;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A formatted {@link Span} for common methods in {@link FormatSpanLinkDirect} 
 * and {@link FormatSpanLinkRef}.
 */
public abstract class FormatSpanLink extends FormatSpan {
    
    FormatSpanLink(List<Span> spanChildren, boolean[] spanFormats){
        super(spanChildren, spanFormats);
    }
    
    /**
     * Return the path of the link.
     */
    public abstract String getPath();
    
    /**
     * Return the display output text.
     */
    public abstract String getText();
    
    @Override 
    public String getOutput(){
        return getText();
    }
}
