package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

enum LinedParsePointer implements SetupParser {
    FOOTNOTE(LINED_FOOTNOTE), ENDNOTE(LINED_ENDNOTE), HYPERLINK(LINED_LINK){
    
        @Override
        public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
            ArrayList<Span> children = new ArrayList<>();
            if (childPointer.startsWith(children, LINED_LINK)){
                parseCommon(childPointer, children);
                if (childPointer.startsWith(children, LINED_DATA)){
                    new ContentParser(SetupLeafStyle.PATH).parse(children, childPointer);
                }
                childPointer.startsWith(children, LINED_END);
                LinedSpanPointLink ans = new LinedSpanPointLink(children);
                return Optional.of(ans);
            }
            return Optional.empty();
        }
        
    };
    
    private final String starter;
    
    private LinedParsePointer(String lineStart){
        starter = lineStart;
    }
    
    DirectoryParser parseCommon(SetupPointer childPointer,
        ArrayList<Span> spanChildren
    ){
        Checker.checkNotNull(childPointer, "childPointer");
        Checker.checkNotNull(spanChildren, "spanChildren");
        DirectoryType idType = DirectoryType.values()[ordinal() + 1];
        DirectoryParser output = new DirectoryParser(idType, LINED_DATA);
        output.parse(spanChildren, childPointer);
        return output;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if (childPointer.startsWith(children, starter)){
            
            parseCommon(childPointer, children);
            
            if (childPointer.startsWith(children, LINED_DATA)){
                new FormatParser(LINED_DATA).parse(children, childPointer);
            }
            childPointer.startsWith(children, LINED_END);
            
            return Optional.of(new LinedSpanPointNote(children));
        }
        return Optional.empty();
    }
}
