package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * SetupParser for {@link FormatSpanCurlyDirectory} and {@link FormatSpanCurlyAgenda} that uses 
 * curly bracket. These are footnote, endnote, cite, and to do.
 */
enum FormatParseAgenda implements SetupParser {
    PARSER;
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if(childPointer.startsWith(children, CURLY_AGENDA)){
            new ContentParser(CURLY_END).parse(children, childPointer);
            
            /// Complete the last steps
            childPointer.startsWith(children, CURLY_END);
            return Optional.of(new FormatSpanAgenda(children));
        }
        return Optional.empty();
    }
}
