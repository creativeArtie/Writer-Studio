package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.CharMatcher;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@link span} for formatted text.
 */
public final class FormatSpanMain extends SpanBranch {
    
    FormatSpanMain(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){ }
    
    public String getWriting(){
        return getScript(false);
    }
    
    public String getAll(){
        return getScript(true);
    }
    
    private String getScript(boolean isAll){
        StringBuilder text = new StringBuilder();
        for (Span span: this){
            if (span instanceof FormatSpanContent){
                FormatSpanContent content = (FormatSpanContent) span;
                if (content.isSpaceBegin()){
                    text.append(" ");
                }
                text.append(content.getParsed());
                if (content.isSpaceEnd()){
                    text.append(" ");
                }
            }
            if (span instanceof FormatSpanLink){
                FormatSpanLink link = (FormatSpanLink) span;
                text.append(link.getText());
            }
            if (isAll && span instanceof FormatSpanAgenda){
                text.append(" ").append(((FormatSpanAgenda)span).getAgenda())
                    .append(" ");
            }
        }
        return CharMatcher.whitespace().collapseFrom(text.toString(), ' ');
    }
    
    //TODO
    //protected DetailUpdater getUpdater(Span edit, String newText){ }

}
