package org.community.jwriter.basic;

import java.util.List;      /// For initialization (enders)

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Creates a text span upto a certain character.
 */
class ContentParser extends BasicParseText{
    
    public ContentParser(List<String> spanEnders){
        super(SetupLeafStyle.TEXT, spanEnders);
    }
    
    public ContentParser(SetupLeafStyle spanStyle, List<String> spanEnders){
        super(spanStyle, spanEnders);
    }
    
    public ContentParser(SetupLeafStyle spanStyle, String ... spanEnders){
        super(spanStyle, spanEnders);
    }
    
    public ContentParser(String ... spanEnders){
        super(SetupLeafStyle.TEXT, spanEnders);
    }
    
    @Override
    protected ContentSpan buildSpan(List<Span> spanChildren, 
        List<String> spanEnders, SetupLeafStyle baseStyle
    ){
        Checker.checkNotNull(spanChildren, "spanChildren");
        Checker.checkNotNull(spanEnders, "spanEnders");
        Checker.checkNotNull(baseStyle, "baseStyle");
        return new ContentSpan(spanChildren, spanEnders, baseStyle);
    }
    
}
