package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanBreak extends LinedSpan {

    LinedSpanBreak(List<Span> spanChildren){
        super(spanChildren);
    } 
}
