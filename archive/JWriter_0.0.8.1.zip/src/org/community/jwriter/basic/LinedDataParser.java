package org.community.jwriter.basic;

import java.util.Optional;

import java.util.ArrayList;

import com.google.common.base.CharMatcher;

import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;
import org.community.jwriter.markup.*;

public enum LinedDataParser implements SetupParser{
    FORMATTED(childPointer -> {
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if (new FormatParser(SetupLeafStyle.DATA).parse(children, childPointer))
        {
            return Optional.of(new LinedDataSpanFormatted(children));
        }
        return Optional.empty();
    }), NUMBER(childPointer -> {
        Checker.checkNotNull(childPointer, "childPointer");
        childPointer.mark();
        ArrayList<Span> children = new ArrayList<>();
        CharMatcher data = CharMatcher.whitespace()
            .and(CharMatcher.isNot(LINED_END.charAt(0)))
            .or(CharMatcher.javaDigit());
        if (childPointer.matches(children, data)){
            if (CharMatcher.javaDigit().countIn(children.get(0).getRaw()) > 0){
                if (! (new ContentParser().parse(children, childPointer))){
                    childPointer.getTo(children, LINED_END);
                    return Optional.of(new LinedDataSpanNumber(children));
                }
            }
        }
        childPointer.rollBack(children);
        return Optional.empty();
    }), TEXT(childPointer -> {
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if (new ContentParser(SetupLeafStyle.DATA)
            .parse(children, childPointer))
        {
            return Optional.of(new LinedDataSpanText(children));
        }
        return Optional.empty();
    }), ERROR (childPointer -> {return Optional.empty();});
    
    private final SetupParser parser;
    
    private LinedDataParser(SetupParser dataParser){
        parser = dataParser;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        return parser.parse(childPointer); /// check inside
    }
}
