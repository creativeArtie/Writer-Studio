package org.community.jwriter.basic;

import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.markup.*;

public enum LinedDataType implements DetailStyle{
    FORMATTED, NUMBER, TEXT;
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_DATA, name());
    }
}
