package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * SetupParser for {@link FormatSpanCurlyDirectory} and {@link FormatSpanCurlyAgenda} that uses 
 * curly bracket. These are footnote, endnote, cite, and to do.
 */
class FormatParseDirectory implements SetupParser {
    
    private final String start;
    private final DirectoryType type;
    private final boolean[] formats;
    
    public static FormatParseDirectory[] getParsers(boolean[] spanFormats){
        Checker.checkArraySize(spanFormats, "spanFormats", FORMAT_TYPES);
        boolean[] formats = Arrays.copyOf(spanFormats, spanFormats.length);
        return new FormatParseDirectory[]{
            new FormatParseDirectory(DirectoryType.FOOTNOTE, formats),
            new FormatParseDirectory(DirectoryType.ENDNOTE, formats),
            new FormatParseDirectory(DirectoryType.NOTE, formats)
        };
    }
    
    private FormatParseDirectory(DirectoryType parseType, boolean[] spanFormats){
        Checker.checkNotNull(parseType, "parseType");
        Checker.checkArraySize(spanFormats, "spanFormats", 4);
        type = parseType;
        switch(parseType){
            case FOOTNOTE:
                start = CURLY_FOOTNOTE;
                break;
            case ENDNOTE:
                start = CURLY_ENDNOTE;
                break;
            case NOTE:
                start = CURLY_CITE;
                break;
            default:
                throw new IllegalArgumentException("DirectoryType not allowed.");
        }
        formats = spanFormats;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if(childPointer.startsWith(children, start)){
            /// CatalogueIdentity for the other Parsers
            DirectoryParser id = new DirectoryParser(type, CURLY_END);
            id.parse(children, childPointer);
            
            /// Complete the last steps
            childPointer.startsWith(children, CURLY_END);
            
            FormatSpanDirectory span = new FormatSpanDirectory(children, 
                formats, type);
            
            return Optional.of(span);
        }
        return Optional.empty();
    }
}
