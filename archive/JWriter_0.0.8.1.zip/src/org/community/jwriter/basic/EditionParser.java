package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Creates a Span to show the edition of an manuscript section.
 */
enum EditionParser implements SetupParser{
    STUB, DRAFT, FINAL, OTHER(){
        @Override
        public Optional<SpanBranch> parse(SetupPointer childPointer){
            Checker.checkNotNull(childPointer, "childPointer");
            ArrayList<Span> children = new ArrayList<>();
            if (childPointer.startsWith(children, EDITION_BEGIN)){
                return finalize(children, childPointer);
            }
            return Optional.empty();
        }
    };
    
    /**
     * Helper method to parse all Spans
     */
    static boolean parseAll(ArrayList<Span> spanChildren, 
        SetupPointer childPointer)
    {
        Checker.checkNotNull(spanChildren, "spanChildren");
        Checker.checkNotNull(childPointer, "childPointer");
        for(EditionParser parser: values()){
            if(parser.parse(spanChildren, childPointer)){
                return true;
            }
        }
        return false;
    }
    
    protected Optional<SpanBranch> finalize(ArrayList<Span> spanChildren, 
        SetupPointer childPointer)
    {
        Checker.checkNotNull(spanChildren, "spanChildren");
        Checker.checkNotNull(childPointer, "childPointer");
        /// Add the meta text, if any found
        new ContentParser().parse(spanChildren, childPointer);
        
        return Optional.of(new EditionSpan(spanChildren));
        
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if (childPointer.startsWith(children, EDITION_BEGIN + name())){
            return finalize(children, childPointer);
        }
        return Optional.empty();
    }
}
