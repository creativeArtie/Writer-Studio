package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;


/**
 * A {@link Span} for stating the current status of a section with a heading or
 * an outline.
 */
public class EditionSpan extends SpanBranch{
    
    EditionSpan(List<Span> children){
        super(children);
    }
    
    public EditionType getEdition(){
        Span first = get(0);
        if (first instanceof SpanLeaf){
            String text = first.getRaw();
            if (text.length() == 1){
                return EditionType.OTHER;
            }
            return EditionType.valueOf(text.substring(1));
        } 
        return EditionType.NONE;
    }
    
    public Optional<ContentSpan> getDetailSpan(){
        return spanAtLast(ContentSpan.class);
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return new DetailStyle[]{getEdition()};
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(getEdition());
    }
}
