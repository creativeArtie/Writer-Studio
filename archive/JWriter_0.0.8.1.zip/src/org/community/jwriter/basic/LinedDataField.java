package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.base.CaseFormat;

import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;
import org.community.jwriter.markup.*;

public enum LinedDataField implements DetailStyle{
    /* //TODO add in future version (for automatic LinedDataField Style)
    AUTHOR, EDITOR, TRANSLATOR, ARTICLE, TITLE, EDITION, PUBLISH_HOUSE, 
    PUBLISH_YEAR, MEDIA, ACCESS_LOCATION, ACCESS_DATE, */
    PAGES(LinedDataParser.NUMBER),
    
    SOURCE(LinedDataParser.FORMATTED), IN_TEXT(LinedDataParser.TEXT), 
    FOOTNOTE(LinedDataParser.TEXT), 
    
    ERROR(LinedDataParser.ERROR);
    
    private final SetupParser parser;
    
    private LinedDataField(SetupParser dataParser){
        parser = dataParser;
    }
    
    String getCode(){
        return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, name());
    }
    
    static LinedDataField getField(SetupPointer childPointer, 
        ArrayList<Span> spanChildren
    ){
        Checker.checkNotNull(childPointer, "childPointer");
        Checker.checkNotNull(spanChildren, "spanChildren");
        for (LinedDataField type: values()){
            if (childPointer.trimStartsWith(spanChildren, SetupLeafStyle.FIELD, 
                type.getCode())
            ){
                return type;
            }
        }
        new ContentParser(SetupLeafStyle.FIELD, LINED_DATA)
            .parse(spanChildren, childPointer);
        return LinedDataField.ERROR;
    }
    
    static LinedDataField getField(String rawText){
        Checker.checkNotNull(rawText, "rawText");
        String trimed = rawText.trim();
        String name = CaseFormat.LOWER_HYPHEN
            .to(CaseFormat.UPPER_UNDERSCORE, trimed);
        try {
            return valueOf(name);
        } catch (IllegalArgumentException ex){
            return LinedDataField.ERROR;
        }
    }
    
    boolean parse(List<Span> spanChildren, 
            SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        Checker.checkNotNull(spanChildren, "spanChildren");
        return parser.parse(spanChildren, childPointer);
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_FIELD, name());
    }
}
