package org.community.jwriter.basic;

import java.util.List;
import java.util.ResourceBundle;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

public abstract class LinedSpan extends SpanBranch {
    
    LinedSpan(List<Span> spanChildren){
        super(spanChildren);
    }
    
    private LinedType type;
    
    public LinedType getType(){
        if (type == null){
            type = LinedType.findType(get(0).getRaw());
        }
        return type;
    }
    
    @Override
    public String toString(){
        return getType() + super.toString();
    }
    
    public String getLineAbbr(ResourceBundle resourceBundle){
        Checker.checkNotNull(resourceBundle, "resrouceBundle");
        return resourceBundle.getString(getType().getStyleClass());
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return new DetailStyle[]{getType()};
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(getType());
    }
    
    @Override
    protected DetailUpdater getUpdater(List<Span> editedSpan, String newText){
        Checker.checkNotNull(newText, "newText");
        if (getType() == LinedType.findType(newText)){
            SetupParser parser = getType().getParser();
            int found = search(newText, CHAR_ESCAPE, LINED_END);
            if (found == -1){
                return DetailUpdater.mergeNext(parser);
            } else if (found == newText.length()){
                return DetailUpdater.replace(parser);
            }
        }
        return DetailUpdater.unable();
    }
}
