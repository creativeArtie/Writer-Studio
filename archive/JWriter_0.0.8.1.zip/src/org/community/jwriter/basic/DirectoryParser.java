package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.Optional;  /// For parsing purposes

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Create a Span for {@link CatalogueIdentity}.
 */
final class DirectoryParser implements SetupParser{
    /// Shows how to end a text
    private final ContentParser idParser;
    
    /// Adds a root category to differentiate footnote, links, etc
    private final Optional<DirectoryType> type;
        
    DirectoryParser(DirectoryType idType, String ... spanEnders){
        type = Optional.ofNullable(idType);
        Checker.checkNotNull(spanEnders, "spanEnders");
        
        /// adding DIRECTORY_CATEGORY into spanEnders by copying into new array
        String[] init = new String[spanEnders.length + 1];
        System.arraycopy(spanEnders, 0, init, 0, spanEnders.length);
        init[spanEnders.length] = DIRECTORY_CATEGORY;
        idParser = new ContentParser(SetupLeafStyle.ID, init);
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer pointer){
        /// Setup for DirectorySpan
        ArrayList<Span> children = new ArrayList<>();
        
        /// Extract category & id
        boolean more;
        do {
            idParser.parse(children, pointer); 
            
            /// last current is not an id but a category
            more = pointer.startsWith(children, DIRECTORY_CATEGORY);
        } while (more);
        
        /// Create span if there are Span extracted
        if (children.size() > 0) {
            DirectorySpan ans = new DirectorySpan(children, type);
            return Optional.of(ans);
        }
        return Optional.empty();
    }
}
