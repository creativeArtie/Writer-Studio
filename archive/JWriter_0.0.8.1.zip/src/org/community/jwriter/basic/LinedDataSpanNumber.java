package org.community.jwriter.basic;

import java.util.List;      /// For initialization (children)

import com.google.common.base.CharMatcher;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedDataSpanNumber extends LinedDataSpan<Integer>{
    
    @Override
    public LinedDataSpanNumber cast(){
        return this;
    }
    
    @Override
    public Integer getDataSpan(){
        String raw = CharMatcher.whitespace().removeFrom(get(0).getRaw());
        try{
            return Integer.parseInt(raw);
        } catch (NumberFormatException ex){
            throw new IllegalStateException("No integer found.", ex);
        }
    }
    
    LinedDataSpanNumber(List<Span> spanChildren){
        super(spanChildren, LinedDataType.NUMBER);
    }
}
