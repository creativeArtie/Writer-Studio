package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanNote extends LinedSpan{
    
    public LinedSpanNote(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public Optional<FormatSpanMain> getFormattedSpan(){
        return spanFromLast(FormatSpanMain.class);
    }
    
    public boolean hasDirectory(){
        return getIdSpan().isPresent();
    }
    
    Optional<DirectorySpan> getIdSpan(){
        return spanFromFirst(DirectorySpan.class);
    }
    
    @Override
    protected DetailUpdater getUpdater(List<Span> editedSpan, String newText){
        return DetailUpdater.unable();
    }
}
