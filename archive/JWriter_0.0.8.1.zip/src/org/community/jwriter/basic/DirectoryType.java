package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * Used by {@link DirectorySpan} to show main categories.
 */
public enum DirectoryType implements DetailStyle{
    /// Enum value order mandated by ListText and LinedParsePointer
    NOTE(TYPE_NOTE), FOOTNOTE(TYPE_FOOTNOTE), ENDNOTE(TYPE_ENDNOTE), 
    LINK(TYPE_LINK);
    
    private final String cat;
    
    private DirectoryType(String category){
        cat = category;
    }
    
    public String getCategory(){
        return cat;
    }
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_CATEGORY, name());
    }
}
