package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import java.util.concurrent.ExecutionException;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class MainSpanSection extends MainSpan {
    
    private Cache<String, Optional<LinedSpanSection>> lines;
    private Cache<String, Optional<MainSpanSection>> sections;
    
    MainSpanSection (List<Span> spanChildren){
        super(spanChildren);
        lines = CacheBuilder.newBuilder().build();
        sections = CacheBuilder.newBuilder().build();
    }
    
    @Override
    protected void invalidateAll(){
        lines.invalidateAll();
        sections.invalidateAll();
    }
    
    private Optional<MainSpanSection> getNextSection(){
        try {
            return sections.get("getNextSection", () -> getSpanSection(false));
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    private Optional<MainSpanSection> getLastSection(){
        try {
            return sections.get("getLastSection", () -> getSpanSection(true));
         } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    private Optional<MainSpanSection> getSpanSection(boolean toLast){
        Document doc = getDocument();
        int idx = doc.indexOf(this);
        SpanBranch siblings;
        do{
            idx += toLast? -1: 1;
            if (idx < 0 || idx >= doc.size()){
                return Optional.empty();
            }
            siblings = doc.get(idx);
        } while(! (siblings instanceof MainSpanSection));
        return Optional.of((MainSpanSection) siblings);
    }
    
    public Optional<LinedSpanSection> getSectionHead(){
        try {
            return lines.get("getSectionHead", () -> {
                return spanAtFirst(LinedSpanSection.class);
            });
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public Optional<MainSpanSection> getLastPart(){
        try {
            return sections.get("getLastPart", () -> {
                if (get(0) instanceof LinedSpanSection){
                    return Optional.empty();
                }
                return getLastSection();
            });
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public Optional<MainSpanSection> getNextPart(){
        try {
            return sections.get("getNextPart", () -> {
                Optional<MainSpanSection> last = getNextSection();
                if (! last.isPresent()){
                    return Optional.empty();
                }
                MainSpanSection span = last.get();
                if (span.get(0) instanceof LinedSpanSection){
                    return Optional.empty();
                }
                return last;
            });
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public Optional<LinedSpanSection> getHeading(){
        try {
            return lines.get("getHeading", () -> {
                Optional<LinedSpanSection> first = spanAtFirst(LinedSpanSection.class);
                if(first.isPresent() && first.get().getType() == LinedType.HEADING){
                    return first;
                }
                Optional<MainSpanSection> last = getLastSection();
                if (last.isPresent()){
                    return last.get().getHeading();
                }
                return Optional.empty();
            });
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public Optional<LinedSpanSection> getOutline(){
        try {
            return lines.get("getOutline", () -> {
                Optional<LinedSpanSection> first = spanAtFirst(LinedSpanSection.class);
                if(first.isPresent()){
                    LinedSpanSection level = first.get();
                    if (level.getType() == LinedType.HEADING){
                        return Optional.empty();
                    }
                    assert level.getType() == LinedType.OUTLINE;
                    return first;
                }
                Optional<MainSpanSection> last = getLastSection();
                if (last.isPresent()){
                    return last.get().getOutline();
                }
                return Optional.empty();
            });
        } catch (ExecutionException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("SECTION:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.MAIN_SECTION);
    }
}
