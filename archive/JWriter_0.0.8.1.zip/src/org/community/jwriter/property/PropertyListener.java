package org.community.jwriter.property;

import java.util.ArrayList;

public interface PropertyListener<T>{
    public void update(Property<T> property, T value);
}
