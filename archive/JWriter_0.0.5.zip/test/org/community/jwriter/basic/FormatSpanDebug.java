package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatSpanDebug {
    
    public static final SpanExpectHelper contentHelp(boolean isBold, 
        boolean isItalics, boolean isUnderline, boolean isCoded, 
        String text
    ){
        return span -> {
            assertEquals(
                "Wrong class gotten for "+ span + ": " + span.getClass(), 
                FormatSpanContent.class, span.getClass()
            );
                
            FormatSpanContent test = (FormatSpanContent) span;
            assertEquals("Wrong text for " + span, text, test.getText());
            formatHelp(isBold, isItalics, isUnderline, isCoded).test(span);
        };
    }
    public static final SpanExpectHelper formatHelp(boolean isBold, 
        boolean isItalics, boolean isUnderline, boolean isCoded
    ){
        return span ->{
            assertTrue(
                span + " is not a sub class of FormatSpan: " + span.getClass(), 
                span instanceof FormatSpan
            );
                
            FormatSpan test = (FormatSpan) span;
            
            assertEquals("Wrong bold format for " + span, isBold, 
                test.isBold());
            assertEquals("Wrong italics format for " + span, isItalics, 
                test.isItalics());
            assertEquals("Wrong underline format for " + span, isUnderline, 
                test.isUnderline());
            assertEquals("Wrong coded format for " + span, isCoded, 
                test.isCoded());
        };
    }
    
    private static final InputParser[] parsers = new InputParser[]{
        new FormatParser()};
    
    @Test
    public void basic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(contentHelp(false, false, false, false, "abc"));
        child.addChild("abc");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void complete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect span;
        span = new SpanExpect(contentHelp(false, false, false, false, "Begin\\"));
        span.addChild("Begin", "");
        SpanExpect child = new SpanExpect();
        child.addChild("\\", "escape-token");
        child.addChild("\\", "escape");
        span.addChild(child);
        parent.addChild(span);
        
        parent.addChild("*", "token");
        span = new SpanExpect(contentHelp(false, true, false, false, "Coral"));
        span.addChild("Coral", "italics");
        parent.addChild(span);
        
        parent.addChild("**", "token");
        
        span = new SpanExpect(contentHelp(true, true, false, false, "s"));
        span.addChild(" s", "bold-italics");
        parent.addChild(span);
        
        parent.addChild("_", "token");
        
        span = new SpanExpect(contentHelp(true, true, true, false, "Hi"));
        span.addChild(" Hi", "bold-italics-underline");
        parent.addChild(span);
        
        parent.addChild("`", "token");
        
        span = new SpanExpect(contentHelp(true, true, true, true, "Joy"));
        span.addChild("Joy", "bold-italics-underline-coded");
        parent.addChild(span);
        
        parent.addChild("`", "token");
        parent.addChild("**", "token");
        parent.addChild("_", "token");
        
        span = new SpanExpect();
        span.addChild("{@", "curly-note-italics-token");
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", "curly-note-italics-id-error");
        span.addChild(id);
        span.addChild("}", "curly-note-italics-token");
        parent.addChild(span);
        
        span = new SpanExpect();
        span.addChild("<@", "link-ref-italics-token");
        id = new SpanExpect();
        id.addGrandchild("abc", "link-ref-italics-id-error");
        span.addChild(id);
        span.addChild(">", "link-ref-italics-token");
        parent.addChild(span);
        
        span = new SpanExpect();
        span.addChild("<", "link-direct-italics-token");
        span.addGrandchild("google.com", "link-direct-italics-path");
        span.addChild("|", "link-direct-italics-token");
        span.addGrandchild("Google", "link-direct-italics");
        span.addChild(">", "link-direct-italics-token");
        parent.addChild(span);
        
        span = new SpanExpect();
        span.addChild("{!", "agenda-token");
        span.addGrandchild("todo text", "agenda");
        span.addChild("}", "agenda-token");
        parent.addChild(span);
        
        span = new SpanExpect(contentHelp(false, true, false, false, "see"));
        span.addChild("see", "italics");
        parent.addChild(span);
        
        parent.addChild("*", "token");
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void bold(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(contentHelp(false, false, false, false, "or"));
        child.addChild("or");/// + 2
        parent.addChild(child);
        
        parent.addChild("**"); /// = 4
        
        child = new SpanExpect(contentHelp(true, false, false, false, "an"));
        child.addChild("an"); /// = 6
        parent.addChild(child);
        
        parent.addChild("**"); /// = 8
        
        child = new SpanExpect(contentHelp(false, false, false, false, "ge"));
        child.addChild("ge");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void italics(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(contentHelp(false, false, false, false, "g"));
        child.addChild("g"); /// = 1 
        parent.addChild(child);
        
        parent.addChild("*"); /// = 2
        
        child = new SpanExpect(contentHelp(false, true, false, false, "ee"));
        child.addChild("ee"); /// = 4
        parent.addChild(child);
        
        parent.addChild("*"); /// = 5
        
        child = new SpanExpect(contentHelp(false, false, false, false, "n"));
        child.addChild("n");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void underlineCoded(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        parent.addChild("_"); /// = 1
        
        SpanExpect child;
        child  = new SpanExpect(contentHelp(false, false, true, false, "g"));
        child.addChild("g"); /// = 2
        parent.addChild(child);
        
        parent.addChild("_"); /// = 3
        
        child = new SpanExpect(contentHelp(false, false, false, false, "e_e"));
        child.addChildren("e", "\\_", "e"); /// e4\\5_6e =7
        parent.addChild(child);
        
        parent.addChild("`"); /// =8
        
        child = new SpanExpect(contentHelp(false, false, false, true, "dd"));
        child.addChild("dd");
        parent.addChild(child);
        
        parent.addChild("_");
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void startedUnderline(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        parent.addChild("_");
        
        SpanExpect child;
        child = new SpanExpect(contentHelp(false, false, true, false, "abc"));
        child.addChild("abc");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void withEndnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        parent.addChild("_");
        
        SpanExpect child;
        child = new SpanExpect(contentHelp(false, false, true, false, "abc")); 
        child.addChild("abc");
        parent.addChild(child);
        
        parent.addChild("{^see}");
        
        child = new SpanExpect(contentHelp(false, false, true, false, "pee"));
        child.addChild("pee");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void empty(){
        SpanExpect doc = new SpanExpect();
        doc.testAll(parsers);
    }
}
