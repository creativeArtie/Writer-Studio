package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Optional;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

import org.community.jwriter.markup.*;

public abstract class MainTest {
    
    public static final Document build(String doc){
        return new Document(doc, new MainParser());
    }
    
    protected static final InputParser[] parsers(){
        return new InputParser[]{new MainParser()};
    }
    
    static class Helper{
        private LinedType type;
        private String[] doc;
        
        private Helper(LinedType t, String[] d){
            type = t;
            doc = d;
        }
        
        private String getDoc(){
            StringBuilder builder = new StringBuilder();
            for(String d: doc){
                builder.append(d);
            }
            return builder.toString();
        }
    }
    
    static void addLine(SpanExpect part, ArrayList<Helper> lines){
        for(Helper input: lines){
            SpanExpect line = new SpanExpect();
            line.addChildren(input.doc);
            part.addChild(line);
        }
    }
    
    public static void addLine(ArrayList<Helper> lines, LinedType type, 
            String ... text){
        lines.add(new Helper(type, text));
    }
    
    public static final SpanExpectHelper sectionHelp(List<Helper> lines){
        return span ->{
            assertEquals("Wrong class.", MainSpanSection.class, span.getClass());
            commonHelp(lines, (MainSpanSection) span);
        };
    }
    
    public static void addLine(ArrayList<Helper> lines, 
            TreeMap<LinedCite, String[]> sources, LinedCite type,
            String ... data){
        for(String d: data){
            addLine(lines, LinedType.SOURCE, "!>", type.getCode(), ":", d, 
                "\n");
        }
        sources.put(type, data);
    }
    
    public static final DirectoryId noteID(String id){
        ArrayList<String> cat = new ArrayList<>();
        cat.add(DirectoryType.NOTE.getCategory());
        return new DirectoryId(cat, id);
    }
    
    public static final SpanExpectHelper noteHelp(List<Helper> lines,
            Map<LinedCite, String[]> sources, DirectoryId id){
        return span ->{
            assertEquals("Wrong class.", MainSpanNote.class, span.getClass());
            MainSpanNote test = (MainSpanNote) span;
            commonHelp(lines, test);
            if (id == null){
                assertFalse("Id is found: ", test.getId().isPresent());
            } else {
                assertTrue("Id is not found: ", test.getId().isPresent());
                assertEquals("Wrong id.", id, test.getId().get());
            }
            for(LinedCite field: LinedCite.values()){
                if (sources.containsKey(field)){
                    List<LinedCiteData<?>> data = test.getSources().get(field);
                    String[] testRaw = new String[data.size()];
                    int i = 0;
                    for(LinedCiteData datum: data){
                        testRaw[i] = datum.getRaw();
                        i++;
                    }
                    assertArrayEquals("Wrong sources data for " + field, 
                        sources.get(field), testRaw); 
                } else {
                    assertTrue("Data fround for " + field, 
                    test.getSources().get(field).isEmpty());
                }
            }
        };
    }
    
    private static final void commonHelp(List<Helper> lines, SpanBranch test){
        assertEquals("Wrong size.", lines.size(), test.size());
        int i = 0;
        for(Helper line: lines){
            Span child = test.get(i);
            assertTrue("Not a lined span: " + child, child instanceof LinedSpan);
            LinedSpan lined = (LinedSpan) child;
            assertEquals("Wrong LinedType.", line.type, lined.getType());
            assertEquals("Wrong text.", line.getDoc(), lined.getRaw());
            i++;
        }
    }
        
    
    public static final void sectionLinks(Span test){
        sectionLinks(test, null, null, null);
    }
    
    public static final void sectionLinks(Span test, Span heading, Span outline,
            Span last){
        MainSpanSection section = (MainSpanSection)test;
        if (heading == null){
            assertFalse("Heading is found:" + test, 
                section.getHeading().isPresent());
        } else {
            Optional<LinedSpanLevel> head = section.getHeading();
            assertTrue("Heading is not found:" + test, head.isPresent());
            assertSame("Heading is not same:" + test, heading, head.get());
        }
        
        if (outline == null){
            assertFalse("Outline is found:" + test, 
                section.getOutline().isPresent());
        } else {
            Optional<LinedSpanLevel> out = section.getOutline();
            assertTrue("Outline is not found:" + test, out.isPresent());
            assertSame("Outline is not same:" + test, outline, out.get());
        }
        if (last == null){
            assertFalse("Last is found.", section.getLast().isPresent());
        } else {

            Optional<MainSpanSection> sec = section.getLast();
            assertTrue("Last is not found.", sec.isPresent());
            assertSame("Last is not same.", last, sec.get());
        }
    }
}
