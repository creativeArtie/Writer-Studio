package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class SupplementStatusDebug{
    
    private static Document createDoc(String raw){
        return new Document(raw, new MainParser());
    }
    
    private static Span getFootnoteRef(Document doc){
        SpanBranch section   = (SpanBranch) doc.get(0);
        SpanBranch paragraph = (SpanBranch) section.get(0);
        SpanBranch format    = (SpanBranch) paragraph.get(0);
        SpanBranch footnote  = (SpanBranch) format.get(0);
        SpanBranch id        = (SpanBranch) footnote.get(1);
        SpanBranch content   = (SpanBranch) id.get(0);
        return content.get(0);
    }
    
    private static Span getFootnoteID(Document doc, int which){
        SpanBranch section = (SpanBranch) doc.get(0);
        SpanBranch line    = (SpanBranch) section.get(which);
        SpanBranch id      = (SpanBranch) line.get(1);
        SpanBranch content = (SpanBranch) id.get(0);
        return content.get(0);
    }
    
    private static void check(String expect, Span test){
        assertTrue(test.toString(), test instanceof SpanLeaf);
        assertEquals("Wrong style: " + test, expect, ((SpanLeaf)test).getStyle());
    }
    
    @Test
    public void unused(){
        Document doc = createDoc("!^abc:unused");
        check("footnote-id-warning", getFootnoteID(doc, 0));
    }
    
    @Test
    public void notFound(){
        Document doc = createDoc("{^abc}");
        check("curly-foot-id-error", getFootnoteRef(doc));
    }
    
    @Test
    public void multiple(){
        Document doc = createDoc("!^abc:first\n!^abc:second");
        check("footnote-id-warning", getFootnoteID(doc, 0));
        check("footnote-id-warning", getFootnoteID(doc, 1));
    }
    
    @Test
    public void none(){
        Document doc = createDoc("{^abc}\n!^abc:inUsed\n");
        check("curly-foot-id", getFootnoteRef(doc));
        check("footnote-id", getFootnoteID(doc, 1));
    }
    
}
