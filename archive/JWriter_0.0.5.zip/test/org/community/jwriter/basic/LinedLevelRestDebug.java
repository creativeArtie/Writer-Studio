package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelRestDebug extends LinedLevelTest{
    
    @Test
    public void heading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("W_Under_", LinedType.HEADING, 
            3, EditionType.OTHER, new String[]{"link", "sub"}, "id"));

        line.addChild("===", "heading-token");
        line.addChild("@", "heading-token");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("sub", "heading-id-warning");
        id.addChild("-", "heading-id-warning-token");
        id.addGrandchild("id", "heading-id-warning");
        line.addChild(id);
        
        line.addChild(":", "heading-token");
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("W", "heading");
        format.addChild("_", "heading-token");
        format.addGrandchild("Under", "heading-underline");
        format.addChild("_", "heading-token");
        line.addChild(format);
        
        SpanExpect status = new SpanExpect();
        status.addChild("#", "heading-edition-token");
        status.addGrandchild("abc", "heading-edition");
        line.addChild(status);
        
        line.addChild("\n", "heading-token");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void outline(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Text abc", LinedType.OUTLINE, 
            1, EditionType.DRAFT, new String[]{"link"}, "id"));

        line.addChild("!#", "outline-token");
        line.addChild("@", "outline-token");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("id", "outline-id-warning");
        line.addChild(id);
        
        line.addChild(":", "outline-token");
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("Text abc", "outline");
        line.addChild(format);
        
        SpanExpect status = new SpanExpect();
        status.addChild("#DRAFT", "outline-edition-draft-token");
        status.addGrandchild("abc", "outline-edition-draft");
        line.addChild(status);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void quote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.QUOTE, 2));
        line.addChild(">>", "quote-token");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc", "quote");
        line.addChild(text);
        
        line.addChild("\n", "quote-token");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void numbered(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.NUMBERED, 5));
        line.addChild("\t\t\t\t#", "numbered-token");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc", "numbered");
        line.addChild(text);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptyBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("", LinedType.BULLET, 1));
        line.addChild("-", "bullet-token");
        line.addChild("\n", "bullet-token");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void fullBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.BULLET, 1));
        line.addChild("-",  "bullet-token");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc",  "bullet");
        line.addChild(text);
        
        line.addChild("\n", "bullet-token");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("{@hello}", 
            LinedType.BULLET, 1));
        line.addChildren( "-", "{@hello}");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("aaa\\\nddd", 
            LinedType.BULLET, 6));
        line.addChildren( "\t\t\t\t\t-", "aaa\\\nddd");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
