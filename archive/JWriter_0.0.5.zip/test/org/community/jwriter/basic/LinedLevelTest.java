package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelTest {
    final InputParser[] parsers = LinedParseLevel.values();
    
    public static final SpanExpectHelper simpleHelp(String text,  LinedType type,
            int level){
        return span ->{
            assertEquals(LinedSpanLevel.class, span.getClass());
            testBasic((LinedSpanLevel) span, text, type, level);
        };
    }
    
    public static final SpanExpectHelper headHelp(String text, LinedType type, 
            int level, EditionType status, String[] category, String id){
        return span ->{
            assertEquals(LinedSpanSection.class, span.getClass());
            LinedSpanSection test = (LinedSpanSection) span;
            testBasic(test, text, type, level);
            assertEquals("Wrong Status.", status, test.getState());
            assertArrayEquals("Wrong category.", category, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
        };
    }

    private static void testBasic(LinedSpanLevel test, String text, LinedType type, 
            int level){
        assertEquals("Wrong text.", text, test.getFormatted().getRaw());
        assertEquals("Wrong type.", type, test.getType());
        assertEquals("Wrong level.", level, test.getLevel()); 
    }
    
}
