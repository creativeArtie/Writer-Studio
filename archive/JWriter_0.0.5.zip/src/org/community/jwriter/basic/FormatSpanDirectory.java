package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@linkplain FormatSpanCurly} for id referance. This has a span where it is
 * reference to
 */
public final class FormatSpanDirectory extends FormatSpan 
        implements DirectoryHolder {
    private final DirectoryType type;
    private final Optional<DirectoryId> refSpan;
    
    FormatSpanDirectory(List<Span> children, boolean[] formats, 
        Optional<DirectorySpan> refData, DirectoryType curlyType
    ){
        super(children, formats);
        type = curlyType;
        refSpan = DirectorySpan.getDirectoryHelper(refData);
    }
    
    public DirectoryType getType(){
        return type;
    }
    
    @Override
    protected String getStyle(String style){
        return Span.appendStyle(Span.appendStyle(type.getStyle(), this), style);
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return refSpan;
    }
    
    public Optional<Span> getSpan(){
        return getTarget();
    }
}
