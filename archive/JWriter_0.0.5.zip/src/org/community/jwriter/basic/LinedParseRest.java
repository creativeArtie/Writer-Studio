package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseRest implements InputParser<LinedSpan> {
    NOTE(pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.startsWith(children, LINED_NOTE)){
            Optional<DirectorySpan> id = Optional.empty();
            if (pointer.trimStartsWith(children, DIRECTORY_BEGIN)){
                id = new DirectoryParser(DirectoryType.NOTE, DIRECTORY_END).parse(children, pointer);
                pointer.startsWith(children, DIRECTORY_END);
            }
            Optional<FormatSpanMain> text = new FormatParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            LinedSpanNote ans = new LinedSpanNote(children, id, text);
            return Optional.of(ans);
        }
        return Optional.empty();
    }),
    AGENDA(pointer ->{
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.startsWith(children, LINED_AGENDA)){
            Optional<ContentSpan> reason = new ContentParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanAgenda(children, 
                LinedType.AGENDA, reason));
        }
        return Optional.empty();
    }), 
    BREAK(pointer ->{
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.startsWith(children, LINED_BREAK)){
            return Optional.of(new LinedSpan(children, LinedType.BREAK));
        }
        return Optional.empty();
    }),
    PARAGRAPH(pointer ->{
        if (pointer.hasNext()){
            ArrayList<Span> children = new ArrayList<>();
            Optional<FormatSpanMain> text = new FormatParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanParagraph(children, text));
        }
        return Optional.empty();
    });
    
    static InputParser<?>[] getSectionList(){
        return new LinedParseRest[]{AGENDA, BREAK, PARAGRAPH};
    }
    
    static InputParser<?>[] getNoteList(){
        return new LinedParseRest[]{NOTE};
    }
    
    private final InputParser<LinedSpan> parser;
    
    private LinedParseRest(InputParser<LinedSpan> p){
        parser = p;
    }
    
    public Optional<LinedSpan> parse(InputPointer pointer){
        return parser.parse(pointer);
    }
}
