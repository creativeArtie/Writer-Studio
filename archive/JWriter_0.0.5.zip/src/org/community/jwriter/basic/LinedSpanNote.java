package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanNote extends LinedSpan implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private final FormatSpanMain text;
    
    public LinedSpanNote(List<Span> children, Optional<DirectorySpan> idSpan, 
            Optional<FormatSpanMain> textSpan){
        super(children, LinedType.NOTE);
        id = DirectorySpan.getDirectoryHelper(idSpan);
        text = textSpan.isPresent()? textSpan.get(): new FormatSpanMain(this);
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
    
    public FormatSpanMain getFormatted(){
        return text;
    }
    
    public boolean hasDirectorySpan(){
        return id.isPresent();
    }
}
