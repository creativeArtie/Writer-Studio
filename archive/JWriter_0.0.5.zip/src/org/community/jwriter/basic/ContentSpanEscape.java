package org.community.jwriter.basic;

import java.util.List; /// For initialization (children)

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Created from {@link ContentParser}. Used only in {@link ContentSpan}
 */
public class ContentSpanEscape extends SpanBranch{
    private String text;
    
    ContentSpanEscape(List<Span> children){
        super(children);
        text = children.size() == 2? children.get(1).getRaw(): "";
    }
    
    @Override
    public String getStyle(){
        return Span.appendStyle(this, STYLE_ESCAPE);
    }
    
    public String getEscape(){
        return text;
    }
}
