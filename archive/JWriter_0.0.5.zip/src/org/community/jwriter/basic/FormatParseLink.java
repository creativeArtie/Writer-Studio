package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * InputParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
abstract class FormatParseLink<T extends FormatSpanLink> implements InputParser<T> {
    
    public static FormatParseLink<?>[] getParsers(boolean[] spanFormats){
        boolean[] formats = Arrays.copyOf(spanFormats, spanFormats.length);
        return new FormatParseLink<?>[]{
            new FormatParseLinkRef(formats),
            new FormatParseLinkDirect(formats)
        };
    }
    
    private String start;
    private boolean[] formats;
    
    FormatParseLink(String s, boolean[] spanFormats){
        start = s;
        formats = spanFormats;
    }
    
    protected boolean[] getFormats(){
        return formats;
    }
    
    @Override
    public Optional<T> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, start)){
            return parseFinish(children, pointer);
        }
        return Optional.empty();
    }
    
    protected abstract Optional<T> parseFinish(ArrayList<Span> children, 
        InputPointer pointer);
    
    protected Optional<ContentSpan> parseRest(ArrayList<Span> children, 
            InputPointer pointer){
        Optional<ContentSpan> ans = Optional.empty();
        
        /// Create display text if any
        if (pointer.startsWith(children, LINK_TEXT)){
            /// Add the text itself
            ans = new ContentParser(LINK_END).parse(children, pointer);
        }
        
        /// Add the ">"
        pointer.startsWith(children, LINK_END);
        
        return ans;
    }
}
