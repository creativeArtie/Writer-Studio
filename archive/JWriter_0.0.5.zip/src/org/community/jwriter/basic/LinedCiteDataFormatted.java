package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedCiteDataFormatted extends LinedCiteData<FormatSpanMain>{
    
    public static final InputParser<LinedCiteDataFormatted> PARSER = pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        Optional<FormatSpanMain> data = new FormatParser()
            .parse(children, pointer);
        if (data.isPresent()){
            return Optional.of(new LinedCiteDataFormatted(children, data.get()));
        }
        return Optional.empty();
    };
    
    private FormatSpanMain data;
    
    public LinedCiteDataFormatted cast(){
        return this;
    }
    
    public boolean isReady(){
        return true;
    }
    
    @Override
    public FormatSpanMain get(){
        return data;
    }
    
    protected LinedCiteDataFormatted(List<Span> children, FormatSpanMain span){
        super(children);
        data = span;
    }
}
