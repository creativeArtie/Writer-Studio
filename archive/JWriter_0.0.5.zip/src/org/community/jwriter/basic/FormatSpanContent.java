package org.community.jwriter.basic;

import java.util.List;
import java.util.ArrayList;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link ContentSpan} with format for {@link FormatSpanMain}. 
 */
public class FormatSpanContent extends FormatSpan implements BasicText{
    
    
    FormatSpanContent(ArrayList<Span> children, boolean[] spanFormats){
        super(children, spanFormats);
    }
    
    protected String getStyle(String style){
        return Span.appendStyle(this, style);
    }
}
