package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@linkplain FormatSpanCurly} for to do text. It will warn user when 
 * exporting while there are these {@link Span spans} still exists.
 */
public final class FormatSpanAgenda extends SpanBranch {

    private final String agenda;
    
    FormatSpanAgenda(List<Span> children, Optional<ContentSpan> agendaText){
        super(children);
        agenda = agendaText.isPresent()? agendaText.get().getText() : "";
    }
    
    public String getAgenda(){
        return agenda;
    }
    
    @Override
    public String getStyle(){
        return Span.appendStyle(this, STYLE_AGENDA);
    }

}
