package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ArrayListMultimap;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class MainSpanNote extends MainSpan implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private ArrayListMultimap<LinedCite, LinedCiteData<?>> sources;
    
    MainSpanNote(List<Span> children, Optional<DirectoryId> idSpan, 
            List<LinedSpanCite> sourceFields){
        super(children);
        id = idSpan;
        sources = ArrayListMultimap.create();
        for (LinedSpanCite source: sourceFields){
            if (source.getField() != LinedCite.ERROR){
                sources.put(source.getField(), source.getData().get());
            }
        }
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
    
    public ImmutableListMultimap<LinedCite, LinedCiteData<?>> getSources(){
        return ImmutableListMultimap.copyOf(sources);
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
}
