package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanParagraph extends LinedSpan {
    private final FormatSpanMain text;

    LinedSpanParagraph(List<Span> children, Optional<FormatSpanMain> textSpan){
        super(children, LinedType.PARAGRAPH);
        text = textSpan.isPresent()? textSpan.get(): new FormatSpanMain(this);
    }
    
    public FormatSpanMain getFormatted(){
        return text;
    }
}
