package org.community.jwriter.basic;

import com.google.common.base.CaseFormat;
import static org.community.jwriter.basic.AtomicTerm.*;

public enum LinedType{
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET, HYPERLINK, FOOTNOTE, ENDNOTE,
    AGENDA, BREAK, PARAGRAPH, NOTE, SOURCE;
    
    public String getStyle(){
        if (this == PARAGRAPH){
            return "";
        }
        return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, name());
    }
}
