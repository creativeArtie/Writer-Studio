package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanCite extends LinedSpan {
    private LinedCite field;
    private Optional<? extends LinedCiteData<?>> data;
    
    public LinedSpanCite(List<Span> children, LinedCite type,
        Optional<? extends LinedCiteData<?>> textSpan
    ){
        super(children, LinedType.SOURCE);
        field = type;
        data = textSpan;
    }
    
    public LinedCite getField(){
        return field;
    }
    
    public Optional<? extends LinedCiteData<?>> getData(){
        return data;
    }
}
