package org.community.jwriter.basic;

import static org.community.jwriter.basic.AtomicTerm.*;

public enum EditionType {
    STUB(STYLE_STUB), DRAFT(STYLE_DRAFT), FINAL(STYLE_FINAL), 
    OTHER(STYLE_REST), NONE(STYLE_REST);
    
    private String style;
    
    private EditionType(String s){
        style = s;
    }
    
    String getStyle(){
        return style;
    }
}
