package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseLevel implements InputParser<LinedSpanLevel> {
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET;
    
    static InputParser<?>[] getSubList(){
        return new InputParser<?>[]{QUOTE, NUMBERED, BULLET};
    }
    
    private interface StartBuilder{
        public String getLevel(int level);
    }
    
    private static String repeat(String ch, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(ch);
        }
        return builder.toString();
    }
    
    public Optional<LinedSpanLevel> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        for(int i = LEVEL_MAX; i >= 1; i--){
            if (pointer.startsWith(children, getLinedLevel(this, i))){
                
                LinedType type = LinedType.values()[ordinal()];
                
                return ordinal() <= OUTLINE.ordinal()?
                    parseSec(children, pointer, type, i):
                    parseBasic(children, pointer, type, i);
            }
        }
        return Optional.empty();
    }
    
    private Optional<LinedSpanLevel> parseSec(
            ArrayList<Span> children, InputPointer pointer, 
            LinedType type, int level){
        
        Optional<DirectorySpan> id = Optional.empty();
        if (pointer.trimStartsWith(children, DIRECTORY_BEGIN)){
            
            id = new DirectoryParser(DirectoryType.LINK, DIRECTORY_END, EDITION_BEGIN).parse(children, 
                pointer);
            pointer.startsWith(children, DIRECTORY_END);
        }
        
        Optional<FormatSpanMain> second = new FormatParser(EDITION_BEGIN)
            .parse(children, pointer);
        
        Optional<EditionSpan> status = EditionParser.parseAll(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        LinedSpanSection ans = new LinedSpanSection(children, level, 
            type, id, second, status);
        id.ifPresent(span -> pointer.getMap().addId(span.getId(), ans));
        return Optional.of(ans);
    }
    
    private Optional<LinedSpanLevel> parseBasic(
            ArrayList<Span> children, InputPointer pointer, 
            LinedType type, int level){
        Optional<FormatSpanMain> text = new FormatParser().parse(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        return Optional.of(
            new LinedSpanLevel(children, level, type, text));
        
    }
}
