package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;

public abstract class LinedCiteData<T> extends SpanBranch{
    
    public abstract LinedCiteData<T> cast();
    
    public abstract boolean isReady();
    
    public abstract T get();
    
    protected LinedCiteData(List<Span> children){
        super(children);
    }
}
