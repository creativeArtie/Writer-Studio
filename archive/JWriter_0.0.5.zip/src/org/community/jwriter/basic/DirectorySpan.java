package org.community.jwriter.basic;

import java.util.ArrayList; /// Use to create DirectoryID
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Created from {@link DirectorySpan}. Used to store {@link DirectoryId}
 */
public class DirectorySpan extends SpanBranch{
    /// helps with categorizing and describes purpose
    private DirectoryType purpose;
    /// stores the actual {@link DirectoryId}
    private DirectoryId id;
    
    /// Helper method to get Optional<DirectorySpan> -> Optional<DirectoryId>
    static Optional<DirectoryId> getDirectoryHelper(Optional<DirectorySpan> id){
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
    
    DirectorySpan(List<Span> children, List<String> categories, 
        Optional<ContentSpan> idSpan, DirectoryType type
    ){
        super(children);
        
        /// Adds main category
        ArrayList<String> builder = new ArrayList<>();
        if (type != DirectoryType.NONE) builder.add(type.getCategory());
        builder.addAll(categories);
        ///build the id
        id = new DirectoryId(builder, idSpan.get().getText());
        
        purpose = type;
    }
    
    @Override
    public String getStyle(){
        String issues = "";
        switch(getDocument().getMap().get(id).getState()){
            case NONE:
                break;
            case UNUSED:
            case MULTIPLE:
                issues = STYLE_WARNING;
                break;
            default:
                issues = STYLE_ERROR;
        }
        return Span.appendStyle(this, Span.appendStyle(STYLE_ID, issues));
    }
    
    public DirectoryId getId(){
        return id;
    }
    
    public DirectoryType getPurpose(){
        return purpose;
    }
    
    public String toString(){
        return "[" + id.getFullIdentity() + "]";
    }
}
