package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

class MainParser implements InputParser<MainSpan> {
    private static final InputParser<?>[] parsers = InputParser.combine(
        InputParser.combine(LinedParseLevel.values(), LinedParsePointer.values()),
        InputParser.combine(LinedParseCite.values(), LinedParseRest.values())
    );
    
    private Optional<LinedSpanLevel> heading;
    private Optional<LinedSpanLevel> outline;
    private Optional<MainSpanSection> lastPart;
    
    public MainParser(){
        heading = Optional.empty();
        outline = Optional.empty();
        lastPart = Optional.empty();
    }
    
    @Override
    public Optional<MainSpan> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        LinedSpan line = null;
        for (InputParser<?> parser: parsers){
            Optional<?> found = parser.parse(children, pointer);
            if(found.isPresent()){
                line = (LinedSpan) found.get();
                break;
            }
        }
        switch (line.getType()){
            case HEADING:
                heading = Optional.of((LinedSpanLevel)line);
                lastPart = Optional.empty();
                outline = Optional.empty();
                return parseSection(children, pointer);
            case OUTLINE:
                outline = Optional.of((LinedSpanLevel)line);
                lastPart = Optional.empty();
                return parseSection(children, pointer);
            case NOTE:
                return parseNote(children, pointer, 
                    ((LinedSpanNote)line).getId());
            case SOURCE:
                return parseNote(children, pointer, Optional.empty());
            default:
                return parseSection(children, pointer);
        }
    }
    
    private Optional<MainSpan> parseSection(ArrayList<Span> children, 
            InputPointer pointer){
        while (true){
            pointer.mark();
            Optional<? extends Span> span = Optional.empty();
            for (InputParser<?> parser : parsers){
                span = parser.parse(pointer);
                if (span.isPresent()){
                    break;
                }
            }
            if (span.isPresent()){
                LinedSpan line = (LinedSpan) span.get();
                switch(line.getType()){
                    case HEADING:
                    case OUTLINE:
                        pointer.rollBackDirectory();
                        return buildSection(children);
                    case NOTE:
                    case SOURCE:
                        pointer.rollBack();
                        return buildSection(children);
                    default:
                        children.add(line);
                }
            } else {
                return buildSection(children);
            }
        }
    }
    
    private Optional<MainSpan> buildSection(List<Span> children){
        lastPart = Optional.of(new MainSpanSection(children, heading, outline, 
            lastPart));
        return Optional.of(lastPart.get());
    }
    
    private Optional<MainSpan> parseNote(ArrayList<Span> children, 
            InputPointer pointer, Optional<DirectoryId> id){
        ArrayList<LinedSpanCite> sources = new ArrayList<>();
        while (true){
            Optional<LinedSpanCite> source = LinedParseCite.INSTANCE.parse(children,
                pointer);
            if (source.isPresent()){
                sources.add(source.get());
            } else {
                pointer.mark();
                Optional<LinedSpan> found = LinedParseRest.NOTE.parse(pointer);
                if (! found.isPresent()){
                    return buildNote(pointer, children, id, sources); 
                } else if (((LinedSpanNote)found.get()).getId().isPresent()){
                    pointer.rollBack();
                    return buildNote(pointer, children, id, sources);
                }
                children.add(found.get());
            }
            
        }
    }
    
    private Optional<MainSpan> buildNote(InputPointer pointer, 
            List<Span> children, Optional<DirectoryId> idFound, 
            List<LinedSpanCite> sources){
        MainSpanNote ans = new MainSpanNote(children, idFound, sources);
        idFound.ifPresent(id -> pointer.getMap().addId(id, ans));
        return Optional.of(ans);
    }
}
