package org.community.jwriter.basic;

import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()
import com.google.common.base.Joiner;      /// To remove spaces
import com.google.common.base.Splitter;    /// To remove spaces
import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

interface BasicText{
    
    public List<Span> delegate();
    
    public default String getText(){
        StringBuilder builder = new StringBuilder();
        for(Span child: delegate()){
            if (child instanceof ContentSpanEscape){
                builder.append(((ContentSpanEscape)child).getEscape());
            } else if (child instanceof SpanLeaf){
                /// Add text from a basic span
                builder.append(child.getRaw());
            } else {
                throw new IllegalArgumentException(
                    "Unexpected child span" + child.toString()
                );
            }
        }
        
        /// Finalizes the text
        CharMatcher spaces = CharMatcher.whitespace();
        /// combine mutiple spaces into one.
        return Joiner.on(" ").join(
            Splitter.on(spaces).omitEmptyStrings().split(builder.toString())
        );
    }
    
    public default boolean isSpaceBegin(){
        List<Span> children = delegate();
        CharMatcher space = CharMatcher.whitespace();
        if (children.size() > 0){
            Span child = children.get(0);
            if (child instanceof ContentSpanEscape){
                String text = ((ContentSpanEscape)child).getEscape();
                if (! text.isEmpty()){
                    return space.matches(text.charAt(0));
                }
            } else {
                String text = child.getRaw();
                if (! text.isEmpty()){
                    return space.matches(text.charAt(0));
                }
            }
        }
        return false;
    }
    
    public default boolean isSpaceEnd(){
        List<Span> children = delegate();
        CharMatcher space = CharMatcher.whitespace();
        if (children.size() > 0){
            Span child = children.get(children.size() - 1);
            if (child instanceof ContentSpanEscape){
                String text = ((ContentSpanEscape)child).getEscape();
                if (! text.isEmpty()){
                    return space.matches(text.charAt(0));
                }
            } else {
                String text = child.getRaw();
                if (! text.isEmpty()){
                    return space.matches(text.charAt(text.length() - 1));
                }
            }
        }
        return false;
    }
}
