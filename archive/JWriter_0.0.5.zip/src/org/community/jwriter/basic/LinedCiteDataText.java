package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedCiteDataText extends LinedCiteData<ContentSpan>{
    
    public static final InputParser<LinedCiteDataText> PARSER = pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        Optional<ContentSpan> data = new ContentParser()
            .parse(children, pointer);
        if (data.isPresent()){
            return Optional.of(new LinedCiteDataText(children, data.get()));
        }
        return Optional.empty();
    };
    
    private ContentSpan data;
    
    public LinedCiteDataText cast(){
        return this;
    }
    
    public boolean isReady(){
        return true;
    }
    
    @Override
    public ContentSpan get(){
        return data;
    }
    
    private LinedCiteDataText(List<Span> children, ContentSpan span){
        super(children);
        data = span;
    }
}
