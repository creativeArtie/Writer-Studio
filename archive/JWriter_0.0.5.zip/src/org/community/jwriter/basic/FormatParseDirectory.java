package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanCurlyDirectory} and {@link FormatSpanCurlyAgenda} that uses 
 * curly bracket. These are footnote, endnote, cite, and to do.
 */
class FormatParseDirectory implements InputParser<FormatSpanDirectory> {
    
    private String start;
    private DirectoryType type;
    private boolean[] formats;
    
    public static FormatParseDirectory[] getParsers(boolean[] spanFormats){
        boolean[] formats = Arrays.copyOf(spanFormats, spanFormats.length);
        return new FormatParseDirectory[]{
            new FormatParseDirectory(DirectoryType.FOOTNOTE, formats),
            new FormatParseDirectory(DirectoryType.ENDNOTE, formats),
            new FormatParseDirectory(DirectoryType.NOTE, formats)
        };
    }
    
    private FormatParseDirectory(DirectoryType parseType, boolean[] spanFormats){
        type = parseType;
        switch(parseType){
            case FOOTNOTE:
                start = CURLY_FOOTNOTE;
                break;
            case ENDNOTE:
                start = CURLY_ENDNOTE;
                break;
            case NOTE:
                start = CURLY_CITE;
                break;
            default:
                throw new IllegalArgumentException("DirectoryType not allowed.");
        }
        formats = spanFormats;
    }
    
    @Override
    public Optional<FormatSpanDirectory> parse(InputPointer pointer){
        /// FOund therefore setup the SpanBranch
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, start)){
            /// DirectoryId for the other Parsers
            Optional<DirectorySpan> data = new DirectoryParser(type, CURLY_END)
                .parse(children, pointer);
            
            /// Complete the last steps
            pointer.startsWith(children, CURLY_END);
            
            FormatSpanDirectory span = new FormatSpanDirectory(children, 
                formats, data, type);
            
            data.ifPresent(id -> pointer.getMap().addRef(id.getId(), span));
            return Optional.of(span);
        }
        return Optional.empty();
    }
}
