package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link FormatSpanLink} with path indicated right in the text.
 */
public class FormatSpanLinkDirect extends FormatSpanLink {

    private final String path;
    private final String text;
    
    FormatSpanLinkDirect(List<Span> children, boolean[] formats, 
        Optional<ContentSpan> linkSpan, Optional<ContentSpan> textSpan
    ){
        super(children, formats);
        path = linkSpan.isPresent()? linkSpan.get().getText(): "";
        text = textSpan.isPresent()? textSpan.get().getText(): path;
    }
    
    @Override
    protected String getStyle(String style){
        return Span.appendStyle(Span.appendStyle(this, STYLE_LINK_DIRECT), style);
    }
    
    public String getPath(){
        return path;
    }
    
    public String getText(){
        return text;
    }

}
