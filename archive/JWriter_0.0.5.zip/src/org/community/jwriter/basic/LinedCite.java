package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.base.CaseFormat;

import org.community.jwriter.markup.*;

public enum LinedCite{
    /* //TODO add in future version (for automatic LinedCite Style)
    AUTHOR, EDITOR, TRANSLATOR, ARTICLE, TITLE, EDITION, PUBLISH_HOUSE, 
    PUBLISH_YEAR, MEDIA, ACCESS_LOCATION, ACCESS_DATE, */
    PAGES(LinedCiteDataNumber.PARSER),
    
    SOURCE(LinedCiteDataFormatted.PARSER), IN_TEXT(LinedCiteDataText.PARSER), 
    FOOTNOTE(LinedCiteDataText.PARSER), 
    
    ERROR(LinedCiteDataText.PARSER);
    
    private InputParser<? extends LinedCiteData<?>> parser;
    
    private LinedCite(InputParser<? extends LinedCiteData<?>> p){
        parser = p;
    }
    
    public String getCode(){
        return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_HYPHEN, name());
    }
    
    public Optional<? extends LinedCiteData<?>> parse(List<Span> children, 
            InputPointer pointer){
        return parser.parse(children, pointer);
    }
    
    
}
