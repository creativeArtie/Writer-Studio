package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanAgenda extends LinedSpan {
    private String reason;

    LinedSpanAgenda(List<Span> children, LinedType spanType, 
            Optional<ContentSpan> textSpan){
        super(children, spanType);
        reason = textSpan.isPresent()? textSpan.get().getText(): "";
    }
    
    public String getReason(){
        return reason;
    }
}
