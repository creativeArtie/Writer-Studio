package org.community.jwriter.basic;

import org.community.jwriter.markup.Span; /// For SEP in Part-2-1

/**
 * All special string use in the markup language.
 */
public final class AtomicTerm{
    /// ========================================================================
    /// @Part-1: Token Constants------------------------------------------------
    
    /// @Part-1.1: Lines with Levels -------------------------------------------
    /// For LinedParseLevel
    
    /// Maximum number of levels
    public static final int LEVEL_MAX = 6;
    
    /// Leveled Line begin part token for numbered and bullet
    private static final String LEVEL_BEGIN    = "\t";
    /// Leveled line begin part tokens
    private static final String LEVEL_HEADING  = "=";
    private static final String LEVEL_NUMBERED = "#";
    private static final String LEVEL_OUTLINE  = "#";
    private static final String LEVEL_BULLET   = "-";
    private static final String LEVEL_QUOTE    = ">";
    /// Create a Leveled Line begin token
    public static String getLinedLevel(LinedParseLevel from, int level){
        switch (from){
            case HEADING:
                return repeat(LEVEL_HEADING, level);
            case OUTLINE:
                return LINED_BEGIN + repeat(LEVEL_OUTLINE, level);
            case QUOTE:
                return repeat(LEVEL_QUOTE, level);
            case NUMBERED:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_NUMBERED;
            case BULLET:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_BULLET;
        }
        throw new IllegalArgumentException("LinedLevelParser not used.");
    }
    /// getLinedLevel helper
    private static String repeat(String repeats, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(repeats);
        }
        return builder.toString();
    }
    
    /// @Part-1-2: Other Lined Details -----------------------------------------
    /// For BasicTextParse, LinedParseCite, LinedParseLevel, LinedParsePointer,
    ///     LinedParseRest, getLinedLevel(LinedParseLevel, int)
    
    /// Line ending token
    public static final String LINED_END = "\n";
    
    /// Data separator token
    public static final String LINED_DATA = ":";
    
    /// "Special" Line begin token  part 1
    private static final String LINED_BEGIN = "!";
    /// "Special" Line begin tokens part 2
    public static final String LINED_AGENDA   = LINED_BEGIN + "!"; 
    public static final String LINED_NOTE     = LINED_BEGIN + "%";   
    public static final String LINED_SOURCE   = LINED_BEGIN + ">";
    public static final String LINED_LINK     = LINED_BEGIN + "@";
    public static final String LINED_FOOTNOTE = LINED_BEGIN + "^";
    public static final String LINED_ENDNOTE  = LINED_BEGIN + "*";
    
    /// Line break token
    public static final String LINED_BREAK = "***\n";
    
    /// @Part-1-3: Directory ---------------------------------------------------
    /// For DirectoryParser, LinedParseLevel, LinedParseRest, CURLY_CITE
    
    public static final String DIRECTORY_BEGIN    = "@"; /// Start
    public static final String DIRECTORY_CATEGORY = "-"; /// Middle (Separator)
    public static final String DIRECTORY_END      = ":"; /// End
    
    /// @Part-1-4: Status ------------------------------------------------------
    /// EditionParser, LinedParseLevel
    
    /// Beginning of edition
    public static final String EDITION_BEGIN = "#";
    /// (more constants from {@link Edition#name()}
    
    /// @Part-1-5: Hyperlinks --------------------------------------------------
    /// For FormatParseLinkDirect, FormatParseLinkRef, listFormatEnders()
    
    /// Starters
    public static final String LINK_BEGIN =              "<"; /// Direct Start
    public static final String LINK_REF   = LINK_BEGIN + "@"; /// Ref Start
    
    /// Others
    public static final String LINK_TEXT  = "|"; /// Text start
    public static final String LINK_END   = ">"; /// End
    
    /// @Part-1-6: Curly Formats ------------------------------------------------
    /// For FormatParseAgenda, FormatParseDirectory, listFormatEnders()
    
    /// Curly format begins token  part 1
    private static final String CURLY_BEGIN   = "{";
    /// Curly format begins tokens part 2
    public static final String CURLY_AGENDA   = CURLY_BEGIN + "!";
    public static final String CURLY_FOOTNOTE = CURLY_BEGIN + "^";
    public static final String CURLY_ENDNOTE  = CURLY_BEGIN + "*";
    public static final String CURLY_CITE     = CURLY_BEGIN + DIRECTORY_BEGIN;
    
    /// Curly format ends
    public static final String CURLY_END      = "}";
    
    /// @Part-1-7: Format Modifiers ---------------------------------------------
    /// For FormatParser, listFormatEnders()
    
    /// list of possible formats
    private static final String FORMAT_ITALICS  = "*";
    private static final String FORMAT_BOLD     = "**";
    private static final String FORMAT_UNDERLINE = "_";
    private static final String FORMAT_CODED     = "`";
    /// Create the list of possible format
    public static final String[] listSpanFormats(){
        /// FORMAT_BOLD must before FORMAT_ITALICS
        return new String[]{
            FORMAT_BOLD, FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED
        };
    }
    
    /// @Part-1-8: Escape Begin Token ------------------------------------------
    /// For BasicTextParser, listFormatEnders()
    public static final String CHAR_ESCAPE    = "\\";
    
    /// @Part-1-9: Format Part Separators --------------------------------------
    /// For FormatParsers
    
    /// Create the list of parts for format, FORMAT_BOLD is optional
    public static String[] listFormatEnders(){
        return new String[]{
            CURLY_AGENDA, CURLY_FOOTNOTE, CURLY_ENDNOTE, CURLY_CITE, CURLY_END, 
            LINK_BEGIN, LINK_REF, 
            /* FORMAT_BOLD, */FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED,
            CHAR_ESCAPE};
    }
    
    /// ========================================================================
    /// @Part-2: Styles --------------------------------------------------------
    
    /// @Part-2-1: Basic Separator ---------------------------------------------
    /// For almost everything below
    private static final String SEP = Span.STYLE_SEPARATOR;
    
    /// @Part-2-2: Escape Style ------------------------------------------------
    /// For ContentSpanEscape
    public static final String STYLE_ESCAPE = "escape";
    
    /// @Part-2-3: Identity Styles ---------------------------------------------
    /// For DirectorySpan
    public static final String STYLE_ID = "id";
    public static final String STYLE_WARNING = "warning";
    public static final String STYLE_ERROR = "error";
    
    /// @Part-2-4: Edition Styles ----------------------------------------------
    /// For EditionType
    private static final String STYLE_EDITION = "edition";
    public static final String STYLE_STUB  = STYLE_EDITION + SEP + "stub";
    public static final String STYLE_DRAFT = STYLE_EDITION + SEP + "draft";
    public static final String STYLE_FINAL = STYLE_EDITION + SEP + "final";
    public static final String STYLE_REST  = STYLE_EDITION;
    
    /// @Part-2-5: Agenda Style ------------------------------------------------
    /// For FormatSpanAgenda
    public static final String STYLE_AGENDA  = "agenda";
    
    /// @Part-2-6: Curly Styles and Diectory Categories ------------------------
    /// For DirectoryType, DirectoryType.getStyle() -> FormatSpanDirectory
    private static final String STYLE_CURLY = "curly";
    public static final String TYPE_FOOTNOTE = "foot";
    public static final String TYPE_ENDNOTE = "end";
    public static final String TYPE_LINK = "link";
    public static final String TYPE_NOTE = "note";
    public static final String TYPE_NONE = "";
    public static String getCurlyStyle(String style){
        return STYLE_CURLY + (style.isEmpty()? "": SEP + style);
    }
    
    /// @Part-2-7 Hyperlink Styles ---------------------------------------------
    /// For FormatSpanLinkDirect, FormatSpanLinkRef
    private static final String STYLE_LINK = "link";
    public static final String STYLE_LINK_DIRECT = STYLE_LINK + SEP + "direct";
    public static final String STYLE_LINK_REF    = STYLE_LINK + SEP + "ref";
    
    /// @Part-2-8 Format Modifier Styles ---------------------------------------
    /// For FormatSpan
    private static final String STYLE_BOLD = "bold";
    private static final String STYLE_ITALICS = "italics";
    private static final String STYLE_UNDERLINE = "underline";
    private static final String STYLE_CODED = "coded";
    public static final String[] STYLE_FORMATS = new String[]{
        STYLE_BOLD, STYLE_ITALICS, STYLE_UNDERLINE, STYLE_CODED
    };
    
    /// ========================================================================
    /// @Part-3: Private Constructor -------------------------------------------
    private AtomicTerm(){}
}
