package org.community.jwriter.markup;

public interface SpanChild extends Span{
    public String getStyle();
}
