package org.community.jwriter.markup;

    
/**
 * Types of error with the DirectoryId.
 */
public enum DirectoryStatus{
    /// This is no id assoicate in a DirectoryHolder
    NO_ID,
    /// There is an id but nothing is refer to it
    UNUSED,
    /// A reference that pointing to no known DirectoryId. 
    NOT_FOUND, 
    /// More than one DirectoryId has the same name
    MULTIPLE, 
    /// No error is found.
    NONE;
}
