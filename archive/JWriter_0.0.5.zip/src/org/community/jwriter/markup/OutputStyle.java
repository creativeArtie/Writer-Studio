package org.community.jwriter.markup;

import java.util.ArrayList;

public enum OutputStyle{
    KEYWORD("token"), ID("id"), FIELD("key"), DATA("data"), PATH("path"), 
    TEXT("");
    
    public static final String STYLE_SEPARATOR = ";";
    
    public static String appendStyle(Span child, String postfix){
        Span parent = child.getParent();
        if (parent instanceof SpanChild){
            return appendStyle(((SpanChild)parent).getStyle(), postfix);
        }
        return appendStyle("", postfix);
    }
    
    public static String appendStyle(String prefix, Span child){
        Span parent = child.getParent();
        if (parent instanceof SpanChild){
            return appendStyle(prefix, ((SpanChild)parent).getStyle());
        }
        return appendStyle(prefix, "");
    }
    
    public static String appendStyle(String prefix, String postfix){
        if (prefix.isEmpty()){
            return postfix;
        } else if (postfix.isEmpty()){
            return prefix;
        }
        return prefix + STYLE_SEPARATOR + postfix;
    }
    
    private String style;
    
    private OutputStyle(String s){
        style = s;
    }
    
    String getStyle(){
        return style;
    }
}
