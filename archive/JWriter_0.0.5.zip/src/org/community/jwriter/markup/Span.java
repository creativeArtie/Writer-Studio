package org.community.jwriter.markup;

import java.util.List;
import java.util.ArrayList;

/**
 * A subdivision of a {@link Document}
 */
public interface Span{
    
    public static final String STYLE_SEPARATOR = "-";
    
    public static String appendStyle(Span child, String postfix){
        Span parent = child.getParent();
        if (parent instanceof SpanChild){
            return appendStyle(((SpanChild)parent).getStyle(), postfix);
        }
        return appendStyle("", postfix);
    }
    
    public static String appendStyle(String prefix, Span child){
        Span parent = child.getParent();
        if (parent instanceof SpanChild){
            return appendStyle(prefix, ((SpanChild)parent).getStyle());
        }
        return appendStyle(prefix, "");
    }
    
    public static String appendStyle(String prefix, String postfix){
        if (prefix.isEmpty()){
            return postfix;
        } else if (postfix.isEmpty()){
            return prefix;
        }
        return prefix + STYLE_SEPARATOR + postfix;
    }
    
    public String getRaw();
    
    public int getLength();
    
    public Document getDocument();
    
    public SpanNode<?> getParent();
}
