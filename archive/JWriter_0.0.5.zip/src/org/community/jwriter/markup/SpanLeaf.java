package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf implements SpanChild{
    private final String text;
    private final Document doc;
    private SpanBranch parent;
    private OutputStyle style;
    
    public static String escapeText(String input){
        return "\"" + input.replace("\n", "\" \\n \"")
            .replace("\t", "\" \\t \"") + "\"";
    }
    
    SpanLeaf(InputPointer pointer, OutputStyle spanStyle){
        text = pointer.getRaw();
        pointer.roll();
        doc = pointer.getDocument();
        style = spanStyle;
    }
    
    public String getStyle(){
        return Span.appendStyle(parent.getStyle(), style.getStyle());
    }
    
    @Override
    public final String getRaw(){
        return text;
    }
    
    @Override
    public String toString(){
        return escapeText(text);
    }
    
    @Override
    public Document getDocument(){
        return doc;
    }
    
    @Override
    public SpanBranch getParent(){
        return parent;
    }
    
    @Override
    public int getLength(){
        return text.length();
    }
    
    void setParent(SpanNode<?> childOf){
        parent = (SpanBranch)childOf;
    }
}
