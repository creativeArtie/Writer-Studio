package org.community.jwriter.property;

import java.util.Locale;
import java.util.Optional;
import java.util.Properties;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.MissingResourceException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class TextResourceManager {
    private static HashMap<String, TextResourceManager> resources = 
        new HashMap<>();
        
    private static final String extension = ".properties";
    
    private static Optional<Locale> locale = Optional.empty();
    
    public static TextResourceManager getResouce(String baseFile){
        if (resources.containsKey(baseFile)){
            return resources.get(baseFile);
        }
        TextResourceManager manager = new TextResourceManager(baseFile);
        resources.put(baseFile, manager);
        return manager;
    }
    
    public static void updateLocale(Locale newLocale) {
        locale = Optional.ofNullable(newLocale);
        for(TextResourceManager manager: resources.values()){
            manager.setBundle();
            for(TextResource text: manager.texts.values()){
                text.update();
            }
        }
    }
    
    private HashMap<String, TextResource> texts;
    
    private Properties defaults;
    
    private Properties bundle;
    
    private String base;
    
    private void setBundle() {
        StringBuilder builder = new StringBuilder(base);
        if(locale.isPresent()){
            Locale l = locale.get();
            String lang = l.getLanguage();
            if (! lang.isEmpty()){
                builder.append("_" + lang);
            }
            String country = l.getCountry();
            if (! country.isEmpty()){
                builder.append("_" + country);
            }
        }
        builder.append(extension);
        bundle = new Properties(defaults);
        File file = new File(builder.toString());
        if (file.isFile()){            
            try (FileInputStream in = new FileInputStream(file)){
                bundle.load(in);
            } catch (IOException ex){
                throw new RuntimeException("This should not be thrown.", ex);
            }
        }
    }
    
    private TextResourceManager(String baseText){
        base = baseText;
        defaults = new Properties();
        try (FileInputStream in = new FileInputStream(base + extension)){
            defaults.load(in);
        } catch (IOException ex){
            throw new MissingResourceException("Resource file fail to load: " +
                base + extension, baseText, "");
        }
        setBundle();
        texts = new HashMap<>();
    }
    
    public TextResource getText(String key){
        if (bundle.getProperty(key) == null){
            throw new MissingResourceException(
                "Resource key not found in " + base + ": " + key, 
                base, key);
        }
        if (texts.containsKey(key)){
            return texts.get(key);
        }
        TextResource resource = new TextResource(key, this);
        texts.put(key, resource);
        return resource;
    }
    
    String get(String key){
        return bundle.getProperty(key);
    }
}
