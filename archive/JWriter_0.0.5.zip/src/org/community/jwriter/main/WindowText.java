package org.community.jwriter.main;

import org.community.jwriter.property.*;

public enum WindowText implements TextResourceEnumHelper{
    TITLE("Title");
    
    private static TextResourceManager manager = TextResourceManager
        .getResouce("data/windowtext/text");;
    
    private TextResource resource;
    
    private final String text;
    
    private WindowText(String textName){
        text = "MainWindow." + textName;
    }

    @Override
    public TextResource delegate(){
        if (resource == null){
            resource = manager.getText(text);
        }
        return resource;
    }
}
