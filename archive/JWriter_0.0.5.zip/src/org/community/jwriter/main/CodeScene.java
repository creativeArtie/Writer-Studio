package org.community.jwriter.main;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import org.fxmisc.richtext.InlineCssTextArea;

import org.community.jwriter.markup.*;

public class CodeScene extends StackPane{
    private InlineCssTextArea writeArea;
    private Document doc;
    
    public CodeScene(){
        writeArea = new InlineCssTextArea("Hello World!");
        writeArea.setStyle(0, 6, "-fx-fill: red; -fx-font-weight: bold");
        getChildren().add(writeArea);
    }
}
