package org.community.jwriter.markup;

import java.util.Optional;

import com.google.common.collect.ImmutableList.Builder;

/**
 * Creator for the {@link Span}.
 */
public interface Parser<T extends Span>{
    
    /** Put two {@linkplain String} list together. */
    public static String[] combine(String[] list1, String[] list2){
        String[] res = new String[list1.length + list2.length];
        System.arraycopy(list1, 0, res, 0, list1.length);
        System.arraycopy(list2, 0, res, list1.length, list2.length);
        return res;
    }
    
    /** Put two {@link Parser} list together. */
    public static  Parser<?>[] combine(
            Parser<?>[] list1, Parser<?>[] list2){
        Parser<?>[] res = new Parser<?>[list1.length + list2.length];
        System.arraycopy(list1, 0, res, 0, list1.length);
        System.arraycopy(list2, 0, res, list1.length, list2.length);
        return res;
    }
    
    public default Optional<T> parse(Builder<Span> children, Pointer pointer){
        Optional<T> child = parse(pointer);
        child.ifPresent(c -> children.add(c));
        return child;
    }
    
    /**
     * Creates a {@link Span} base on the Parsers. If the span does not exist, it
     * should <em> not </em> move the {@link Pointer} and returns 
     * {@code Optional.empty()}.
     */
    public Optional<T> parse(Pointer pointer);
}
