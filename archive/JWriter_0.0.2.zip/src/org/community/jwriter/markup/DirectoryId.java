package org.community.jwriter.markup;

import java.util.List;
import java.util.Objects;

import com.google.common.collect.ImmutableList;

public class DirectoryId implements Comparable<DirectoryId>{
    private final ImmutableList<String> cat;
    private final String id;
    
    public DirectoryId(List<String> category, String identity){
        cat = ImmutableList.copyOf(category);
        id = identity;
    }
    
    
    public String[] getCategory(){
        return cat.toArray(new String[0]);
    }
    
    public String getIdentity(){
        return id;
    }
    
    public String getFullIdentity(){
        StringBuilder builder = new StringBuilder();
        int i = 0;
        for(String cat: getCategory()){
            builder.append(cat);
            builder.append("-");
        }
        builder.append(getIdentity());
        return builder.toString();
    }
    
    @Override
    public String toString(){
        return "DirectoryId(" + getFullIdentity() + ")";
    }
    
    @Override
    public int compareTo(DirectoryId obj){
        int i = 0;
        for (String cat: cat){
            if (i >= obj.cat.size()){
                return 1;
            }
            int compare = cat.compareTo(obj.cat.get(i));
            if (compare != 0){
                return compare;
            }
            i++;
        }
        if (i < obj.cat.size()){
            return -1;
        }
        return id.compareTo(obj.id);
    }
    
    @Override
    public boolean equals(Object obj){
        if (obj instanceof DirectoryId){
            DirectoryId span = (DirectoryId) obj;
            if (cat.equals(span.cat)){
                return id.equals(span.id);
            }
        }
        return false;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(cat, id);
    }
}
