package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf implements Span{
    private final String text;
    private final Document doc;
    private SpanNode<?> parent;
    
    public static String escapeText(String input){
        return "\"" + input.replace("\n", "\" \\n \"")
            .replace("\t", "\" \\t \"") + "\"";
    }
    
    SpanLeaf(Pointer pointer){
        text = pointer.getRaw();
        pointer.roll();
        doc = pointer.getDocument();
    }
    
    @Override
    public final String getRaw(){
        return text;
    }
    
    @Override
    public String toString(){
        return escapeText(text);
    }
    
    @Override
    public Document getDocument(){
        return doc;
    }
    
    @Override
    public SpanNode<?> getParent(){
        return parent;
    }
    
    @Override
    public int getLength(){
        return text.length();
    }
    
    void setParent(SpanNode<?> childOf){
        parent = childOf;
    }
}
