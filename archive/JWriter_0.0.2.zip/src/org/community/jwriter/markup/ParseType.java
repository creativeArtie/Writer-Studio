package org.community.jwriter.markup;

public enum ParseType{
    SPACED_START, START_WITH, GET_TO, NEXT_CHAR;
}
