package org.community.jwriter.markup;
import java.util.Stack;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.base.CharMatcher;

/**
 * Pointer for the rawText. Stores two points: {@linkplain start} for where the
 * pointer is currently checking from and {@linkplain end} for where is the 
 * next matching data. 
 */
public final class Pointer{

    private final String text;
    private final Document doc;
    private final DirectoryMap.Builder idMap;
    
    /// Points to where the pointer would roll back to
    private int mark;
    /// Points to the matching start
    private int cur;
    /// Points to the last success (but not commit) check
    private int found;
    
    public Pointer(Document document){
        text = document.getRaw();
        idMap = DirectoryMap.builder();
        cur = 0;
        found = 0;
        mark = 0;
        doc = document;
    }
    
    public void mark(){
        mark = cur;
    }
    
    public void rollBack(){
        cur = mark;
        found = mark;
    }
    
    public void rollBackDirectory(){
        rollBack();
        idMap.removeLastId();
    }
    
    public void rollBackRef(){
        rollBack();
        idMap.removeLastRef();
    }
    
    public boolean trimStartsWith(ImmutableList.Builder<Span> children, 
            String compare){
        return finishing(children, trimStartsWith(compare));
    }
    
    public boolean trimStartsWith(List<String> compares){
        return trimStartsWith(compares.toArray(new String[0]));
    }
    
    public boolean trimStartsWith(String ... compares){
        if (cur >= text.length()){
            return false;
        }
        int next = cur;
        while(CharMatcher.whitespace().matches(text.charAt(next))){
            next++;
            if (next >= text.length()){
                return false;
            }
        }
        for (String compare: compares){
            if (text.startsWith(compare, next)){
                found = next + compare.length();
    
                return true;
            }
        }
        return false;
    }
    
    public boolean startsWith(ImmutableList.Builder<Span> children, 
            String compare){
        return finishing(children, startsWith(compare));
    }
    
    public boolean startsWith(List<String> compares){
        return startsWith(compares.toArray(new String[0]));
    }
    
    
    /**
     * Check if the pointer at the text location starts with 
     * {@linkplain compare}. If so move {@linkplain end} to the length of 
     * {@linkplain compare}.
     */
    public boolean startsWith(String ... compares){
        
        int next = cur;
        for(String compare : compares){
            if (text.startsWith(compare, next)){
                found = next + compare.length();
    
                return true;
            }
        }
        return false;
    }
    
    public boolean getTo(ImmutableList.Builder<Span> children, 
            List<String> compare){
        return finishing(children, getTo(compare));
    }
    
    public boolean getTo(ImmutableList.Builder<Span> children, 
            String ... compare){
        return finishing(children, getTo(compare));
    }
    
    /**
     * Moves {@linkplain end} pointer to before one of the {@linkplain enders} 
     * or the end of the rawText.
     * @see #getTo(List<String>)
     */
    public boolean getTo(String ... enders){
        return getTo(ImmutableList.copyOf(enders));
    }
    
    /**
     * Moves {@linkplain end} pointer to before one of the {@linkplain enders} 
     * or the end of the rawText.
     * @see #getTo(String ...)
     */
    public boolean getTo(List<String> enders) {
        
        /// Set up next
        int next = cur;
        /// going the the text from pointer, looking out for ender strings
        for(;next < text.length(); next++){
            for (String ender : enders){
                if (text.startsWith(ender, next)){
                    /// Match is found
                    found = next;
                    if (found != cur){
                        return true;
                    }
                    return false;
                }
            }
        }
        if (cur != next) {
            found = next;
            return true;
        }
        
        
        return false;
    }
    
    public boolean nextChars(ImmutableList.Builder<Span> children, int size){
        return finishing(children, nextChars(size));
    }
    
    /**
     * Moves {@linkpalin end} pointer to {@linkplain size}, if possible. If not
     * possible do not move {@linkplain end}
     */
    public boolean nextChars(int size) {
        if (cur + size <= text.length()){
            found = cur + size;
    
            return true;
        }
        return false;
    }
    
    private boolean finishing(ImmutableList.Builder<Span> children, 
            boolean matches){
        
        if(matches){
            children.add(new SpanLeaf(this));
            
        }
        return matches;
    }
    
    public boolean hasNext(){
        return cur < text.length();
    }
    
    protected String getRaw(){
        return text.substring(cur, found);
    }
    
    public Document getDocument(){
        return doc;
    }
    
    protected void roll(){
        cur = found;
    }
    
    public DirectoryMap.Builder getMap(){
        return idMap;
    }
    
    @Override
    public String toString(){
        return "(" + pointerHelper(mark) + "-" + pointerHelper(cur) + "-" + 
            pointerHelper(found) + "): " + text;
    }
    
    private String pointerHelper(int ptr){
        if (ptr < text.length()){
            return ptr + "(" + text.charAt(ptr) + ")";
        }
        return ptr + "(end)";
    }
}
