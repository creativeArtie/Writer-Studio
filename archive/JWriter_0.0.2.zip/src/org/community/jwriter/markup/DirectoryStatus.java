package org.community.jwriter.markup;

    
/**
 * Types of error with the DirectoryId.
 */
public enum DirectoryStatus{
    /// There is an id but nothing is refer to it
    UNUSED,
    /// A reference that pointing to no known DirectoryId. 
    NOT_FOUND, 
    /// More than one DirectoryId has the same name
    MUTILPLE, 
    /// No error is found.
    NONE;
}
