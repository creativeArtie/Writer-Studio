package org.community.jwriter.basic;

public enum EditionType {
    STUB, DRAFT, FINAL, OTHER, NONE;
}
