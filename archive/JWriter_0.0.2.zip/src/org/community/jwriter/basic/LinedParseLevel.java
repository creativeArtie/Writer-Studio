package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseLevel implements Parser<LinedSpanLevel> {
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET;
    
    static Parser<?>[] getSubList(){
        return new Parser<?>[]{QUOTE, NUMBERED, BULLET};
    }
    
    private interface StartBuilder{
        public String getLevel(int level);
    }
    
    private static String repeat(String ch, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(ch);
        }
        return builder.toString();
    }
    
    public Optional<LinedSpanLevel> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        for(int i = LEVEL_MAX; i >= 1; i--){
            if (pointer.startsWith(children, getLinedLevel(this, i))){
                
                LinedType type = LinedType.values()[ordinal()];
                
                return ordinal() <= OUTLINE.ordinal()?
                    parseSec(children, pointer, type, i):
                    parseBasic(children, pointer, type, i);
            }
        }
        return Optional.empty();
    }
    
    private Optional<LinedSpanLevel> parseSec(
            ImmutableList.Builder<Span> children, Pointer pointer, 
            LinedType type, int level){
        
        Optional<DirectorySpan> id = Optional.empty();
        if (pointer.trimStartsWith(children, Directory_BEGIN)){
            
            id = new DirectoryParser(DirectoryType.LINK, Directory_END, STATUS_BEGIN).parse(children, 
                pointer);
            pointer.startsWith(children, Directory_END);
        }
        
        Optional<FormatSpan> second = new FormatParser(STATUS_BEGIN)
            .parse(children, pointer);
        
        Optional<EditionSpan> status = EditionParser.parseAll(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        LinedSpanSection ans = new LinedSpanSection(children.build(), level, 
            type, id, second, status);
        id.ifPresent(span -> pointer.getMap().addId(span.getId(), ans));
        return Optional.of(ans);
    }
    
    private Optional<LinedSpanLevel> parseBasic(
            ImmutableList.Builder<Span> children, Pointer pointer, 
            LinedType type, int level){
        Optional<FormatSpan> text = new FormatParser().parse(children, pointer);
        
        pointer.startsWith(children, LINED_END);
        
        return Optional.of(
            new LinedSpanLevel(children.build(), level, type, text));
        
    }
}
