package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableListMultimap;

import org.community.jwriter.markup.*;

public class MainSpanNote extends MainSpan implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private ImmutableListMultimap<LinedTypeSource, String> sources;
    
    MainSpanNote(List<Span> children, Optional<DirectoryId> idSpan, 
            List<LinedSpanCite> sourceFields){
        super(children);
        id = idSpan;
        ImmutableListMultimap.Builder<LinedTypeSource, String> builder = 
            ImmutableListMultimap.builder();
        for (LinedSpanCite source: sourceFields){
            if (source.getField() != LinedTypeSource.ERROR){
                builder.put(source.getField(), source.getOutput());
            }
        }
        sources = builder.build();
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
    
    public ImmutableListMultimap<LinedTypeSource, String> getSources(){
        return sources;
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
}
