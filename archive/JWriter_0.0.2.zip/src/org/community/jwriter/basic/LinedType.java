package org.community.jwriter.basic;


public enum LinedType{
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET, HYPERLINK, FOOTNOTE, ENDNOTE,
    AGENDA, BREAK, PARAGRAPH, NOTE, SOURCE;
}
