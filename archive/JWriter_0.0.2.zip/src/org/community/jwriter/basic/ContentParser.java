package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {link Parser} for a text and escape sequences. 
 */
class ContentParser implements Parser<ContentSpan>{
    private final ImmutableList<String> fullEnders;
    
    public ContentParser(List<String> enders){
        this(enders.toArray(new String[0]));
    }
    
    public ContentParser(String ... enders){
        /// combining text span enders with escape ender and new line.
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        builder.add(FORMAT_ESCAPE);
        builder.add(LINED_END);
        for (String ender: enders){
            builder.add(ender);
        }
        fullEnders = builder.build();
    }
    
    private Optional<SpanBranch> parseEscape(Pointer pointer){
        /// Setup the children
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        /// For char "\"
        if (pointer.startsWith(children, FORMAT_ESCAPE)){
            
            /// Add the next character
            pointer.nextChars(children, 1);
            return Optional.of(new ContentSpanEscape(children.build()));
        }
        return Optional.empty();
    }
    
    @Override
    public Optional<ContentSpan> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        boolean hasMore = true;
        do{
            /// Find text
            pointer.getTo(children, fullEnders);
            
            /// Find escape text, for both cases text is before or not
            Optional<SpanBranch> span = parseEscape(pointer);
            if (! span.isPresent()){
                hasMore = false;
            } else {
                children.add(span.get());
            }
        } while (hasMore);
        
        /// Complete the span
        ImmutableList<Span> spans = children.build();
        if (spans.size() > 0) {
            /// Create span only if there are text related to the ContentSpan
            return Optional.of(new ContentSpan(spans));
        }
        return Optional.empty();
    }
}
