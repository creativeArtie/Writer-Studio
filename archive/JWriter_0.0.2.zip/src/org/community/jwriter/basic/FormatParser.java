package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link Span} for text that has been formatted. This makes all {@link Span}
 * starting with {@code Format}.
 */
class FormatParser implements Parser<FormatSpan> {
    
    private final ContentParser textParser;
    private static final Parser<?>[] parsers = 
        Parser.combine(FormatParseCurly.values(), FormatParseLink.values());
    
    public FormatParser(String ... enders){
        /// Combine the list of span enders and formatting enders
        String[] output = Parser.combine(listFormatEnders(), enders);
        textParser = new ContentParser(output);
    }
    
    @Override
    public Optional<FormatSpan> parse(Pointer pointer){
        /// Setup format style: bold, italics, underline, coded
        boolean[] formats = new boolean[]{false, false, false, false};
        
        /// Setup for FormatSpan
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        Optional<ContentSpan> text = Optional.empty();
        
        /// check where the loop ends
        boolean hasMore;
        
        do {
            hasMore = false; /// Assume FormatSpan has ended
            
            /// try to find text first
            text = textParser.parse(pointer);
            if (text.isPresent()){
                children.add(new FormatSpanContent(formats, text.get()));
                hasMore = true;
            }
            
            /// Keeps FomratContentParser parsing alone b/c of needs to edit format
            int i = 0;
            for (String type : listSpanFormats()){
                if (pointer.startsWith(children, type)){
                    /// change format of bold/italics/underline/code
                    
                    formats[i] = ! formats[i];
                    
                    hasMore = true;
                    break;
                }
                i++;
            }
            
            /// Lastly deal with FormatParseCurly and FormatParseLink together
            for (Parser<?> parser: parsers){
                Optional<? extends Span> note = parser.parse(children, pointer);
                if(note.isPresent()){
                    /// Striaght forwarding adding of found spans.
                    hasMore = true;
                }
            }
        } while(hasMore);
        
        /// Add the FormatParser with its children spans if there are children.
        ImmutableList<Span> spans = children.build();
        if (spans.size() > 0){
            return Optional.of(new FormatSpan(spans));
        }
        return Optional.empty();
    }
}
