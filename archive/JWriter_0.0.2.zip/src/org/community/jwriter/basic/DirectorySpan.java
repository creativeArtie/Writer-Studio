package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.Objects;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} that is an DirectoryId pointing to somewhere in the {@link Document}.
 */
public class DirectorySpan extends SpanBranch{
    private final DirectoryType type;
    private final DirectoryId id;
    
    static Optional<DirectoryId> getDirectoryHelper(Optional<DirectorySpan> id){
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
    
    DirectorySpan(List<Span> children, List<String> categories, 
            Optional<ContentSpan> idSpan, DirectoryType idType){
        super(children);
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        if (idType != DirectoryType.NONE) builder.add(idType.getCategory());
        builder.addAll(categories);
        id = new DirectoryId(builder.build(),
            idSpan.isPresent()? idSpan.get().getOutput(): ""
        );
        type = idType;
    }
    
    public DirectoryId getId(){
        return id;
    }
    
    public DirectoryType getType(){
        return type;
    }
    
    public String toString(){
        return "[" + id.getFullIdentity() + "]";
    }
}
