package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableListMultimap;

import org.community.jwriter.markup.*;

public class MainSpan extends SpanBranch{
    MainSpan(List<Span> children){
        super(children);
    }
}
