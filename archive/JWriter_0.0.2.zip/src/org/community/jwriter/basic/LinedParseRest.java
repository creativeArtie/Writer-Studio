package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseRest implements Parser<LinedSpan> {
    NOTE(pointer -> {
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        if (pointer.startsWith(children, LINED_NOTE)){
            Optional<DirectorySpan> id = Optional.empty();
            if (pointer.trimStartsWith(children, Directory_BEGIN)){
                id = new DirectoryParser(DirectoryType.NOTE, Directory_END).parse(children, pointer);
                pointer.startsWith(children, Directory_END);
            }
            Optional<FormatSpan> text = new FormatParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            LinedSpanNote ans = new LinedSpanNote(children.build(), id, text);
            return Optional.of(ans);
        }
        return Optional.empty();
    }),
    AGENDA(pointer ->{
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        if (pointer.startsWith(children, LINED_AGENDA)){
            Optional<ContentSpan> reason = new ContentParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanTodo(children.build(), 
                LinedType.AGENDA, reason));
        }
        return Optional.empty();
    }), 
    BREAK(pointer ->{
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        if (pointer.startsWith(children, LINED_BREAK)){
            return Optional.of(new LinedSpan(children.build(), LinedType.BREAK));
        }
        return Optional.empty();
    }),
    PARAGRAPH(pointer ->{
        if (pointer.hasNext()){
            ImmutableList.Builder<Span> children = ImmutableList.builder();
            Optional<FormatSpan> text = new FormatParser()
                .parse(children, pointer);
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanParagraph(children.build(), text));
        }
        return Optional.empty();
    });
    
    static Parser<?>[] getSectionList(){
        return new LinedParseRest[]{AGENDA, BREAK, PARAGRAPH};
    }
    
    static Parser<?>[] getNoteList(){
        return new LinedParseRest[]{NOTE};
    }
    
    private final Parser<LinedSpan> parser;
    
    private LinedParseRest(Parser<LinedSpan> p){
        parser = p;
    }
    
    public Optional<LinedSpan> parse(Pointer pointer){
        return parser.parse(pointer);
    }
}
