package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanLevel extends LinedSpan {
    private final int level;
    private final FormatSpan text;

    LinedSpanLevel(List<Span> children, int levelDepth, LinedType spanType, 
            Optional<FormatSpan> textSpan){
        this(children, levelDepth, spanType, 
            textSpan.isPresent()? textSpan.get(): new ArrayList<>());
    }
    
    LinedSpanLevel(List<Span> children, int levelDepth, 
            LinedType spanType, List<Span> textSpans){
        super(children, spanType);
        level = levelDepth;
        text = new FormatSpan(textSpans);
    }
    
    public FormatSpan getText(){
        return text;
    }
    
    public int getLevel(){
        return level;
    }
}
