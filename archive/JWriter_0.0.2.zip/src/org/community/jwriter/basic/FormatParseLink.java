package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Parser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * Parser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
enum FormatParseLink implements Parser<FormatSpanLink> {
    REFER(LINK_REF), INLINE(LINK_BEGIN);
    
    private String start;
    
    private FormatParseLink(String s){
        start = s;
    }
    
    @Override
    public Optional<FormatSpanLink> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        if(pointer.startsWith(children, start)){
            
            /// Create span base on enum value
            if (this == REFER){
                /// DirectoryId for the FormatSpanLinkRef
                Optional<DirectorySpan> id = 
                    new DirectoryParser(DirectoryType.LINK, LINK_TEXT, LINK_END)
                    .parse(children, pointer);
                
                /// Complete the last steps 
                Optional<ContentSpan> text = parseRest(children, pointer);
                FormatSpanLinkRef span = new FormatSpanLinkRef(children.build(), 
                    id, text);
                id.ifPresent(found -> pointer.getMap().addRef(found.getId(), span));
                return Optional.of(span);

            } /// else if (this == INLINE) {
            /// Text for the FormatDirectSpan
            Optional<ContentSpan> path = new ContentParser(LINK_TEXT, LINK_END)
                .parse(children, pointer);
            
            /// Complete the last steps 
            Optional<ContentSpan> text = parseRest(children, pointer);
            return Optional.of(new FormatSpanLinkDirect(children.build(), path, 
                text));
            ///}
        }
        return Optional.empty();
    }
    
    private Optional<ContentSpan> parseRest(ImmutableList.Builder<Span> children, 
            Pointer pointer){
        Optional<ContentSpan> ans = Optional.empty();
        
        /// Create display text if any
        if (pointer.startsWith(children, LINK_TEXT)){
            /// Add the text itself
            ans = new ContentParser(LINK_END).parse(children, pointer);
        }
        
        /// Add the ">"
        pointer.startsWith(children, LINK_END);
        
        return ans;
    }
}
