package org.community.jwriter.basic;

import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link Parser} for create section status. Will warn if #FINAL is not on all
 * headings and outline (unless the user allows headings and outline with out
 * {@code #FINAL} to be call final draft.
 */
enum EditionParser implements Parser<EditionSpan>{
    STUB, DRAFT, FINAL, OTHER(){
        @Override
        public Optional<EditionSpan> parse(Pointer pointer){
            ImmutableList.Builder<Span> children = ImmutableList.builder();
            if (pointer.startsWith(children, STATUS_BEGIN)){
                return setUp(children, pointer);
            }
            return Optional.empty();
        }
    };
    
    static Optional<EditionSpan> parseAll(ImmutableList.Builder<Span> children, 
            Pointer pointer){
        for(EditionParser parser: values()){
            Optional<EditionSpan> ans = parser.parse(children, pointer);
            if (ans.isPresent()){
                return ans;
            }
        }
        return Optional.empty();
    }
    
    protected Optional<EditionSpan> setUp(ImmutableList.Builder<Span> children, 
            Pointer pointer){
        
        /// Add the meta text, if any found
        Optional<ContentSpan> text = new ContentParser().parse(children, pointer);
        
        return Optional.of(new EditionSpan(children.build(), 
            EditionType.values()[ordinal()], text));
        
    }
    
    @Override
    public Optional<EditionSpan> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        if (pointer.startsWith(children, STATUS_BEGIN + name())){
            return setUp(children, pointer);
        }
        return Optional.empty();
    }
}
