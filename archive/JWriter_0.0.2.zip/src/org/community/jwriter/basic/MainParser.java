package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

class MainParser implements Parser<MainSpan> {
    private static final Parser<?>[] parsers = Parser.combine(
        Parser.combine(LinedParseLevel.values(), LinedParsePointer.values()),
        Parser.combine(LinedParseCite.values(), LinedParseRest.values())
    );
    
    private Optional<LinedSpanLevel> heading;
    private Optional<LinedSpanLevel> outline;
    private Optional<MainSpanSection> lastPart;
    
    public MainParser(){
        heading = Optional.empty();
        outline = Optional.empty();
        lastPart = Optional.empty();
    }
    
    @Override
    public Optional<MainSpan> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        LinedSpan line = null;
        for (Parser<?> parser: parsers){
            Optional<?> found = parser.parse(children, pointer);
            if(found.isPresent()){
                line = (LinedSpan) found.get();
                break;
            }
        }
        switch (line.getType()){
            case HEADING:
                heading = Optional.of((LinedSpanLevel)line);
                lastPart = Optional.empty();
                outline = Optional.empty();
                return parseSection(children, pointer);
            case OUTLINE:
                outline = Optional.of((LinedSpanLevel)line);
                lastPart = Optional.empty();
                return parseSection(children, pointer);
            case NOTE:
                return parseNote(children, pointer, 
                    ((LinedSpanNote)line).getId());
            case SOURCE:
                return parseNote(children, pointer, Optional.empty());
            default:
                return parseSection(children, pointer);
        }
    }
    
    private Optional<MainSpan> parseSection(ImmutableList.Builder<Span> children, 
            Pointer pointer){
        while (true){
            pointer.mark();
            Optional<? extends Span> span = Optional.empty();
            for (Parser<?> parser : parsers){
                span = parser.parse(pointer);
                if (span.isPresent()){
                    break;
                }
            }
            if (span.isPresent()){
                LinedSpan line = (LinedSpan) span.get();
                switch(line.getType()){
                    case HEADING:
                    case OUTLINE:
                        pointer.rollBackDirectory();
                        return buildSection(children.build());
                    case NOTE:
                    case SOURCE:
                        pointer.rollBack();
                        return buildSection(children.build());
                    default:
                        children.add(line);
                }
            } else {
                return buildSection(children.build());
            }
        }
    }
    
    private Optional<MainSpan> buildSection(ImmutableList<Span> children){
        lastPart = Optional.of(new MainSpanSection(children, heading, outline, 
            lastPart));
        return Optional.of(lastPart.get());
    }
    
    
    
    private Optional<MainSpan> parseNote(ImmutableList.Builder<Span> children, 
            Pointer pointer, Optional<DirectoryId> id){
        ImmutableList.Builder<LinedSpanCite> sources = ImmutableList.builder();
        while (true){
            Optional<LinedSpanCite> source = LinedParseCite.INSTANCE.parse(children,
                pointer);
            if (source.isPresent()){
                sources.add(source.get());
            } else {
                pointer.mark();
                Optional<LinedSpan> found = LinedParseRest.NOTE.parse(pointer);
                if (! found.isPresent()){
                    return buildNote(pointer, children.build(), id, 
                        sources.build()); 
                } else if (((LinedSpanNote)found.get()).getId().isPresent()){
                    pointer.rollBack();
                    return buildNote(pointer, children.build(), id, 
                        sources.build());
                }
                children.add(found.get());
            }
            
        }
    }
    
    
    private Optional<MainSpan> buildNote(Pointer pointer, 
            ImmutableList<Span> children, Optional<DirectoryId> idFound, 
            ImmutableList<LinedSpanCite> sources){
        MainSpanNote ans = new MainSpanNote(children, idFound, sources);
        idFound.ifPresent(id -> pointer.getMap().addId(id, ans));
        return Optional.of(ans);
    }
}
