package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@linkplain FormatSpanCurly} for id referance. This has a span where it is
 * reference to
 */
public final class FormatSpanCurlyDirectory extends FormatSpanCurly 
        implements DirectoryHolder {
    private final DirectoryType type;
    private final Optional<DirectoryId> refSpan;
    
    FormatSpanCurlyDirectory(List<Span> children, Optional<DirectorySpan> refData, 
            DirectoryType curlyType){
        super(children);
        type = curlyType;
        refSpan = DirectorySpan.getDirectoryHelper(refData);
    }
    
    public DirectoryType getType(){
        return type;
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return refSpan;
    }
    
    public Optional<Span> getSpan(){
        return getTarget(getDocument());
    }
}
