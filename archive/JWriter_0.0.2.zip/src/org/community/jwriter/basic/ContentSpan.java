package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} for text and super class of {@link FormatSpanContent}.
 */
public class ContentSpan extends SpanBranch{
    
    private final boolean spaceBegin;
    private final boolean spaceEnd;
    private final String output;
    
    ContentSpan(){
        super(new ArrayList<>());
        output = "";
        spaceBegin = false;
        spaceEnd = false;
    }
    
    ContentSpan (List<Span> children){
        super(children);
        
        /// Create a display output text
        StringBuilder builder = new StringBuilder();
        for(Span child: children){
            if (child instanceof SpanLeaf){
                /// Add text from a basic span
                builder.append(child.getRaw());
            } else {
                /// Add escape text but only for the second span.
                SpanBranch escape = (SpanBranch) child;
                if (escape.size() == 2){
                    builder.append(escape.get(1).getRaw());
                }
            }
        }
        CharMatcher spaces = CharMatcher.whitespace();
        String tmp = builder.toString();
        if (tmp.isEmpty()){
            output = tmp;
            spaceBegin = false;
            spaceEnd = false;
        } else {
            spaceBegin = spaces.matches(tmp.charAt(0));
            spaceEnd = spaces.matches(tmp.charAt(builder.length() - 1));
            /// combine mutiple spaces into one.
            output = Joiner.on(" ").join(
                Splitter.on(spaces).omitEmptyStrings().split(tmp)
            );
        }
    }
    
    public String getOutput(){
        return output;
    }
    
    public boolean isSpaceBegin(){
        return spaceBegin;
    }
    
    public boolean isSpaceEnd(){
        return spaceEnd;
    }
}
