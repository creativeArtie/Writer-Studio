package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@linkplain FormatSpanCurly} for to do text. It will warn user when 
 * exporting while there are these {@link Span spans} still exists.
 */
public final class FormatSpanCurlyAgenda extends FormatSpanCurly {

    private final String agenda;
    
    FormatSpanCurlyAgenda(List<Span> children, Optional<ContentSpan> agendaText){
        super(children);
        agenda = agendaText.isPresent()? agendaText.get().getOutput() : "";
    }
    
    public String getAgenda(){
        return agenda;
    }

}
