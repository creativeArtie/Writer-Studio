package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseCite implements Parser<LinedSpanCite> {
    INSTANCE;
    
    private LinedSpanCite parseNamed(ImmutableList.Builder<Span> children, 
            Pointer pointer, LinedTypeSource type){
        Optional<ContentSpan> lastName = new ContentParser(LINED_NAME)
            .parse(children, pointer);
        Optional<ContentSpan> firstName = Optional.empty();
        if (pointer.startsWith(children, LINED_NAME)){
            firstName = new ContentParser().parse(children, pointer);
        }
        pointer.startsWith(children, LINED_END);
        return new LinedSpanCiteName(children.build(), type, lastName, 
            firstName);
    }
    
    private LinedSpanCite parseBasic(ImmutableList.Builder<Span> children, 
            Pointer pointer, LinedTypeSource type){
        Optional<ContentSpan> content = new ContentParser().parse(children,
            pointer);
        pointer.startsWith(children, LINED_END);
        return new LinedSpanCiteText(children.build(), type, content);
    }
    
    public Optional<LinedSpanCite> parse(Pointer pointer){
        ImmutableList.Builder<Span> children = ImmutableList.builder();
        
        if (pointer.startsWith(children, LINED_SOURCE)){
            
            for (LinedTypeSource t: LinedTypeSource.values()){
                
                if (pointer.trimStartsWith(children, t.getCode())){
                    pointer.trimStartsWith(children, LINED_DATA);
                    if( t.ordinal() > LinedTypeSource.TRANSLATOR.ordinal()){
                        return Optional.of(parseBasic(children, pointer, t));
                    } else {
                        return Optional.of(parseNamed(children, pointer, t));
                    }
                }
            }
            return Optional.of(parseBasic(children, pointer, 
                LinedTypeSource.ERROR));
        }
        return Optional.empty();
    }
}
