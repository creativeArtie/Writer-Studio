package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} for text and super class of {@link FormatSpanContent}.
 */
public class ContentSpanEscape extends SpanBranch{
    public String text;
    
    public ContentSpanEscape(List<Span> children){
        super(children);
        text = children.size() == 2? children.get(1).getRaw(): "";
    }
    
    public String getEscape(){
        return text;
    }
}
