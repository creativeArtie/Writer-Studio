package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanParagraph extends LinedSpan {
    private final FormatSpan text;

    LinedSpanParagraph(List<Span> children, Optional<FormatSpan> textSpan){
        super(children, LinedType.PARAGRAPH);
        text = textSpan.isPresent()? textSpan.get(): new FormatSpan();
    }
    
    public FormatSpan getText(){
        return text;
    }
}
