package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.MainTest.*;

@RunWith(JUnit4.class)
public class MainSectionDebug extends MainTest{
    @Test
    public void empty(){
        assertTrue("Document is not empty.", 
            new Document("", parsers()).getRaw().isEmpty());
    }
    
    @Test
    public void simple(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> lines = new ArrayList<>();
        addLine(lines, LinedType.PARAGRAPH, "abc", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(lines));
        addLine(section, lines);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        sectionLinks(base.get(0));
    }
    @Test
    public void allSectionLines(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> lines = new ArrayList<>();
        addLine(lines, LinedType.QUOTE, ">", "qoute", "\n");
        addLine(lines, LinedType.NUMBERED, "#", "numbered", "\n");
        addLine(lines, LinedType.BULLET, "-", "bullet", "\n");
        addLine(lines, LinedType.HYPERLINK, "!@", "hyperlink", ":", 
            "http://google.com", "\n");
        addLine(lines, LinedType.FOOTNOTE, "!^", "footnote", ":", " many text", 
            "\n");
        addLine(lines, LinedType.ENDNOTE, "!*", "endnote", ":", " text", "\n");
        addLine(lines, LinedType.AGENDA, "!!", "agenda", "\n");
        addLine(lines, LinedType.BREAK, "***\n");
        addLine(lines, LinedType.PARAGRAPH, "abc", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(lines));
        addLine(section, lines);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        sectionLinks(base.get(0));
    }
    
    @Test
    public void list(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> lines = new ArrayList<>();
        addLine(lines, LinedType.NUMBERED, "#", " abc", "\n");
        addLine(lines, LinedType.NUMBERED, "#", " ccc", "\n");
        addLine(lines, LinedType.NUMBERED, "#", "dead", "\n");
        addLine(lines, LinedType.NUMBERED, "\t#", "win", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(lines));
        addLine(section, lines);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        sectionLinks(base.get(0));
    }
    
    @Test
    public void emptyToHeading(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.QUOTE, ">", "quote", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.HEADING, "=", "next!", "\n");
        addLine(raw2, LinedType.PARAGRAPH, "explain..", "\n");
        section = new SpanExpect(sectionHelp(raw2));
        addLine(section, raw2);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        sectionLinks(base.get(0));
        
        Span span = base.get(1);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(1), span, null, null);
    }
    
    @Test
    public void emptyToOutline(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.FOOTNOTE, "!^", "first", ":", 
            " before text? Really?", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.OUTLINE, "!#", "before all", "\n");
        addLine(raw2, LinedType.PARAGRAPH, "show me the footnote{^first}", 
            "\n");
        section = new SpanExpect(sectionHelp(raw2));
        addLine(section, raw2);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        sectionLinks(base.get(0));
        
        Span span = base.get(1);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(1), null, span, null);
    }
    
    @Test
    public void header(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw = new ArrayList<>();
        addLine(raw, LinedType.HEADING, "===", "abc", "\n");
        addLine(raw, LinedType.AGENDA, "!!", "To do line is part of section:).");
        SpanExpect section = new SpanExpect(sectionHelp(raw));
        addLine(section, raw);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        
        Span span = base.get(0);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(0), span, null, null);
    }
    
    @Test
    public void outline(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw = new ArrayList<>();
        addLine(raw, LinedType.OUTLINE, "!#", "manuscript", "\n");
        addLine(raw, LinedType.HYPERLINK, "!@", "link", ":", "/dev/null", "\n");
        addLine(raw, LinedType.NUMBERED, "#", "link to the {@ link|best part}", 
            "\n");
        addLine(raw, LinedType.NUMBERED, "#", "win me! ", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw));
        addLine(section, raw);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        
        Span span = base.get(0);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(0), null, span, null);
    }
    
    @Test
    public void multiOutline(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.OUTLINE, "!#", "abc", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.OUTLINE, "!#", "next!", "\n");
        addLine(raw2, LinedType.PARAGRAPH, "be mine", "\n");
        section = new SpanExpect(sectionHelp(raw2));
        addLine(section, raw2);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        
        Span span = base.get(0);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(0), null, span, null);
        span = base.get(1);
        span = ((SpanBranch)span).get(0);
        sectionLinks(base.get(1), null, span, null);
    }
    
    @Test
    public void headAndPoint(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.HEADING, "===", "abc", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.OUTLINE, "!#", "section", "\n");
        addLine(raw2, LinedType.NUMBERED, "\t\t\t\t#", "See you!", "\n");
        section = new SpanExpect(sectionHelp(raw2));
        addLine(section, raw2);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        
        Span heading = base.get(0);
        heading = ((SpanBranch)heading).get(0);
        sectionLinks(base.get(0), heading, null, null);
        
        Span outline = base.get(1);
        outline = ((SpanBranch)outline).get(0);
        sectionLinks(base.get(1), heading, outline, null);
    }
    
    @Test
    public void twoSections(){
        SpanExpect doc = new SpanExpect();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.HEADING, "=", "1st topic", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.OUTLINE, "!#", "   ", "#STUB", "\n");
        section = new SpanExpect(sectionHelp(raw2));
        addLine(section, raw2);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw3 = new ArrayList<>();
        addLine(raw3, LinedType.HEADING, "=", "2nd topic", "\n");
        section = new SpanExpect(sectionHelp(raw3));
        addLine(section, raw3);
        doc.addChild(section);
        
        Document base = doc.testAll(parsers());
        
        Span heading = base.get(0);
        heading = ((SpanBranch)heading).get(0);
        sectionLinks(base.get(0), heading, null, null);
        
        Span outline = base.get(1);
        outline = ((SpanBranch)outline).get(0);
        sectionLinks(base.get(1), heading, outline, null);
        
        heading = base.get(2);
        heading = ((SpanBranch)heading).get(0);
        sectionLinks(base.get(2), heading, null, null);
    }
}
