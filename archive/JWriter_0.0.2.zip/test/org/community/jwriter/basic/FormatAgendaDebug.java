package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatAgendaDebug{
    
    public static final SpanExpectHelper agendaHelp(String text){
        return span ->{
            assertEquals("Wrong span class", FormatSpanCurlyAgenda.class, 
                span.getClass());
            FormatSpanCurlyAgenda test = (FormatSpanCurlyAgenda) span;
            assertEquals("Wrong id.", text, test.getAgenda());
        };
    }
    
    private static final Parser[] parsers = new Parser[]{
        FormatParseCurly.AGENDA};

    @Test
    public void complete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("AGENDAa"));
        agenda.addChild("{!");
        agenda.addChild("AGENDA\\a");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void noEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("abc"));
        agenda.addChild("{!");
        agenda.addChild("abc");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void onlyStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp(""));
        agenda.addChild("{!");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
}
    
