package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelRestDebug extends LinedLevelTest{
    
    @Test
    public void heading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Text\\#abc", 
            LinedType.HEADING, 3, EditionType.DRAFT, new String[]{"link"}, 
            "id"));
        line.addChild( "===", "@", "id", ":", "Text\\#abc", "#DRAFTabc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void outline(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Text abc", LinedType.OUTLINE, 
            1, EditionType.DRAFT, new String[]{"link"}, "id"));
        line.addChild( "!#", "@", "id", ":", "Text abc", "#DRAFTabc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void quote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.QUOTE, 2));
        line.addChild( ">>", "@id:Text abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void numbered(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.NUMBERED, 5));
        line.addChild( "\t\t\t\t#", "@id:Text abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptyBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("", LinedType.BULLET, 1));
        line.addChild("-", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void fullBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.BULLET, 1));
        line.addChild( "-", "@id:Text abc", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.BULLET, 1));
        line.addChild( "-", "@id:Text abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.BULLET, 6));
        line.addChild( "\t\t\t\t\t-", "@id:Text abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
