package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class IDStateDebug extends IDParamTest{
    @Test
    public void test() {
        boolean isFrist = true;
        for (States state: input){
            DirectoryId input = new DirectoryId(new ArrayList<>(), "abc");
            if (state == States.ID){
                if(!isFrist){
                    addId(input);
                } else {
                    addId(input, expected, 0);
                }
            } else {
                if(!isFrist){
                    addRef(input);
                } else {
                    addRef(input, expected, 0);
                }
            }
            isFrist = false;
        }
        testAll();
    }
}
