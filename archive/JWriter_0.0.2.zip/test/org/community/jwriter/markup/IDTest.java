package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.Set;

import org.community.jwriter.basic.*;

public class IDTest{
    private ArrayList<Integer> order;
    private ArrayList<DirectoryId> idList;
    private ArrayList<DirectoryStatus> errors;
    private DirectoryMap.Builder builder;
    
    public IDTest(){
        builder = DirectoryMap.builder();
        idList = new ArrayList<>();
        errors = new ArrayList<>();
        order = new ArrayList<>();
    }
    
    private static SpanLeaf filler;
    
    private static SpanLeaf tmpSpan(){
        if (filler == null){
            filler = new SpanLeaf(new Pointer(new Document("", new Parser[0])));
        }
        return filler;
    }
    
    public void addId(DirectoryId id, DirectoryStatus outcome, int i){
        addId(id);
        add(id, outcome, i);
    }
    
    public void addId(DirectoryId id, int i){
        addId(id, DirectoryStatus.UNUSED, i);
    }
    
    public void addId(DirectoryId id){
        builder.addId(id, tmpSpan());
    }
    
    public void add(DirectoryId id, DirectoryStatus outcome, int i){
        idList.add(id);
        errors.add(outcome);
        order.add(i);
    }
    
    public void addRef(DirectoryId id, DirectoryStatus outcome, int i){
        addRef(id);
        add(id, outcome, i);
    }
    
    public void addRef(DirectoryId id){
        builder.addRef(id, tmpSpan());
    }
    
    public void testAll(){
        testAll(false, null);
    }
    
    public void testAll(boolean printOrder){
        testAll(printOrder, null);
    }
    
    public void testAll(Document doc){
        testAll(false, doc);
    }
    
    public void testAll(boolean printOrder, Document doc){
        DirectoryMap system = doc == null? builder.build(): doc.getMap();
        
        Set<Entry<DirectoryId,DirectoryData>> entries = system.entrySet();
        if (printOrder) {
            System.out.println(system.keySet());
        }
        int i = 0;
        assertEquals("Wrong key size", idList.size(), entries.size());
        for (Entry<DirectoryId, DirectoryData> entry: entries){
            int idx = order.indexOf(i);
            assertEquals("Wrong span order at " + idx, idList.get(idx), 
                entry.getKey());
            assertEquals("Wrong id status at " + idx, 
                errors.get(idx), entry.getValue().getState());
            i++;
        }
    }
}
