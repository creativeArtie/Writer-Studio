package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import org.community.jwriter.basic.*;

public class OutputCursorDebug{
    private Document doc;
    
    private static String[] spans = {
        "=", "@", "Chapter 1", ":", " Story of nobody", "\n",
        "#", "An outline thing.", "\n",
        "See me fly", "{^", "random footnote", "}", "\n",
        "!^", "footnote", ":", "text for the foot note", "\n",
        "!%", "Add some random note", "\n",
        "Paragraph ", "*", "continue", "*", " from above", "\n",
        "=", "@", "Chapter 2", ":", " More ", "#STUB", " abc", "\\", "d", "ee"
    };
    
    @Before
    public void buildDocument(){
        doc = MainTest.build(String.join("", spans));
    }
    
    @Test
    public void intialStart(){
        OutputCursor cursor = new OutputCursor(doc);
        SpanBranch span =      doc.get(doc.size() - 1);/// Section
        span = (SpanBranch)(span).get(span.size() - 1);/// Heading
        span = (SpanBranch)(span).get(span.size() - 1);/// Status
        span = (SpanBranch)(span).get(span.size() - 1);/// Content
        Object current =   (span).get(span.size() - 1);/// child
        assertSame(current, cursor.getCurrentSpan());
    }
    
    @Test
    public void midStart(){
        OutputCursor cursor = new OutputCursor(doc, 40);
        SpanBranch span =     doc.get(0);/// Section
        span = (SpanBranch)(span).get(1);/// Paragraph
        span = (SpanBranch)(span).get(1);/// Format 
        span = (SpanBranch)(span).get(0);/// Content
        assertSame(span.get(0), cursor.getCurrentSpan());
    }
    
    @Test
    public void shiftForwards(){
        OutputCursor cursor = new OutputCursor(doc, 0);
        for (String expect: spans){
            for(int i = 0; i < expect.length(); i++){
                cursor.shift(1);
                assertEquals("Wrong span for(" + i + ": " + expect,
                    expect, cursor.getCurrentSpan().getRaw());
            }
        }
    }
    
    @Test
    public void shiftBackwards(){
        OutputCursor cursor = new OutputCursor(doc);
        for (int i = spans.length - 1; i > 0; i--){
            String expect = spans[i];
            for(int j = 0; j < expect.length(); j++){
                cursor.shift(-1);
                assertEquals("Wrong span for(" + j + ": " + expect,
                    expect, cursor.getCurrentSpan().getRaw());
            }
        }
    }
    
    @Test
    public void shiftBackwardsTwice(){
        OutputCursor cursor = new OutputCursor(doc, 63);
        cursor.shift(-11);
        SpanBranch span =     doc.get(0);/// Section
        span = (SpanBranch)(span).get(2);/// Paragraph
        span = (SpanBranch)(span).get(0);/// Format 
        span = (SpanBranch)(span).get(0);/// Content
        assertSame(span.get(0), cursor.getCurrentSpan());
        
        cursor.shift(-48);
        span =                doc.get(0);/// Section
        span = (SpanBranch)(span).get(0);/// Paragraph
        span = (SpanBranch)(span).get(2);/// Format
        span = (SpanBranch)(span).get(0);/// Id
        assertSame(span.get(0), cursor.getCurrentSpan());
    }
    
    @Test
    public void shiftForwardsTwice(){
        OutputCursor cursor = new OutputCursor(doc, 150);
        cursor.shift(8);
        SpanBranch span =     doc.get(2);/// Section
        span = (SpanBranch)(span).get(0);/// Paragraph
        span = (SpanBranch)(span).get(0);/// Format 
        span = (SpanBranch)(span).get(4);/// Content
        assertSame(span.get(0), cursor.getCurrentSpan());
        
        cursor.shift(23);
        span =                doc.get(3);/// Section
        span = (SpanBranch)(span).get(0);/// Paragraph
        span = (SpanBranch)(span).get(4);/// Format
        span = (SpanBranch)(span).get(0);/// Content
        assertSame(span.get(0), cursor.getCurrentSpan());
    }
}
