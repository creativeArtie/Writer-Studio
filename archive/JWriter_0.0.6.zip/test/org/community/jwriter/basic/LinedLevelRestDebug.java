package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelRestDebug extends LinedLevelTest{
    
    @Test
    public void heading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("W_Under_", LinedType.HEADING, 
            3, EditionType.OTHER, new String[]{"link", "sub"}, "id"));

        line.addChild("===", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        line.addChild("@", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("sub", "Basic:all;Heading:lined;text:tmp;warning:tmp;");
        id.addChild("-", "Basic:all;Heading:lined;keyword:tmp;override:true;warning:tmp;");
        id.addGrandchild("id", "Basic:all;Heading:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("W", "Basic:all;Heading:lined;text:tmp;");
        format.addChild("_", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        format.addGrandchild("Under", "Basic:all;Heading:lined;text:tmp;underline:tmp;");
        format.addChild("_", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        line.addChild(format);
        
        SpanExpect status = new SpanExpect();
        status.addChild("#", "Basic:all;Heading:lined;final:tmp;keyword:tmp;override:true;");
        status.addGrandchild("abc", "Basic:all;Heading:lined;final:tmp;text:tmp;");
        line.addChild(status);
        
        line.addChild("\n", "Basic:all;Heading:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void outline(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Text abc", LinedType.OUTLINE, 
            1, EditionType.DRAFT, new String[]{"link"}, "id"));

        line.addChild("!#", "Basic:all;Outline:lined;keyword:tmp;override:true;");
        line.addChild("@", "Basic:all;Outline:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("id", "Basic:all;Outline:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Outline:lined;keyword:tmp;override:true;");
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("Text abc", "Basic:all;Outline:lined;text:tmp;");
        line.addChild(format);
        
        SpanExpect status = new SpanExpect();
        status.addChild("#DRAFT", "Basic:all;Outline:lined;draft:tmp;keyword:tmp;override:true;");
        status.addGrandchild("abc", "Basic:all;Outline:lined;draft:tmp;text:tmp;");
        line.addChild(status);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void quote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.QUOTE, 2));
        line.addChild(">>", "Basic:all;Quote:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc", "Basic:all;Quote:lined;text:tmp;");
        line.addChild(text);
        
        line.addChild("\n", "Basic:all;Quote:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void numbered(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.NUMBERED, 5));
        line.addChild("\t\t\t\t#", "Basic:all;Numbered:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc", "Basic:all;Numbered:lined;text:tmp;");
        line.addChild(text);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptyBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("", LinedType.BULLET, 1));
        line.addChild("-", "Basic:all;Bullet:lined;keyword:tmp;override:true;");
        line.addChild("\n", "Basic:all;Bullet:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void fullBullet(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("@id:Text abc", 
            LinedType.BULLET, 1));
        line.addChild("-",  "Basic:all;Bullet:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("@id:Text abc",  "Basic:all;Bullet:lined;text:tmp;");
        line.addChild(text);
        
        line.addChild("\n", "Basic:all;Bullet:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("{@hello}", 
            LinedType.BULLET, 1));
        line.addChildren( "-", "{@hello}");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void bulletLevel6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(simpleHelp("aaa\\\nddd", 
            LinedType.BULLET, 6));
        line.addChildren( "\t\t\t\t\t-", "aaa\\\nddd");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
