package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class EditionDebug {

    public static final SpanExpectHelper statusHelp(EditionType type, 
            String text){
        return span ->{
            assertEquals("Wrong class gotten: " + span.getClass(), 
                EditionSpan.class, span.getClass());
            EditionSpan test = (EditionSpan) span;
            assertEquals("Wrong type.", type, test.getType());
            assertEquals("Wrong detail.", text, test.getDetail());
        };
    }
    
    private static final InputParser[] parsers = EditionParser.values();
    
    @Test
    public void statusOtherBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "abc"));
        ref.addChild("#", "Basic:all;final:tmp;keyword:tmp;override:true;");
        ref.addGrandchild("abc", "Basic:all;final:tmp;text:tmp;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusEscaped(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "FINAL"));
        ref.addChild("#");
        ref.addChild("\\FINAL");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusStub(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.STUB, "d2"));
        ref.addChild("#STUB", "Basic:all;keyword:tmp;override:true;stub:tmp;");
        ref.addGrandchild("d2", "Basic:all;stub:tmp;text:tmp;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, ""));
        ref.addChild("#FINAL", "Basic:all;final:tmp;keyword:tmp;override:true;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalTrim(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "2"));
        ref.addChild("#FINAL", "Basic:all;final:tmp;keyword:tmp;override:true;");
        ref.addGrandchild("  2  ", "Basic:all;final:tmp;text:tmp;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalMidSpanced(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "abc ad"));
        ref.addChildren("#FINAL", "abc  ad");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusDraft(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(EditionType.DRAFT, "ccc"));
        ref.addChild("#DRAFT");
        SpanExpect text = new SpanExpect();
        text.addChild("cc", "Basic:all;draft:tmp;text:tmp;");
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", "Basic:all;draft:tmp;escape:tmp;keyword:tmp;override:true;");
        escape.addChild("c", "Basic:all;draft:tmp;escape:tmp;override:false;text:tmp;");
        text.addChild(escape);
        ref.addChild(text);
        doc.addChild(ref);
        doc.testAll(parsers);
    }

}
