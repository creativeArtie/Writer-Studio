package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedCiteDebug {
    
    public static final SpanExpectHelper textHelp(LinedCite expectedType, 
        String expectedOutput)
    {
        return span -> {
            LinedCiteData child = basicHelp(span, expectedType, 
                expectedOutput != null);
            if(expectedOutput != null){
                assertEquals("Wrong citation class." + child, 
                    LinedCiteDataText.class, child.getClass());
                LinedCiteDataText test = (LinedCiteDataText) child;
                assertEquals("Wrong text: " + test, expectedOutput, 
                    test.get().getText());
            }
        };
    }
    
    public static final SpanExpectHelper formatHelp(LinedCite expectedType, 
        String expectedOutput)
    {
        return span -> {
            LinedCiteData child = basicHelp(span, expectedType, 
                expectedOutput != null);
            if(expectedOutput != null){
                assertEquals("Wrong citation class." + child, 
                    LinedCiteDataFormatted.class, child.getClass());
                LinedCiteDataFormatted test = (LinedCiteDataFormatted) child;
                assertEquals("Wrong text: " + span, expectedOutput, 
                    test.get().getRaw());
            }
        };
    }
    
    public static final SpanExpectHelper errorHelp(){
        return span -> basicHelp(span, LinedCite.ERROR, false);
    }
    
    public static final SpanExpectHelper numberHelp(LinedCite expectedType, 
        int expectedOutput)
    {
        return span -> {
            LinedCiteData child = basicHelp(span, expectedType, true);
            assertEquals("Wrong citation class." + child, 
                LinedCiteDataNumber.class, child.getClass());
            assertEquals("Wrong number: " + child, expectedOutput, child.get());
        };
    }
    
    public static final SpanExpectHelper numberHelp(LinedCite expectedType)
    {
        return span -> {
            LinedCiteData child = basicHelp(span, expectedType, false);
        };
    }
    
    public static final LinedCiteData basicHelp(Span span, 
        LinedCite expectedType, boolean hasResult
    ){
        assertEquals("Wrong class.", LinedSpanCite.class, span.getClass());
        LinedSpanCite test = (LinedSpanCite) span;
        assertEquals("Wrong line type.", LinedType.SOURCE, test.getType());
        assertEquals("Wrong source field.", expectedType, test.getField());
        if (hasResult){
            Optional<? extends LinedCiteData> data = test.getData();
            assertTrue("Ready is not set " + test, test.isReady());
            assertTrue("Data is not found: " + test, data.isPresent());
            return data.get();
        }
        assertFalse("Data is found: " + span, test.getData().isPresent());
        assertFalse("Ready is set: " + span, test.isReady());
        return null;
    }
    
    private static final InputParser[] parsers = new InputParser[]{
            LinedParseCite.INSTANCE};
            
    
    @Test
    public void part1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedCite.IN_TEXT, "a"));
        line.addChild("!>", "Basic:all;Source:lined;keyword:tmp;override:true;");
        line.addChild("in-text", "Basic:all;Source:lined;field:tmp;");
        line.addChild(":", "Basic:all;Source:lined;keyword:tmp;override:true;");
        
        SpanExpect data = new SpanExpect();
        data.addGrandchild("a", "Basic:all;Source:lined;data:tmp;");
        line.addChild(data);
        
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part2(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", ":a", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part3(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedCite.IN_TEXT, null));
        line.addChildren("!>", "in-text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part4(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedCite.IN_TEXT, null));
        line.addChildren("!>", "in-text");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part5(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedCite.IN_TEXT, "see"));
        line.addChildren("!>", "in-text", "see");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChild("!>", "Basic:all;Source:lined;cite:error;keyword:tmp;override:true;");
        line.addGrandchild("sdaf", "Basic:all;Source:lined;cite:error;text:tmp;");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part7(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf:", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part8(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf:aaa", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part9(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(errorHelp());
        line.addChildren("!>", "sdaf:");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void format(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(formatHelp(LinedCite.SOURCE, "abc\\\\"));
        line.addChildren("!>", "source", ":", "abc\\\\");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(textHelp(LinedCite.FOOTNOTE, "abc\\"));
        line.addChildren("!>", "footnote", ":", "abc\\\\");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pages(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedCite.PAGES, 6));
        line.addChild("!>", "Basic:all;Source:lined;keyword:tmp;override:true;");
        line.addChild("pages", "Basic:all;Source:lined;field:tmp;");
        line.addChild(":", "Basic:all;Source:lined;keyword:tmp;override:true;");
        
        SpanExpect data = new SpanExpect();
        data.addChild(" 6", "Basic:all;Source:lined;data:tmp;");
        data.addChild("     ", "Basic:all;Source:lined;data:tmp;");
        line.addChild(data);
        
        line.addChild("\n", "Basic:all;Source:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pagesError(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(numberHelp(LinedCite.PAGES));
        line.addChild("!>", "Basic:all;Source:lined;cite:error;keyword:tmp;override:true;");
        line.addChild("pages", "Basic:all;Source:lined;cite:error;field:tmp;");
        line.addChild(":", "Basic:all;Source:lined;cite:error;keyword:tmp;override:true;");
        SpanExpect data = new SpanExpect();
        data.addChild("abc", "Basic:all;Source:lined;cite:error;text:tmp;");
        line.addChild(data);
        doc.addChild(line);
        doc.testAll(parsers);
    }

}
