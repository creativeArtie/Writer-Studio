package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatLinkDebug {
    
    public static final SpanExpectHelper refHelp(String[] cat, String id,
            String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkRef.class, 
                span.getClass());
            FormatSpanLinkRef test = (FormatSpanLinkRef) span;
            assertArrayEquals("Wrong category.", cat, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
            testCommon(span, path, text);
        };
    }
    
    public static final SpanExpectHelper linkHelp(String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkDirect.class, 
                span.getClass());
            testCommon(span, path, text);
        };
    }
        
    static void testCommon(Span span, String path, String text){
        FormatSpanLink test = (FormatSpanLink) span;
        assertEquals("Wrong link path", path, test.getPath());
        assertEquals("Wrong link text.", text, test.getText());
    }
    
    private static final InputParser[] parsers = FormatParseLink.getParsers(
        new boolean[4]);
    
    @Test
    public void refFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", "text"));
        ref.addChild("<@", "Basic:all;keyword:tmp;link:inline;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("cat", "Basic:all;error:tmp;link:inline;text:tmp;");
        id.addChild("-", "Basic:all;error:tmp;keyword:tmp;link:inline;override:true;");
        id.addGrandchild("id", "Basic:all;error:tmp;link:inline;text:tmp;");
        ref.addChild(id);
        
        ref.addChild("|", "Basic:all;keyword:tmp;link:inline;override:true;");
        ref.addGrandchild("text", "Basic:all;link:inline;text:tmp;");
        ref.addChild(">", "Basic:all;keyword:tmp;link:inline;override:true;");
        
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refEmptyText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChildren("<@","cat-id", "|", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refNoText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChildren("<@", "cat-id", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    @Test
    public void refNoCategory(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", "text"));
        ref.addChildren("<@", "id", "|", "text", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", ""));
        ref.addChildren("<@", "id", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refEmpty(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[0], "", "", ""));
        ref.addChild("<@", "Basic:all;error:tmp;keyword:tmp;link:inline;override:true;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
        
    
    @Test
    public void linkFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        
        ref.addChild("<", "Basic:all;keyword:tmp;link:inline;override:true;");
        ref.addGrandchild("path", "Basic:all;link:inline;path:tmp;");
        ref.addChild("|", "Basic:all;keyword:tmp;link:inline;override:true;");
        ref.addGrandchild("text", "Basic:all;link:inline;text:tmp;");
        ref.addChild(">", "Basic:all;keyword:tmp;link:inline;override:true;");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkPath(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "path"));
        ref.addChildren("<", "path", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("", ""));
        ref.addChild("<");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        ref.addChildren("<", "path", "|", "text");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
}
