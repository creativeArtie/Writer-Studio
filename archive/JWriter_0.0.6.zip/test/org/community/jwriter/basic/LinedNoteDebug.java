package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedNoteDebug {

    private final InputParser[] parsers = new InputParser[]{LinedParseRest.NOTE};
        
    public static final SpanExpectHelper noteHelp(String text, 
            String[] category, String id){
        return span ->{
            assertEquals(LinedSpanNote.class, span.getClass());
            LinedSpanNote test = (LinedSpanNote) span;
            assertEquals("Wrong text.", text, test.getFormatted().getRaw());
            assertEquals("Wrong type.", LinedType.NOTE, test.getType());
            assertArrayEquals("Wrong category.", category, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
        };
    }
    
    @Test
    public void noteComplete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", new String[]{"note"}, 
            "id"));
        line.addChild("!%", "Basic:all;Note:lined;keyword:tmp;override:true;");
        line.addChild("     @", "Basic:all;Note:lined;keyword:tmp;override:true;");
        
        line.addChildren("id"); /// Note does not create id
        
        line.addChild(":", "Basic:all;Note:lined;keyword:tmp;override:true;");
        
        SpanExpect format = new SpanExpect();
        format.addGrandchild("Text", "Basic:all;Note:lined;text:tmp;");
        line.addChild(format);
        
        line.addChild("\n", "Basic:all;Note:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noteWithoutNewLine(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", new String[]{"note"}, 
            "id"));
        line.addChildren( "!%", "     @", "id", ":", "Text");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void note(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", new String[]{"note"}, 
            "id"));
        line.addChildren( "!%", "@", "id", ":", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("", new String[]{"note"}, 
            "id"));
        line.addChildren( "!%", "@", "id", ":", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noColon(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("", new String[]{"note"}, 
            "id"));
        line.addChildren( "!%", "@", "id");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void blackID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", new String[0], ""));
        line.addChildren( "!%", "@", ":", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void noID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("Text", new String[0], ""));
        line.addChildren( "!%", "Text", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void startOnly(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("", new String[0], ""));
        line.addChild( "!%");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void startID(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp("", new String[0], ""));
        line.addChildren("!%", "@");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
