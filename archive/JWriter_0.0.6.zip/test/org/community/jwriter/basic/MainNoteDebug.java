package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Optional;
import java.util.TreeMap;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.MainTest.*;

@RunWith(JUnit4.class)
public class MainNoteDebug extends MainTest{
    
    
    
    @Test
    public void noIDStyle(){
        SpanExpect doc = new SpanExpect();
        
        SpanExpect section = new SpanExpect();
        SpanExpect line = new SpanExpect();
        line.addChild("!%", "Basic:all;Note:lined;error:tmp;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("abc", "Basic:all;Note:lined;error:tmp;text:tmp;");
        line.addChild(text);
        
        section.addChild(line);
        doc.addChild(section);
        doc.testAll(parsers());
    }
    
    @Test
    public void withIDStyle(){
        SpanExpect doc = new SpanExpect();
        
        SpanExpect section = new SpanExpect();
        SpanExpect line = new SpanExpect();
        line.addChild("!%", "Basic:all;Note:lined;keyword:tmp;override:true;");
        line.addChild("@", "Basic:all;Note:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("id", "Basic:all;Note:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Note:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("data", "Basic:all;Note:lined;text:tmp;");
        line.addChild(text);
        
        section.addChild(line);
        doc.addChild(section);
        doc.testAll(parsers());
    }
    
    @Test
    public void basic(){
        SpanExpect doc = new SpanExpect();
        TreeMap<LinedCite, String[]> sources = new TreeMap<>();
        
        ArrayList<MainTest.Helper> lines = new ArrayList<>();
        addLine(lines, LinedType.NOTE, 
            "!%", "@", "see", ":", "basic note", "\n");
        addLine(lines, sources, LinedCite.IN_TEXT, "Smith, p 3");
        SpanExpect section = new SpanExpect(noteHelp(lines, sources, 
            noteID("see")));
        addLine(section, lines);
        doc.addChild(section);
        
        doc.testAll(parsers());
    }
    
    @Test
    public void backToBackNotes(){
        SpanExpect doc = new SpanExpect();
        TreeMap<LinedCite, String[]> sources = new TreeMap<>();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.NOTE, "!%", " basic note", "\n");
        SpanExpect section = new SpanExpect(noteHelp(raw1, sources, null));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.NOTE, "!%", "@", "ed", ":", "data", "\n");
        section = new SpanExpect(noteHelp(raw2, sources, noteID("ed")));
        addLine(section, raw2);
        doc.addChild(section);
        
        doc.testAll(parsers());
    }
    
    @Test
    public void sources(){
        SpanExpect doc = new SpanExpect();
        TreeMap<LinedCite, String[]> sources = new TreeMap<>();
        
        ArrayList<MainTest.Helper> raw = new ArrayList<>();
        addLine(raw, LinedType.SOURCE, "!>", "dsaf", "\n");
        addLine(raw, sources, LinedCite.IN_TEXT, "Doe, p40", "Smith, p3");
        SpanExpect section = new SpanExpect(noteHelp(raw, sources, null));
        addLine(section, raw);
        doc.addChild(section);
        
        doc.testAll(parsers());
    }
    
    @Test
    public void noteMiddle(){
        SpanExpect doc = new SpanExpect();
        TreeMap<LinedCite, String[]> sources = new TreeMap<>();
        
        ArrayList<MainTest.Helper> raw1 = new ArrayList<>();
        addLine(raw1, LinedType.HEADING, "=", "Random text title", "\n");
        addLine(raw1, LinedType.PARAGRAPH, "Random text", "\n");
        SpanExpect section = new SpanExpect(sectionHelp(raw1));
        addLine(section, raw1);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw2 = new ArrayList<>();
        addLine(raw2, LinedType.NOTE, "!%", "text in middle", "\n");
        section = new SpanExpect(noteHelp(raw2, sources, null));
        addLine(section, raw2);
        doc.addChild(section);
        
        ArrayList<MainTest.Helper> raw3 = new ArrayList<>();
        addLine(raw3, LinedType.PARAGRAPH, "abc");
        section = new SpanExpect(sectionHelp(raw3));
        addLine(section, raw3);
        doc.addChild(section); 
        
        Document base = doc.testAll(parsers());
        Span heading = base.get(0);
        heading = ((SpanBranch)heading).get(0);
        Span last = base.get(0);
        sectionLinks(base.get(0), heading, null, null);
        sectionLinks(base.get(2), heading, null, last);
    }
}
