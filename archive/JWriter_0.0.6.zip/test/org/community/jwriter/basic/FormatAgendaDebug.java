package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatAgendaDebug{
    
    public static final SpanExpectHelper agendaHelp(String text){
        return span ->{
            assertEquals("Wrong span class", FormatSpanAgenda.class, 
                span.getClass());
            FormatSpanAgenda test = (FormatSpanAgenda) span;
            assertEquals("Wrong id.", text, test.getAgenda());
        };
    }
    
    private static final InputParser[] parsers = new InputParser[]{
        FormatParseAgenda.PARSER};

    @Test
    public void complete(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("AGENDA}"));
        agenda.addChild("{!", "Basic:all;agenda:tmp;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addChild("AGENDA", "Basic:all;agenda:tmp;text:tmp;");
        
        SpanExpect escape = new SpanExpect();
        escape.addChild("\\", "Basic:all;agenda:tmp;escape:tmp;keyword:tmp;override:true;");
        escape.addChild("}", "Basic:all;agenda:tmp;escape:tmp;override:false;text:tmp;");
        text.addChild(escape);
        
        agenda.addChild(text);
        
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void noEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp("abc"));
        agenda.addChildren("{!", "abc");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
    
    @Test
    public void onlyStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(agendaHelp(""));
        agenda.addChild("{!");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
}
    
