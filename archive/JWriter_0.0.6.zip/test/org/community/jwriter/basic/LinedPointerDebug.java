package org.community.jwriter.basic;


import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class LinedPointerDebug{
    
    private final InputParser[] parsers = LinedParsePointer.values();
        
    public static final SpanExpectHelper linkHelp(DirectoryType idType, 
            LinedType type, String id, String path){
        return span ->{
            assertEquals("Wrong class.", LinedSpanPointLink.class, 
                span.getClass());
            LinedSpanPointLink test = (LinedSpanPointLink) span;
            testCommon(test, idType, type, id);
            assertEquals("Wrong path.", path, test.getPath());
        };
    }
    
    public static final SpanExpectHelper noteHelp(DirectoryType idType, 
            LinedType type, String id, String docText){
        return span ->{
            assertEquals("Wrong class.", LinedSpanPointNote.class, 
                span.getClass());
            LinedSpanPointNote test = (LinedSpanPointNote) span;
            testCommon(test, idType, type, id);
            assertEquals("Wrong text.", docText, test.getFormatted().getRaw());
        };
    }
    
    private static void testCommon(LinedSpanPoint test, DirectoryType idType, 
            LinedType type, String id){
        assertEquals("Wrong DirectoryId type.", idType, test.getDirectoryType());
        assertEquals("Wrong line type.", type, test.getType());
        String[] category = idType == DirectoryType.NONE? new String[0] :
            new String[]{idType.getCategory()};
        assertArrayEquals("Wrong category.", category, test.getCategory());
        assertEquals("Wrong id.", id, test.getIdentity());
    }
    
    @Test
    public void linkFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", "test"));
        line.addChild("!@", "Basic:all;Hyperlink:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", "Basic:all;Hyperlink:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Hyperlink:lined;keyword:tmp;override:true;");
        line.addGrandchild("test", "Basic:all;Hyperlink:lined;path:tmp;");
        line.addChild("\n", "Basic:all;Hyperlink:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", "test"));
        line.addChildren("!@", "abc", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkPathLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", ""));
        line.addChildren("!@", "abc", ":");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkColonLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.LINK, 
            LinedType.HYPERLINK, "abc", ""));
        line.addChildren("!@", "abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoId(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(linkHelp(DirectoryType.NONE, 
            LinedType.HYPERLINK, "", "test"));
        line.addChildren("!@", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", "test**hello**"));
        line.addChild("!*", "Basic:all;Endnote:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", "Basic:all;Endnote:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Endnote:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("test", "Basic:all;Endnote:lined;text:tmp;");
        text.addChild("**", "Basic:all;Endnote:lined;keyword:tmp;override:true;");
        text.addGrandchild("hello", "Basic:all;Endnote:lined;bold:tmp;text:tmp;");
        text.addChild("**", "Basic:all;Endnote:lined;keyword:tmp;override:true;");
        
        line.addChild(text);
        line.addChild("\n", "Basic:all;Endnote:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    
    @Test
    public void endnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", "test"));
        line.addChildren("!*", "abc", ":", "test");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteTextLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", ""));
        line.addChildren("!*", "abc", ":");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteColonLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.ENDNOTE, 
            LinedType.ENDNOTE, "abc", ""));
        line.addChildren("!*", "abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void endnoteIDlLess(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.NONE, 
            LinedType.ENDNOTE, "", "test"));
        line.addChildren("!*", ":", "test", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(noteHelp(DirectoryType.FOOTNOTE, 
            LinedType.FOOTNOTE, "abc", "test"));
        line.addChild("!^", "Basic:all;Footnote:lined;keyword:tmp;override:true;");
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("abc", "Basic:all;Footnote:lined;text:tmp;warning:tmp;");
        line.addChild(id);
        
        line.addChild(":", "Basic:all;Footnote:lined;keyword:tmp;override:true;");
        
        SpanExpect text = new SpanExpect();
        text.addGrandchild("test", "Basic:all;Footnote:lined;text:tmp;");
        line.addChild(text);
        
        line.addChild("\n", "Basic:all;Footnote:lined;keyword:tmp;override:true;");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
