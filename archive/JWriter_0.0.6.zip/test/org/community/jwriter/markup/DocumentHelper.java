package org.community.jwriter.markup;

public class DocumentHelper extends Document{
    
    public DocumentHelper(){}
    
    public DocumentHelper(String doc, InputParser ... parsers){
        super(doc, parsers);
    }
    
    public static InputPointer createEmptyPointer(){
        return new InputPointer("", new DocumentHelper());
    }
}
