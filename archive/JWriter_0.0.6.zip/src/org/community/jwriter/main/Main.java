package org.community.jwriter.main;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import org.fxmisc.richtext.CodeArea;

public class Main extends Application{

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage window){
        WindowText.TITLE.addAndCall((resource, value) -> window.setTitle(value));
        CodeArea basic = new CodeArea();
        Scene tmp = new Scene(new CodeScene(), 600, 600);
        window.setScene(tmp);
        window.show();
    }
}
