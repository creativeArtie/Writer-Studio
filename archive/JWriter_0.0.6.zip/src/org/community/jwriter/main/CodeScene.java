package org.community.jwriter.main;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import org.fxmisc.richtext.InlineCssTextArea;

import org.community.jwriter.markup.*;
import org.community.jwriter.basic.BasicDocument;

public class CodeScene extends StackPane{
    private InlineCssTextArea writeArea;
    private Document doc;
    
    public CodeScene(){
        writeArea = new InlineCssTextArea("#Hello World!");
        writeArea.setStyle("-fx-highlight-fill: blue; -fx-font-weight: bold");
        writeArea.caretPositionProperty().addListener(
            (observable, oldValue, newValue) ->
            System.out.println(writeArea.getCaretPosition()));
        
        
        getChildren().add(writeArea);
    }
}
