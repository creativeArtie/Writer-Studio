package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Creates a text span upto a certain character.
 */
abstract class BasicTextParser<T extends Span> implements InputParser<T>{
    /// Describes how the Span will end
    private final ImmutableList<String> fullEnders;
    private final InputStyle style;
    
    public BasicTextParser(List<String> enders){
        this(InputStyle.TEXT, enders);
    }
    
    public BasicTextParser(InputStyle spanStyle, List<String> enders){
        this(spanStyle, enders.toArray(new String[0]));
    }
    
    public BasicTextParser(String ... enders){
        this(InputStyle.TEXT, enders);
    }
    
    public BasicTextParser(InputStyle spanStyle, String ... enders){
        /// combining text span enders with escape ender and new line.
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        builder.add(CHAR_ESCAPE);
        builder.add(LINED_END);
        for (String ender: enders){
            builder.add(ender);
        }
        fullEnders = builder.build();
        style = spanStyle;
    }
    
    @Override
    public Optional<T> parse(InputPointer pointer){
        /// Setup
        ArrayList<Span> children = new ArrayList<>();
        boolean hasMore = true;
        
        /// Extract the text
        do{
            pointer.getTo(children, style, fullEnders);
            Optional<SpanBranch> span = parseEscape(pointer);
            /// no more escape span = no more text to deal with
            if (! span.isPresent()){
                hasMore = false;
            } else {
                children.add(span.get());
            }
        } while (hasMore);
        
        /// Create span if there are Span extracted
        if (children.size() > 0) {
            return Optional.of(buildSpan(children, fullEnders));
        }
        return Optional.empty();
    }
    
    protected abstract T buildSpan(List<Span> children, List<String> enders);
    
    /// helper method for parse(InputPointer)
    private Optional<SpanBranch> parseEscape(InputPointer pointer){
        /// Setup 
        ArrayList<Span> children = new ArrayList<>();
        
        /// build Span if found
        if (pointer.startsWith(children, CHAR_ESCAPE)){
            pointer.nextChars(children, InputStyle.TEXT, 1);
            return Optional.of(new BasicTextEscape(children));
        }
        return Optional.empty();
    }
}
