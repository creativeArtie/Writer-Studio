package org.community.jwriter.basic;

import com.google.common.base.CaseFormat;
import static org.community.jwriter.basic.AtomicTerm.*;

public enum LinedType{
    HEADING, OUTLINE, QUOTE, NUMBERED, BULLET, HYPERLINK, FOOTNOTE, ENDNOTE,
    AGENDA, BREAK, NOTE, SOURCE, PARAGRAPH;
}
