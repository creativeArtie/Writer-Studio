package org.community.jwriter.basic;

import java.util.ArrayList; /// Use to create DirectoryID
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method

import com.google.common.base.CharMatcher;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedCiteDataNumber extends LinedCiteData<Integer>{
    
    public static final InputParser<LinedCiteDataNumber> PARSER = pointer -> {
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.trimMatches(children, CharMatcher.javaDigit())){
            Span child = children.get(0);
            int data = Integer.parseInt(
                CharMatcher.whitespace().trimFrom(children.get(0).getRaw())
            );
            pointer.matches(children, 
                CharMatcher.whitespace().and(
                    CharMatcher.isNot(LINED_END.charAt(0))
                )
            );
            return Optional.of(new LinedCiteDataNumber(children, data));
        }
        return Optional.empty();
    };
    
    private Integer data;
    
    public LinedCiteDataNumber cast(){
        return this;
    }
    
    public Integer get(){
        return data;
    }
    
    public Integer getText(){
        return data;
    }
    
    private LinedCiteDataNumber(List<Span> children, Integer input){
        super(children);
        data = input;
    }
}
