package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;


/**
 * A {@link Span} for stating the current status of a section with a heading or
 * an outline.
 */
public class EditionSpan extends SpanBranch{
    private final EditionType type;
    private final String detail;
    
    EditionSpan(List<Span> children, EditionType statusType, 
            Optional<ContentSpan> detailSpan){
        super(children);
        detail = detailSpan.isPresent()? detailSpan.get().getText(): "";
        type = statusType;
    }
    
    public EditionType getType(){
        return type;
    }
    
    public String getDetail(){
        return detail;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        ans.add(getEditionStyle(type));
        return ans;
    }
}
