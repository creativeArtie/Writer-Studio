package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List; /// For initialization (children)
import java.util.Optional;

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()
import com.google.common.base.Joiner;      /// To remove spaces
import com.google.common.base.Splitter;    /// To remove spaces

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Created from {@link ContentParser}, super class of 
 * {@link ContentSpanContent}. Used for whenever text is needed.
 */
public class ContentSpan extends SpanBranch implements BasicText{
    private List<String> enders;
    
    ContentSpan (List<Span> children, List<String> spanEnders){
        super(children);
        enders = spanEnders;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        return new ArrayList<>();
    }
    
    @Override
    public List<String> getEnders(){
        return enders;
    }
}
