package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link FormatSpanLink} with path located somewhere in the document.
 */
public final class FormatSpanLinkRef extends FormatSpanLink 
        implements DirectoryHolder{
    private final Optional<String> text;
    private final Optional<DirectoryId> idSpan;
    
    FormatSpanLinkRef(List<Span> children, boolean[] formats, 
            Optional<DirectorySpan> inputDirectory, Optional<ContentSpan> textSpan){
        super(children, formats);
        idSpan = DirectorySpan.getDirectoryHelper(inputDirectory);
        text = Optional.ofNullable(textSpan.isPresent()? textSpan.get().getText(): 
            null);
    }
    
    public String getPath(){
        Optional<Span> span = getTarget();
        if (span.isPresent()){
            return ((LinedSpanPointLink)span.get()).getPath();
        }
        return "";
    }
    
    public String getText(){
        if (text.isPresent()){
            return text.get();
        }
        return getPath();
    }

    @Override
    public Optional<DirectoryId> getId(){
        return idSpan;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        if (! hasID()) ans.add(STYLE_NO_ID);
        ans.add(getDirectoryStyle(DirectoryType.LINK));
        ans.addAll(super.getStyleClasses());
        return ans;
    }
}
