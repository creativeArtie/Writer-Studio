package org.community.jwriter.basic;

import java.util.ArrayList; 
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Created from {@link DirectorySpan}. Used to store {@link DirectoryId}
 */
public class DirectorySpan extends SpanBranch{
    /// helps with categorizing and describes purpose
    private DirectoryType purpose;
    /// stores the actual {@link DirectoryId}
    private DirectoryId id;
    
    /// Helper method to get Optional<DirectorySpan> -> Optional<DirectoryId>
    static Optional<DirectoryId> getDirectoryHelper(Optional<DirectorySpan> id){
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
    
    DirectorySpan(List<Span> children, List<String> categories, 
        Optional<ContentSpan> idSpan, DirectoryType type
    ){
        super(children);
        
        /// Adds main category
        ArrayList<String> builder = new ArrayList<>();
        if (type != DirectoryType.NONE) builder.add(type.getCategory());
        builder.addAll(categories);
        ///build the id
        id = new DirectoryId(builder, idSpan.get().getText());
        
        purpose = type;
    }
    
    public DirectoryId getId(){
        return id;
    }
    
    public DirectoryType getPurpose(){
        return purpose;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        DirectoryData data = getDocument().getMap().get(id);
        if (data == null){
            ans.add(DirectoryStatus.NO_ID.getStyle());
        } else if (data.getState() != DirectoryStatus.NONE){
            ans.add(data.getState().getStyle());
        }
        return ans;
    }
        
    
    public String toString(){
        return "[" + id.getFullIdentity() + "]";
    }
}
