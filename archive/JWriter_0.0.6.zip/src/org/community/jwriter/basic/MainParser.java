package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

class MainParser implements InputParser<MainSpan> {
    private static final InputParser<?>[] parsers = InputParser.combine(
        InputParser.combine(LinedParseLevel.values(), LinedParsePointer.values()),
        InputParser.combine(LinedParseCite.values(), LinedParseRest.values())
    );
    
    @Override
    public Optional<MainSpan> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        LinedSpan line = null;
        for (InputParser<?> parser: parsers){
            Optional<?> found = parser.parse(children, pointer);
            if(found.isPresent()){
                line = (LinedSpan) found.get();
                break;
            }
        }
        switch (line.getType()){
            case NOTE:
            case SOURCE:
                return parseNote(children, pointer);
            default:
                return parseSection(children, pointer);
        }
    }
    
    private Optional<MainSpan> parseSection(ArrayList<Span> children, 
            InputPointer pointer){
        while (true){
            pointer.mark();
            Optional<? extends Span> span = Optional.empty();
            for (InputParser<?> parser : parsers){
                span = parser.parse(pointer);
                if (span.isPresent()){
                    break;
                }
            }
            if (span.isPresent()){
                LinedSpan line = (LinedSpan) span.get();
                switch(line.getType()){
                    case HEADING:
                    case OUTLINE:
                        line.setRemove();
                        pointer.rollBack();
                        return buildSection(children);
                    case NOTE:
                    case SOURCE:
                        pointer.rollBack();
                        return buildSection(children);
                    default:
                        children.add(line);
                }
            } else {
                return buildSection(children);
            }
        }
    }
    
    private Optional<MainSpan> buildSection(List<Span> children){
        return Optional.of(new MainSpanSection(children));
    }
    
    private Optional<MainSpan> parseNote(ArrayList<Span> children, 
            InputPointer pointer){
        ArrayList<LinedSpanCite> sources = new ArrayList<>();
        while (true){
            pointer.mark();
            if (! LinedParseCite.INSTANCE.parse(children, pointer).isPresent()){
                Optional<LinedSpan> found = LinedParseRest.NOTE.parse(pointer);
                if (! found.isPresent()){
                    return buildNote(pointer, children); 
                } else if (((LinedSpanNote)found.get()).getId().isPresent()){
                    pointer.rollBack();
                    return buildNote(pointer, children);
                }
                children.add(found.get());
            }
            
        }
    }
    
    private Optional<MainSpan> buildNote(InputPointer pointer, 
            List<Span> children){
        MainSpanNote ans = new MainSpanNote(children);
        Optional<DirectoryId> idFound = ans.getId();
        idFound.ifPresent(id -> pointer.getMap().addId(id, ans));
        return Optional.of(ans);
    }
}
