package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@linkplain FormatSpanCurly} for to do text. It will warn user when 
 * exporting while there are these {@link Span spans} still exists.
 */
public final class FormatSpanAgenda extends SpanBranch {

    private final String agenda;
    
    FormatSpanAgenda(List<Span> children, Optional<ContentSpan> agendaText){
        super(children);
        agenda = agendaText.isPresent()? agendaText.get().getText() : "";
    }
    
    public String getAgenda(){
        return agenda;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        ans.add(STYLE_INLINE_AGENDA);
        return ans;
    }
}
