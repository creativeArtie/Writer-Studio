package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public abstract class LinedSpanPoint extends LinedSpan implements DirectoryHolder{
    private final DirectoryType type;
    private final Optional<DirectoryId> idSpan;

    LinedSpanPoint(List<Span> children, LinedType spanType, 
            Optional<DirectorySpan> foundDirectory){
        super(children, spanType);
        idSpan = DirectorySpan.getDirectoryHelper(foundDirectory);
        type = idSpan.isPresent()? foundDirectory.get().getPurpose(): 
            DirectoryType.NONE;
    }
    
    public DirectoryType getDirectoryType(){
        return type;
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return idSpan;
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        if (! hasID()) ans.add(STYLE_NO_ID);
        ans.addAll(super.getStyleClasses());
        return ans;
    }
}
