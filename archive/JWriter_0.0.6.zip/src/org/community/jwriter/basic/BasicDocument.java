package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

public class BasicDocument extends Document{
    
    public BasicDocument(){}
    
    public BasicDocument(String doc){
        super(doc, new MainParser());
    }
}
