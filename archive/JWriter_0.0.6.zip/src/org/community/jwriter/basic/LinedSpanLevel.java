package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanLevel extends LinedSpan {
    private final int level;
    private final FormatSpanMain text;

    LinedSpanLevel(List<Span> children, int levelDepth, LinedType spanType, 
            Optional<FormatSpanMain> textSpan){
        super(children, spanType);
        level = levelDepth;
        text = textSpan.isPresent()? textSpan.get(): new FormatSpanMain(this);
    }
    
    public FormatSpanMain getFormatted(){
        return text;
    }
    
    public int getLevel(){
        return level;
    }
}
