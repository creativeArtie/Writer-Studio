package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Creates a text span upto a certain character.
 */
class ContentParser extends BasicTextParser<ContentSpan>{
    
    public ContentParser(List<String> enders){
        super(InputStyle.TEXT, enders);
    }
    
    public ContentParser(InputStyle spanStyle, List<String> enders){
        super(spanStyle, enders.toArray(new String[0]));
    }
    
    public ContentParser(InputStyle spanStyle, String ... enders){
        super(spanStyle, enders);
    }
    
    public ContentParser(String ... enders){
        super(InputStyle.TEXT, enders);
    }
    
    @Override
    protected ContentSpan buildSpan(List<Span> children, List<String> enders){
        return new ContentSpan(children, enders);
    }
    
}
