package org.community.jwriter.basic;

import com.google.common.base.CaseFormat;

import static org.community.jwriter.markup.AtomicMarkupTerms.STYLE_ID_ERROR;

/**
 * All special string use in the markup language.
 */
public final class AtomicTerm{
    /// ========================================================================
    /// @Part-1: Token Constants------------------------------------------------
    
    /// @Part-1.1: Lines with Levels -------------------------------------------
    /// For LinedParseLevel
    
    /// Maximum number of levels
    public static final int LEVEL_MAX = 6;
    
    /// Leveled Line begin part token for numbered and bullet
    private static final String LEVEL_BEGIN    = "\t";
    /// Leveled line begin part tokens
    private static final String LEVEL_HEADING  = "=";
    private static final String LEVEL_NUMBERED = "#";
    private static final String LEVEL_OUTLINE  = "#";
    private static final String LEVEL_BULLET   = "-";
    private static final String LEVEL_QUOTE    = ">";
    /// Create a Leveled Line begin token
    public static String getLinedLevel(LinedParseLevel from, int level){
        switch (from){
            case HEADING:
                return repeat(LEVEL_HEADING, level);
            case OUTLINE:
                return LINED_BEGIN + repeat(LEVEL_OUTLINE, level);
            case QUOTE:
                return repeat(LEVEL_QUOTE, level);
            case NUMBERED:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_NUMBERED;
            case BULLET:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_BULLET;
        }
        throw new IllegalArgumentException("LinedLevelParser not used.");
    }
    /// getLinedLevel helper
    private static String repeat(String repeats, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(repeats);
        }
        return builder.toString();
    }
    
    /// @Part-1-2: Other Lined Details -----------------------------------------
    /// For BasicTextParse, LinedParseCite, LinedParseLevel, LinedParsePointer,
    ///     LinedParseRest, getLinedLevel(LinedParseLevel, int)
    
    /// Line ending token
    public static final String LINED_END = "\n";
    
    /// Data separator token
    public static final String LINED_DATA = ":";
    
    /// "Special" Line begin token  part 1
    private static final String LINED_BEGIN = "!";
    /// "Special" Line begin tokens part 2
    public static final String LINED_AGENDA   = LINED_BEGIN + "!"; 
    public static final String LINED_NOTE     = LINED_BEGIN + "%";   
    public static final String LINED_SOURCE   = LINED_BEGIN + ">";
    public static final String LINED_LINK     = LINED_BEGIN + "@";
    public static final String LINED_FOOTNOTE = LINED_BEGIN + "^";
    public static final String LINED_ENDNOTE  = LINED_BEGIN + "*";
    
    /// Line break token
    public static final String LINED_BREAK = "***\n";
    
    /// @Part-1-3: Directory ---------------------------------------------------
    /// For DirectoryParser, LinedParseLevel, LinedParseRest, CURLY_CITE
    
    public static final String DIRECTORY_BEGIN    = "@"; /// Start
    public static final String DIRECTORY_CATEGORY = "-"; /// Middle (Separator)
    public static final String DIRECTORY_END      = ":"; /// End
    
    /// @Part-1-4: Status ------------------------------------------------------
    /// EditionParser, LinedParseLevel
    
    /// Beginning of edition
    public static final String EDITION_BEGIN = "#";
    /// (more constants from {@link Edition#name()}
    
    /// @Part-1-5: Hyperlinks --------------------------------------------------
    /// For FormatParseLinkDirect, FormatParseLinkRef, listFormatEnders()
    
    /// Starters
    public static final String LINK_BEGIN =              "<"; /// Direct Start
    public static final String LINK_REF   = LINK_BEGIN + "@"; /// Ref Start
    
    /// Others
    public static final String LINK_TEXT  = "|"; /// Text start
    public static final String LINK_END   = ">"; /// End
    
    /// @Part-1-6: Curly Formats ------------------------------------------------
    /// For FormatParseAgenda, FormatParseDirectory, listFormatEnders()
    
    /// Curly format begins token  part 1
    private static final String CURLY_BEGIN   = "{";
    /// Curly format begins tokens part 2
    public static final String CURLY_AGENDA   = CURLY_BEGIN + "!";
    public static final String CURLY_FOOTNOTE = CURLY_BEGIN + "^";
    public static final String CURLY_ENDNOTE  = CURLY_BEGIN + "*";
    public static final String CURLY_CITE     = CURLY_BEGIN + DIRECTORY_BEGIN;
    
    /// Curly format ends
    public static final String CURLY_END      = "}";
    
    /// @Part-1-7: Format Modifiers ---------------------------------------------
    /// For FormatParser, listFormatEnders()
    
    /// list of possible formats
    private static final String FORMAT_ITALICS  = "*";
    private static final String FORMAT_BOLD     = "**";
    private static final String FORMAT_UNDERLINE = "_";
    private static final String FORMAT_CODED     = "`";
    /// Create the list of possible format
    public static final String[] listSpanFormats(){
        /// FORMAT_BOLD must before FORMAT_ITALICS
        return new String[]{
            FORMAT_BOLD, FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED
        };
    }
    
    /// @Part-1-8: Escape Begin Token ------------------------------------------
    /// For BasicTextParser, listFormatEnders()
    public static final String CHAR_ESCAPE    = "\\";
    
    /// @Part-1-9: Format Part Separators --------------------------------------
    /// For FormatParsers
    
    /// Create the list of parts for format, FORMAT_BOLD is optional
    public static String[] listFormatEnders(){
        return new String[]{
            CURLY_AGENDA, CURLY_FOOTNOTE, CURLY_ENDNOTE, CURLY_CITE, CURLY_END, 
            LINK_BEGIN, LINK_REF, 
            /* FORMAT_BOLD, */FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED,
            CHAR_ESCAPE};
    }
    
    /// ========================================================================
    /// @Part-2: Directory Type ------------------------------------------------
    public static final String TYPE_FOOTNOTE = "foot";
    public static final String TYPE_ENDNOTE = "end";
    public static final String TYPE_LINK = "link";
    public static final String TYPE_NOTE = "note";
    public static final String TYPE_NONE = "";
    
    /// ========================================================================
    /// @Part-3: Span Style Property Name --------------------------------------
    
    private static final String SEP = ".";
    
    public static final String STYLE_ESCAPE = "Other" + SEP + "Escape";
    public static final String STYLE_CITE_ERROR = "Other" + SEP + "Error";
    
    public static final String STYLE_NO_ID = STYLE_ID_ERROR;
    
    private static final String STYLE_EDITION = "Edition" + SEP;
    public static String getEditionStyle(EditionType type){
        return STYLE_EDITION + 
            CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, type.name());
    }
    
    private static final String STYLE_FORMAT = "Format" + SEP;
    private static final String STYLE_FORMAT_BOLD     = STYLE_FORMAT + "Bold";
    public static final String STYLE_FORMAT_ITALICS   = STYLE_FORMAT + "Italics";
    public static final String STYLE_FORMAT_UNDERLINE = STYLE_FORMAT + "Underline";
    public static final String STYLE_FORMAT_CODED     = STYLE_FORMAT + "Coded";
    public static final String[] getFormatStyles(){
        return new String[]{
            STYLE_FORMAT_BOLD, STYLE_FORMAT_ITALICS, STYLE_FORMAT_UNDERLINE,
            STYLE_FORMAT_CODED
        };
    }
    
    private static final String STYLE_INLINE = "Inline" + SEP;
    public static final String STYLE_INLINE_AGENDA = STYLE_INLINE + "Agenda";
    public static String getDirectoryStyle(DirectoryType type){
        return STYLE_INLINE + 
            CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, type.name());
    }
    public static final String STYLE_INLINE_LINK = STYLE_INLINE + "Link";
    
    private static final String STYLE_LINED = "Lined" + SEP;
    public static String getLinedStyle(LinedType type){
        return STYLE_LINED + 
            CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, type.name());
    }
        
    
    /// ========================================================================
    /// @Part-4: Private Constructor -------------------------------------------
    private AtomicTerm(){}
}
