package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanParagraph extends LinedSpan {

    LinedSpanParagraph(List<Span> children){
        super(children, LinedType.PARAGRAPH);
    }
    
    public FormatSpanMain getFormatted(){
        if (size() == 0) {
            return new FormatSpanMain(this);
        }
        return (FormatSpanMain) get(0);
    }
}
