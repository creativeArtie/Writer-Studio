package org.community.jwriter.basic;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link ContentSpan} with format for {@link FormatSpanMain}. 
 */
public class FormatSpanContent extends FormatSpan implements BasicText{
    
    private Optional<String> output;
    private List<String> enders;
    
    FormatSpanContent(List<Span> children, boolean[] spanFormats, 
        List<String> spanEnders
    ){
        super(children, spanFormats);
        output = Optional.empty();
        enders = spanEnders;
    }
    
    @Override
    public String getOutput(){
        if (! output.isPresent()){
            output = Optional.of(BasicText.super.getOutput());
        }
        return output.get();
    }
    @Override
    public List<String> getEnders(){
        return enders;
    }
}
