package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * InputParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
class FormatParseLinkRef extends FormatParseLink<FormatSpanLinkRef> {
    
    FormatParseLinkRef(boolean[] formats){
        super(LINK_REF, formats);
    }

    @Override
    public Optional<FormatSpanLinkRef> parseFinish(ArrayList<Span> children, 
        InputPointer pointer
    ){
        Optional<DirectorySpan> id = 
            new DirectoryParser(DirectoryType.LINK, LINK_TEXT, LINK_END)
            .parse(children, pointer);
        
        /// Complete the last steps 
        Optional<ContentSpan> text = parseRest(children, pointer);
        FormatSpanLinkRef span = new FormatSpanLinkRef(children, getFormats(), 
            id, text);
        id.ifPresent(found -> pointer.getMap().addRef(found.getId(), span));
        return Optional.of(span);
    }
}
