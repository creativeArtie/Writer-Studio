package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;

import org.community.jwriter.markup.*;

public abstract class LinedCiteData<T> extends SpanBranch{
    
    public abstract LinedCiteData<T> cast();
    
    public abstract T get();
    
    protected LinedCiteData(List<Span> children){
        super(children);
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        return new ArrayList<>();
    }
}
