package org.community.jwriter.basic;

import java.util.Arrays; 
import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Creates a text span upto a certain character.
 */
class FormatParseContent extends BasicTextParser<FormatSpanContent>{
    
    private boolean[] formats;
    
    public FormatParseContent(boolean[] formats, List<String> enders){
        this(InputStyle.TEXT, formats, enders);
    }
    
    public FormatParseContent(InputStyle spanStyle, boolean[] formats, 
        List<String> enders
    ){
        this(spanStyle, formats, enders.toArray(new String[0]));
    }
    
    public FormatParseContent(boolean[] spanFormats, String ... enders){
        this(InputStyle.TEXT, spanFormats, enders);
    }
    
    public FormatParseContent(InputStyle spanStyles, boolean[] spanFormats, 
        String ... enders
    ){
        super(spanStyles, enders);
        formats = Arrays.copyOf(spanFormats, spanFormats.length);
    }
    
    @Override
    protected FormatSpanContent buildSpan(List<Span> children, 
        List<String> enders
    ){
        return new FormatSpanContent(children, formats, enders);
    }
    
}
