package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

enum LinedParseCite implements InputParser<LinedSpanCite> {
    INSTANCE;
    
    public Optional<LinedSpanCite> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        
        if (pointer.startsWith(children, LINED_SOURCE)){
            LinedCite type = LinedCite.ERROR;
            for (LinedCite t: LinedCite.values()){
                
                if (pointer.trimStartsWith(children, InputStyle.FIELD, 
                    t.getCode())
                ){
                    pointer.trimStartsWith(children, LINED_DATA);
                    type = t;
                    break;
                }
            }
            Optional<? extends LinedCiteData<?>> content = Optional.empty();
            if (type != LinedCite.ERROR){
                content = type.parse(children, pointer);
            }
            if (! content.isPresent()){
                new ContentParser().parse(children, pointer);
            }
            pointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanCite(children, type, content));
        }
        return Optional.empty();
    }
}
