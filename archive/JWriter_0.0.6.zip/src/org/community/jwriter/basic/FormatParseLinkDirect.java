package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * InputParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
class FormatParseLinkDirect extends FormatParseLink<FormatSpanLinkDirect> {
    
    FormatParseLinkDirect(boolean[] formats){
        super(LINK_BEGIN, formats);
    }
    
    @Override
    public Optional<FormatSpanLinkDirect> parseFinish(ArrayList<Span> children, 
        InputPointer pointer
    ){
        Optional<ContentSpan> path = new ContentParser(InputStyle.PATH, 
            LINK_TEXT, LINK_END).parse(children, pointer);
        
        /// Complete the last steps 
        Optional<ContentSpan> text = parseRest(children, pointer);
        return Optional.of(new FormatSpanLinkDirect(children, getFormats(), path, 
            text));
    }
}
