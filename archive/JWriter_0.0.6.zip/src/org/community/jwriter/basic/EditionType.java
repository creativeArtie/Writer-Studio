package org.community.jwriter.basic;

import static org.community.jwriter.basic.AtomicTerm.*;

public enum EditionType {
    STUB, DRAFT, FINAL, OTHER, NONE;
    
    private EditionType(){
    }
}
