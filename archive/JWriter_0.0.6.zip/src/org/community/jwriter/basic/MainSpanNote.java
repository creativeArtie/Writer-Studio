package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ArrayListMultimap;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class MainSpanNote extends MainSpan implements DirectoryHolder{
    
    MainSpanNote(List<Span> children){
        super(children);
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        Span child = get(0);
        if (child instanceof LinedSpanNote){
            return ((LinedSpanNote)child).getId();
        }
        return Optional.empty();
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        if (! hasID()) ans.add(STYLE_NO_ID);
        ans.addAll(super.getStyleClasses());
        return ans;
    }
    
    public ImmutableListMultimap<LinedCite, LinedCiteData<?>> getSources(){
        ImmutableListMultimap.Builder<LinedCite, LinedCiteData<?>> data = 
            ImmutableListMultimap.builder();
        for (Span child: this){
            if (child instanceof LinedSpanCite){
                LinedSpanCite cite = (LinedSpanCite) child;
                if (cite.isReady()){
                    data.put(cite.getField(), cite.getData().get());
                }
            }
        }
        return data.build();
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
}
