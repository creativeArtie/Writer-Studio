package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List; /// For initialization (children)
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Created from {@link ContentParser}. Used only in {@link ContentSpan}
 */
public class BasicTextEscape extends SpanBranch{
    
    BasicTextEscape(List<Span> children){
        super(children);
    }
    
    public String getEscape(){
        return size() == 2? get(1).getRaw(): "";
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        ans.add(STYLE_ESCAPE);
        return ans;
    }
}
