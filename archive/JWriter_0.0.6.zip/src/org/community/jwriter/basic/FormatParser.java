package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link Span} for text that has been formatted. This makes all {@link Span}
 * starting with {@code Format}.
 */
class FormatParser implements InputParser<FormatSpanMain> {
    
    private final String[] ends;   
    
    public FormatParser(String ... enders){
        /// Combine the list of span enders and formatting enders
        ends = InputParser.combine(listFormatEnders(), enders);
    }
    
    @Override
    public Optional<FormatSpanMain> parse(InputPointer pointer){
        /// Setup format style: bold, italics, underline, coded
        boolean[] formats = new boolean[]{false, false, false, false};
        
        /// Setup for FormatSpanMain
        ArrayList<Span> children = new ArrayList<>();
        Optional<FormatSpanContent> text = Optional.empty();
        
        /// check where the loop ends
        boolean hasMore;
        
        do {
            hasMore = false; /// Assume FormatSpanMain has ended
            
            /// try to find text first
            text = new FormatParseContent(formats, ends).parse(children, 
                pointer);
            if (text.isPresent()){
                hasMore = true;
            }
            
            if (FormatParseAgenda.PARSER.parse(children, pointer).isPresent()){
                hasMore = true;
            }
            
            /// Keeps FomratContentParser parsing alone b/c of needs to edit format
            int i = 0;
            for (String type : listSpanFormats()){
                if (pointer.startsWith(children, type)){
                    /// change format of bold/italics/underline/code
                    formats[i] = ! formats[i];
                    
                    hasMore = true;
                    break;
                }
                i++;
            }
            
            /// Lastly deal with FormatParseCurly and FormatParseLink together
            for (InputParser<?> parser: InputParser.combine(
                FormatParseDirectory.getParsers(formats), 
                FormatParseLink.getParsers(formats)
            )){
                Optional<? extends Span> note = parser.parse(children, pointer);
                if(note.isPresent()){
                    /// Striaght forwarding adding of found spans.
                    hasMore = true;
                }
            }
        } while(hasMore);
        
        /// Add the FormatParser with its children spans if there are children.
        if (children.size() > 0){
            return Optional.of(new FormatSpanMain(children));
        }
        return Optional.empty();
    }
}
