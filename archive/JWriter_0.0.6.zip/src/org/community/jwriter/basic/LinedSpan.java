package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import org.community.jwriter.property.PropertyManager;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpan extends SpanBranch {
    private final LinedType type;
    
    LinedSpan(List<Span> children, LinedType t){
        super(children);
        type = t;
    }
    
    public LinedType getType(){
        return type;
    }
    
    public String toString(){
        return type + super.toString();
    }
    
    @Override
    protected ArrayList<String> getStyleClasses(){
        ArrayList<String> ans = new ArrayList<>();
        ans.add(getLinedStyle(type));
        return ans;
    }
}
