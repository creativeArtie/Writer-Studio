package org.community.jwriter.basic;

import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()
import com.google.common.base.Joiner;      /// To remove spaces
import com.google.common.base.Splitter;    /// To remove spaces
import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

interface BasicText{
    
    public List<Span> delegate();
    
    public List<String> getEnders();
    
    public default String getOutput(){
        StringBuilder builder = new StringBuilder();
        for(Span child: delegate()){
            if (child instanceof BasicTextEscape){
                builder.append(((BasicTextEscape)child).getEscape());
            } else if (child instanceof SpanLeaf){
                /// Add text from a basic span
                builder.append(child.getRaw());
            } else {
                throw new IllegalArgumentException(
                    "Unexpected child span" + child.toString()
                );
            }
        }
        return CharMatcher.whitespace().collapseFrom(builder, ' ');
    }
    
    public default String getText(){
        return CharMatcher.whitespace().trimFrom(getOutput());
    }
    
    public default boolean isSpaceBegin(){
        String output = getOutput();
        if (output.isEmpty()){
            return false;
        }
        return CharMatcher.whitespace().matches(output.charAt(0));
    }
    
    public default boolean isSpaceEnd(){
        String output = getOutput();
        if (output.isEmpty()){
            return false;
        }
        return CharMatcher.whitespace()
            .matches(output.charAt(output.length() - 1));
    }
}
