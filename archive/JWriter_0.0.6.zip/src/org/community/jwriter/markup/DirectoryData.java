package org.community.jwriter.markup;

import java.util.ArrayList;
import com.google.common.collect.ImmutableList;

public class DirectoryData{
    private ArrayList<SpanBranch> ids;
    private ArrayList<SpanBranch> refs;
    private DirectoryStatus status;
    private DirectoryMap parent;
    private DirectoryId key;
    
    public DirectoryData(DirectoryMap mapTo, DirectoryId forId){
        ids = new ArrayList<>();
        refs = new ArrayList<>();
        parent = mapTo;
        key = forId;
    }
        
    void addId(SpanBranch span){
        ids.add(span);
        span.addListener(out -> ids.remove(span));
        updateStatus();
    }
    
    void addRef(SpanBranch span){
        refs.add(span);
        span.addListener(out -> refs.remove(span));
        updateStatus();
    }
    
    private void updateStatus(){
        if (ids.size() > 1){
            status = DirectoryStatus.MULTIPLE;
        } else if (ids.isEmpty()){
            status = DirectoryStatus.NOT_FOUND;
        } else if (refs.isEmpty()){
            status = DirectoryStatus.UNUSED;
        } else {
            status = DirectoryStatus.NONE;
        }
    }
    
    public DirectoryStatus getState(){
        return status;
    }
    
    public boolean isReady(){
        return status == DirectoryStatus.NONE;
    }
    
    public Span getTarget(){
        if (ids.size() == 1){
            return ids.get(0);
        }
        throw new IllegalStateException("DirectoryId Data is in the wrong state: " 
            + status);
    }
    
    public ImmutableList<SpanBranch> getIds(){
        return ImmutableList.copyOf(ids);
    }
    
    public ImmutableList<SpanBranch> getRefs(){
        return ImmutableList.copyOf(refs);
    }
    
    public String toString(){
        return status.toString() + "\n\tIds{\n\t" + 
            ids.toString().replace("\n", "\n\t\t") + "\n\t}Refs{" +
            refs.toString() + "}\n";
    }
}
