package org.community.jwriter.markup;

import java.util.Optional;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import com.google.common.collect.ImmutableList;

import org.fxmisc.richtext.InlineStyleTextArea;

import org.community.jwriter.property.PropertyManager;

public class OutputCursor{
    private final Document doc;
    private int childPointer;
    private Optional<SpanLeaf> current;
    
    public OutputCursor(Document document){
        doc = document;
        if (document.size() == 0) {
            current = Optional.empty();
        } else {
            current = getEnds(false);
            childPointer = current.get().getLength();
        }
    }
    
    public OutputCursor(Document document, int location){
        doc = document;
        goTo(location);
    }
    
    public void toStart(){
        current = getEnds(true);
    }
    
    private Optional<SpanLeaf> getEnds(boolean forFirst){
        if (doc.size() == 0){
            return Optional.empty();
        }
        Span span = doc.get(forFirst? 0 : doc.size() - 1);
        while (!( span instanceof SpanLeaf)){
            SpanNode<?> parent = (SpanNode<?>)span;
            int to = forFirst? 0: parent.size() - 1;
            span = parent.get(to);
        }
        return Optional.of((SpanLeaf) span);
    }
    
    private Optional<SpanLeaf> shift(Span child, boolean isForwards){
        SpanNode<?> parent = child.getParent();
        int loc = parent.indexOf(child);
        loc += isForwards? 1 : -1;
        if (isForwards ? loc < parent.size(): loc >= 0) {
            Span ans = parent.get(loc);
            while (ans instanceof SpanNode){
                parent = (SpanNode) ans;
                ans = parent.get(isForwards? 0 : parent.size() - 1);
            }
            return Optional.of((SpanLeaf)ans);
        } else if (parent instanceof Document) {
            return Optional.empty();
        }
        return shift(parent, isForwards);
    }
        
    public void goTo(int location){
        if (location == doc.getLength()){
            current = getEnds(false);
            childPointer = current.get().getLength();
        }
        if (doc.isEmpty()){
            return;
        }
        Span first = doc;
        while (! (first instanceof SpanLeaf)) {
            first = ((SpanNode<?>)first).get(0);
        }
        SpanLeaf ptr = (SpanLeaf)first;
        
        int search = 0;
        while (search + ptr.getLength() < location) {
            search += ptr.getLength();
            Optional<SpanLeaf> found = shift(ptr, true);
            if (found.isPresent()){
                ptr = found.get();
            } else {
                throw new IllegalArgumentException("Span not in range.");
            }
            
        }
        current = Optional.of(ptr);
        childPointer = location - search;
    }
    
    public void shift(int shift){
        if (shift > 0){
            shiftForward(shift);
        } else {
            shiftBack(shift);
        }
    }
    
    private void shiftBack(int shift){
        childPointer += shift;
        while (childPointer < 0){
            Optional<SpanLeaf> span = shift(current.get(), false);
            if (span.isPresent()){
                current = span;
                childPointer += current.get().getLength();
            } else {
                throw new IllegalArgumentException("Shift too far back.");
            }
        }
    }
    
    private void shiftForward(int shift){
        childPointer += shift;
        while(childPointer > current.get().getLength()){
            childPointer -= current.get().getLength();
            Optional<SpanLeaf> span = shift(current.get(), true);
            if (span.isPresent()){
                current = span;
            } else {
                throw new IllegalArgumentException("Shift too far forward.");
            }
        }
            
    }
    
    public void toSpan(SpanLeaf leaf, int localPointer){
        if (doc != leaf.getDocument()){
            throw new IllegalArgumentException("Span " + leaf + 
                " not in document: " + doc);
        }
        childPointer = localPointer;
        current = Optional.of(leaf);
    }
    
    public Iterable<OutputListSpan> getReverse(){
        return getLeaves(false);
    }
    
    public Iterable<OutputListSpan> getLeaves(){
        return getLeaves(true);
    }
    
    private Iterable<OutputListSpan> getLeaves(boolean isForwards){
        final Optional<SpanLeaf> last = getEnds(! isForwards);
        if (! last.isPresent()){
            return new ArrayList<>();
        }
        return () -> {
            return new Iterator<OutputListSpan>(){
                SpanLeaf ptr;
                int start, end;
                public boolean hasNext(){
                    return ptr != last.get();
                }
                public OutputListSpan next(){
                    if (ptr == null){
                        ptr = getEnds(isForwards).get();
                        if (isForwards){
                            end = ptr.getLength();
                            start = 0;
                        } else {
                            end = doc.getLength();
                            start = end - ptr.getLength();
                        }
                    } else {
                        Optional<SpanLeaf> found = shift(ptr, isForwards);
                        if (! found.isPresent()){
                            throw new NoSuchElementException();
                        }
                        ptr = found.get();
                        if (isForwards){
                            start = end;
                            end += ptr.getLength();
                        } else {
                            end = start;
                            start -= ptr.getLength();
                        }
                        
                    }
                    return new OutputListSpan(start, end, ptr);
                }
            };
        };
    }
    
    public SpanLeaf getCurrentSpan(){
        return current.get();
    }
}
