package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.Map;

import static org.community.jwriter.markup.AtomicMarkupTerms.*;
import org.community.jwriter.property.PropertyManager;
import com.google.common.base.CaseFormat;

public enum InputStyle {
    KEYWORD, ID, FIELD, DATA, PATH, TEXT;
    
    public Map<String, String> getStyleList(PropertyManager manager){
        String style = style = STYLE_BASIC + CaseFormat.UPPER_UNDERSCORE
            .to(CaseFormat.UPPER_CAMEL, name());
        return manager.getStyleProperty(style).get();
    }
}
