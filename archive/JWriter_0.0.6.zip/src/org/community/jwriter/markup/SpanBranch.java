package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.TreeMap;

import org.community.jwriter.property.PropertyManager;

/**
 * A {@link Span} handling {@link SpanLeaf}
 */
public abstract class SpanBranch extends SpanNode<Span> implements Span {
    
    private ArrayList<Span> spans;
    
    private ArrayList<DirectoryRemover> listeners;
    
    private SpanNode<?> parent;
    
    public SpanBranch(List<Span> children){
        spans = new ArrayList<>(children);
        for(Span span : spans){
            if (span instanceof SpanBranch){
                ((SpanBranch)span).setParent(this);
            } else {
                ((SpanLeaf)span).setParent(this);
            }
        }
        listeners = new ArrayList<>();
    }
    
    final void addListener(DirectoryRemover listener){
        listeners.add(listener);
    }
    
    @Override
    public final List<Span> delegate(){
        return spans;
    }
    
    @Override
    public Document getDocument(){
        return get(0).getDocument();
    }
    
    @Override
    public SpanNode<?> getParent(){
        return parent;
    }
    
    protected void setParent(SpanNode<?> childOf){
        parent = childOf;
    }
    
    public void setRemove(){
        for(DirectoryRemover remover: listeners){
            remover.remove(this);
        }
        for(Span child: this){
            if (child instanceof SpanBranch){
                ((SpanBranch)child).setRemove();
            }
        }
    }
    
    
    Map<String, String> getStyleList(PropertyManager manager){
        TreeMap<String, String> styles = new TreeMap<>();
        if (parent instanceof SpanBranch){
            styles.putAll(((SpanBranch)parent).getStyleList(manager));
        }
        for(String clazz : getStyleClasses()){
            styles.putAll(manager.getStyleProperty(clazz).get());
        }
        return styles;
    }
    
    protected abstract List<String> getStyleClasses();
    
    // protected abstract void addText(Span span, String oldText, String insert);
}
