package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ForwardingList;

/**
 * Common methods for {@link Document} and {@link SpanBranch}.
 */
public abstract class SpanNode<T extends Span> extends ForwardingList<T> 
        implements Span {
    
    public SpanNode(){}
    
    @Override
    public final String getRaw(){
        StringBuilder builder = new StringBuilder();
        
        for (Span span: this){
            builder.append(span.getRaw());
        }
        return builder.toString();
    }
    
    @Override
    public int getLength(){
        int ans = 0;
        for(Span child: this){
            ans += child.getLength();
        }
        return ans;
    }
}
