package org.community.jwriter.markup;

public class OutputListSpan {
    private int start;
    private int end;
    private SpanLeaf ptr;
    
    OutputListSpan(int spanStart, int spanEnd, SpanLeaf span){
        start = spanStart;
        end = spanEnd;
        ptr = span;
    }
    
    public int getStart(){
        return start;
    }
    
    public int getEnd(){
        return end;
    }
    
    public SpanLeaf getSpan(){
        return ptr;
    }
}
