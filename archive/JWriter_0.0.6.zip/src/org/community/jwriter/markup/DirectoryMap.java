package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ForwardingMap;

/**
 * A System of {@link DirectorySpan} references with their status
 */
public final class DirectoryMap extends ForwardingMap<DirectoryId, DirectoryData>{
    private final TreeMap<DirectoryId, DirectoryData> ids;
    
    public DirectoryMap(){
        ids = new TreeMap<>();
    }
    
    public void addId(DirectoryId id, SpanBranch span){
        DirectoryData data = ids.get(id);
        if (data == null){
            data = new DirectoryData(this, id);
            ids.put(id, data);
        }
        data.addId(span);
    }
    
    public void addRef(DirectoryId ref, SpanBranch span){
        DirectoryData data = ids.get(ref);
        if (data == null){
            data = new DirectoryData(this, ref);
            ids.put(ref, data);
        }
        data.addRef(span);
    }
    
    public ImmutableMap<DirectoryId, DirectoryData> delegate(){
        return ImmutableMap.copyOf(ids);
    }
}
