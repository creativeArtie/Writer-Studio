package org.community.jwriter.markup;

import java.util.List;
import java.util.Optional;

/**
 * Creator for the {@link Span}.
 */
public interface InputParser<T extends Span>{
    
    /** Put two {@linkplain String} list together. */
    public static String[] combine(String[] list1, String[] list2){
        String[] res = new String[list1.length + list2.length];
        System.arraycopy(list1, 0, res, 0, list1.length);
        System.arraycopy(list2, 0, res, list1.length, list2.length);
        return res;
    }
    
    /** Put two {@link InputParser} list together. */
    public static  InputParser<?>[] combine(
            InputParser<?>[] list1, InputParser<?>[] list2){
        InputParser<?>[] res = new InputParser<?>[list1.length + list2.length];
        System.arraycopy(list1, 0, res, 0, list1.length);
        System.arraycopy(list2, 0, res, list1.length, list2.length);
        return res;
    }
    
    public default Optional<T> parse(List<Span> children, InputPointer pointer){
        Optional<T> child = parse(pointer);
        child.ifPresent(c -> children.add(c));
        return child;
    }
    
    /**
     * Creates a {@link Span} base on the Parsers. If the span does not exist, it
     * should <em> not </em> move the {@link InputPointer} and returns 
     * {@code Optional.empty()}.
     */
    public Optional<T> parse(InputPointer pointer);
}
