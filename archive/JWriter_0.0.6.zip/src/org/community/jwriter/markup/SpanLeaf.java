package org.community.jwriter.markup;

//TODO: add functions for highlighting, node creation and GUI editor
import java.util.Map;
import java.util.TreeMap;

import org.community.jwriter.property.PropertyManager;
import static org.community.jwriter.markup.AtomicMarkupTerms.*;

/**
 * A {@link Span} handling markup editor highlighting, export node creation and
 * formatting for GUI editor. The constructor will get the pointer to roll (move 
 * {@linkplain start} pointer to {@linkplain end} pointer).
 */
public class SpanLeaf implements Span{
    private String text;
    private Document doc;
    private SpanBranch parent;
    private InputStyle style;
    
    public static String escapeText(String input){
        return "\"" + input.replace("\n", "\" \\n \"")
            .replace("\t", "\" \\t \"") + "\"";
    }
    
    SpanLeaf(InputPointer pointer, InputStyle spanStyle){
        text = pointer.getRaw();
        pointer.roll();
        doc = pointer.getDocument();
        style = spanStyle;
    }
    
    public String getStyle(PropertyManager manager){
        TreeMap<String, String> styles = new TreeMap<>();
        styles.putAll(getParent().getStyleList(manager));
        styles.putAll(style.getStyleList(manager));
        styles.putAll(manager.getStyleProperty(STYLE_BASIC_COMMON).get());
        StringBuilder ans = new StringBuilder();
        for(Map.Entry<String, String> entry: styles.entrySet()){
            ans.append(entry.getKey() + ":" + entry.getValue() + ";");
        }
        return ans.toString();
    }
    
    @Override
    public final String getRaw(){
        return text;
    }
    
    @Override
    public String toString(){
        return escapeText(text);
    }
    
    @Override
    public Document getDocument(){
        return doc;
    }
    
    @Override
    public SpanBranch getParent(){
        return parent;
    }
    
    @Override
    public int getLength(){
        return text.length();
    }
    
    void setParent(SpanNode<?> childOf){
        parent = (SpanBranch)childOf;
    }
}
