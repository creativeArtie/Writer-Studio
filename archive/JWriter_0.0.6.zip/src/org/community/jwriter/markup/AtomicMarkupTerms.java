package org.community.jwriter.markup;

public class AtomicMarkupTerms{
    
    private static final String STYLE_ID_PREFIX = "ID.";
    public static final String STYLE_ID_WARNING = STYLE_ID_PREFIX + "Warning";
    public static final String STYLE_ID_ERROR   = STYLE_ID_PREFIX + "Error";
    public static final String STYLE_ID_NONE = "";
    
    public static final String STYLE_BASIC =  "Basic.";
    public static final String STYLE_BASIC_COMMON = STYLE_BASIC + "All";
    
    private AtomicMarkupTerms(){}
}
