package org.community.jwriter.markup;

import static org.community.jwriter.markup.AtomicMarkupTerms.*;
    
/**
 * Types of error with the DirectoryId.
 */
public enum DirectoryStatus{
    /// This is no id assoicate in a DirectoryHolder
    NO_ID(STYLE_ID_ERROR),
    /// There is an id but nothing is refer to it
    UNUSED(STYLE_ID_WARNING),
    /// A reference that pointing to no known DirectoryId. 
    NOT_FOUND(STYLE_ID_ERROR), 
    /// More than one DirectoryId has the same name
    MULTIPLE(STYLE_ID_WARNING), 
    /// No error is found.
    NONE(STYLE_ID_NONE);
    
    private String style;
    
    private DirectoryStatus(String type){
        style = type;
    }
    
    public String getStyle(){
        return style;
    }
}
