package org.community.jwriter.property;

import java.util.Observable;
import java.util.Properties;
import java.util.HashMap;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class PropertyManager{
    private static final String extension = ".properties";
    private HashMap<String, Property<?>> properties;
    
    private Properties defaults;
    private Properties list;
    
    private String baseFile;
    private String userFile;
    
    public PropertyManager(String base, String user) throws IOException{
        baseFile = base + extension;
        defaults = new Properties();
        try(FileInputStream load = new FileInputStream(baseFile)){
            defaults.load(load);
        }
        list = new Properties(defaults);
        userFile = user + extension;
        try (FileInputStream load = new FileInputStream(userFile)){
            list.load(load);
        }
        properties = new HashMap<>();
    }
    
    public StyleProperty getStyleProperty(String key){
        StyleProperty ans = getProperty(key, StyleProperty.class);
        if (ans == null){
            ans = new StyleProperty(key, this);
            properties.put(key, ans);
        }
        return ans;
    }
    
    public IntegerProperty getIntProperty(String key){
        IntegerProperty ans = getProperty(key, IntegerProperty.class);
        if (ans == null){
            ans = new IntegerProperty(key, this);
            properties.put(key, ans);
        }
        return ans;
    }
    
    private <T> T getProperty(String key, Class<T> cast){
        Property<?> ans = found(key);
        if (ans != null){
            if (cast.isInstance(ans)){
                return cast.cast(ans);
            }
            throw new IllegalArgumentException(
                "Property is not an object of: " + cast.getSimpleName());
        }
        return null;
    }
    
    private Property<?> found(String key){
        if (list.getProperty(key) == null){
            throw new IllegalArgumentException("Property is not found: " + key +
                ".");
        }
        if (properties.containsKey(key)){
            return properties.get(key);
        }
        return null;
    }
    
    public void store() throws Exception{
        try(FileOutputStream out = new FileOutputStream(userFile)){
            list.store(out, "");
        }
    }
    
    String get(String key){
        return list.getProperty(key);
    }
    
    void set(String key, String property){
        list.setProperty(key, property);
    }
}
