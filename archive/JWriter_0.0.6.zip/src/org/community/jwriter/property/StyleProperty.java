package org.community.jwriter.property;

import java.util.Map;

import com.google.common.base.CharMatcher;

public class StyleProperty extends MapProperty{
    
    StyleProperty(String propertyKey, PropertyManager propertyManager){
        super(propertyKey, propertyManager, ":", ";");
    }
    
    protected Map<String, String> fromStorage(String value){
        return super.fromStorage(CharMatcher.whitespace().removeFrom(value));
    }
}
