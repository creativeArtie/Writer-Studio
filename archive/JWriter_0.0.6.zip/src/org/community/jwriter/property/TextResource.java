package org.community.jwriter.property;

import java.util.ArrayList;

public class TextResource {

    private String key;
    private TextResourceManager manager;
    private ArrayList<TextResourceListener> listeners;
    
    TextResource(String textKey, TextResourceManager textManager){
        key = textKey;
        manager = textManager;
        listeners = new ArrayList<>();
    }
    
    public String get(){
        return manager.get(key);
    }
    
    public void addAndCall(TextResourceListener listener){
        addListener(listener);
        listener.update(this, get());
    }
    
    protected void update(){
        for (TextResourceListener listener: listeners){
            listener.update(this, get());
        }
    }
    
    public void clearListeners(){
        listeners.clear();
    }
    
    public void addListener(TextResourceListener listener){
        listeners.add(listener);
    }
    
    public void removeListener(TextResourceListener listener){
        listeners.remove(listener);
    }
}
