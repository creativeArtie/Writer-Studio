package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import java.util.ArrayList;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class DirectoryDebug{
    
    public static final SpanExpectHelper id(ArrayList<String> cat, String id){
        DirectoryId dir = new DirectoryId(cat, id);
        return span ->{
            assertEquals("Wrong Class.", DirectorySpan.class, span.getClass());
            DirectorySpan base = (DirectorySpan)span;
            assertEquals("Wrong type.", DirectoryType.NONE, base.getPurpose());
            DirectoryId test = base.getId();
            assertArrayEquals("Wrong Category", dir.getCategory(), 
                test.getCategory());
            assertEquals("Wrong id", dir.getIdentity(), test.getIdentity());
            assertEquals("Wrong full id", dir.getFullIdentity(),
                test.getFullIdentity());
        };
    }
    
    private static final InputParser[] parsers = new InputParser[]{
        new DirectoryParser(DirectoryType.NONE)};
    
    @Test
    public void basic(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        SpanExpect child = new SpanExpect(id(category, "Hello"));
        child.addChild("Hello");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void singleCategory(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        category.add("cat");
        SpanExpect child = new SpanExpect(id(category, "Hi"));
        child.addChild("cat", "id");
        child.addChild("-", "id-token");
        child.addChild("Hi", "id");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void twoSubcategories(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        category.add("a");
        category.add("b");
        SpanExpect child = new SpanExpect(id(category, "c"));
        child.addChildren("a", "-", "b", "-", "c");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptySubcategory(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        category.add("");
        SpanExpect child = new SpanExpect(id(category, "c"));
        child.addChildren("-", "c");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptySecondSubcategory(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        category.add("yes");
        category.add("");
        SpanExpect child = new SpanExpect(id(category, "c"));
        child.addChildren("yes", "-", "-", "c");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void categoryEscape(){
        SpanExpect doc = new SpanExpect();
        ArrayList<String> category = new ArrayList<>();
        SpanExpect child = new SpanExpect(id(category, "-c"));
        child.addChild("\\-c");
        doc.addChild(child);
        doc.testAll(parsers);
    }
}
