package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatLinkDebug {
    
    public static final SpanExpectHelper refHelp(String[] cat, String id,
            String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkRef.class, 
                span.getClass());
            FormatSpanLinkRef test = (FormatSpanLinkRef) span;
            assertArrayEquals("Wrong category.", cat, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
            testCommon(span, path, text);
        };
    }
    
    public static final SpanExpectHelper linkHelp(String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkDirect.class, 
                span.getClass());
            testCommon(span, path, text);
        };
    }
        
    static void testCommon(Span span, String path, String text){
        FormatSpanLink test = (FormatSpanLink) span;
        assertEquals("Wrong link path", path, test.getPath());
        assertEquals("Wrong link text.", text, test.getText());
    }
    
    private static final InputParser[] parsers = FormatParseLink.values();
    
    @Test
    public void refFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", "text"));
        ref.addChild("<@", "link-ref-error-token");
        
        SpanExpect id = new SpanExpect();
        SpanExpect idPart = new SpanExpect();
        idPart.addChild("cat", "link-ref-error-id");
        id.addChild(idPart);
        id.addChild("-", "link-ref-error-id-token");
        idPart = new SpanExpect();
        idPart.addChild("id", "link-ref-error-id");
        id.addChild(idPart);
        ref.addChild(id);
        
        ref.addChild("|", "link-ref-error-token");
        
        SpanExpect text = new SpanExpect();
        text.addChild("text", "link-ref-error");
        ref.addChild(text);
        
        ref.addChild(">", "link-ref-error-token");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refEmptyText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChild("<@");
        ref.addChild("cat-id");
        ref.addChild("|");
        ref.addChild(">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refNoText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChild("<@");
        ref.addChild("cat-id");
        ref.addChild(">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    @Test
    public void refNoCategory(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", "text"));
        ref.addChild("<@");
        ref.addChild("id");
        ref.addChild("|");
        ref.addChild("text");
        ref.addChild(">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", ""));
        ref.addChild("<@");
        ref.addChild("id");
        ref.addChild(">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        
        ref.addChild("<", "link-direct-token");
        
        SpanExpect path = new SpanExpect();
        path.addChild("path", "link-direct-path");
        ref.addChild(path);
        
        ref.addChild("|");
        
        SpanExpect title = new SpanExpect();
        title.addChild("text", "link-direct");
        ref.addChild(title);
        
        ref.addChild(">", "link-direct-token");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkPath(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "path"));
        ref.addChild("<");
        ref.addChild("path");
        ref.addChild(">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("", ""));
        ref.addChild("<");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        ref.addChild("<");
        ref.addChild("path");
        ref.addChild("|");
        ref.addChild("text");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
}
