package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedLevelHeadDebug extends LinedLevelTest{
    
    @Test
    public void spacedDirectoryFullHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title", LinedType.HEADING, 
            3, EditionType.OTHER, new String[]{"link"}, "id"));
        line.addChildren("===", "   @", "id", ":", "Title", "#abc", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void nonSpacedDirectoryFullHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title",  LinedType.HEADING, 
            3, EditionType.OTHER, new String[]{"link"},  "id"));
        line.addChildren("===", "@", "id", ":", "Title", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    @Test
    public void noStatusHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title",  LinedType.HEADING, 
            3, EditionType.NONE, new String[]{"link"},  "id"));
        line.addChildren( "===", "@", "id", ":", "Title");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    @Test
    public void nonSpacedDirectoryTitlelessHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("",  LinedType.HEADING, 3, 
            EditionType.OTHER, new String[]{"link"},  "id"));
        line.addChildren( "===", "@", "id", ":", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void partlyDirectoryHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("",  LinedType.HEADING, 3, 
            EditionType.NONE, new String[]{"link"},  "id"));
        line.addChildren( "===", "@", "id" );
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void idLessHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title",  LinedType.HEADING, 
            3, EditionType.OTHER, new String[0], ""));
        line.addChildren( "===", "Title", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusOnlyHeading(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("", LinedType.HEADING, 3,  
            EditionType.OTHER, new String[0], ""));
        line.addChildren( "===", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void heading6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title",  LinedType.HEADING, 
            6, EditionType.OTHER, new String[]{"link"},  "id"));
        line.addChildren("======", "@", "id", ":", "Title", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void heading1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(headHelp("Title",  LinedType.HEADING, 
            1, EditionType.OTHER, new String[0], ""));
        line.addChildren( "=", "Title", "#abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
