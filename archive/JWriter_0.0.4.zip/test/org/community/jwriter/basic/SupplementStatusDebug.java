package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.lang.reflect.Field;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class SupplementStatusDebug{

    @Parameters
    public static Collection<Object[]> data() {
        ArrayList<Object[]> ans = new ArrayList<>();
        for(DirectoryStatus status: DirectoryStatus.values()){
            ans.add(new Object[]{status});
        }
        return ans;
    }
    
    
    @Parameter
    public DirectoryStatus testCase;
    
    @Test 
    @Ignore("test not implemented")
    public void note(){
        StringBuilder base = new StringBuilder("{^abc}\n");
        String line = "!^abc:text\n";
        switch (testCase){
            //TODO stub test
            case NO_ID:
                break;
            case UNUSED:
                break;
            case NOT_FOUND:
                break;
            case MUTILPLE:
                break;
            case NONE:
                break;
        }
    }
    
    private void testSpan(Span span, String status){
    }
}
