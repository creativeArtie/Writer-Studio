package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedCiteDebug {
    
    public static final SpanExpectHelper basicHelp(LinedTypeSource expectedType, 
            String expectedOutput){
        return span ->{
        assertEquals("Wrong class.", LinedSpanCiteText.class, span.getClass());
            testCommon((LinedSpanCiteText)span, expectedType, expectedOutput);
        };
    }
    
    public static final SpanExpectHelper nameHelp(LinedTypeSource expectedType, 
            String lastName, String firstName){
        return span ->{
            assertEquals("Wrong class.", LinedSpanCiteName.class, span.getClass());
            LinedSpanCiteName test = (LinedSpanCiteName) span;
            testCommon(test, expectedType, lastName + ", " + firstName);
            assertEquals("Wrong last name.", lastName, test.getLastName());
            assertEquals("Wrong first name.", firstName, test.getFirstName());
        };
    }
    
    private static void testCommon(LinedSpanCite test, LinedTypeSource expectedType, 
            String expectedOutput){
        assertEquals("Wrong line type.", LinedType.SOURCE, test.getType());
        assertEquals("Wrong source field.", expectedType, test.getField());
        assertEquals("Wrong source data.", expectedOutput, test.getText());
    }
    
    private static final InputParser[] parsers = new InputParser[]{
            LinedParseCite.INSTANCE};
    
    @Test
    public void author(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(nameHelp(LinedTypeSource.AUTHOR, "Johnson", "See"));
        line.addChildren("!>", "author", ":", "Johnson", ",", "See");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void editor(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(nameHelp(LinedTypeSource.EDITOR, "Johnson", "See"));
        line.addChildren("!>", "editor", ":", "Johnson", ",", "See");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void translator(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(nameHelp(LinedTypeSource.TRANSLATOR, "Johnson", "See"));
        line.addChildren("!>", "translator", ":","Johnson", ",", "See");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void article(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ARTICLE, "hello"));
        line.addChildren("!>", "article", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void title(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.TITLE, "hello"));
        line.addChildren("!>", "title", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void edition(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.EDITION, "hello"));
        line.addChildren("!>", "edition", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void publishHouse(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.PUBLISH_HOUSE, "hello"));
        line.addChildren("!>", "publish-house", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void publishYear(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.PUBLISH_YEAR, "hello"));
        line.addChildren("!>", "publish-year", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void media(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, "hello"));
        line.addChildren("!>", "media", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void accessLocation(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ACCESS_LOCATION, "hello"));
        line.addChildren("!>", "access-location", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void accessDate(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ACCESS_DATE, "hello"));
        line.addChildren("!>", "access-date", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void pages(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.PAGES, "hello"));
        line.addChildren("!>", "pages", ":", "hello");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void partSpaced(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, "a"));
        line.addChildren("!>", "  media", "  :", "a");
    }

    @Test
    public void part1(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, "a"));
        line.addChildren("!>", "media", ":", "a");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part2(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ERROR, ":a"));
        line.addChildren("!>", ":a", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part3(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, ""));
        line.addChildren("!>", "media", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part4(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, ""));
        line.addChildren("!>", "media");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part5(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.MEDIA, "see"));
        line.addChildren("!>", "media", "see");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part6(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ERROR, "sdaf"));
        line.addChildren("!>", "sdaf");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part7(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ERROR, "sdaf:"));
        line.addChildren("!>", "sdaf:", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part8(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ERROR, "sdaf:aaa"));
        line.addChildren("!>", "sdaf:aaa", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }

    @Test
    public void part9(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(basicHelp(LinedTypeSource.ERROR, "sdaf:"));
        line.addChildren("!>", "sdaf:");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
