package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.runners.Parameterized.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.lang.reflect.Field;

import org.community.jwriter.markup.*;

@RunWith(Parameterized.class)
public class SupplementIDDebug extends IDParamTest{
    
    @Test
    public void linkRaw(){
        run("!@abc:text");
    }
    
    @Test
    public void outlineRaw(){
        run("!#@abc:hello");
    }
    
    @Test
    public void headingRaw(){
        run("=@abc:hello");
    }
    
    @Test
    public void endnote(){
        run("{*abc}", "!*abc:text", DirectoryType.ENDNOTE);
    }
    
    @Test
    public void footnote(){
        run("{^abc}", "!^abc:text", DirectoryType.FOOTNOTE);
    }
    
    @Test
    public void link(){
        run("<@abc>", "!@abc:text", DirectoryType.LINK);
    }
    
    @Test
    public void outline(){
        run("<@abc>", "!#@abc:hello", DirectoryType.LINK);
    }
    
    @Test
    public void heading(){
        run("<@abc>", "=@abc:hello", DirectoryType.LINK);
    }
    
    @Test
    public void note(){
        run("{@abc}", "!%@abc:hello", DirectoryType.NOTE);
    }
    
    private void run(String line){
        add(new DirectoryId(
            Arrays.asList(DirectoryType.LINK.getCategory()), "abc"), expected, 0);
        testAll(new Document(buildDoc("<@abc>", line), basic));
    }
    private void run(String ref, String line, DirectoryType cat){
        add(new DirectoryId(Arrays.asList(cat.getCategory()), "abc"), expected, 
            0);
        testAll(new Document(buildDoc(ref, line), main));
    }
    
    private String buildDoc(String ref, String line){
        StringBuilder text = new StringBuilder();
        for (States state: input){
            if (state == States.ID){
                text.append(line + "\n");
            } else {
                text.append(ref + "\n");
            }
        }
        return text.toString();
    }

    private static InputParser[] basic = new InputParser[]{LinedParseLevel.HEADING, 
        LinedParseLevel.OUTLINE, LinedParsePointer.HYPERLINK, 
        LinedParseRest.PARAGRAPH};
        
    private static InputParser[] main = new InputParser[]{new MainParser()};
}
