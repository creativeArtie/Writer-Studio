package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

public interface SpanExpectHelper{
    public void test(Span span);
}
