package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.time.LocalDateTime;
import java.time.Duration;
import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class StressFileDebug {
    @Test
    @Ignore("Because it doubles the test time for the package.")
    public void reallyLarge() throws Exception{
        String raw = new String(Files.readAllBytes(Paths.get("data/stressTest.txt")),
            StandardCharsets.UTF_8);
        LocalDateTime from = LocalDateTime.now();
        new Document(raw, new MainParser());
        System.out.println(Duration.between(from, LocalDateTime.now()));
    }
}
