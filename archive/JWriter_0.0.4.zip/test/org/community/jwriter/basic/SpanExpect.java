package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;

public class SpanExpect{

    private String text;
    
    private Optional<SpanExpectHelper> helper;
    
    public boolean verbose = false;
    
    private ArrayList<SpanExpect> expects;
    
    private Optional<String> style;
    
    public SpanExpect(){
        this(Optional.empty());
    }
    
    public SpanExpect(SpanExpectHelper help){
        this(Optional.ofNullable(help));
    }
    
    private SpanExpect(Optional<SpanExpectHelper> h){
        helper = h;
        expects = new ArrayList<>();
        text = "";
        style = Optional.empty();
    }
    
    public String getRaw(){
        return text;
    }
    
    public void addChildren(String ... children){
        for (String child: children){
            addChild(child, null);
        }
    }
    
    public void addChild(String text){
        addChild(text, null);
    }
    
    public void addChild(String text, String style){
        SpanExpect ans = new SpanExpect();
        ans.text = text;
        ans.style = Optional.ofNullable(style);
        addChild(ans);
    }
    
    public void addChild(SpanExpect expect){
        String doc = expect.getRaw();
        text += expect.text;
        expects.add(expect);
        if (verbose) {
            System.out.println("child" + expect);
            System.out.println("this " + this);
            System.out.println();
        }
    }
    
    public Document testAll(InputParser[] parsers){
        if (verbose) System.out.println();
        Document doc = new Document(getRaw(), parsers);
        test(0, doc);
        return doc;
    }
    
    private String toString(Span span, int count){
        String base = span.toString();
        base = base.replace("\n", "\n" + count + ": ");
        return count + ": " + base;
    }
    
    private int count = -1;
    public void test(Span span){
        test(0, span);
    }
    
    public int test(int start, Span span){
        count++;
        if (verbose){
            System.out.println(count + ": ");
            System.out.println(count + ": " + span.getClass());
            System.out.println(toString(span, count));
            System.out.println(count + ": " + this);
        }
        
        assertEquals("Wrong text: " + span, text, span.getRaw());
        assertEquals("Wrong length: " + span, text.length(), span.getLength());
        style.ifPresent(expect -> assertEquals(
            "Wrong style class.", expect, ((SpanChild)span).getStyle()
        ));
        helper.ifPresent(tester -> tester.test(span));
        int localStart = start;
        if (expects.size() > 0){
            assertTrue("Not a SpanNode class: " + span.getClass(), 
                span instanceof SpanNode);
            SpanNode test = (SpanNode) span;
            assertEquals("Wrong size: " + span, expects.size(), test.size());
            int i = 0;
            for (SpanExpect expect: expects){
                if (verbose){
                    System.out.println(toString((Span)test.get(i), count));
                    System.out.println(count + ": " + expect);
                    expect.verbose = true;
                }
                expect.count = count;
                Span child = (Span) test.get(i);
                expect.test(localStart, child);
                assertSame("Wrong parent.", test, child.getParent());
                localStart += expect.text.length();
                i++;
            }
        }
        if (verbose) System.out.println(count + ": passed");
        count--;
        return start + text.length();
    }
    
    public int length(){
        return text.length();
    }
    
    public String toString(){
        String help = (helper.isPresent()? "has" : " no") + "-help";
        String size = "childrens-" + expects.size();
        String outText = SpanLeaf.escapeText(text);
        return help + " " + size + " " + outText + style;
    }
}
