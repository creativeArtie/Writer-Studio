package org.community.jwriter.basic;

import java.util.List;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * A {@link ContentSpan} with format for {@link FormatSpan}. 
 */
public class FormatSpanContent extends ContentSpan {
    private boolean[] formats; 
    
    FormatSpanContent(boolean[] spanFormats, ContentSpan children){
        super(children);
        formats = new boolean[spanFormats.length];
        for(int i = 0; i < formats.length; i++){
            formats[i] = spanFormats[i];
        }
    }
    
    @Override
    public String getStyle(){
        String ans = "";
        int i = 0;
        for (String format: STYLE_FORMATS){
            if (formats[i]){
                ans = Span.appendStyle(ans, format);
            }
            i++;
        }
        return Span.appendStyle(this, ans);
    }
    
    public boolean isBold(){
        return formats[0];
    }
    
    public boolean isItalics(){
        return formats[1];
    }
    
    public boolean isUnderline(){
        return formats[2];
    }
    
    public boolean isCoded(){
        return formats[3];
    }
    
    @Override
    public String toString(){
        StringBuilder ans = new StringBuilder();
        if (formats[0]) ans.append("b");
        if (formats[1]) ans.append("i");
        if (formats[2]) ans.append("u");
        if (formats[3]) ans.append("c");
        return ans.toString() + super.toString();
    }
    
}
