package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Used by {@link DirectorySpan} to show main categories.
 */
public enum DirectoryType{
    FOOTNOTE(TYPE_FOOTNOTE), ENDNOTE(TYPE_ENDNOTE), 
    LINK(TYPE_LINK), NOTE(TYPE_NOTE), NONE(TYPE_NONE);
    
    private String categoryName;
    
    private DirectoryType(String name){
        categoryName = name;
    }
    
    public String getCategory(){
        return categoryName;
    }
    
    String getStyle(){
        return getCurlyStyle(categoryName);
    }
}
