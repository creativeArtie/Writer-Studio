package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import java.util.TreeMap;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class MainSpan extends SpanBranch{
    MainSpan(List<Span> children){
        super(children);
    }
    
    @Override
    public String getStyle(){
        return "";
    }
}
