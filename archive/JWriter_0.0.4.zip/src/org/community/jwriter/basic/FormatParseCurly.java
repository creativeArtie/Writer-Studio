package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanCurlyDirectory} and {@link FormatSpanCurlyAgenda} that uses 
 * curly bracket. These are footnote, endnote, cite, and to do.
 */
enum FormatParseCurly implements InputParser<FormatSpanCurly> {
    FOOTNOTE(CURLY_FOOTNOTE), ENDNOTE(CURLY_ENDNOTE), 
    AGENDA(CURLY_AGENDA), CITE(CURLY_CITE);
    
    private final String start;
    
    private FormatParseCurly(String st){
        start = st;
    }
    
    private Optional<FormatSpanCurly> parseAgenda(InputPointer pointer, 
        ArrayList<Span> children
    ){
        Optional<ContentSpan> text = new ContentParser(CURLY_END)
            .parse(children, pointer);
        
        /// Complete the last steps
        pointer.startsWith(children, CURLY_END);
        return Optional.of(new FormatSpanCurlyAgenda(children, text));
    }
    
    private Optional<FormatSpanCurly> parseNote(InputPointer pointer, 
        ArrayList<Span> children
    ){
            
        /// DirectoryId for the other Parsers
        Optional<DirectorySpan> data = new DirectoryParser(
            DirectoryType.values()[ordinal()], CURLY_END)
            .parse(children, pointer);
        
        /// Complete the last steps
        pointer.startsWith(children, CURLY_END);
        
        FormatSpanCurlyDirectory span = new FormatSpanCurlyDirectory(
            children, data, DirectoryType.values()[ordinal()]);
        
        data.ifPresent(id -> pointer.getMap().addRef(id.getId(), span));
        return Optional.of(span);
        
    }
    
    @Override
    public Optional<FormatSpanCurly> parse(InputPointer pointer){
        /// FOund therefore setup the SpanBranch
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, start)){
            if (this == AGENDA){
                return parseAgenda(pointer, children);
            } // else {
                return parseNote(pointer, children);
            // }
        }
        return Optional.empty();
    }
}
