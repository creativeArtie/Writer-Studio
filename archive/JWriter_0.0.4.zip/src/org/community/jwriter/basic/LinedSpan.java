package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpan extends SpanBranch {
    private final LinedType type;
    
    LinedSpan(List<Span> children, LinedType t){
        super(children);
        type = t;
    }
    
    @Override
    public String getStyle(){
        return type.getStyle();
    }
    
    public LinedType getType(){
        return type;
    }
    
    public String toString(){
        return type + super.toString();
    }
}
