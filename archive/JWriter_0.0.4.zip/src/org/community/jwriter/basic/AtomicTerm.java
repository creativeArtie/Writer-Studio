package org.community.jwriter.basic;

/**
 * All special string use in the markup language.
 */
public final class AtomicTerm{
    /// For LinedParseLevel 
    public static final int LEVEL_MAX = 6; /// maximum # of levels
    private static final String LEVEL_BEGIN    = "\t";
    private static final String LEVEL_HEADING  = "=";
    private static final String LEVEL_NUMBERED = "#";
    private static final String LEVEL_OUTLINE  = "#";
    private static final String LEVEL_BULLET   = "-";
    private static final String LEVEL_QUOTE    = ">";
    public static String getLinedLevel(LinedParseLevel from, int level){
        switch (from){
            case HEADING:
                return repeat(LEVEL_HEADING, level);
            case OUTLINE:
                return LINED_BEGIN + repeat(LEVEL_OUTLINE, level);
            case QUOTE:
                return repeat(LEVEL_QUOTE, level);
            case NUMBERED:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_NUMBERED;
            case BULLET:
                return repeat(LEVEL_BEGIN, level - 1) + LEVEL_BULLET;
        }
        throw new IllegalArgumentException("LinedLevelParser not used.");
    }
    /// getLinedLevel helper
    private static String repeat(String repeats, int level){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < level; i++){
            builder.append(repeats);
        }
        return builder.toString();
    }
    
    /// For LinedParser and subclass, excluding LinedParseLevel
    private static final String LINED_BEGIN = "!"; ///Special starter
    public static final String LINED_DATA = ":"; /// between id & text/data
    public static final String LINED_NAME = ","; /// between last & first names
    public static final String LINED_END = "\n"; /// ends lines anywhere
    public static final String LINED_AGENDA   = LINED_BEGIN + "!"; 
    public static final String LINED_NOTE     = LINED_BEGIN + "%";   
    public static final String LINED_SOURCE   = LINED_BEGIN + ">";
    public static final String LINED_LINK     = LINED_BEGIN + "@";
    public static final String LINED_FOOTNOTE = LINED_BEGIN + "^";
    public static final String LINED_ENDNOTE  = LINED_BEGIN + "*";
    public static final String LINED_BREAK = "***\n";
    
    /// For LinedParseLevel, LinedParseRest, DirectoryParser, CURLY_CITE
    public static final String DIRECTORY_BEGIN    = "@"; /// Start
    public static final String DIRECTORY_CATEGORY = "-"; /// Middle (Separator)
    public static final String DIRECTORY_END      = ":"; /// End
    
    /// For LinedParseLevel, EditionParser
    public static final String EDITION_BEGIN = "#";
    
    /// For FormatParseLink, listFormatEnders
    public static final String LINK_BEGIN =              "<"; /// Direct Start
    public static final String LINK_REF   = LINK_BEGIN + "@"; /// Ref Start
    public static final String LINK_TEXT  =              "|"; /// Text start
    public static final String LINK_END   =              ">"; /// End
    
    /// For FormatParseCurly
    private static final String CURLY_BEGIN   = "{";
    public static final String CURLY_AGENDA   = CURLY_BEGIN + "!";
    public static final String CURLY_FOOTNOTE = CURLY_BEGIN + "^";
    public static final String CURLY_ENDNOTE  = CURLY_BEGIN + "*";
    public static final String CURLY_CITE     = CURLY_BEGIN + DIRECTORY_BEGIN;
    public static final String CURLY_END      = "}";
    
    /// For FormatParser, listFormatEnders
    private static final String FORMAT_ITALICS  = "*";
    private static final String FORMAT_BOLD     = "**";
    private static final String FORMAT_UNDERLINE = "_";
    private static final String FORMAT_CODED     = "`";
    public static final String[] listSpanFormats(){
        return new String[]{
            FORMAT_BOLD, FORMAT_ITALICS, FORMAT_UNDERLINE, FORMAT_CODED
        };
    }
    
    /// For ContentParser, listFormatEnders
    public static final String CHAR_ESCAPE    = "\\";
    
    /// For FormatParsers
    public static String[] listFormatEnders(){
        return new String[]{
            CURLY_AGENDA, CURLY_FOOTNOTE, CURLY_ENDNOTE, CURLY_CITE, CURLY_END, 
            LINK_BEGIN, LINK_REF, 
            FORMAT_ITALICS, FORMAT_BOLD, FORMAT_UNDERLINE, FORMAT_CODED,
            CHAR_ESCAPE};
    }
    
    
    /// Styles
    private static final String SEP = "-";
    
    public static final String STYLE_ESCAPE = "escape";
    
    public static final String STYLE_ID = "id";
    
    private static final String STYLE_EDITION = "edition";
    public static final String STYLE_STUB  = STYLE_EDITION + SEP + "stub";
    public static final String STYLE_DRAFT = STYLE_EDITION + SEP + "draft";
    public static final String STYLE_FINAL = STYLE_EDITION + SEP + "final";
    public static final String STYLE_REST  = STYLE_EDITION;
    
    public static final String STYLE_AGENDA  = "agenda";
    
    private static final String STYLE_CURLY = "curly";
    public static final String TYPE_FOOTNOTE = "foot";
    public static final String TYPE_ENDNOTE = "end";
    public static final String TYPE_LINK = "link";
    public static final String TYPE_NOTE = "note";
    public static final String TYPE_NONE = "";
    public static String getCurlyStyle(String style){
        return STYLE_CURLY + (style.isEmpty()? "": SEP + style);
    }
    
    private static final String STYLE_LINK = "link";
    public static final String STYLE_LINK_DIRECT= STYLE_LINK + SEP +"direct";
    public static final String STYLE_LINK_REF = STYLE_LINK + SEP + "ref";
    
    private static final String STYLE_BOLD = "b";
    private static final String STYLE_ITALICS = "i";
    private static final String STYLE_UNDERLINE = "u";
    private static final String STYLE_CODED = "c";
    public static final String[] STYLE_FORMATS = new String[]{
        STYLE_BOLD, STYLE_ITALICS, STYLE_UNDERLINE, STYLE_CODED
    };
    
    private AtomicTerm(){}
}
