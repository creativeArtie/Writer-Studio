package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public abstract class LinedSpanCite extends LinedSpan {
    private final LinedTypeSource field;
    
    public LinedSpanCite(List<Span> children, LinedTypeSource type){
        super(children, LinedType.SOURCE);
        field = type;
    }
    
    public LinedTypeSource getField(){
        return field;
    }
    
    public abstract String getText();
}
