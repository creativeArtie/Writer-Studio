package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.Optional;  /// For parsing purposes

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Create a Span for {@link DirectoryId}.
 */
final class DirectoryParser implements InputParser<DirectorySpan>{
    /// Shows how to end a text
    private final ContentParser idParser;
    
    /// Adds a root category to differentiate footnote, links, etc
    private final DirectoryType type;
    
    private static OutputStyle USE_STYLE = OutputStyle.ID;
    
    DirectoryParser(DirectoryType idType, String ... enders){
        type = idType;
        
        /// adding DIRECTORY_CATEGORY into enders by copying into new array
        String[] init = new String[enders.length + 1];
        System.arraycopy(enders, 0, init, 0, enders.length);
        init[enders.length] = DIRECTORY_CATEGORY;
        idParser = new ContentParser(init);
    }
    
    @Override
    public Optional<DirectorySpan> parse(InputPointer pointer){
        /// Setup for DirectorySpan
        ArrayList<Span> children = new ArrayList<>();
        ArrayList<String> cat = new ArrayList<>();
        
        /// Extract category & id
        boolean hasMore = true;
        Optional<ContentSpan> current; /// doubles as id
        do {
            current = idParser.parse(children, pointer); 
            
            /// last current is not an id but a category
            if (pointer.startsWith(children, DIRECTORY_CATEGORY)){
                cat.add(current.isPresent()? current.get().getText(): "");
                current = Optional.empty();
                hasMore = true;
            } else {
                hasMore = false;
            }
        } while (hasMore);
        
        /// Create span if there are Span extracted
        if (children.size() > 0) {
            return Optional.of(new DirectorySpan(children, cat, current, type));
        }
        return Optional.empty();
    }
}
