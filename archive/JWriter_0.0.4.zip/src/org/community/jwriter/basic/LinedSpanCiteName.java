package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

public class LinedSpanCiteName extends LinedSpanCite {
    
    private final Optional<String> first;
    private final Optional<String> last;
    
    public LinedSpanCiteName(List<Span> children, 
            LinedTypeSource type, Optional<ContentSpan> lastName, 
            Optional<ContentSpan> firstName){
        super(children, type);
        first = Optional.ofNullable(firstName.isPresent()? 
            firstName.get().getText(): null);
        last = Optional.ofNullable(lastName.isPresent()? 
            lastName.get().getText(): null);
    }
    
    public String getFirstName(){
        return first.orElse("");
    }
    
    public String getLastName(){
        return last.orElse("");
    }
    
    public String getText(){
        return last.orElse("") + LINED_NAME + " " + first.orElse("");
    }
    
    public boolean isCorrect(){
        return first.isPresent() && last.isPresent();
    }
}
