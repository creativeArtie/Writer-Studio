package org.community.jwriter.markup;

import java.util.ArrayList;
import com.google.common.collect.ImmutableList;

public class DirectoryData{
    private final ArrayList<Span> targets;
    private final ArrayList<Span> pointers;
    private final DirectoryStatus status;
    
    static class Builder{
        private ArrayList<Span> tBuild;
        private ArrayList<Span> pBuild;
        
        private Builder(){
            tBuild = new ArrayList<>();
            pBuild = new ArrayList<>();
        }
        
        void addId(Span span){
            tBuild.add(span);
        }
        
        void addRef(Span span){
            pBuild.add(span);
        }
        
        void removeLastId(){
            tBuild.remove(tBuild.size() - 1);
        }
        
        void removeLastRef(){
            pBuild.remove(pBuild.size() - 1);
        }
        
        DirectoryData build(){
            return new DirectoryData(tBuild, pBuild);
        }
    }
    
    static Builder builder(){
        return new Builder();
    }
    
    private DirectoryData (ArrayList<Span> t, ArrayList<Span> p){
        targets = t;
        pointers = p;
        if (targets.size() > 1){
            status = DirectoryStatus.MUTILPLE;
        } else if (targets.size() == 0){
            status = DirectoryStatus.NOT_FOUND;
        } else {
            status = pointers.size() > 0? DirectoryStatus.NONE: DirectoryStatus.UNUSED;
        }
    }
    
    public DirectoryStatus getState(){
        return status;
    }
    
    public boolean isReady(){
        return status == DirectoryStatus.NONE;
    }
    
    public Span getTarget(){
        if (targets.size() == 1){
            return targets.get(0);
        }
        throw new IllegalStateException("DirectoryId Data is in the wrong state: " 
            + status);
    }
    
    public ImmutableList<Span> getIds(){
        return ImmutableList.copyOf(targets);
    }
    
    public ImmutableList<Span> getRefs(){
        return ImmutableList.copyOf(pointers);
    }
    
    public String toString(){
        return status.toString() + "\nIds{\n\t" + 
            targets.toString().replace("\n", "\n\t") + "\n}Refs{" +
            pointers.toString() + "}\n";
    }
}
