package org.community.jwriter.markup;

/**
 * A subdivision of a {@link Document}
 */
public interface Span{
    
    public static String appendStyle(Span child, String postfix){
        Span parent = child.getParent();
        if (parent instanceof SpanBranch){
            return appendStyle(((SpanBranch)parent).getStyle(), postfix);
        }
        return appendStyle("", postfix);
    }
    
    public static String appendStyle(String prefix, Span child){
        Span parent = child.getParent();
        if (parent instanceof SpanBranch){
            return appendStyle(prefix, ((SpanBranch)parent).getStyle());
        }
        return appendStyle(prefix, "");
    }
    
    public static String appendStyle(String prefix, String postfix){
        if (prefix.isEmpty()){
            return postfix;
        } else if (postfix.isEmpty()){
            return prefix;
        }
        return prefix + "-" + postfix;
    }
    
    /**
     * Get the raw text for saving and for markup editor.
     */
    public String getRaw();
    
    public int getLength();
    
    public Document getDocument();
    
    public SpanNode<?> getParent();
}
