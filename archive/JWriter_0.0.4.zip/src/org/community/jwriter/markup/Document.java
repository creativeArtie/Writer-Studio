package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * {@code Document} is what {@link org.community.jwriter.window} and 
 * {@link org.community.output} use to represent the text file. This will
 * immediately parse the document upon the constructor.
 */
public final class Document extends SpanNode<SpanBranch>{

    private final ArrayList<SpanBranch> children;
    private final DirectoryMap idMap;
    private final String doc;
    
    public Document(String document, InputParser<?> ... init){
        assert document != null;
        /// Setup for runtime exceptions
        int counter = 0; 
        doc = document;
        
        /// Setup for building the doc and a pointer to use
        children = new ArrayList<>();
        InputPointer ptr = new InputPointer(this);
        
        /// Parse loop
        while (ptr.hasNext()){
            /// DirectoryStatus checking what happen if InputPointer fails or 
            /// InputParser[] misses the texts
            if(counter > doc.length()){
                System.out.println(children);
                System.out.println(ptr);
                throw new RuntimeException("Loop too much");
            }
            counter++;
            
            /// Finding the correct InputParser to build span from
            for(InputParser<?> s: init){
                Optional<?> span = s.parse(ptr);
                
                //Span has been created
                if (span.isPresent()){
                    SpanBranch found = (SpanBranch)span.get();
                    found.setParent(this);
                    children.add(found);
                    break;
                }
            }
        }
        
        /// Finalize the parse loop
        idMap = ptr.getMap().build();
    }
    
    @Override
    public List<SpanBranch> delegate(){
        return children;
    }
    
    @Override
    public final String getRaw(){
        return doc;
    }
    
    public DirectoryMap getMap(){
        return idMap;
    }
    
    public String toString(){
        if (idMap.size() == 0){
            return super.toString() + idMap.toString();
        }
        return super.toString() + "\n" + idMap.toString();
    }
    
    @Override
    public Document getDocument(){
        return this;
    }
    
    @Override
    public int getLength(){
        return doc.length();
    }
    
    @Override
    public SpanNode<?> getParent(){
        throw new UnsupportedOperationException("No parents");
    }
}
