package org.community.jwriter.markup;

import java.util.ArrayList;

public enum OutputStyle{
    KEYWORD("token"), ID("id"), FIELD("key"), DATA("data"), PATH("path"), 
    TEXT("");
    
    private String style;
    
    private OutputStyle(String s){
        style = s;
    }
    
    String getStyle(){
        return style;
    }
}
