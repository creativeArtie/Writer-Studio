package org.community.jwriter.markup;

import java.util.Optional;

public interface DirectoryHolder extends Comparable<DirectoryHolder>, Span{
    static final String STYLE_WARNING = "warning";
    static final String STYLE_ERROR = "error";
    
    public Optional<DirectoryId> getId();
    
    public Document getDocument();
    
    public default DirectoryStatus getStatus(){
        Optional<DirectoryId> id = getId();
        if (id.isPresent()){
            return getDocument().getMap().get(id.get()).getState();
        }
        return DirectoryStatus.NO_ID;
    }
    
    static String appendStyle(String start, DirectoryHolder instance){
        String issues = "";
        switch(instance.getStatus()){
            case NONE:
                break;
            case UNUSED:
            case MUTILPLE:
                issues = STYLE_WARNING;
                break;
            default:
                issues = STYLE_ERROR;
        }
        return Span.appendStyle(start, Span.appendStyle(instance, issues));
    }
    
    public default String[] getCategory(){
        Optional<DirectoryId> id = getId();
        return getId().isPresent()? id.get().getCategory(): new String[0];
    }
    
    public default String getIdentity(){
        Optional<DirectoryId> id = getId();
        return id.isPresent()? id.get().getIdentity(): "";
    }
    
    public default int compareTo(DirectoryHolder holder){
        Optional<DirectoryId> id = getId();
        if (id.isPresent()){
            Optional<DirectoryId> id2 = holder.getId();
            if (id2.isPresent()){
                return id.get().compareTo(id2.get());
            }
            return 1;
        }
        return -1;
    }
    
    public default Optional<Span> getTarget(){
        Optional<DirectoryId> id = getId();
        if (id.isPresent()){
            DirectoryData data = getDocument().getMap().get(id.get());
            if (data.isReady()){
                return Optional.of(data.getTarget());
            }
        }
        return Optional.empty();
    }
}
