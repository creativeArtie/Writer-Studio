package org.community.jwriter.markup;

import java.util.ArrayList;

public class OutputCursor{
    private final Document doc;
    private int docPointer;
    private int childPointer;
    private int ptr;
    private ArrayList<SpanLeaf> children;
    
    public OutputCursor(Document document){
        this(document, document.getLength());
    }
    
    private void getChildren(SpanBranch span){
        for(Span child: span){
            if (child instanceof SpanBranch){
                getChildren((SpanBranch)child);
            } else if (child instanceof SpanLeaf){
                children.add((SpanLeaf)child);
            } else {
                throw new IllegalArgumentException(
                    "Document contains unacceptable Span sub class.");
            }
        }
    }
    
    public OutputCursor(Document document, int location){
        doc = document;
        docPointer = location;
        Span span = document;
        children = new ArrayList<>();
        for (SpanBranch child: document){
            getChildren(child);
        }
        goTo(location);
    }
    
    public void goTo(int location){
        int search = 0;
        int i = 0;
        for (SpanLeaf child: children){
            if (search + child.getLength() < location){
                search += child.getLength();
            } else {
                ptr = i;
                break;
            }
            i++;
        }
        childPointer = docPointer - search;
    }
    
    public void shift(int shift){
        childPointer += shift;
        while(childPointer < 0){
            ptr--;
            childPointer = children.get(ptr).getLength() + childPointer;
        }
        while(childPointer > children.get(ptr).getLength()){
            childPointer -= children.get(ptr).getLength();
            ptr++;
        }
    }
    
    public SpanLeaf getCurrentSpan(){
        return children.get(ptr);
    }
}
