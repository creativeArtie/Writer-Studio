package org.community.jwriter.markup;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ForwardingList;

/**
 * Common methods for {@link Document} and {@link SpanBranch}.
 */
public abstract class SpanNode<T extends Span> extends ForwardingList<T> 
        implements Span {
    
    public SpanNode(){}
    
}
