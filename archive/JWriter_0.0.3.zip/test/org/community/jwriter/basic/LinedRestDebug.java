package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class LinedRestDebug {
    
    public static final SpanExpectHelper breakHelp(){
        return span ->{
            assertEquals("Wrong class.", LinedSpan.class, span.getClass());
            assertEquals("Wrong type.", 
                LinedType.BREAK, ((LinedSpan)span).getType());
        };
    }
    
    public static final SpanExpectHelper agendaHelp(String text){
        return span ->{
            assertEquals("Wrong class.", LinedSpanTodo.class, span.getClass());
            LinedSpanTodo test = (LinedSpanTodo) span;
            assertEquals("Wrong type.", LinedType.AGENDA, test.getType());
            assertEquals("Wrong text.", text, test.getReason());
        };
    }
    
    public static final SpanExpectHelper paragraphHelp(){
        return span -> {
            assertEquals("Wrong class.", LinedSpanParagraph.class, span.getClass());
            LinedSpanParagraph test = (LinedSpanParagraph)span;
            assertEquals("Wrong type.", LinedType.PARAGRAPH, test.getType());
        };
    }
    
    private static final InputParser[] parsers = LinedParseRest.values();
    
    @Test
    public void testBreak(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(breakHelp());
        line.addChild("***\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void fullAgenda(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(agendaHelp("abc"));
        line.addChild("!!", "abc", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptyAgenda(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(agendaHelp(""));
        line.addChild("!!");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void spaceAgenda(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(agendaHelp(""));
        line.addChild("!!", " ");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void basicAgenda(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(agendaHelp("Help"));
        line.addChild("!!", "Help");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void escapeAgenda(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(agendaHelp("H!"));
        line.addChild("!!", "H\\!");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void emptyParagraph(){
        SpanExpect doc = new SpanExpect();
        doc.testAll(parsers);
    }
    
    @Test
    public void noNewlineParagraph(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(paragraphHelp());
        line.addChild("abc");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void simpleParagraph(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(paragraphHelp());
        line.addChild("abc", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void basicParagraph(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(paragraphHelp());
        SpanExpect format = new SpanExpect();
        format.addChild("abc\\{@");
        line.addChild(format);
        line.addChild("\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
    
    @Test
    public void doubleParagraph(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line1 = new SpanExpect(paragraphHelp());
        SpanExpect format = new SpanExpect();
        format.addChild("abc\\{@", "**", "abc", "**");
        line1.addChild(format);
        line1.addChild("\n");
        doc.addChild(line1);
        SpanExpect line2 = new SpanExpect(paragraphHelp());
        line2.addChild("Charles is boy.");
        doc.addChild(line2);
        doc.testAll(parsers);
    }
    
    @Test
    public void doubleParagraph2(){
        SpanExpect doc = new SpanExpect();
        SpanExpect line = new SpanExpect(paragraphHelp());
        line.addChild("abc\\{@", "\n");
        doc.addChild(line);
        line = new SpanExpect();
        line.addChild("Charles is boy.", "\n");
        doc.addChild(line);
        doc.testAll(parsers);
    }
}
