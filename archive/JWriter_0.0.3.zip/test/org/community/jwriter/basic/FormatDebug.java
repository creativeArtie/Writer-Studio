package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatDebug {
    
    public static final SpanExpectHelper formatHelp(boolean isBold, 
            boolean isItalics, boolean isUnderline, boolean isCoded, 
            String text){
        return span ->{
        assertEquals("Wrong class gotten for "+ span + ": " + span.getClass(), 
            FormatSpanContent.class, span.getClass());
            
        FormatSpanContent test = (FormatSpanContent) span;
        assertEquals("Wrong text for " + span, text, test.getText());
        
        assertEquals("Wrong bold format for " + span, isBold, test.isBold());
        assertEquals("Wrong italics format for " + span, isItalics, 
            test.isItalics());
        assertEquals("Wrong underline format for " + span, isUnderline, 
            test.isUnderline());
        assertEquals("Wrong coded format for " + span, isCoded, test.isCoded());
        };
    }
    
    private static final InputParser[] parsers = new InputParser[]{new FormatParser()};
    
    @Test
    public void parseBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(formatHelp(false, false, false, false, "abc"));
        child.addChild("abc");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseBold(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(formatHelp(false, false, false, false, "or"));
        child.addChild("or");/// + 2
        parent.addChild(child);
        
        parent.addChild("**"); /// = 4
        
        child = new SpanExpect(formatHelp(true, false, false, false, "an"));
        child.addChild("an"); /// = 6
        parent.addChild(child);
        
        parent.addChild("**"); /// = 8
        
        child = new SpanExpect(formatHelp(false, false, false, false, "ge"));
        child.addChild("ge");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseItalics(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        SpanExpect child;
        child = new SpanExpect(formatHelp(false, false, false, false, "g"));
        child.addChild("g"); /// = 1 
        parent.addChild(child);
        
        parent.addChild("*"); /// = 2
        
        child = new SpanExpect(formatHelp(false, true, false, false, "ee"));
        child.addChild("ee"); /// = 4
        parent.addChild(child);
        
        parent.addChild("*"); /// = 5
        
        child = new SpanExpect(formatHelp(false, false, false, false, "n"));
        child.addChild("n");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseUnderlineCoded(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        
        parent.addChild("_"); /// = 1
        
        SpanExpect child;
        child  = new SpanExpect(formatHelp(false, false, true, false, "g"));
        child.addChild("g"); /// = 2
        parent.addChild(child);
        
        parent.addChild("_"); /// = 3
        
        child = new SpanExpect(formatHelp(false, false, false, false, "e_e"));
        child.addChild("e", "\\_", "e"); /// e4\\5_6e =7
        parent.addChild(child);
        
        parent.addChild("`"); /// =8
        
        child = new SpanExpect(formatHelp(false, false, false, true, "dd"));
        child.addChild("dd");
        parent.addChild(child);
        
        parent.addChild("_");
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseStarted(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        parent.addChild("_");
        
        SpanExpect child;
        child = new SpanExpect(formatHelp(false, false, true, false, "abc"));
        child.addChild("abc");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseSeparate(){
        SpanExpect doc = new SpanExpect();
        SpanExpect parent = new SpanExpect();
        parent.addChild("_"); /// = 1
        
        SpanExpect child;
        child = new SpanExpect(formatHelp(false, false, true, false, "abc")); 
        child.addChild("abc"); /// a2b3c = 4
        parent.addChild(child);
        
        parent.addChild("{^see}"); /// {5^6s7e8e9} = 10
        
        child = new SpanExpect(formatHelp(false, false, true, false, "pee"));
        child.addChild("pee");
        parent.addChild(child);
        
        doc.addChild(parent);
        doc.testAll(parsers);
    }
    
    @Test
    public void parseEmpty(){
        SpanExpect doc = new SpanExpect();
        doc.testAll(parsers);
    }
}
