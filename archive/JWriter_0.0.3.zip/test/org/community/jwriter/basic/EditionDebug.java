package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class EditionDebug {

    public static final SpanExpectHelper statusHelp(EditionType type, 
            String text){
        return span ->{
            assertEquals("Wrong class gotten: " + span.getClass(), 
                EditionSpan.class, span.getClass());
            EditionSpan test = (EditionSpan) span;
            assertEquals("Wrong type.", type, test.getType());
            assertEquals("Wrong detail.", text, test.getDetail());
        };
    }
    
    private static final InputParser[] parsers = EditionParser.values();
    
    @Test
    public void statusOtherBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "abc"));
        ref.addChild("#");
        ref.addChild("abc");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusEscaped(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.OTHER, "FINAL"));
        ref.addChild("#");
        ref.addChild("\\FINAL");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusStub(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.STUB, "d2"));
        ref.addChild("#STUB");
        ref.addChild("d2");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, ""));
        ref.addChild("#FINAL");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalTrim(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "2"));
        ref.addChild("#FINAL");
        ref.addChild("  2  ");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusFinalMidSpanced(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.FINAL, "abc ad"));
        ref.addChild("#FINAL");
        ref.addChild("abc  ad");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void statusDraft(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(statusHelp(
            EditionType.DRAFT, "ccc"));
        ref.addChild("#DRAFT");
        ref.addChild("cc\\c");
        doc.addChild(ref);
        doc.testAll(parsers);
    }

}
