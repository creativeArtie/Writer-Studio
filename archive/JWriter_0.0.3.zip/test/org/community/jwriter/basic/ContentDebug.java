package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class ContentDebug{
    
    public static final SpanExpectHelper contentHelp(String text,
            boolean isBegin, boolean isEnd){
        return span ->{
            assertEquals("Wrong Class.", ContentSpan.class, span.getClass());
            ContentSpan test = (ContentSpan) span;
            assertEquals("Wrong text.", text, test.getText());
            assertEquals("Wrong begin.", isBegin, test.isSpaceBegin());
            assertEquals("Wrong end.", isEnd, test.isSpaceEnd());
        };
    }
    
    public static final SpanExpectHelper escapeHelp(String text){
        return span ->{
            assertEquals("Wrong Class.", ContentSpanEscape.class, 
                span.getClass());
            assertEquals("Wrong text.", text, 
                ((ContentSpanEscape)span).getEscape());
        };
    }
    
    private static final InputParser[] parsers = new InputParser[]{new ContentParser()};
    
    @Test
    public void empty(){
        new SpanExpect().testAll(parsers);
    }
    
    @Test
    public void basic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect child = new SpanExpect(contentHelp("Hello", false, true));
        child.addChild("Hello  ");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void singleSpace(){
        SpanExpect doc = new SpanExpect();
        SpanExpect child = new SpanExpect(contentHelp("", true, true));
        child.addChild(" ");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void doubleSpace(){
        SpanExpect doc = new SpanExpect();
        SpanExpect child = new SpanExpect(contentHelp("", true, true));
        child.addChild("  ");
        doc.addChild(child);
        doc.testAll(parsers);
    }
    
    @Test
    public void basicEscape(){
        SpanExpect doc = new SpanExpect();
        SpanExpect text = new SpanExpect(contentHelp("b", false, false));
        
        SpanExpect escape = new SpanExpect(escapeHelp("b"));
        escape.addChild("\\");
        escape.addChild("b");
        text.addChild(escape);
        
        doc.addChild(text);
        doc.testAll(parsers);
    }
    
    @Test
    public void midEscape(){
        SpanExpect doc = new SpanExpect();
        SpanExpect text = new SpanExpect(contentHelp("abc", true, false));
        text.addChild("   a");
        
        SpanExpect escape = new SpanExpect(escapeHelp("b"));
        escape.addChild("\\");
        escape.addChild("b");
        text.addChild(escape);
        
        text.addChild("c");
        
        doc.addChild(text);
        doc.testAll(parsers);
    }
    
    @Test
    public void escapeSlash(){
        SpanExpect doc = new SpanExpect();
        SpanExpect text = new SpanExpect(contentHelp("\\", false, false));
        
        SpanExpect escape = new SpanExpect(escapeHelp("\\"));
        escape.addChild("\\");
        escape.addChild("\\");
        text.addChild(escape);
        
        doc.addChild(text);
        doc.testAll(parsers);
    }
    
    @Test
    public void escapeSpace(){
        SpanExpect doc = new SpanExpect();
        SpanExpect text = new SpanExpect(contentHelp("", true, true));
        SpanExpect escape = new SpanExpect(escapeHelp(" "));
        escape.addChild("\\");
        escape.addChild(" ");
        text.addChild(escape);
        
        doc.addChild(text);
        doc.testAll(parsers);
    }
    
    @Test
    public void escapeCutOff(){
        SpanExpect doc = new SpanExpect();
        SpanExpect text = new SpanExpect(contentHelp("", false, false));
        SpanExpect escape = new SpanExpect(escapeHelp(""));
        escape.addChild("\\");
        text.addChild(escape);
        
        doc.addChild(text);
        doc.testAll(parsers);
    }
}
