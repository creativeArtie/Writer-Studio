package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatCurlyDebug {
    
    public static final SpanExpectHelper noteHelp(DirectoryType type, 
            String[] expectRef, String expectId){
        return span ->{
            assertEquals("Wrong span class", FormatSpanCurlyDirectory.class,
                span.getClass());
            FormatSpanCurlyDirectory test = (FormatSpanCurlyDirectory) span;
            assertEquals("Wrong note type", type, test.getType());
            assertArrayEquals("Wrong Category.", expectRef, test.getCategory());
            assertEquals("Wrong id.", expectId, test.getIdentity());
        };
    }
    
    private static final InputParser[] parsers = FormatParseCurly.values();
    @Test
    public void cite(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.NOTE, new String[]{"note"}, "abc"));
        agenda.addChild("{@");
        agenda.addChild("abc");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }

    @Test
    public void endnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.ENDNOTE, new String[]{"end"}, "abc"));
        agenda.addChild("{*");
        agenda.addChild("abc");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }

    @Test
    public void footnote(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[]{"foot"}, "abc"));
        agenda.addChild("{^");
        agenda.addChild("abc");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }

    @Test
    public void noEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[]{"foot"}, "abc"));
        agenda.addChild("{^");
        agenda.addChild("abc");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }

    @Test
    public void onlyStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[0], ""));
        agenda.addChild("{^");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }

    @Test
    public void noText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect agenda = new SpanExpect(noteHelp(
            DirectoryType.FOOTNOTE, new String[0], ""));
        agenda.addChild("{^");
        agenda.addChild("}");
        doc.addChild(agenda);
        doc.testAll(parsers);
    }
}
