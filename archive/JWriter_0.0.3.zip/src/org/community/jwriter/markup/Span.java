package org.community.jwriter.markup;

/**
 * A subdivision of a {@link Document}
 */
public interface Span{
    
    /**
     * Get the raw text for saving and for markup editor.
     */
    public String getRaw();
    
    public int getLength();
    
    public Document getDocument();
    
    public SpanNode<?> getParent();
}
