package org.community.jwriter.markup;

import java.util.LinkedList;
import java.util.List;


/**
 * A {@link Span} handling {@link SpanLeaf}
 */
public abstract class SpanBranch extends SpanNode<Span> {
    
    private final LinkedList<Span> spans;
    private SpanNode<?> parent;
    
    public SpanBranch(List<Span> children){
        spans = new LinkedList<>(children);
        for(Span span : spans){
            if (span instanceof SpanBranch){
                ((SpanBranch)span).setParent(this);
            } else {
                ((SpanLeaf)span).setParent(this);
            }
        }
    }
    
    @Override
    public final List<Span> delegate(){
        return spans;
    }
    
    @Override
    public final String getRaw(){
        StringBuilder builder = new StringBuilder();
        
        for (Span span: this){
            builder.append(span.getRaw());
        }
        return builder.toString();
    }
    
    @Override
    public Document getDocument(){
        return get(0).getDocument();
    }
    
    @Override
    public SpanNode<?> getParent(){
        return parent;
    }
    
    public int getLength(){
        int ans = 0;
        for(Span child: spans){
            ans += child.getLength();
        }
        return ans;
    }
    
    void setParent(SpanNode<?> childOf){
        parent = childOf;
    }
}
