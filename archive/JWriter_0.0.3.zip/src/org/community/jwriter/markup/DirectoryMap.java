package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ForwardingMap;

/**
 * A System of {@link DirectorySpan} references with their status
 */
public final class DirectoryMap extends ForwardingMap<DirectoryId, DirectoryData>{
    private final ImmutableMap<DirectoryId, DirectoryData> ids;
    
    /**
     * Builds the DirectoryMap.
     */
    public static class Builder{
        private TreeMap<DirectoryId, DirectoryData.Builder> idBuilders;
        private Optional<DirectoryId> lastDirectory;
        private Optional<DirectoryId> lastRef;
        
        private Builder(){
            idBuilders = new TreeMap<>();
            lastDirectory = Optional.empty();
            lastRef = Optional.empty();
        }
        
        public void addId(DirectoryId id, Span value){
            if (idBuilders.containsKey(id)){
                idBuilders.get(id).addId(value);
            } else {
                DirectoryData.Builder data = DirectoryData.builder();
                data.addId(value);
                idBuilders.put(id, data);
            }
            lastDirectory = Optional.of(id);
        }
        
        public void removeLastId(){
            lastDirectory.ifPresent(id -> idBuilders.get(id).removeLastId());
        }
        
        public void addRef(DirectoryId id, Span value){
            if (idBuilders.containsKey(id)){
                idBuilders.get(id).addRef(value);
            } else {
                DirectoryData.Builder data = DirectoryData.builder();
                data.addRef(value);
                idBuilders.put(id, data);
            }
            lastRef = Optional.of(id);
        }
        
        public void removeLastRef(){
            lastRef.ifPresent(id -> idBuilders.get(id).removeLastRef());
        }
        
        DirectoryMap build(){
            ImmutableMap.Builder<DirectoryId, DirectoryData> data = ImmutableMap.builder();
            for(Entry<DirectoryId, DirectoryData.Builder> entry: idBuilders.entrySet()){
                data.put(entry.getKey(), entry.getValue().build());
            }
            return new DirectoryMap(data.build());
        }
    }
    
    public static Builder builder(){
        return new Builder();
    }
    
    public ImmutableMap<DirectoryId, DirectoryData> delegate(){
        return ids;
    }
    
    private DirectoryMap(ImmutableMap<DirectoryId, DirectoryData> data){
        ids = data;
    }
}
