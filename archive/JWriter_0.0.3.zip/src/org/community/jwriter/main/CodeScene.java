package org.community.jwriter.main;

import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import org.fxmisc.richtext.CodeArea;

import org.community.jwriter.markup.*;

public class CodeScene extends StackPane{
    private CodeArea writeArea;
    private Document doc;
    
    public CodeScene(){
        writeArea = new CodeArea();
        getChildren().add(writeArea);
    }
}
