package org.community.jwriter.basic;

import java.util.ArrayList; /// Use to create DirectoryID
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method

import org.community.jwriter.markup.*;

/**
 * Created from {@link DirectorySpan}. Used to store {@link DirectoryId}
 */
public class DirectorySpan extends SpanBranch{
    /// helps with categorizing and describes purpose
    private DirectoryType purpose;
    /// stores the actual {@link DirectoryId}
    private DirectoryId id;
    
    /// Helper method to get Optional<DirectorySpan> -> Optional<DirectoryId>
    static Optional<DirectoryId> getDirectoryHelper(Optional<DirectorySpan> id){
        return id.isPresent()? Optional.of(id.get().getId()): Optional.empty();
    }
    
    DirectorySpan(List<Span> children, List<String> categories, 
        Optional<ContentSpan> idSpan, DirectoryType type
    ){
        super(children);
        
        /// Adds main category
        ArrayList<String> builder = new ArrayList<>();
        if (type != DirectoryType.NONE) builder.add(type.getCategory());
        builder.addAll(categories);
        ///build the id
        id = new DirectoryId(builder,
            idSpan.isPresent()? idSpan.get().getText(): ""
        );
        
        purpose = type;
    }
    
    public DirectoryId getId(){
        return id;
    }
    
    public DirectoryType getPurpose(){
        return purpose;
    }
    
    public String toString(){
        return "[" + id.getFullIdentity() + "]";
    }
}
