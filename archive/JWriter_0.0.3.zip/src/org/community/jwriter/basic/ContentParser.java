package org.community.jwriter.basic;

import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Creates a text span upto a certain character.
 */
class ContentParser implements InputParser<ContentSpan>{
    /// Describes how the Span will end
    private final ImmutableList<String> fullEnders;
    
    public ContentParser(List<String> enders){
        this(enders.toArray(new String[0]));
    }
    
    public ContentParser(String ... enders){
        /// combining text span enders with escape ender and new line.
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        builder.add(CHAR_ESCAPE);
        builder.add(LINED_END);
        for (String ender: enders){
            builder.add(ender);
        }
        fullEnders = builder.build();
    }
    
    @Override
    public Optional<ContentSpan> parse(InputPointer pointer){
        /// Setup
        ArrayList<Span> children = new ArrayList<>();
        boolean hasMore = true;
        
        /// Extract the text
        do{
            pointer.getTo(children, fullEnders);
            Optional<SpanBranch> span = parseEscape(pointer);
            /// no more escape span = no more text to deal with
            if (! span.isPresent()){
                hasMore = false;
            } else {
                children.add(span.get());
            }
        } while (hasMore);
        
        /// Create span if there are Span extracted
        if (children.size() > 0) {
            return Optional.of(new ContentSpan(children));
        }
        return Optional.empty();
    }
    
    /// helper method for parse(InputPointer)
    private Optional<SpanBranch> parseEscape(InputPointer pointer){
        /// Setup 
        ArrayList<Span> children = new ArrayList<>();
        
        /// build Span if found
        if (pointer.startsWith(children, CHAR_ESCAPE)){
            pointer.nextChars(children, 1);
            return Optional.of(new ContentSpanEscape(children));
        }
        return Optional.empty();
    }
}
