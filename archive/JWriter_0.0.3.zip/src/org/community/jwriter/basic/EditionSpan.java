package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;

/**
 * A {@link Span} for stating the current status of a section with a heading or
 * an outline.
 */
public class EditionSpan extends SpanBranch{
    private final EditionType type;
    private final String detail;
    
    EditionSpan(List<Span> children, EditionType statusType, 
            Optional<ContentSpan> detailSpan){
        super(children);
        detail = detailSpan.isPresent()? detailSpan.get().getText(): "";
        type = statusType;
    }
    
    public EditionType getType(){
        return type;
    }
    
    public String getDetail(){
        return detail;
    }
}
