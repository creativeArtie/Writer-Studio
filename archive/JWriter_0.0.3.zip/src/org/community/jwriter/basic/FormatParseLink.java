package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * InputParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * InputParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
enum FormatParseLink implements InputParser<FormatSpanLink> {
    REFER(LINK_REF), INLINE(LINK_BEGIN);
    
    private String start;
    
    private FormatParseLink(String s){
        start = s;
    }
    
    @Override
    public Optional<FormatSpanLink> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        if(pointer.startsWith(children, start)){
            
            /// Create span base on enum value
            if (this == REFER){
                /// DirectoryId for the FormatSpanLinkRef
                Optional<DirectorySpan> id = 
                    new DirectoryParser(DirectoryType.LINK, LINK_TEXT, LINK_END)
                    .parse(children, pointer);
                
                /// Complete the last steps 
                Optional<ContentSpan> text = parseRest(children, pointer);
                FormatSpanLinkRef span = new FormatSpanLinkRef(children, 
                    id, text);
                id.ifPresent(found -> pointer.getMap().addRef(found.getId(), span));
                return Optional.of(span);

            } /// else if (this == INLINE) {
            /// Text for the FormatDirectSpan
            Optional<ContentSpan> path = new ContentParser(LINK_TEXT, LINK_END)
                .parse(children, pointer);
            
            /// Complete the last steps 
            Optional<ContentSpan> text = parseRest(children, pointer);
            return Optional.of(new FormatSpanLinkDirect(children, path, 
                text));
            ///}
        }
        return Optional.empty();
    }
    
    private Optional<ContentSpan> parseRest(ArrayList<Span> children, 
            InputPointer pointer){
        Optional<ContentSpan> ans = Optional.empty();
        
        /// Create display text if any
        if (pointer.startsWith(children, LINK_TEXT)){
            /// Add the text itself
            ans = new ContentParser(LINK_END).parse(children, pointer);
        }
        
        /// Add the ">"
        pointer.startsWith(children, LINK_END);
        
        return ans;
    }
}
