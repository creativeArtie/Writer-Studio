package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ArrayListMultimap;

import org.community.jwriter.markup.*;

public class MainSpanNote extends MainSpan implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private ArrayListMultimap<LinedTypeSource, String> sources;
    
    MainSpanNote(List<Span> children, Optional<DirectoryId> idSpan, 
            List<LinedSpanCite> sourceFields){
        super(children);
        id = idSpan;
        sources = ArrayListMultimap.create();
        for (LinedSpanCite source: sourceFields){
            if (source.getField() != LinedTypeSource.ERROR){
                sources.put(source.getField(), source.getText());
            }
        }
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
    
    public ImmutableListMultimap<LinedTypeSource, String> getSources(){
        return ImmutableListMultimap.copyOf(sources);
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("NOTE:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
}
