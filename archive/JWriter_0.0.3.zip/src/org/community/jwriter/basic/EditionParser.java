package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AtomicTerm.*;

/**
 * Creates a Span to show the edition of an manuscript section.
 */
enum EditionParser implements InputParser<EditionSpan>{
    STUB, DRAFT, FINAL, OTHER(){
        @Override
        public Optional<EditionSpan> parse(InputPointer pointer){
            ArrayList<Span> children = new ArrayList<>();
            if (pointer.startsWith(children, EDITION_BEGIN)){
                return finalize(children, pointer);
            }
            return Optional.empty();
        }
    };
    
    /**
     * Helper method to parse all Spans
     */
    static Optional<EditionSpan> parseAll(ArrayList<Span> children, 
            InputPointer pointer){
        for(EditionParser parser: values()){
            Optional<EditionSpan> ans = parser.parse(children, pointer);
            if (ans.isPresent()){
                return ans;
            }
        }
        return Optional.empty();
    }
    
    protected Optional<EditionSpan> finalize(ArrayList<Span> children, 
        InputPointer pointer
    ){
        /// Add the meta text, if any found
        Optional<ContentSpan> text = new ContentParser().parse(children, pointer);
        
        return Optional.of(new EditionSpan(children, 
            EditionType.values()[ordinal()], text));
        
    }
    
    @Override
    public Optional<EditionSpan> parse(InputPointer pointer){
        ArrayList<Span> children = new ArrayList<>();
        if (pointer.startsWith(children, EDITION_BEGIN + name())){
            return finalize(children, pointer);
        }
        return Optional.empty();
    }
}
