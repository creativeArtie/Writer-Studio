package org.community.jwriter.basic;

import java.util.List; /// For initialization (children)

import com.google.common.base.CharMatcher; /// For CharMatcher.whitespaces()
import com.google.common.base.Joiner;      /// To remove spaces
import com.google.common.base.Splitter;    /// To remove spaces

import org.community.jwriter.markup.*;

/**
 * Created from {@link ContentParser}, super class of 
 * {@link ContentSpanContent}. Used for whenever text is needed.
 */
public class ContentSpan extends SpanBranch{
    
    /// Tells if the text started with spaces
    private boolean spaceBegin;
    /// Tells if the text ended with spaces
    private boolean spaceEnd;
    /// Has removed the extra spaces and "\\" of the ContentSpanEscape
    private String text;
    
    ContentSpan (List<Span> children){
        super(children);
        
        /// Create a display text text
        StringBuilder builder = new StringBuilder();
        for(Span child: children){
            if (child instanceof ContentSpanEscape){
                builder.append(((ContentSpanEscape)child).getEscape());
            } else if (child instanceof SpanLeaf){
                /// Add text from a basic span
                builder.append(child.getRaw());
            } else {
                throw new IllegalArgumentException(
                    "Unexpected child span" + child.toString()
                );
            }
        }
        
        /// Finalizes the text
        CharMatcher spaces = CharMatcher.whitespace();
        String tmp = builder.toString();
        if (tmp.isEmpty()){
            text = tmp;
            spaceBegin = false;
            spaceEnd = false;
        } else {
            spaceBegin = spaces.matches(tmp.charAt(0));
            spaceEnd = spaces.matches(tmp.charAt(builder.length() - 1));
            /// combine mutiple spaces into one.
            text = Joiner.on(" ").join(
                Splitter.on(spaces).omitEmptyStrings().split(tmp)
            );
        }
    }
    
    public String getText(){
        return text;
    }
    
    public boolean isSpaceBegin(){
        return spaceBegin;
    }
    
    public boolean isSpaceEnd(){
        return spaceEnd;
    }
}
