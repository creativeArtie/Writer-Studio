package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class MainSpanSection extends MainSpan {
    private final Optional<LinedSpanLevel> heading;
    private final Optional<MainSpanSection> last;
    private final Optional<LinedSpanLevel> point;
    
    MainSpanSection (List<Span> children, Optional<LinedSpanLevel> header, 
            Optional<LinedSpanLevel> outlinePoint,
            Optional<MainSpanSection> from){
        super(children);
        last = from;
        heading = header;
        point = outlinePoint;
    }
    
    public Optional<MainSpanSection> getLast(){
        return last;
    }
    
    public Optional<LinedSpanLevel> getHeading(){
        return heading;
    }
    
    public Optional<LinedSpanLevel> getOutline(){
        return point;
    }
    
    public String toString(){
        StringBuilder output = new StringBuilder("SECTION:{");
        for(Span s: this){
            output.append("\n\t" + s);
        }
        output.append("\n}");
        return output.toString();
    }
}
