package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

/**
 * Used by {@link DirectorySpan} to show main categories.
 */
public enum DirectoryType{
    FOOTNOTE("foot"), ENDNOTE("end"), LINK("link"), NOTE("note"), NONE("");
    
    private String categoryName;
    
    private DirectoryType(String name){
        categoryName = name;
    }
    
    public String getCategory(){
        return categoryName;
    }
}
