package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

/**
 * A {@link span} for formatted text.
 */
public final class FormatSpan extends SpanBranch {
    FormatSpan (List<Span> children){
        super(children);
    }
    
    FormatSpan (){
        super(new ArrayList<>());
    }
}
