package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

public abstract class FormatSpanCurly extends SpanBranch {

    FormatSpanCurly(List<Span> children){
        super(children);
    }
}
