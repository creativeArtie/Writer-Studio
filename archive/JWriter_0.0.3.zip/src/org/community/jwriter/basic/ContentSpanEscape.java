package org.community.jwriter.basic;

import java.util.List; /// For initialization (children)

import org.community.jwriter.markup.*;

/**
 * Created from {@link ContentParser}. Used only in {@link ContentSpan}
 */
public class ContentSpanEscape extends SpanBranch{
    public String text;
    
    public ContentSpanEscape(List<Span> children){
        super(children);
        text = children.size() == 2? children.get(1).getRaw(): "";
    }
    
    public String getEscape(){
        return text;
    }
}
