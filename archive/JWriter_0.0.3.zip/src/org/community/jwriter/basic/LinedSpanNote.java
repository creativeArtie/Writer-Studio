package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanNote extends LinedSpan implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private final FormatSpan text;
    
    public LinedSpanNote(List<Span> children, Optional<DirectorySpan> idSpan, 
            Optional<FormatSpan> textSpan){
        super(children, LinedType.NOTE);
        id = DirectorySpan.getDirectoryHelper(idSpan);
        text = textSpan.isPresent()? textSpan.get(): new FormatSpan();
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
    
    public FormatSpan getFormatted(){
        return text;
    }
    
    public boolean hasDirectorySpan(){
        return id.isPresent();
    }
}
