package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;

/**
 * A {@link FormatSpanLink} with path located somewhere in the document.
 */
public final class FormatSpanLinkRef extends FormatSpanLink implements 
        DirectoryHolder{
    private final Optional<String> text;
    private final Optional<DirectoryId> idSpan;
    
    FormatSpanLinkRef(List<Span> children, 
            Optional<DirectorySpan> inputDirectory, Optional<ContentSpan> textSpan){
        super(children);
        idSpan = DirectorySpan.getDirectoryHelper(inputDirectory);
        text = Optional.ofNullable(textSpan.isPresent()? textSpan.get().getText(): 
            null);
    }
    
    public String getPath(){
        Optional<Span> span = getTarget();
        if (span.isPresent()){
            return ((LinedSpanPointLink)span.get()).getPath();
        }
        return "";
    }
    
    public String getText(){
        if (text.isPresent()){
            return text.get();
        }
        return getPath();
    }

    @Override
    public Optional<DirectoryId> getId(){
        return idSpan;
    }
}
