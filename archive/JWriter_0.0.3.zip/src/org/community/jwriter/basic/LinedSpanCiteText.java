package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanCiteText extends LinedSpanCite {
    private final String data;
    
    public LinedSpanCiteText(List<Span> children, LinedTypeSource type,
            Optional<ContentSpan> textSpan){
        super(children, type);
        data = textSpan.isPresent()? textSpan.get().getText(): "";
    }
    
    public String getData(){
        return data;
    }
    
    @Override
    public String getText(){
        return data;
    }
}
