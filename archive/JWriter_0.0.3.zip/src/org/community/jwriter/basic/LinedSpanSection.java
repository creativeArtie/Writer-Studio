package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;

public class LinedSpanSection extends LinedSpanLevel implements DirectoryHolder{
    private final Optional<DirectoryId> id;
    private final Optional<EditionSpan> status;

    LinedSpanSection(List<Span> children, int levelDepth, 
            LinedType spanType, Optional<DirectorySpan> spanDirectory, 
            Optional<FormatSpan> text, Optional<EditionSpan> spanEdition){
        super(children, levelDepth, spanType, text);
        id = DirectorySpan.getDirectoryHelper(spanDirectory);
        
        status = spanEdition;
    }
    
    public EditionType getState(){
        return status.isPresent()? status.get().getType(): EditionType.NONE;
    }
    
    @Override
    public Optional<DirectoryId> getId(){
        return id;
    }
}
