package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.io.File;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class FormatLinkDebug {
    
    public static final SpanExpectHelper refHelp(String[] cat, String id,
            String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkRef.class, 
                span.getClass());
            FormatSpanLinkRef test = (FormatSpanLinkRef) span;
            assertArrayEquals("Wrong category.", cat, test.getCategory());
            assertEquals("Wrong id.", id, test.getIdentity());
            testCommon(span, path, text);
        };
    }
    
    public static final SpanExpectHelper linkHelp(String path, String text){
        return span ->{
            assertEquals("Wrong class gotten.", FormatSpanLinkDirect.class, 
                span.getClass());
            testCommon(span, path, text);
        };
    }
        
    static void testCommon(Span span, String path, String text){
        FormatSpanLink test = (FormatSpanLink) span;
        assertEquals("Wrong link path", path, test.getPath());
        assertEquals("Wrong link text.", text, test.getText());
    }
    
    private static final SetupParser[] parsers = FormatParseLink.getParsers(
        new boolean[4]);
    
    @Test
    public void refFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", "text"));
        ref.addChild("<@", AuxiliaryStyle.REF_LINK, SetupLeafStyle.KEYWORD);
        
        SpanExpect id = new SpanExpect();
        id.addGrandchild("cat", AuxiliaryStyle.REF_LINK, CatalogueStatus.NOT_FOUND, SetupLeafStyle.ID);
        id.addChild("-", AuxiliaryStyle.REF_LINK, CatalogueStatus.NOT_FOUND, SetupLeafStyle.KEYWORD);
        id.addGrandchild("id", AuxiliaryStyle.REF_LINK, CatalogueStatus.NOT_FOUND, SetupLeafStyle.ID);
        ref.addChild(id);
        
        ref.addChild("|", AuxiliaryStyle.REF_LINK, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("text", AuxiliaryStyle.REF_LINK, SetupLeafStyle.TEXT);
        ref.addChild(">", AuxiliaryStyle.REF_LINK, SetupLeafStyle.KEYWORD);
        
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refEmptyText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChildren("<@","cat-id", "|", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refNoText(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link", "cat"}, "id", "", ""));
        ref.addChildren("<@", "cat-id", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    @Test
    public void refNoCategory(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", "text"));
        ref.addChildren("<@", "id", "|", "text", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refBasic(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[]{"link"}, "id", "", ""));
        ref.addChildren("<@", "id", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void refEmpty(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(refHelp(
            new String[0], "", "", ""));
        ref.addChild("<@", AuxiliaryStyle.REF_LINK, AuxiliaryStyle.NO_ID, SetupLeafStyle.KEYWORD);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
        
    
    @Test
    public void linkFull(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        
        ref.addChild("<", AuxiliaryStyle.DIRECT_LINK, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("path", AuxiliaryStyle.DIRECT_LINK, SetupLeafStyle.PATH);
        ref.addChild("|", AuxiliaryStyle.DIRECT_LINK, SetupLeafStyle.KEYWORD);
        ref.addGrandchild("text", AuxiliaryStyle.DIRECT_LINK, SetupLeafStyle.TEXT);
        ref.addChild(">", AuxiliaryStyle.DIRECT_LINK, SetupLeafStyle.KEYWORD);
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkPath(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "path"));
        ref.addChildren("<", "path", ">");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkStart(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("", ""));
        ref.addChild("<");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
    
    @Test
    public void linkNoEnd(){
        SpanExpect doc = new SpanExpect();
        SpanExpect ref = new SpanExpect(linkHelp("path", "text"));
        ref.addChildren("<", "path", "|", "text");
        doc.addChild(ref);
        doc.testAll(parsers);
    }
}
