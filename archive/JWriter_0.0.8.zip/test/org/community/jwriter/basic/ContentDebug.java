package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class ContentDebug{
    
    private static final SetupParser[] parsers = new SetupParser[]{
        new ContentParser()};
    
    public static DocumentAssert checkContent(DocumentAssert checker, 
        String text, boolean isBegin, boolean isEnd)
    {
        Span span = checker.getSpan();
        assertEquals("Wrong Class.", ContentSpan.class, span.getClass());
        ContentSpan test = (ContentSpan) span;
        assertEquals("Wrong text.", text, test.getParsed());
        assertEquals("Wrong begin.", isBegin, test.isSpaceBegin());
        assertEquals("Wrong end.", isEnd, test.isSpaceEnd());
        return checker;
    }
    
    public static DocumentAssert checkEscape(DocumentAssert checker, 
        String escapes)
    {
        Span span = checker.getSpan();
        assertEquals("Wrong Class.", BasicTextEscape.class, span.getClass());
        BasicTextEscape test = (BasicTextEscape) span;
        DetailStyle[] styles = new DetailStyle[]{AuxiliaryStyle.ESCAPE};
        assertArrayEquals("Wrong DetailInfo.",  styles,  test.getInfo());
        assertEquals     ("Wrong escape text.", escapes, test.getEscape());
        return checker;
    }
    
    @Test
    public void basic(){
        String raw = "Hello";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, raw, false, false);
        
        text.assertTextLeaf(0, raw.length(), raw, 0);
    }
    
    @Test
    public void singleSpace(){
        String raw = " ";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, "", true, true);
        
        text.assertTextLeaf(0, raw.length(), raw, 0);
    }
    
    @Test
    public void doubleSpace(){
        String raw = "  ";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, "", true, true);
        
        text.assertTextLeaf(0, raw.length(), raw, 0);
    }
    
    @Test
    public void basicEscape(){
        String raw = "\\b";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, "b", false, false);
        
        DocumentAssert escape = text.checkBranch(2, raw, 0);
        checkEscape(escape, "b");
        
        escape.assertKeyLeaf( 0, 1, "\\", 0);
        escape.assertTextLeaf(1, 2, "b",  1);
    }
    
    @Test
    public void midEscape(){
        String raw = "a\\bc\t";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(3, raw, 0);
        checkContent(text, "abc", false, true);
        
        
        DocumentAssert escape = text.checkBranch(2, "\\b", 1);
        checkEscape(escape, "b");
        
        text.assertTextLeaf(0, 1, "a",   0);
        text.assertKeyLeaf( 1, 2, "\\",  1, 0);
        text.assertTextLeaf(2, 3, "b",   1, 1);
        text.assertTextLeaf(3, 5, "c\t", 2);
    }
    
    @Test
    public void escapeSlash(){
        String raw = "\\\\";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, "\\", false, false);
        
        DocumentAssert escape = text.checkBranch(2, "\\\\", 0);
        checkEscape(escape, "\\");
        
        escape.assertKeyLeaf( 0, 1, "\\", 0);
        escape.assertTextLeaf(1, 2, "\\", 1);
    }
    
    @Test
    public void escapeSpace(){
        String raw = "\\ ";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(1, raw, 0);
        checkContent(text, "", true, true);
        
        DocumentAssert escape = text.checkBranch(2, "\\ ", 0);
        checkEscape(escape, " ");
        
        escape.assertKeyLeaf( 0, 1, "\\",  0);
        escape.assertTextLeaf(1, 2, " ",   1);
    }
    
    @Test
    public void escapeCutOff(){
        String raw = "  abc\\";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert text = doc.checkBranch(2, raw, 0);
        checkContent(text, "abc", true, false);
        
        DocumentAssert escape = text.checkBranch(1, "\\", 1);
        checkEscape(escape, "");
        
        text.assertTextLeaf(0, 5, "  abc", 0);
        text.assertKeyLeaf( 5, 6, "\\",    1, 0);
    }
}
