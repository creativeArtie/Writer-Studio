package org.community.jwriter.basic;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;
import org.junit.rules.*;

import java.io.File;
import java.util.Optional;

import java.util.Arrays;
import java.util.ArrayList;

import org.community.jwriter.markup.*;

@RunWith(JUnit4.class)
public class DirectoryDebug{
        
    private static void checkId(DocumentAssert checker, String id, 
        String ... cat)
    {
        Span span = checker.getSpan();
        CatalogueIdentity dir = new CatalogueIdentity(Arrays.asList(cat), id);
        assertEquals("Wrong Class.", DirectorySpan.class, span.getClass());
        DirectorySpan base = (DirectorySpan)span;
        assertEquals("Wrong type.", null, base.getPurpose());
        
        CatalogueIdentity test = base.getId();
        assertArrayEquals("Wrong Category", dir.getCategory(), 
            test.getCategory());
        assertEquals("Wrong id", dir.getIdentity(), test.getIdentity());
        assertEquals("Wrong full id", dir.getFullIdentity(),
            test.getFullIdentity());
    }
    
    private static final SetupParser[] parsers = new SetupParser[]{
        new DirectoryParser(null)};
    
    @Test
    public void basic(){
        String raw = "Hello";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(1, raw, 0);
        checkId(test, raw);
        
        DocumentAssert id = test.checkBranch(1, raw, 0);
        ContentDebug.checkContent(id, raw, false, false);
        
        test.assertIdLeaf(0, raw.length(), raw, 0, 0);
    }
    
    @Test
    public void singleCategory(){
        String raw = "cat-Hi";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(3, raw, 0);
        checkId(test, "Hi", "cat");
        
        DocumentAssert cat = test.checkBranch(1, "cat", 0);
        DocumentAssert id =  test.checkBranch(1, "Hi",  2);
        
        ContentDebug.checkContent(cat, "cat", false, false);
        ContentDebug.checkContent(id,  "Hi",  false, false);
        
        test.assertIdLeaf( 0, 3, "cat", 0, 0);
        test.assertKeyLeaf(3, 4, "-",   1); 
        test.assertIdLeaf( 4, 6, "Hi",  2, 0);
    }
    
    @Test
    public void twoSubcategories(){
        String raw = "a-b-c ";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(5, raw, 0);
        checkId(test, "c", "a", "b");
        
        DocumentAssert cat1 = test.checkBranch(1, "a",  0);
        DocumentAssert cat2 = test.checkBranch(1, "b",  2);
        DocumentAssert id   = test.checkBranch(1, "c ", 4);
        ContentDebug.checkContent(cat1, "a", false, false);
        ContentDebug.checkContent(cat2, "b", false, false);
        ContentDebug.checkContent(id,   "c", false, true);
        
        test.assertIdLeaf( 0, 1, "a",  0, 0);
        test.assertKeyLeaf(1, 2, "-",  1);
        test.assertIdLeaf( 2, 3, "b",  2, 0);
        test.assertKeyLeaf(3, 4, "-",  3);
        test.assertIdLeaf( 4, 6, "c ", 4, 0);
    }
    
    @Test
    public void emptySubcategory(){
        String raw = "-See";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(2, raw, 0);
        checkId(test, "See", "");
        
        DocumentAssert id = test.checkBranch(1, "See", 1);
        ContentDebug.checkContent(id, "See", false, false);
        
        test.assertKeyLeaf(0, 1, "-",   0);
        test.assertIdLeaf( 1, 4, "See", 1, 0);
    }
    
    @Test
    public void emptySecondSubcategory(){
        ///           012345678901234
        String raw = "Yes  Sir- -Wee";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(5, raw, 0);
        checkId(test, "Wee", "Yes Sir" , "");
        
        
        DocumentAssert cat1 = test.checkBranch(1, "Yes  Sir", 0);
        DocumentAssert cat2 = test.checkBranch(1, " ",        2);
        DocumentAssert id = test.checkBranch( 1, "Wee",       4);
        ContentDebug.checkContent(cat1, "Yes Sir", false, false);
        ContentDebug.checkContent(cat2, "",        true,  true);
        ContentDebug.checkContent(id,   "Wee",     false, false);
        
        test.assertIdLeaf (0,   8, "Yes  Sir", 0, 0);
        test.assertKeyLeaf(8,   9, "-",        1);
        test.assertIdLeaf (9,  10, " ",        2, 0);
        test.assertKeyLeaf(10, 11, "-",        3);
        test.assertIdLeaf (11, 14, "Wee",      4, 0);
    }
    
    @Test
    public void categoryEscape(){
        ///           0 123
        String raw = "\\-c";
        DocumentAssert doc = DocumentAssert.checkDoc(1, raw, parsers);
        DocumentAssert test = doc.checkBranch(1, raw, 0);
        checkId(test, "-c");
        
        DocumentAssert content = test.checkBranch(2, "\\-c", 0);
        ContentDebug.checkContent(content, "-c", false, false);
        
        DocumentAssert escape = content.checkBranch(2, "\\-", 0);
        ContentDebug.checkEscape(escape, "-");
        
        
        test.assertKeyLeaf(0, 1, "\\", 0, 0, 0);
        test.assertIdLeaf( 1, 2, "-",  0, 0, 1);
        test.assertIdLeaf( 2, 3, "c",  0, 1);
        
    }
}
