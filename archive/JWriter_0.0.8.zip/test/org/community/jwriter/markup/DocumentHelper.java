package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;

@Deprecated
public class DocumentHelper extends Document{
    
    public DocumentHelper(){}
    
    public DocumentHelper(String doc, SetupParser ... parsers){
        super(doc, parsers);
    }
    
    public static SetupPointer createEmptyPointer(){
        return SetupPointer.newPointer("", new DocumentHelper());
    }
        
    public static Document checkDoc(int childrenSize, String rawText, 
        SetupParser ... parsers
    ){
        Document test = new Document(rawText, parsers){};
        assertEquals("Wrong doc text.", rawText,      test.getRaw());  
        assertEquals("Wrong doc size.", childrenSize, test.size());
        return test;
    }
    
    public static SpanBranch checkBranch(int size, String rawText, Document doc, 
        SpanNode<?> parent, int idx
    ){
        Span span = parent.get(idx);
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanBranch, gotten " + span.getClass(), 
            span instanceof SpanBranch);
        SpanBranch test = (SpanBranch) span;
        assertEquals("Wrong branch text: " + test, rawText, test.getRaw()); 
        assertEquals("Wrong branch size: " + test, size,    test.size()); 
        assertSame  ("Wrong document: "    + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "      + test, parent,  test.getParent());
        return test;
    }
    
    public static SpanBranch checkBranch(int size, String rawText, Document doc, 
        SpanNode<?> parent, int idx, DetailStyle ... styles
    ){
        SpanBranch test = checkBranch(size, rawText, doc, parent, idx);
        assertArrayEquals("Wrong style: " + test, styles, test.getInfo());
        return test;
    }
    
    public static SpanLeaf checkLeaf(String rawText, DetailStyle info, 
        Document doc, SpanNode<?> parent, int start, int end, int idx
    ){
        SpanLeaf test = checkLeaf(rawText, info, doc, parent, idx);
        assertEquals("Wrong start: "      + test, start,   test.getStart());
        assertEquals("Wrong end: "      + test, end,     test.getEnd());
        return test;
    }
    
    public static SpanLeaf checkLeaf(String rawText, DetailStyle info, 
        Document doc, SpanNode<?> parent, int idx
    ){
        Span span = parent.get(idx);
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanLeaf, gotten " + span.getClass(), 
            span instanceof SpanLeaf);
        SpanLeaf test = (SpanLeaf) span;
        assertEquals("Wrong leaf text: "  + test, rawText, test.getRaw()); 
        assertEquals("Wrong leaf style: " + test, info,    test.getInfo()); 
        assertSame  ("Wrong document: "   + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "     + test, parent,  test.getParent());
        return test;
    }
    
    public static SpanBranch checkGrandBranch(int size, String rawText, 
        Document doc, SpanBranch parent, int ... idx
    ){
        SpanBranch last = parent;
        for (int i = 0; i < idx.length; i++){
            last = checkBranch(1, rawText, doc, last, idx[i]);
        }
        return last;
    }
    
    public static SpanLeaf checkGrandLeaf(String rawText, DetailStyle info,
        Document doc, SpanBranch parent, int ... idx
    ){
        for (int i = 0; i < idx.length - 1; i++){
            parent = checkBranch(1, rawText, doc, parent, idx[i]);
        }
        return checkLeaf(rawText, info, doc, parent, idx[idx.length - 1]);
    }
}
