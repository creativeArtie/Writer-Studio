package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;
import org.junit.runner.*;
import org.junit.runners.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.Set;

import org.community.jwriter.basic.*;

public class IDTest{
    private ArrayList<Integer> order;
    private ArrayList<CatalogueIdentity> idList;
    private ArrayList<CatalogueStatus> errors;
    private CatalogueMap builder;
    
    public IDTest(){
        builder = new CatalogueMap();
        idList = new ArrayList<>();
        errors = new ArrayList<>();
        order = new ArrayList<>();
    }
    
    private static SpanBranch filler;
    
    private static SpanBranch tmpSpan(){
        if (filler == null){
            filler = new SpanBranch(new ArrayList<>()){
                protected void addInfo(List<DetailStyle> info){}
            };
        }
        return filler;
    }
    
    public void addId(CatalogueIdentity id, CatalogueStatus outcome, int i){
        addId(id);
        add(id, outcome, i);
    }
    
    public void addId(CatalogueIdentity id, int i){
        addId(id, CatalogueStatus.UNUSED, i);
    }
    
    public void addId(CatalogueIdentity id){
        builder.addId(id, tmpSpan());
    }
    
    public void add(CatalogueIdentity id, CatalogueStatus outcome, int i){
        idList.add(id);
        errors.add(outcome);
        order.add(i);
    }
    
    public void addRef(CatalogueIdentity id, CatalogueStatus outcome, int i){
        addRef(id);
        add(id, outcome, i);
    }
    
    public void addRef(CatalogueIdentity id){
        builder.addRef(id, tmpSpan());
    }
    
    public CatalogueMap testAll(){
        return testAll(false, null);
    }
    
    public CatalogueMap testAll(boolean printOrder){
        return testAll(printOrder, null);
    }
    
    public CatalogueMap testAll(Document doc){
        return testAll(false, doc);
    }
    
    public CatalogueMap testAll(boolean printOrder, Document doc){
        CatalogueMap system = doc == null? builder: doc.getMap();
        
        Set<Entry<CatalogueIdentity,CatalogueData>> entries = system.entrySet();
        if (printOrder) {
            System.out.println(system.keySet());
        }
        int i = 0;
        assertEquals("Wrong key size", idList.size(), entries.size());
        for (Entry<CatalogueIdentity, CatalogueData> entry: entries){
            int idx = order.indexOf(i);
            assertEquals("Wrong span order at " + idx, idList.get(idx), 
                entry.getKey());
            assertEquals("Wrong id status at " + idx, 
                errors.get(idx), entry.getValue().getState());
            i++;
        }
        return system;
    }
}
