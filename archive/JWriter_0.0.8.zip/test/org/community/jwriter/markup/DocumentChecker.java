package org.community.jwriter.markup;

import static org.junit.Assert.*;

import org.junit.*;

public class DocumentChecker {
    
    private Document doc;
    private Span ptr;
    private DocumentChecker parent;
    
    private DocumentChecker(DocumentChecker parentChecker, Document document, 
        Span pointer)
    {
        parent = parentChecker;
        doc = document;
        ptr = pointer;
    }
    
    public Document getDocument(){
        return doc;
    }
    
    public DocumentChecker getParent(){
        return parent;
    }
    
    public Span getSpan(){
        return ptr;
    }
    
    public static SetupPointer createEmptyPointer(){
        return SetupPointer.newPointer("", new DocumentHelper());
    }
        
    public static DocumentChecker checkDoc(int childrenSize, String rawText, 
        SetupParser ... parsers
    ){
        Document test = new Document(rawText, parsers){};
        assertEquals("Wrong doc text.", rawText,      test.getRaw());  
        assertEquals("Wrong doc size.", childrenSize, test.size());
        return new DocumentChecker(null, test, test);
    }
    
    public DocumentChecker checkBranch(int size, String rawText, int idx){
        Span span = ((SpanNode)ptr).get(idx);
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanBranch, gotten " + span.getClass(), 
            span instanceof SpanBranch);
        SpanBranch test = (SpanBranch) span;
        assertEquals("Wrong branch text: " + test, rawText, test.getRaw()); 
        assertEquals("Wrong branch size: " + test, size,    test.size()); 
        assertSame  ("Wrong document: "    + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "      + test, ptr,     test.getParent());
        return new DocumentChecker(this, doc, test);
    }
    
    public DocumentChecker checkBranchDetails(DetailStyle ... styles){
        SpanBranch test = (SpanBranch) ptr;
        assertArrayEquals("Wrong style: " + test, styles, test.getInfo());
        return this;
    }
    
    public DocumentChecker checkLeaf(int start, int end, String rawText, 
        DetailStyle info, int idx
    ){
        DocumentChecker test = checkLeaf(rawText, info, idx);
        assertEquals("Wrong start: " + test.ptr, start, test.ptr.getStart());
        assertEquals("Wrong end: "   + test.ptr, end,   test.ptr.getEnd());
        return test;
    }
    
    public DocumentChecker checkLeaf(String rawText, DetailStyle info, int idx){
        Span span = ((SpanBranch)ptr).get(idx);
        assertTrue("Wrong class for " + span + 
            "Expects instance of SpanLeaf, gotten " + span.getClass(), 
            span instanceof SpanLeaf);
        SpanLeaf test = (SpanLeaf) span;
        assertEquals("Wrong leaf text: "  + test, rawText, test.getRaw()); 
        assertEquals("Wrong leaf style: " + test, info,    test.getInfo()); 
        assertSame  ("Wrong document: "   + test, doc,     test.getDocument());
        assertSame  ("Wrong parent: "     + test, ptr,     test.getParent());
        return new DocumentChecker(this, doc, test);
    }
    
    public DocumentChecker checkTextLeaf(int start, int end, String rawText,  
        int idx)
    {
        return checkLeaf(start, end, rawText, SetupLeafStyle.TEXT, idx);
    }
    
    public DocumentChecker checkTextLeaf(String rawText, int idx){
        return checkLeaf(rawText, SetupLeafStyle.TEXT, idx);
    }
    
    public DocumentChecker checkKeyLeaf(int start, int end, String rawText, 
        int idx)
    {
        return checkLeaf(start, end, rawText, SetupLeafStyle.KEYWORD, idx);
    }
    
    public DocumentChecker checkKeyLeaf(String rawText, int idx){
        return checkLeaf(rawText, SetupLeafStyle.KEYWORD, idx);
    }
    
    public DocumentChecker checkGrandBranch(int size, String rawText, 
        int ... idx)
    {
        DocumentChecker last = this;
        for (int i = 0; i < idx.length; i++){
            last = last.checkBranch(1, rawText, idx[i]);
        }
        return last;
    }
    
    public DocumentChecker checkGrandLeaf(String rawText, DetailStyle info,
        int ... idx)
    {
        DocumentChecker last = this;
        for (int i = 0; i < idx.length - 1; i++){
            last = last.checkBranch(1, rawText, idx[i]);
        }
        return last.checkLeaf(rawText, info, idx[idx.length - 1]);
    }
}
