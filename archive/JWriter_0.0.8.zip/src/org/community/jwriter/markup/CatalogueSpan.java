package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeMap;
import java.util.List;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ForwardingMap;

/**
 * A System of {@link DirectorySpan} references with their status
 */
public interface CatalogueSpan {
    
    public CatalogueIdentity getId();
}
