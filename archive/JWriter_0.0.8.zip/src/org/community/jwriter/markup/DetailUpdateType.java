package org.community.jwriter.markup;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

enum DetailUpdateType{
    REPLACE(1), MERGE_LAST(2), MERGE_NEXT(2), MERGE_BOTH(3), UNABLE(0);
    private final int remove;
    
    private DetailUpdateType(int removeSpans){
        remove = removeSpans;
    }
    
    public int getRemoveSpans(){
        return remove;
    }
}
