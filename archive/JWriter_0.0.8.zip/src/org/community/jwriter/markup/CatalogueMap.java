package org.community.jwriter.markup;

import java.util.Map.Entry;
import java.util.Arrays;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.SortedMap;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSortedMap;
import com.google.common.collect.ForwardingSortedMap;

import org.community.jwriter.main.Checker;

/**
 * A System of {@link DirectorySpan} references with their status
 */
public final class CatalogueMap extends ForwardingSortedMap<CatalogueIdentity, CatalogueData>{
    private final TreeMap<CatalogueIdentity, CatalogueData> ids;
    
    public CatalogueMap(){
        ids = new TreeMap<>();
    }
    
    public void addId(CatalogueIdentity newId, SpanBranch pointSpan){
        Checker.checkNotNull(newId, "newId");
        Checker.checkNotNull(pointSpan, "ptrSpan");
        CatalogueData data = ids.get(newId);
        if (data == null){
            data = new CatalogueData(this, newId);
            ids.put(newId, data);
        }
        data.addId(pointSpan);
    }
    
    public void addRef(CatalogueIdentity addRef, SpanBranch pointSpan){
        Checker.checkNotNull(addRef, "addRef");
        Checker.checkNotNull(pointSpan, "pointSpan");
        CatalogueData data = ids.get(addRef);
        if (data == null){
            data = new CatalogueData(this, addRef);
            ids.put(addRef, data);
        }
        data.addRef(pointSpan);
    }
    
    public SortedMap<CatalogueIdentity, CatalogueData> delegate(){
        return ImmutableSortedMap.copyOf(ids);
    }
    
    public SortedMap<CatalogueIdentity, CatalogueData> getCategory(
        String ... category)
    {
        SortedMap<CatalogueIdentity, CatalogueData> map = delegate();
        CatalogueIdentity first = new CatalogueIdentity(
            ImmutableList.copyOf(category), "");
        category[category.length - 1] = category[category.length - 1] + (char)0;
        
        CatalogueIdentity last = new CatalogueIdentity(
            ImmutableList.copyOf(category), "");
        return map.subMap(first, last);
    }
}
