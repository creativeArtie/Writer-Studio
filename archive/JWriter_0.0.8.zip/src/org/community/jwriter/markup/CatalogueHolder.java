package org.community.jwriter.markup;

import java.util.Optional;
import org.community.jwriter.main.Checker;

public interface CatalogueHolder extends Comparable<CatalogueHolder>, 
        Iterable<Span>{
    
    public default Optional<CatalogueIdentity> getId(){
        Optional<CatalogueSpan> found = getIdSpan();
        if (found.isPresent()){
            return Optional.of(found.get().getId());
        }
        return Optional.empty();
    }
    
    public Document getDocument();
    
    public default boolean hasId(){
        return getId().isPresent();
    }
    
    public default Optional<CatalogueSpan> getIdSpan(){
        for (Span span: this){
            if (span instanceof CatalogueSpan){
                return Optional.of((CatalogueSpan) span);
            }
        }
        return Optional.empty();
    }
    
    public default CatalogueStatus getStatus(){
        Optional<CatalogueIdentity> id = getId();
        if (id.isPresent()){
            return id.get().getStatus(getDocument().getMap());
        }
        return CatalogueStatus.NO_ID;
    }
    
    public default String[] getCategory(){
        Optional<CatalogueIdentity> id = getId();
        return getId().isPresent()? id.get().getCategory(): new String[0];
    }
    
    public default String getIdentity(){
        Optional<CatalogueIdentity> id = getId();
        return id.isPresent()? id.get().getIdentity(): "";
    }
    
    public default String getFullIdentity(){
        Optional<CatalogueIdentity> id = getId();
        return id.isPresent()? id.get().getFullIdentity(): "";
    }
    
    
    public default int compareTo(CatalogueHolder otherHolder){
        if (otherHolder == null){
            return 1;
        }
        Optional<CatalogueIdentity> id = getId();
        if (id.isPresent()){
            Optional<CatalogueIdentity> id2 = otherHolder.getId();
            if (id2.isPresent()){
                return id.get().compareTo(id2.get());
            }
            return 1;
        }
        return -1;
    }
    
    public default Optional<Span> getTarget(){
        Optional<CatalogueIdentity> id = getId();
        if (id.isPresent()){
            CatalogueData data = getDocument().getMap().get(id.get());
            if (data.isReady()){
                return Optional.of(data.getTarget());
            }
        }
        return Optional.empty();
    }
    
    public boolean isId();
    
    public default boolean isRef(){
        return ! isId();
    }
    
    public default void fillMap(CatalogueMap storedMap){
        Checker.checkNotNull(storedMap, "storedMap");
        Optional<CatalogueIdentity> adding = getId();
        adding.ifPresent(id -> {
            if (isId()){
                storedMap.addId(id, (SpanBranch) this);
            } else {
                storedMap.addRef(id, (SpanBranch) this);
            }
        });
    }
}
