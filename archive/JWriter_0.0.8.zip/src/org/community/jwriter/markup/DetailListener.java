package org.community.jwriter.markup;

/**
 * A System of {@link DirectorySpan} references with their status
 */
interface DetailListener{
    
    public void changed(Span changedSpan);
}
