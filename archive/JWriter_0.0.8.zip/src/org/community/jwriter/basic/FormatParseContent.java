package org.community.jwriter.basic;

import java.util.Arrays; 
import java.util.ArrayList; /// For storing the span children
import java.util.List;      /// For initialization (enders)
import java.util.Optional;  /// For parsing purposes

import com.google.common.collect.ImmutableList; /// Lis of key enders

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Creates a text span upto a certain character.
 */
class FormatParseContent extends BasicParseText{
    
    private boolean[] formats;
    private boolean parse;
    
    public FormatParseContent(SetupLeafStyle spanStyles, boolean[] spanFormats, 
        boolean allowParse, List<String> formatEnders
    ){
        this(spanStyles, spanFormats, allowParse, 
            Checker.checkNotNull(formatEnders, "formatEnders")
            .toArray(new String[0]));
    }
    
    public FormatParseContent(SetupLeafStyle spanStyles, boolean[] spanFormats, 
        boolean allowParse, String[] formatEnders
    ){
        super(spanStyles, formatEnders);
        Checker.checkArraySize(spanFormats, "spanFormats", FORMAT_TYPES);
        formats = Arrays.copyOf(spanFormats, spanFormats.length);
        parse = allowParse; /// no limitations
    }

    @Override
    protected FormatSpanContent buildSpan(List<Span> spanChildren, 
        List<String> formatEnders, SetupLeafStyle baseStyle
    ){
        return new FormatSpanContent(spanChildren, formats, formatEnders, 
            baseStyle, parse);
    }
    
}
