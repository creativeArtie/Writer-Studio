package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;

public abstract class LinedDataSpan<T> extends SpanBranch{
    
    public abstract LinedDataSpan<T> cast();
    
    public abstract T getDataSpan();
    
    private LinedDataType type;
    
    protected LinedDataSpan(List<Span> children, LinedDataType dataType){
        super(children);
        type = dataType;
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return new DetailStyle[]{type};
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(type);
    }
    
    @Override
    public String toString(){
        return "{" + getDataSpan() + "}";
    }
}
