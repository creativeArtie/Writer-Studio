package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;



import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * SetupParser for {@link FormatSpanLink} that uses angler bracket. It therefore is a 
 * SetupParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
class FormatParseLinkDirect extends FormatParseLink {
    
    FormatParseLinkDirect(boolean[] spanFormats){
        super(LINK_BEGIN, spanFormats);
    }
    
    @Override
    public Optional<SpanBranch> parseFinish(ArrayList<Span> spanChildren, 
        SetupPointer childPointer
    ){
        Checker.checkNotNull(spanChildren, "spanChildren");
        Checker.checkNotNull(childPointer, "childPointer");
        new ContentParser(SetupLeafStyle.PATH, LINK_TEXT, LINK_END)
            .parse(spanChildren, childPointer);
        
        /// Complete the last steps 
        parseRest(spanChildren, childPointer);
        return Optional.of(new FormatSpanLinkDirect(spanChildren, getFormats()));
    }
}
