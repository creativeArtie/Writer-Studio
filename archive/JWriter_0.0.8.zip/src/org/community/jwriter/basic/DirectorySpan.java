package org.community.jwriter.basic;

import java.util.ArrayList; 
import java.util.List;      /// For initialization (children)
import java.util.Optional;  /// For the helper method

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * Created from {@link DirectorySpan}. Used to store {@link CatalogueIdentity}
 */
public class DirectorySpan extends SpanBranch implements CatalogueSpan{
    /// helps with categorizing and describes purpose
    private final Optional<DirectoryType> purpose;
    
    DirectorySpan(List<Span> spanChildren, Optional<DirectoryType> idPurpose){
        super(spanChildren);
        Checker.checkNotNull(idPurpose, "idPurpose");
        purpose = idPurpose;
    }
    
    @Override
    public CatalogueIdentity getId(){
        ArrayList<String> builder = new ArrayList<>();
        purpose.ifPresent(found -> builder.add(found.getCategory()));
        Optional<String> idTmp = Optional.empty();
        for(Span child: this){
            if (child instanceof SpanLeaf){
                builder.add(idTmp.orElse(""));
                idTmp = Optional.empty();
            } else {
                idTmp = Optional.of(((ContentSpan)child).getParsed());
            }
        }
        return new CatalogueIdentity(builder, idTmp.orElse(""));
    }
    
    public String getIdRaw(){
        StringBuilder builder = new StringBuilder();
        for (Span span: this){
            builder.append(span.getRaw());
        }
        return builder.toString();
    }
    
    public DirectoryType getPurpose(){
        //TODO
        return purpose.isPresent()? purpose.get(): null;
    }
    
    @Override
    public DetailStyle[] getInfo(){
        CatalogueData data = getDocument().getMap().get(getId());
        if (data == null) {
            return new DetailStyle[]{CatalogueStatus.NO_ID};
        }
        return new DetailStyle[]{data.getState()};
    }

    @Override
    protected void addInfo(List<DetailStyle> styleList){
        Checker.checkNotNull(styleList, "styleList");
        CatalogueData data = getDocument().getMap().get(getId());
        if (data == null) {
            styleList.add(CatalogueStatus.NO_ID);
        } else {
            styleList.add(data.getState());
        }
    }
        
    @Override
    public String toString(){
        return "ID" + getId().toString();
    }
}
