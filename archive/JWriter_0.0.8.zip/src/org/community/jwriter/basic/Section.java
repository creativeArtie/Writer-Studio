package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import java.util.List;

public abstract class Section {
    Section(){}
    
    public abstract List<? extends Section> getChildren();
}
