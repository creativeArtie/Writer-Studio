package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

enum LinedParseCite implements SetupParser {
    INSTANCE;
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        ArrayList<Span> children = new ArrayList<>();
        
        if (childPointer.startsWith(children, LINED_CITE)){
            LinedDataField type = LinedDataField.getField(childPointer, children);
            childPointer.trimStartsWith(children, LINED_DATA);
            if (! type.parse(children, childPointer)){
                new ContentParser(SetupLeafStyle.DATA).parse(children, childPointer);
            }
            childPointer.startsWith(children, LINED_END);
            return Optional.of(new LinedSpanCite(children));
        }
        return Optional.empty();
    }
}
