package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public abstract class LinedSpanPoint extends LinedSpan implements CatalogueHolder{

    LinedSpanPoint(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public abstract DirectoryType getDirectoryType();
    
    @Override
    public DetailStyle[] getInfo(){
        if (hasId()){
            return super.getInfo();
        }
        return combineInfo(super.getInfo(), new DetailStyle[]{AuxiliaryStyle.NO_ID});
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        super.addInfo(list);
        if (! hasId()) list.add(AuxiliaryStyle.NO_ID);
    }
}
