package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@linkplain FormatSpanCurly} for id reference. This has a span where it is
 * reference to
 */
public final class FormatSpanDirectory extends FormatSpan 
        implements CatalogueHolder {
    private final DirectoryType type;
    
    FormatSpanDirectory(List<Span> spanChildren, boolean[] spanFormats, 
        DirectoryType curlyType
    ){
        super(spanChildren, spanFormats);
        type = curlyType;
    }
    
    public DirectoryType getIdType(){
        return type;
    }
    
    @Override
    public DetailStyle[] getInfo(){
        DetailStyle[] base;
        if (hasId()){
            base = new DetailStyle[]{type};
        } else {
            base = new DetailStyle[]{type, AuxiliaryStyle.NO_ID};
        }
        return combineInfo(super.getInfo(), base);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(type);
        if (! hasId()) list.add(AuxiliaryStyle.NO_ID);
        super.addInfo(list);
    }
    
    @Override
    public boolean isId(){
        return false;
    }
    
    @Override
    public String getOutput(){
        Optional<CatalogueSpan> id = getIdSpan();
        if (id.isPresent()){
            return ((DirectorySpan)id.get()).getIdRaw();
        }
        return "";
    }
}
