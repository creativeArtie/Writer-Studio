package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Optional;


import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * SetupParser for {@link FormatSpanLink} that uses anglar bracket. It therefore is a 
 * SetupParser for {@link FormatSpanLinkDirect} and {@link FormatRefSpan}.
 */
abstract class FormatParseLink implements SetupParser {
    
    public static FormatParseLink[] getParsers(boolean[] spanFormats){
        boolean[] formats = Arrays.copyOf(spanFormats, spanFormats.length);
        return new FormatParseLink[]{
            new FormatParseLinkRef(formats),
            new FormatParseLinkDirect(formats)
        };
    }
    
    private final String start;
    private final boolean[] formats;
    
    FormatParseLink(String spanStart, boolean[] spanFormats){
        start = Checker.checkNotNull(spanStart, "spanStart");
        formats = Checker.checkArraySize(spanFormats, "spanFormats", FORMAT_TYPES);
    }
    
    protected boolean[] getFormats(){
        return formats;
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        if(childPointer.startsWith(children, start)){
            return parseFinish(children, childPointer);
        }
        return Optional.empty();
    }
    
    protected abstract Optional<SpanBranch> parseFinish(
        ArrayList<Span> spanChildren, SetupPointer childPointer);
    
    protected void parseRest(ArrayList<Span> spanChildren, 
            SetupPointer childPointer){
        
        /// Create display text if any
        if (childPointer.startsWith(spanChildren, LINK_TEXT)){
            /// Add the text itself
            new ContentParser(LINK_END).parse(spanChildren, childPointer);
        }
        
        /// Add the ">"
        childPointer.startsWith(spanChildren, LINK_END);
    }
}
