package org.community.jwriter.basic;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ImmutableList;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

/**
 * A {@link span} for formatted text.
 */
public abstract class FormatSpan extends SpanBranch {
    private boolean[] formats; 
    FormatSpan(List<Span> spanChildren, boolean[] spanFormats){
        super(spanChildren);
        Checker.checkArraySize(spanFormats, "spanFormats", FORMAT_TYPES);
        formats = Arrays.copyOf(spanFormats, spanFormats.length);
    }
    
    FormatSpan(){
        this(new ArrayList<>(), new boolean[FORMAT_TYPES]);
    }
    
    boolean[] getFormats(){
        return formats;
    }
    
    public List<FormatType> listFormats(){
        ImmutableList.Builder<FormatType> list = ImmutableList.builder();
        int i = 0;
        for (boolean format: formats){
            if (format){
                list.add(FormatType.values()[i]);
            }
            i++;
        }
        return list.build();
    }
    
    public boolean isBold(){
        return formats[0];
    }
    
    public boolean isItalics(){
        return formats[1];
    }
    
    public boolean isUnderline(){
        return formats[2];
    }
    
    public boolean isCoded(){
        return formats[3];
    }
    
    @Override
    public String toString(){
        StringBuilder ans = new StringBuilder();
        if (formats[0]) ans.append("b");
        if (formats[1]) ans.append("i");
        if (formats[2]) ans.append("u");
        if (formats[3]) ans.append("c");
        return ans.toString() + super.toString();
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return listFormats().toArray(new DetailStyle[0]);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        Checker.checkNotNull(list, "list");
        int i = 0;
        for(boolean format: formats){
            if (format){
                list.add(FormatType.values()[i]);
            }
            i++;
        }
    }
    
    public abstract String getOutput();
}
