package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanAgenda extends LinedSpan {

    LinedSpanAgenda(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public Optional<ContentSpan> getReasonSpan(){
        return spanFromLast(ContentSpan.class);
    }
}
