package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@linkplain FormatSpanCurly} for to do text. It will warn user when 
 * exporting while there are these {@link Span spans} still exists.
 */
public final class FormatSpanAgenda extends SpanBranch {
        
    FormatSpanAgenda(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public Optional<ContentSpan> getAgendaSpan(){
        return spanFromLast(ContentSpan.class);
    }
    
    public String getAgenda(){
        Optional<ContentSpan> text = getAgendaSpan();
        if (text.isPresent()){
            return text.get().getParsed();
        }
        return "";
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return new DetailStyle[]{AuxiliaryStyle.AGENDA};
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.AGENDA);
    }
}
