package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanPointLink extends LinedSpanPoint {

    LinedSpanPointLink(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    public DirectoryType getDirectoryType(){
        return DirectoryType.LINK;
    }
    
    public String getPath(){
        Optional<ContentSpan> span = spanFromLast(ContentSpan.class);
        return span.isPresent()? span.get().getParsed() : "";
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
