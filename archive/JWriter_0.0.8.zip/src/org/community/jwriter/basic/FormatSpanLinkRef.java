package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@link FormatSpanLink} with path located somewhere in the document.
 */
public final class FormatSpanLinkRef extends FormatSpanLink 
        implements CatalogueHolder{
    
    FormatSpanLinkRef(List<Span> spanChildren, boolean[] spanFormats){
        super(spanChildren, spanFormats);
    }
    
    @Override
    public String getPath(){
        Optional<Span> span = getTarget();
        if (span.isPresent()){
            return ((LinedSpanPointLink)span.get()).getPath();
        }
        return "";
    }
    
    @Override
    public String getText(){
        Optional<ContentSpan> text = spanFromFirst(ContentSpan.class);
        if (text.isPresent()){
            return text.get().getParsed();
        }
        return getPath();
    }
    
    @Override
    public DetailStyle[] getInfo(){
        DetailStyle[] base;
        if (hasId()){
            base = new DetailStyle[]{AuxiliaryStyle.REF_LINK};
        } else{
            base = new DetailStyle[]{AuxiliaryStyle.REF_LINK, 
                AuxiliaryStyle.NO_ID
            };
        }
        return combineInfo(super.getInfo(), base);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.REF_LINK);
        if (! hasId()) list.add(AuxiliaryStyle.NO_ID);
        super.addInfo(list);
    }
    
    @Override
    public boolean isId(){
        return false;
    }
}
