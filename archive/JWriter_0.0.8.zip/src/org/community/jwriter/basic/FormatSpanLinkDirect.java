package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;
import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

/**
 * A {@link FormatSpanLink} with path indicated right in the text.
 */
public class FormatSpanLinkDirect extends FormatSpanLink {
    
    FormatSpanLinkDirect(List<Span> spanChildren, boolean[] spanFormats){
        super(spanChildren, spanFormats);
    }
    
    @Override
    public String getPath(){
        Optional<ContentSpan> path = spanFromFirst(ContentSpan.class);
        return path.isPresent()? path.get().getParsed(): "";
    }
    
    @Override
    public String getText(){
        Optional<ContentSpan> text = spanFromLast(ContentSpan.class);
        return text.isPresent()? text.get().getParsed(): "";
    }
    
    @Override
    public DetailStyle[] getInfo(){
        return combineInfo(super.getInfo(), 
                new DetailStyle[]{AuxiliaryStyle.DIRECT_LINK});
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        list.add(AuxiliaryStyle.DIRECT_LINK);
        super.addInfo(list);
    }

}
