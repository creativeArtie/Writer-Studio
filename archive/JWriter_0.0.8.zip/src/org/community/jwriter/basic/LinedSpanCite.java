package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanCite extends LinedSpan {
    
    public LinedSpanCite(List<Span> spanChildren){
        super(spanChildren);
    }
    
    public LinedDataField getField(){
        Optional<SpanLeaf> span = firstLeaf(SetupLeafStyle.FIELD);
        if (span.isPresent()) {
            return LinedDataField.getField(span.get().getRaw());
        }
        return LinedDataField.ERROR;
    }
    
    public Optional<LinedDataSpan> getData(){
        return spanFromLast(LinedDataSpan.class);
    }
    
    @Override
    public DetailStyle[] getInfo(){
        DetailStyle[] base;
        if (getData().isPresent ()){
            base = new DetailStyle[]{getField()};
        } else {
            base = new DetailStyle[]{getField(), AuxiliaryStyle.DATA_ERROR};
        }
        return combineInfo(super.getInfo(), base);
    }
    
    @Override
    protected void addInfo(List<DetailStyle> list){
        super.addInfo(list);
        list.add(getField());
        if (! getData().isPresent()) list.add(AuxiliaryStyle.DATA_ERROR);
    }
}
