package org.community.jwriter.basic;

import org.community.jwriter.markup.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;

public class SectionHeading extends Section {
    private Optional<SectionHeading> parent;
    private Optional<LinedSpanSection> heading;
    private ArrayList<SectionOutline> outlines;
    private ArrayList<SectionHeading> children;
    private int level;
    
    SectionHeading(){
        this (0, null, null);
    }
    
    private SectionHeading(int sectionLevel, SectionHeading parentLine, 
        LinedSpanSection headingLine)
    {
        level = sectionLevel;
        heading = Optional.ofNullable(headingLine);
        parent = Optional.ofNullable(parentLine);
        outlines = new ArrayList<>();
        children = new ArrayList<>();
    }
    
    SectionHeading appendHeading(LinedSpanSection line){
        int add = line.getLevel();
        if (add <= level){
            return parent.get().appendHeading(line);
        }
        if (add == level + 1){
            SectionHeading ans = new SectionHeading(level + 1, this, line);
            children.add(ans);
            return ans;
        }
        assert add > level + 1;
        SectionHeading ans = new SectionHeading(level + 1, this, null);
        children.add(ans);
        return ans.appendHeading(line);
    }
    
    SectionOutline appendOutline(LinedSpanSection line){
        int depth = line.getLevel();
        if (depth == 1){
            SectionOutline ans = new SectionOutline(this, null, depth, line);
            outlines.add(ans);
            return ans;
        }
        SectionOutline parent = new SectionOutline(this, null, 1, null);
        outlines.add(parent);
        for(int i = 2; i < depth; i++){
            parent = new SectionOutline(this, parent, i, null);
        }
        parent.append(line);
        return parent;
        
    }
    
    public int getLevel(){
        return level;
    }
    
    public Optional<LinedSpanSection> getHeading(){
        return heading;
    }
    
    @Override
    public List<SectionHeading> getChildren(){
        return ImmutableList.copyOf(children);
    }
    
    public List<SectionOutline> getOutlines(){
        return ImmutableList.copyOf(outlines);
    }
    
    public Optional<SectionHeading> findChild(Optional<LinedSpanSection> search)
    {
        if (! search.isPresent()){
            if (parent.isPresent()){
                return parent.get().findChild(search);
            } else {
                return Optional.of(this);
            }
        }
        if (heading.isPresent()){
            if (heading.get() == search.get()){
                return Optional.of(this);
            }
        }
        for (SectionHeading child: children){
            Optional<SectionHeading> gotten = child.findChild(search);
            if (gotten.isPresent()){
                return gotten;
            }
        }
        return Optional.empty();
    }
    
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append(level + "\t\t");
        builder.append(heading);
        String prefix = "\n" + level + "\t\t";
        for (SectionOutline outline: outlines){
            builder.append(prefix);
            builder.append(outline.toString().replace("\n", prefix));
        }
        prefix = "\n" + level + ".";
        for (SectionHeading child: children){
            builder.append(prefix);
            builder.append(child.toString().replace("\n", prefix));
        }
        return builder.toString();
    }
}
