package org.community.jwriter.basic;

import java.util.ArrayList;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;
import org.community.jwriter.main.Checker;

enum LinedParseLevel implements SetupParser {
    HEADING, OUTLINE, 
    /// Split into 2 to separate between praseSec(...) and parseBasic(...)
    QUOTE, NUMBERED, BULLET;
    
    static SetupParser[] getSubList(){
        return new SetupParser[]{QUOTE, NUMBERED, BULLET};
    }
    
    @Override
    public Optional<SpanBranch> parse(SetupPointer childPointer){
        Checker.checkNotNull(childPointer, "childPointer");
        ArrayList<Span> children = new ArrayList<>();
        for(int i = LEVEL_MAX; i >= 1; i--){
            if (childPointer.startsWith(children, getLevelToken(this, i))){
                                
                return ordinal() <= OUTLINE.ordinal()?
                    parseSec(children, childPointer): parseBasic(children, childPointer);
            }
        }
        return Optional.empty();
    }
    
    private Optional<SpanBranch> parseSec(
        ArrayList<Span> spanChildren, SetupPointer childPointer
    ){
        Checker.checkNotNull(childPointer, "childPointer");
        Checker.checkNotNull(spanChildren, "spanChildren");
        DirectoryParser id = new DirectoryParser(DirectoryType.LINK, 
            DIRECTORY_END, EDITION_BEGIN);
        if (childPointer.trimStartsWith(spanChildren, DIRECTORY_BEGIN)){
            id.parse(spanChildren, childPointer);
            childPointer.startsWith(spanChildren, DIRECTORY_END);
        }
        
        new FormatParser(EDITION_BEGIN).parse(spanChildren, childPointer);
        
        EditionParser.parseAll(spanChildren, childPointer);
        
        childPointer.startsWith(spanChildren, LINED_END);
        
        LinedSpanSection ans = new LinedSpanSection(spanChildren);
        return Optional.of(ans);
    }
    
    private Optional<SpanBranch> parseBasic(
        ArrayList<Span> spanChildren, SetupPointer childPointer
    ){
        Checker.checkNotNull(childPointer, "childPointer");
        Checker.checkNotNull(spanChildren, "spanChildren");
        new FormatParser().parse(spanChildren, childPointer);
        
        childPointer.startsWith(spanChildren, LINED_END);
        
        return Optional.of(new LinedSpanLevel(spanChildren));
        
    }
}
