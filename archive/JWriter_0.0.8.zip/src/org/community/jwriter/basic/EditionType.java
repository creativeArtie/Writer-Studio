package org.community.jwriter.basic;

import static org.community.jwriter.basic.AuxiliaryData.*;

import org.community.jwriter.markup.DetailStyle;
public enum EditionType implements DetailStyle{
    /// Enum order mandated by WindowText
    STUB, DRAFT, FINAL, OTHER, NONE;
    
    @Override
    public String getStyleClass(){
        return DetailStyle.styleFromEnum(STYLE_EDITION, name());
    }
}
