package org.community.jwriter.basic;

import java.util.List;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public abstract class MainSpan extends SpanBranch{
    MainSpan(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    protected DetailUpdater getUpdater(List<Span> edit, String newText){
        if (size() == 1){
            return DetailUpdater.mergeBoth(new MainParser());
        }
        
        if (edit.get(0) == get(0)){
            return DetailUpdater.mergeLast(new MainParser());
        } 
        
        if (edit.get(0) == get(size() - 1)){
            return DetailUpdater.mergeNext(new MainParser());
        }
        return DetailUpdater.replace(new MainParser());
    }
}
