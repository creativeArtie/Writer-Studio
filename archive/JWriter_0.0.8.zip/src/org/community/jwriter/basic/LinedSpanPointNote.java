package org.community.jwriter.basic;

import java.util.List;
import java.util.Optional;

import org.community.jwriter.markup.*;
import static org.community.jwriter.basic.AuxiliaryData.*;

public class LinedSpanPointNote extends LinedSpanPoint {

    LinedSpanPointNote(List<Span> spanChildren){
        super(spanChildren);
    }
    
    @Override
    public DirectoryType getDirectoryType(){
        return getType() == LinedType.FOOTNOTE? DirectoryType.FOOTNOTE: 
            DirectoryType.ENDNOTE;
    }
    
    public Optional<FormatSpanMain> getFormatted(){
        return spanFromLast(FormatSpanMain.class);
    }
    
    @Override
    public boolean isId(){
        return true;
    }
}
