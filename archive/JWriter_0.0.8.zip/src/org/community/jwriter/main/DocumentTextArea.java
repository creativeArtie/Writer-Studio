package org.community.jwriter.main;

import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.control.Label;
import java.io.IOException;

import org.fxmisc.richtext.InlineCssTextArea;
import org.fxmisc.richtext.model.PlainTextChange;

import org.community.jwriter.markup.*;
import org.community.jwriter.property.PropertyManager;
import org.community.jwriter.basic.ManuscriptDocument;


public class DocumentTextArea extends InlineCssTextArea{
    private DocumentPane parent;
    
    DocumentTextArea(DocumentPane parentPane) throws IOException{
        super(parentPane.getDocument().getRaw());
        parent = parentPane;
        setWrapText(true);
        plainTextChanges().subscribe(data -> textChanged(data));
        update();
        requestFollowCaret();
    }
    
    private void textChanged(PlainTextChange change){
        int pos = change.getPosition();
        switch (change.getType()){
        case DELETION:
            deleteChar(pos, change.getRemovalEnd());
        break;
        case INSERTION:
            insertChar(pos, change.getInserted());
        break;
        case REPLACEMENT:
            deleteChar(pos, change.getRemovalEnd());
            insertChar(pos, change.getInserted());
        break;
        }
        assert parent.getDocument().getRaw().equals(getText());
        update();
    }
    
    private void insertChar(int pos, String text){
        for (int i = 0; i < text.length(); i++){
            parent.getDocument().insertChar(pos, text.charAt(i));
        }
    }
    
    private void deleteChar(int pos, int end){
        for(int i = pos; i < end; i++){
            parent.getDocument().deleteChar(pos);
        }
        
    }
    
    void update(){
        for (SpanLeaf span: parent.getDocument().getLeaves()){
            setStyle(span.getStart(), span.getEnd(), span.toCss(Utilities
                .getStyles()));
        }
        parent.update();
    }
}
