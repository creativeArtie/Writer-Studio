package org.community.jwriter.main;

import java.io.File;
import java.io.IOException;
import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

import org.community.jwriter.basic.ManuscriptDocument;
import org.community.jwriter.property.PropertyManager;

public class DocumentPane extends BorderPane{
    
    private DocumentTextArea area;
    private DocumentTreeView table;
    private DocumentListView lists;;
    private ManuscriptDocument doc;
    private boolean isReady;
    
    public DocumentPane(File file) throws IOException{
        this(new ManuscriptDocument(file));
    }
    
    public DocumentPane() throws IOException{
        this(new ManuscriptDocument(""));
    }
    
    public DocumentPane(ManuscriptDocument document) throws IOException{
        isReady = false;
        doc = document;
        BorderPane main = new BorderPane();
        
        area = new DocumentTextArea(this);
        table = new DocumentTreeView(this);
        lists = new DocumentListView(this);
        
        setCenter(area);
        setTop(lists);
        setLeft(table);
        area.caretPositionProperty().addListener((observable, oldValue, 
            newValue) -> {
            if (area.isFocused()){
                table.setPosition(newValue);
            }
        });
        isReady = true;
    }
    
    public void setDocument(ManuscriptDocument document){
        doc = document;
    }
    
    void update(){
        if (isReady){
            table.refreshHeadings();
        }
    }
    
    ManuscriptDocument getDocument(){
        return doc;
    }
    
    void setPosition(int start){
        area.moveTo(start);
        area.requestFocus();
        area.requestFollowCaret();
    }
    
    public int getPosition(){
        return area.getCaretPosition();
    }
}
