package org.community.jwriter.main;

import java.util.Optional;
import javafx.scene.control.ListView;
import javafx.scene.control.TreeView;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Pane;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.layout.ColumnConstraints;
import javafx.geometry.Insets;
import javafx.scene.control.ListCell;

import org.community.jwriter.basic.*;
import org.community.jwriter.markup.CatalogueHolder;
import org.community.jwriter.markup.Span;
import org.community.jwriter.property.TextResourceEnumHelper;

public class DocumentListView extends GridPane{
    private ListView<DirectoryType> types;
    private TreeView<String> categories;
    private ListView<CatalogueHolder> ids;
    private Pane details;
    private TitledPane detailsPane;
    private DocumentPane parent;
    
    public DocumentListView(DocumentPane parentPane){
        for(int i = 0; i < 4; i++){
             ColumnConstraints column = new ColumnConstraints();
             column.setPercentWidth(25);
             getColumnConstraints().add(column);
        }
        setHgap(-20.0);
        parent = parentPane;
        
        types = setupTypes();
        categories = setupCategories();
        ids = setupIds();
        
        details = new Pane();
        detailsPane = setupDetails(new Pane());
    }
    
    private static class TypeCell extends ListCell<DirectoryType>{
        @Override
        protected void updateItem(DirectoryType item, boolean empty) {
            super.updateItem(item, empty);
            if (item != null){
                setText(ListText.valueOf(item).get());
            }
        }
    }
    
    private ListView<DirectoryType> setupTypes(){
        ListView<DirectoryType> ans = new ListView<>(FXCollections
            .observableArrayList(DirectoryType.values()));
        ans.setCellFactory(list -> new TypeCell());
        add(setupPane(WindowText.LIST_TYPES, ans), 0, 0);
        ans.getSelectionModel().select(0);
        return ans;
    }
    
    private TreeView<String> setupCategories(){
        TreeView<String> ans = new TreeView<>();
        add(setupPane(WindowText.LIST_CATEGORY, ans), 1, 0);
        return ans;
    }
    
    private ListView<CatalogueHolder> setupIds(){
        ListView<CatalogueHolder> ans = new ListView<>();
        add(setupPane(WindowText.LIST_IDS, ans), 2, 0);
        return ans;
    }
    
    private TitledPane setupDetails(Pane pane){
        TitledPane ans = setupPane(ListText.NOTE, pane);
        add(ans, 3, 0);
        return ans;
    }
    
    private TitledPane setupPane(TextResourceEnumHelper label, Node node){
        TitledPane title = new TitledPane(label.get(), node);
        title.setPrefHeight(150.0);
        title.setCollapsible(false);
        setMargin(title, new Insets(5.0));
        return title;
    }
}
