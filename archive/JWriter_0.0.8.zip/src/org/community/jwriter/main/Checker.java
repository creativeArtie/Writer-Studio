package org.community.jwriter.main;

public class Checker {

    /** 
     * Create {@linkplain NullPointerException} for a field.
     * @param <T>
     *      the type object to check
     * @param testObj
     *      the object to check for null.
     * @param forField
     *      name of the field
     * @return the error String for null exceptions.
     */
    public static <T> T checkNotNull(T testObj, String forField){
        String error = addBegin(forField) + "can not be null.";
        if (testObj == null){
            throw new IllegalArgumentException(error);
        }
        return testObj;
    }
    
    public static IllegalArgumentException typeNotUse(Object type, 
        String forField)
    {
        return new IllegalArgumentException("Argument \"" + forField + 
            "\" can not be used: " + type);
    }
    
    public static int checkInt(int testInt, String forField, int lowerBound, 
        boolean includeLower, int upperBound, boolean includeUpper)
    {
        String error = addBegin(forField) + "is not between " + 
            lowerBound + " and " + upperBound + ": " + testInt;
        if (lowerBound > testInt || (lowerBound == testInt && ! includeLower) ||
            upperBound < testInt || (upperBound == testInt && ! includeUpper))
        {
            throw new IllegalArgumentException(error);
        }
        return testInt;
    }

    public static boolean[] checkArraySize(boolean[] testArray, String forField, 
        int size)
    {
        checkNotNull(testArray, forField);
        String error = addBegin(forField) + "does not have the right size: " +
                testArray.length;
        if (testArray.length != size){
            throw new IllegalArgumentException(error);
        }
        return testArray;
    }
    
    private static String addBegin(String forField){
        return "Argument \"" + forField + "\" ";
    }
    
    private Checker() {}
}
