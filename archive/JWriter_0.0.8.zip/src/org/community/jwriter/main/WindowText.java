package org.community.jwriter.main;

import org.community.jwriter.property.*;
import org.community.jwriter.basic.EditionType;

public enum WindowText implements TextResourceEnumHelper{
    STUB_STATUS("SectionStatus.Stub"), DRAFT_STATUS("SectionStatus.Draft"), 
    FINAL_STATUS("SectionStatus.Final"), OTHER_STATUS("SectionStatus.Other"), 
    NONE_STATUS("SectionStatus.None"),
    
    LIST_TYPES("ListView.Types"), LIST_CATEGORY("ListView.Category"),
    LIST_IDS("ListView.Ids"),
    
    TREE_HEADINGS("TreeView.Headings"), TREE_OUTLINES("TreeView.Outlines"), 
    TITLE("MainWindow.Title"), 
    VIEW_NO_FOUND("HeadingView.NoFound"), 
    VIEW_EMPTY("HeadingView.NoText");
    
    public static WindowText getStatus(EditionType type){
        return values()[type.ordinal()];
    }
    
    private static TextResourceManager manager = TextResourceManager
        .getResouce("data/windowtext/text");
    
    private TextResource resource;
    
    private final String text;
    
    private WindowText(String textName){
        text = textName;
    }

    @Override
    public TextResource delegate(){
        if (resource == null){
            resource = manager.getText(text);
        }
        return resource;
    }
}
