package org.community.jwriter.main;

import com.google.common.base.Preconditions;

import org.community.jwriter.property.PropertyManager;

public class Utilities{
    
    private static PropertyManager styles;
    
    public static PropertyManager getStyles(){
        if (styles == null){
            try {
                styles = new PropertyManager("data/base-styles", 
                    "data/user-styles");
            } catch (Exception ex){
                throw new RuntimeException(ex);
            }
        }
        return styles;
    }
    
    private Utilities(){}
}
