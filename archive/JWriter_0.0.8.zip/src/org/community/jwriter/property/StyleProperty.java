package org.community.jwriter.property;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.google.common.base.CharMatcher;
import com.google.common.base.Joiner;

public class StyleProperty extends MapProperty{
    private static final String field = ":";
    private static final String line = ";";
    
    StyleProperty(String propertyKey, PropertyManager propertyManager){
        super(propertyKey, propertyManager, field, line);
    }
    
    protected Map<String, String> fromStorage(String value){
        return super.fromStorage(CharMatcher.whitespace().removeFrom(value));
    }
    
    public String toCss(){
        return toCss(Arrays.asList(new StyleProperty[]{this}));
    }
    
    public static String toCss(List<StyleProperty> properties){
        TreeMap<String, String> rawMap = new TreeMap<>();
        for (StyleProperty property: properties){
            for(Map.Entry<String, String> entry: property.get().entrySet()){
                rawMap.put(entry.getKey(), entry.getValue());
            }
        }
        return Joiner.on(line).withKeyValueSeparator(field).join(rawMap) + line;
    }
}
