package org.community.jwriter.property;

import java.util.Map;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;

public class MapProperty extends Property<Map<String, String>>{
    private String line;
    private String field;
    
    MapProperty(String propertyKey, PropertyManager propertyManager,
        String fieldSplit, String lineSplit
    ){
        super(propertyKey, propertyManager);
        line = lineSplit;
        field = fieldSplit;
    }
    
    protected Map<String, String> fromStorage(String value){
        if (value.isEmpty()){
            return ImmutableMap.of(); 
        }
        if (value.endsWith(line)){
            value = value.substring(0, value.length() - line.length());
        }
        return Splitter.on(line).withKeyValueSeparator(field).split(value);
    }
    
    protected String toStorage(Map<String, String> value){
        return Joiner.on(line).withKeyValueSeparator(field).join(value);
    }
}
